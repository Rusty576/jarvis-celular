﻿# ============================================================
#  Actualizar TU bot del celular solo: lo llama «python configurar.py celular» (o decirle a JARVIS «actualizá el bot
#  del celular»)
# ------------------------------------------------------------
#  Sube el Codigo.gs de esta PC a tu proyecto de Apps Script y publica la versión nueva en la MISMA dirección (la que
#  usan Telegram y la app). Vos solo entrás con tu cuenta y, si la versión nueva pide un permiso nuevo, lo aceptás.
#  Del proyecto cambia solo el archivo del bot: la zona horaria y cualquier otro archivo quedan como estaban.
#  El permiso que le das a esta PC se borra al terminar.
# ============================================================
param(
    [Parameter(Mandatory = $true)][string]$Script,          # el proyecto (el bot lo dice en «estado»)
    [Parameter(Mandatory = $true)][string]$Implementacion   # lo que va en /macros/s/<esto>/exec
)
$ErrorActionPreference = "Stop"

$AQUI = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $AQUI "clasp_comun.ps1")
$CODIGO = Join-Path $AQUI "Codigo.gs"
$OBRA = Join-Path $env:TEMP ("jarvis_actualizar_" + [guid]::NewGuid().ToString("N").Substring(0, 8))
$PROYECTO = Join-Path $OBRA "proyecto"
$AUTH = Join-Path $OBRA ".clasprc.json"   # (fuera de la carpeta del proyecto: el permiso nunca se sube)
$URL = "https://script.google.com/macros/s/$Implementacion/exec"

if ($Script -notmatch '^[\w-]{20,}$' -or $Implementacion -notmatch '^AKfyc[\w-]{20,}$') {
    Ojo "No reconozco tu proyecto o tu implementación."
    exit 1
}
$fuente = [IO.File]::ReadAllText($CODIGO)
if ($fuente -notmatch 'const VERSION = "([\d.]+)"') { throw "No encontré VERSION en $CODIGO" }
$version = $Matches[1]

$ok = $false
$antes = Get-Location
try {
    Limpiar-Restos "jarvis_actualizar_"
    $node = Carpeta-Node
    $env:Path = "$node;$env:Path"
    $script:CLASP = Instalar-Clasp $node
    New-Item -ItemType Directory -Force $PROYECTO | Out-Null
    Set-Location $PROYECTO
    Escribir (Join-Path $PROYECTO ".clasp.json") (@{ scriptId = $Script } | ConvertTo-Json)

    Paso "1. Entrá con tu cuenta de Google (la que tiene el bot)"
    Dice "Es el permiso para que esta PC suba el código: se borra solo al terminar."
    Entrar-Cuenta

    Paso "2. Bajando tu proyecto de Apps Script"
    $otraCuenta = 0
    $sinCasillas = 0
    while ($true) {
        $s = Clasp-Con-API pull   # (si la «API de Google Apps Script» está apagada, abre la página y espera)
        if ($script:codigoClasp -eq 0) { break }
        if ((Faltan-Permisos $s) -and $sinCasillas -lt 2) {
            $sinCasillas++
            Ojo "En la página de Google quedaron permisos sin marcar. Entrá de nuevo y tocá «Seleccionar todo»."
            Soltar-Permiso
            Remove-Item $AUTH -Force -ErrorAction SilentlyContinue
            Entrar-Cuenta
            continue
        }
        Sin-API $s
        if ($s -match "not found|NOT_FOUND|permission|PERMISSION_DENIED" -and $otraCuenta -lt 2) {
            $otraCuenta++
            Ojo "Esa cuenta no tiene tu bot. Se abre el navegador de nuevo: elegí la OTRA cuenta (la del proyecto del bot)."
            Soltar-Permiso
            Remove-Item $AUTH -Force -ErrorAction SilentlyContinue
            Entrar-Cuenta
            continue
        }
        throw "No pude bajar tu proyecto:`n$s"
    }

    # el archivo que tiene el bot (en el editor puede llamarse Código, Code, Codigo...): solo ese cambia
    $bot = @(Get-ChildItem $PROYECTO -File -Recurse -Include *.js, *.gs | Where-Object {
        $t = [IO.File]::ReadAllText($_.FullName)
        ($t -match 'const VERSION = "') -and ($t -match 'function doPost\(')
    })
    if ($bot.Count -ne 1) { throw "No encontré el código del bot en tu proyecto (archivos con el bot: $($bot.Count))." }
    Escribir $bot[0].FullName $fuente

    # sin «webapp» en el manifiesto, la dirección /exec dejaría de ser una aplicación web; y las APIs de Google que el bot
    # usa por su cuenta (Drive: los archivos grandes para la PC; Slides: presentaciones y pósters) van declaradas: así
    # Google las prende en el proyecto (lo demás del manifiesto queda igual)
    $manifiesto = Join-Path $PROYECTO "appsscript.json"
    $m = Get-Content $manifiesto -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $m.webapp) {
        $m | Add-Member -NotePropertyName webapp -NotePropertyValue ([ordered]@{ executeAs = "USER_DEPLOYING"; access = "ANYONE_ANONYMOUS" })
    }
    Agregar-Servicios $m
    Escribir $manifiesto ($m | ConvertTo-Json -Depth 20)

    Paso "3. Subiendo el código nuevo (versión $version) y publicándolo en la misma dirección"
    # (la API pudo haberse prendido recién en el paso 2: Google tarda unos minutos y acá todavía puede decir que no)
    $s = Clasp-Con-API push --force
    if ($script:codigoClasp -ne 0) { Sin-API $s; throw "No pude subir el código:`n$s" }
    $s = Clasp-Con-API create-deployment --deploymentId $Implementacion --description "JARVIS $version"
    if ($script:codigoClasp -ne 0) { Sin-API $s; throw "No pude publicarlo:`n$s" }

    Paso "4. Esperando que tu bot conteste con la versión nueva"
    $desde = Get-Date
    $pidioPermiso = $false
    while ($true) {
        $e = Estado-Bot $URL
        if ($e -and $e -isnot [string] -and $e.version -eq $version) { break }
        $minutos = ((Get-Date) - $desde).TotalMinutes
        # (una página de Google en vez de la respuesta del bot: la versión nueva pide un permiso que falta aceptar)
        if (-not $pidioPermiso -and ($e -is [string] -or $minutos -gt 0.75)) {
            $pidioPermiso = $true
            Ojo "Tu bot pide un permiso nuevo de Google (esta vez: Google Drive, para pasarle archivos a la PC). Te abro tu proyecto:"
            Ojo " 1. Arriba, en la lista de funciones (al lado de «Ejecutar» y «Depurar»), elegí «autorizar»."
            Ojo " 2. Tocá «Ejecutar» > «Revisar permisos» > tu cuenta."
            Ojo " 3. Si dice que Google no verificó la app: «Configuración avanzada» > «Ir a ... (no seguro)» > «Permitir»."
            Dice "Yo sigo esperando solo."
            Navegador "https://script.google.com/d/$Script/edit"
        }
        if ($minutos -gt 15) { throw "Tu bot todavía no contesta con la versión nueva." }
        Start-Sleep -Seconds 4
    }

    Paso "5. Revisando que tu bot tenga todos los permisos de Google"
    Revisar-Permisos $URL "tu cuenta (la del bot)"
    $ok = $true
    Paso "Listo: tu bot ya tiene la versión $version (la dirección es la misma)"
} catch {
    Write-Host ""
    Ojo "No pude terminar: $($_.Exception.Message)"
} finally {
    Set-Location $antes
    Soltar-Permiso
    Remove-Item $OBRA -Recurse -Force -ErrorAction SilentlyContinue
}
if (-not $ok) { exit 1 }
