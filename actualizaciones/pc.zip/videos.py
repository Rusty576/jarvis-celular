"""Videos de JARVIS: los crea y los edita, todo en la compu.

CREAR ("haceme un video sobre la pila electroquímica", "haceme un tiktok sobre el ciclo del agua"):
  1) la IA escribe el guion (escenas: lo que dice la voz, un texto corto para la pantalla y la imagen),
     con datos verificados en Wikipedia (o con tu texto pegado / lo que hablaron, si lo pedís así);
  2) la voz de Windows lee cada escena (voz_archivo.py, en un programa aparte);
  3) el generador de imágenes pinta cada escena (el de la PC o Pollinations);
  4) se arma el MP4 con PyAV (trae ffmpeg adentro): movimiento suave sobre cada imagen, subtítulos y fundidos.
  Explicativo: horizontal 1280x720. Tipo TikTok: vertical 720x1280, más corto, con letras grandes.

EDITAR (el video que adjuntaste, el último que hiciste o grabaste, o uno por su nombre):
  cortar ("cortá del 1:10 al 2:30", "dejá los primeros 30 segundos"), unir ("uní los últimos 2 videos"),
  subtítulos ("ponele subtítulos": entiende lo que se dice con el reconocimiento de Google), sacar el audio,
  pasarlo a vertical para TikTok, cambiar la velocidad y ponerle música de fondo (un archivo tuyo).
Los videos quedan en documentos\\videos.
"""
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import wave
from fractions import Fraction

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA_VIDEOS = os.path.join(BASE, "documentos", "videos")
FPS = 24
TASA = 44100  # muestras de audio por segundo
EXT_VIDEO = {".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv", ".m4v"}
EXT_AUDIO = {".mp3", ".wav", ".m4a", ".ogg", ".flac", ".aac", ".wma"}
FUENTE_NEGRITA = r"C:\Windows\Fonts\segoeuib.ttf"
FUENTE = r"C:\Windows\Fonts\segoeui.ttf"
CELESTE = (41, 217, 255)


# =========================================================================
#  PIEZAS: letras, imágenes, audio y el que escribe el MP4
# =========================================================================

_fuentes = {}


def fuente(tam, negrita=True):
    clave = (tam, negrita)
    if clave not in _fuentes:
        try:
            _fuentes[clave] = ImageFont.truetype(FUENTE_NEGRITA if negrita else FUENTE, tam)
        except OSError:
            _fuentes[clave] = ImageFont.load_default()
    return _fuentes[clave]


def envolver(texto, letra, ancho, dibujo):
    """Parte el texto en renglones que entran en 'ancho' píxeles."""
    renglones, actual = [], ""
    for palabra in texto.split():
        prueba = f"{actual} {palabra}".strip()
        if actual and dibujo.textlength(prueba, font=letra) > ancho:
            renglones.append(actual)
            actual = palabra
        else:
            actual = prueba
    if actual:
        renglones.append(actual)
    return renglones


def cartel(texto, W, H, estilo):
    """Una capa transparente del tamaño del video con el texto dibujado.
    estilo: 'subtitulo' (abajo, en una caja oscura), 'titulo' (arriba, con una raya celeste) o 'tiktok' (grande, al
    medio, con borde negro, como en los videos cortos)."""
    capa = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if not texto.strip():
        return capa
    d = ImageDraw.Draw(capa)
    if estilo == "tiktok":
        letra = fuente(int(W * 0.075))
        renglones = envolver(texto.upper(), letra, W * 0.86, d)[:4]
        alto_r = int(letra.size * 1.2)
        y = int(H * 0.62) - alto_r * len(renglones) // 2
        for r in renglones:
            d.text((W // 2, y), r, font=letra, fill="white", anchor="mt", stroke_width=max(3, letra.size // 12),
                   stroke_fill="black")
            y += alto_r
        return capa
    if estilo == "titulo":
        letra = fuente(int(H * 0.06))
        renglones = envolver(texto, letra, W * 0.8, d)[:2]
        alto_r = int(letra.size * 1.25)
        x, y = int(W * 0.05), int(H * 0.06)
        ancho = max(d.textlength(r, font=letra) for r in renglones)
        d.rounded_rectangle((x - 18, y - 12, x + ancho + 22, y + alto_r * len(renglones) + 6), 14, fill=(6, 18, 28, 190))
        d.rectangle((x - 18, y - 12, x - 10, y + alto_r * len(renglones) + 6), fill=CELESTE + (255,))
        for r in renglones:
            d.text((x, y), r, font=letra, fill="white")
            y += alto_r
        return capa
    letra = fuente(int(H * 0.042) if W > H else int(W * 0.05), negrita=False)  # subtítulo
    renglones = envolver(texto, letra, W * 0.84, d)[:3]
    alto_r = int(letra.size * 1.3)
    alto = alto_r * len(renglones) + 24
    y0 = H - alto - int(H * 0.05)
    ancho = max(d.textlength(r, font=letra) for r in renglones)
    d.rounded_rectangle(((W - ancho) / 2 - 22, y0, (W + ancho) / 2 + 22, y0 + alto), 16, fill=(0, 0, 0, 165))
    y = y0 + 12
    for r in renglones:
        d.text((W // 2, y), r, font=letra, fill="white", anchor="mt")
        y += alto_r
    return capa


def cubrir(img, W, H):
    """La imagen recortada al tamaño W x H sin deformarla (como 'cover' en CSS)."""
    img = img.convert("RGB")
    escala = max(W / img.width, H / img.height)
    img = img.resize((max(W, round(img.width * escala)), max(H, round(img.height * escala))), Image.LANCZOS)
    x, y = (img.width - W) // 2, (img.height - H) // 2
    return img.crop((x, y, x + W, y + H))


def encajar(img, W, H, fondo_borroso=False):
    """La imagen entera dentro de W x H (con franjas negras, o con la misma imagen borrosa de fondo)."""
    img = img.convert("RGB")
    escala = min(W / img.width, H / img.height)
    chica = img.resize((max(2, round(img.width * escala)), max(2, round(img.height * escala))), Image.BILINEAR)
    if fondo_borroso:
        fondo = cubrir(img.resize((max(2, img.width // 4), max(2, img.height // 4))), W, H)
        fondo = Image.blend(fondo.filter(ImageFilter.GaussianBlur(14)), Image.new("RGB", (W, H)), 0.35)
    else:
        fondo = Image.new("RGB", (W, H))
    fondo.paste(chica, ((W - chica.width) // 2, (H - chica.height) // 2))
    return fondo


def ken_burns(base, W, H, p, sentido):
    """Un cuadro del movimiento suave sobre la imagen ('base' es un poco más grande que el video).
    p va de 0 a 1 a lo largo de la escena; sentido alterna entre acercarse y alejarse."""
    zoom = 1 + 0.08 * (p if sentido % 2 == 0 else 1 - p)
    cw, ch = base.width / zoom, base.height / zoom
    dx = (base.width - cw) * (0.5 + 0.2 * (p - 0.5) * (1 if sentido % 3 else -1))
    dy = (base.height - ch) * 0.5
    return base.resize((W, H), Image.BILINEAR, box=(dx, dy, dx + cw, dy + ch))


def leer_wav(ruta):
    """El audio de un WAV como números entre -1 y 1, un canal, a 44.100 por segundo."""
    with wave.open(ruta) as w:
        tasa, canales, ancho = w.getframerate(), w.getnchannels(), w.getsampwidth()
        datos = w.readframes(w.getnframes())
    muestras = np.frombuffer(datos, dtype=np.int16 if ancho == 2 else np.uint8).astype(np.float32)
    muestras = muestras / 32768.0 if ancho == 2 else (muestras - 128) / 128.0
    if canales > 1:
        muestras = muestras.reshape(-1, canales).mean(axis=1)
    return cambiar_tasa(muestras, tasa, TASA)


def cambiar_tasa(muestras, de, a):
    if de == a or not len(muestras):
        return muestras.astype(np.float32)
    largo = int(len(muestras) * a / de)
    return np.interp(np.linspace(0, len(muestras) - 1, largo), np.arange(len(muestras)), muestras).astype(np.float32)


def silencio(segundos):
    return np.zeros(int(segundos * TASA), dtype=np.float32)


class Escritor:
    """Escribe el MP4: video H.264 (el formato que abre cualquier celular o compu) y audio AAC."""

    def __init__(self, ruta, W, H, fps=FPS, con_audio=True):
        import av

        self.av = av
        self.c = av.open(ruta, "w")
        self.v = self.c.add_stream("libx264", rate=fps)
        self.v.width, self.v.height, self.v.pix_fmt = W, H, "yuv420p"
        self.v.options = {"preset": "veryfast", "crf": "21"}
        self.fps, self.n = fps, 0
        self.a = None
        if con_audio:
            self.a = self.c.add_stream("aac", rate=TASA)
            self.a.layout = "mono"

    def cuadro(self, img):
        f = self.av.VideoFrame.from_image(img.convert("RGB"))
        f.pts, f.time_base = self.n, Fraction(1, self.fps)
        for paquete in self.v.encode(f):
            self.c.mux(paquete)
        self.n += 1

    def audio(self, muestras):
        if self.a is None:
            return
        muestras = np.clip(muestras, -1, 1).astype(np.float32)
        for k in range(0, len(muestras), 1024):
            trozo = muestras[k:k + 1024].reshape(1, -1)
            f = self.av.AudioFrame.from_ndarray(trozo, format="fltp", layout="mono")
            f.sample_rate, f.pts, f.time_base = TASA, k, Fraction(1, TASA)
            for paquete in self.a.encode(f):
                self.c.mux(paquete)

    def cerrar(self):
        for paquete in self.v.encode():
            self.c.mux(paquete)
        if self.a is not None:
            for paquete in self.a.encode():
                self.c.mux(paquete)
        self.c.close()


class SubTarea:
    """Para que el generador de imágenes muestre su avance dentro del porcentaje que le toca en el video."""

    def __init__(self, tarea, desde, hasta, nombre):
        self.tarea, self.desde, self.hasta, self.nombre = tarea, desde, hasta, nombre
        self.cancelada = tarea.cancelada
        self._ultimo = None

    def avance(self, etapa, progreso=None):
        self._ultimo = (etapa, progreso)
        p = self.desde if progreso is None else self.desde + (self.hasta - self.desde) * min(100, progreso) / 100
        self.tarea.avance(f"{self.nombre}: {etapa.lower()}", int(p))


def ruta_libre(nombre, ext=".mp4"):
    os.makedirs(CARPETA_VIDEOS, exist_ok=True)
    base = re.sub(r'[<>:"/\\|?*\n]+', "", nombre).strip(" .")[:60] or "video"
    ruta = os.path.join(CARPETA_VIDEOS, base + ext)
    n = 2
    while os.path.exists(ruta):
        ruta = os.path.join(CARPETA_VIDEOS, f"{base} ({n}){ext}")
        n += 1
    return ruta


def mmss(segundos):
    m, s = divmod(int(round(segundos)), 60)
    return f"{m}:{s:02d}"


def duracion_texto(segundos):
    m, s = divmod(int(round(segundos)), 60)
    return f"{m} min {s} s" if m else f"{s} s"


# =========================================================================
#  CREAR UN VIDEO
# =========================================================================

PROMPT_GUION = """Sos guionista de videos educativos en español rioplatense, claros y entretenidos (para la escuela).
Escribí el guion de un video sobre el tema que te paso, con {escenas} escenas. Usá este formato EXACTO, un renglón por línea:
TITULO: <título corto>
ESCENA: <lo que dice la voz: {largo}> || <TÍTULO corto de la escena: 2 a 5 palabras> || <qué se ve en la imagen: el objeto o la persona del tema, concreto>
Ejemplo de una escena (sobre la pila de Volta):
ESCENA: En 1800, Alessandro Volta apiló discos de zinc y de cobre separados por cartón mojado en agua salada, y así creó la primera pila eléctrica de la historia. || La primera pila || Alessandro Volta en su laboratorio apilando discos de zinc y cobre
{extra}
Reglas: el segundo campo es un TÍTULO cortito, no una descripción. La imagen muestra siempre algo del tema (nada de
personas o cosas sueltas que no tengan que ver). Datos concretos y correctos (si te paso información, sacalos de ahí;
si no estás seguro de un número, no lo pongas). Nada de emojis. No escribas nada más que el título y las escenas."""
EXTRA_EXPLICATIVO = ("La primera escena presenta el tema y por qué importa; las del medio lo explican paso a paso; la "
                     "última resume la idea principal.")
EXTRA_TIKTOK = ("Es un video corto vertical tipo TikTok: la primera escena es un gancho (una pregunta o un dato "
                "sorprendente), ritmo rápido, frases cortas y la última invita a comentar o seguir aprendiendo.")
ESTILO_IMAGENES = "digital illustration, clean educational style, soft lighting, vibrant colors, no text, no letters"
ESTILO_TIKTOK = "vivid detailed educational illustration, cinematic lighting, bold colors, no text, no letters"


def leer_guion(texto):
    titulo, escenas = "", []
    for linea in texto.splitlines():
        linea = linea.strip().strip("*").strip()
        m = re.match(r"(?i)^t[ií]tulo\s*:\s*(.+)$", linea)
        if m and not titulo:
            titulo = m.group(1).strip(" *\"«»")
            continue
        m = re.match(r"(?i)^(?:escena\s*\d*\s*[:.\-]?|\d+[.)-])\s*(.+)$", linea)
        if m:
            partes = [p.strip(" *\"«»") for p in re.split(r"\s*\|\|?\s*", m.group(1))]
            if len(partes) >= 3 and len(partes[0]) > 8:
                pantalla = partes[1] if len(partes[1].split()) <= 7 else ""  # si escribió una descripción, no va
                escenas.append({"voz": partes[0], "pantalla": pantalla.rstrip("."), "imagen": partes[2]})
    return titulo, escenas


def escribir_guion(sistema, pedido, tarea, temperatura):
    texto = ""
    for parte in jarvis.chat_modelo([{"role": "system", "content": sistema}, {"role": "user", "content": pedido}],
                                    stream=True, temperature=temperatura, num_predict=1600):
        texto += parte["message"]["content"]
        tarea.avance("Escribiendo el guion", 8 + min(12, int(len(texto) / 1400 * 12)))
    return texto


def pintar(prompt, ancho, alto, ruta, sub):
    """Una imagen para una escena: el generador de la PC; si no anda, Pollinations. None si no se pudo."""
    j = jarvis
    if not j.herramientas.modo_juego.is_set() and j.GeneradorLocal.disponible():
        try:
            return j.generador_local.generar(prompt, ancho, alto, ruta, sub)
        except j.Cancelado:
            raise
        except Exception:
            pass
    for clave in ([j.clave_pollinations()] if j.clave_pollinations() else []) + [None]:
        try:
            hecha = j.generar_pollinations(prompt, ancho, alto, "escena video", sub, clave)
            os.replace(hecha, ruta)
            return ruta
        except j.Cancelado:
            raise
        except Exception:
            continue
    return None


def fondo_sin_imagen(W, H, texto, numero):
    """Si no se pudo pintar una escena: un fondo de color con el texto (el video igual se termina)."""
    colores = [((8, 24, 42), (29, 106, 128)), ((30, 20, 60), (120, 60, 160)), ((10, 40, 30), (40, 140, 100))]
    a, b = colores[numero % len(colores)]
    grad = np.linspace(0, 1, H).reshape(-1, 1, 1)
    arr = (np.array(a) * (1 - grad) + np.array(b) * grad).astype(np.uint8)
    img = Image.fromarray(np.repeat(arr, W, axis=1))
    d = ImageDraw.Draw(img)
    letra = fuente(int(min(W, H) * 0.08))
    renglones = envolver(texto, letra, W * 0.8, d)[:3]
    y = H // 2 - len(renglones) * letra.size * 0.6
    for r in renglones:
        d.text((W // 2, y), r, font=letra, fill="white", anchor="mt")
        y += letra.size * 1.2
    return img


def grabar_voces(frases, carpeta, tarea):
    """Graba todas las frases con la voz de Windows (en otro programa). Devuelve las rutas de los WAV."""
    pedido = {"velocidad": max(-2, min(4, getattr(jarvis, "VELOCIDAD_VOZ", 0))),
              "frases": [{"texto": f, "ruta": os.path.join(carpeta, f"voz{i}.wav")} for i, f in enumerate(frases)]}
    python = sys.executable.replace("pythonw.exe", "python.exe")
    r = subprocess.run([python, os.path.join(BASE, "voz_archivo.py")], input=json.dumps(pedido), capture_output=True,
                       text=True, encoding="utf-8", timeout=300, creationflags=0x08000000)
    tarea.avance("Grabando la voz", 28)
    rutas = []
    for f in pedido["frases"]:
        rutas.append(f["ruta"] if os.path.exists(f["ruta"]) and os.path.getsize(f["ruta"]) > 1000 else None)
    if not any(rutas):
        raise RuntimeError("no pude grabar la voz (" + (r.stderr.strip().splitlines() or ["sin detalles"])[-1] + ")")
    return rutas


def componer(escenas, titulo, ruta, vertical, tarea, desde=85, hasta=99):
    """Arma el MP4 con las escenas ya listas (imagen + audio de la voz)."""
    W, H = (720, 1280) if vertical else (1280, 720)
    escritor = Escritor(ruta, W, H)
    audio = [silencio(0.3)]
    anterior = None
    total_cuadros = sum(int((len(e["audio"]) / TASA + 0.45) * FPS) for e in escenas) or 1
    hechos = 0
    for k, e in enumerate(escenas):
        dur = len(e["audio"]) / TASA + 0.45
        audio += [e["audio"], silencio(0.45)]
        n = max(int(dur * FPS), FPS)
        base = cubrir(e["img"], int(W * 1.12), int(H * 1.12))
        # los subtítulos: la frase en pedazos, cada uno el tiempo que le toca según su largo
        palabras = e["voz"].split()
        cuantos = max(1, -(-len(palabras) // (4 if vertical else 11)))  # pedazos parejos (sin una palabra sola al final)
        por_pedazo = max(1, -(-len(palabras) // cuantos))
        pedazos = [" ".join(palabras[i:i + por_pedazo]) for i in range(0, len(palabras), por_pedazo)] or [""]
        largos = np.cumsum([len(p) + 1 for p in pedazos]) / sum(len(p) + 1 for p in pedazos)
        capas = [cartel(p, W, H, "tiktok" if vertical else "subtitulo") for p in pedazos]
        texto_arriba = titulo if (vertical and k == 0) else e.get("pantalla", "")
        arriba = cartel(texto_arriba, W, H, "titulo") if texto_arriba else None
        for i in range(n):
            p = i / max(1, n - 1)
            cuadro = ken_burns(base, W, H, p, k).convert("RGBA")
            if arriba is not None:
                cuadro.alpha_composite(arriba)
            momento = min(1.0, (i / FPS) / max(0.1, dur - 0.45))
            cuadro.alpha_composite(capas[min(len(capas) - 1, int(np.searchsorted(largos, momento)))])
            cuadro = cuadro.convert("RGB")
            if anterior is not None and i < 10:  # fundido con la escena anterior
                cuadro = Image.blend(anterior, cuadro, (i + 1) / 11)
            if k == len(escenas) - 1 and i >= n - 14:  # al final, a negro
                cuadro = Image.blend(cuadro, Image.new("RGB", (W, H)), (i - (n - 14) + 1) / 14)
            escritor.cuadro(cuadro)
            hechos += 1
            if hechos % 24 == 0:
                tarea.avance("Armando el video", desde + int((hasta - desde) * hechos / total_cuadros))
        anterior = cuadro
    pista = np.concatenate(audio)
    pico = float(np.max(np.abs(pista))) if len(pista) else 0
    if pico > 0:
        pista = pista * min(3.0, 0.9 / pico)  # que la voz se escuche bien, sin saturar
    escritor.audio(pista)
    escritor.cerrar()
    return len(pista) / TASA


def material_para(tema, de_la_charla=False, del_texto=False):
    """Información para que el guion no invente: tu texto pegado, lo que hablaron o Wikipedia."""
    j = jarvis
    if del_texto:
        doc = j.adjuntos.documento_vigente()
        if doc:
            parte = j.adjuntos.seccion_del_texto(j.normalizar(tema), doc["texto"])
            return (parte[0] if parte else doc["texto"])[:7000]
    if de_la_charla:
        return j.lo_hablado_sobre(tema)[1][:7000]
    try:
        if j.herramientas.hay_internet():
            return j.herramientas.material_web(tema, 3500)[0]
    except Exception:
        pass
    return ""


def crear_video(tema, vertical=False, de_la_charla=False, del_texto=False):
    j = jarvis
    if j.herramientas.modo_juego.is_set():
        return "En modo juego no puedo armar videos: mi IA y el generador de imágenes están en pausa."
    tipo = "video corto (vertical)" if vertical else "video"
    j.emitir("progreso", f"Dame unos minutos: estoy armando un {tipo} sobre {tema}...")
    tarea = j.Tarea("video", tema)
    carpeta = tempfile.mkdtemp(prefix="jarvis_video_")
    try:
        tarea.avance("Buscando información", 4)
        material = material_para(tema, de_la_charla, del_texto)
        tarea.avance("Escribiendo el guion", 8)
        sistema = PROMPT_GUION.format(
            escenas="6" if vertical else "7", extra=EXTRA_TIKTOK if vertical else EXTRA_EXPLICATIVO,
            largo="2 oraciones cortas, unas 20 a 25 palabras" if vertical else "2 o 3 oraciones claras, unas 35 a 45 palabras")
        pedido = f"Tema: {tema}" + (f"\n\nInformación para usar:\n{material}" if material else "")
        titulo, escenas = "", []
        for intento in range(2):
            texto = escribir_guion(sistema, pedido, tarea, 0.4 if intento == 0 else 0.2)
            titulo, escenas = leer_guion(texto)
            if len(escenas) >= 3:
                break
        if len(escenas) < 3:
            raise RuntimeError("la IA no me armó un guion que pudiera usar")
        escenas = escenas[:7]
        titulo = titulo or tema[:1].upper() + tema[1:]
        tarea.avance("Grabando la voz", 22)
        voces = grabar_voces([e["voz"] for e in escenas], carpeta, tarea)
        W, H = (768, 1344) if vertical else (1344, 768)
        estilo, _ = j.estilo_de(j.normalizar(tema))
        estilo = estilo or (ESTILO_TIKTOK if vertical else ESTILO_IMAGENES)
        # el generador entiende inglés: cada escena se pasa a una descripción en inglés que nombra el tema (antes iban
        # en castellano y pintaba cualquier cosa: un DJ, un ojo y una llama para la pila de Volta)
        for i, e in enumerate(escenas):
            tarea.avance("Preparando las imágenes", 23 + int(6 * i / len(escenas)))
            e["prompt"] = j.prompt_en_ingles(f"Imagen para un video sobre {tema}. Tiene que mostrar: {e['imagen']}")
        for i, e in enumerate(escenas):
            e["audio"] = leer_wav(voces[i]) if voces[i] else silencio(2.5)
            desde = 30 + int(55 * i / len(escenas))
            sub = SubTarea(tarea, desde, 30 + int(55 * (i + 1) / len(escenas)), f"Imagen {i + 1} de {len(escenas)}")
            tarea.avance(f"Imagen {i + 1} de {len(escenas)}", desde)
            hecha = pintar(f"{e['prompt']}, {estilo}", W, H, os.path.join(carpeta, f"escena{i}.png"), sub)
            e["img"] = Image.open(hecha) if hecha else fondo_sin_imagen(W, H, e["pantalla"] or titulo, i)
            e["sin_imagen"] = not hecha
        ruta = ruta_libre(titulo)
        dur = componer(escenas, titulo, ruta, vertical, tarea)
        tarea.avance("Abriendo el video", 99)
    except j.Cancelado:
        tarea.fallar("Cancelado")
        return "Listo, cancelé el video."
    except j.IAPausada as e:
        tarea.fallar("Error")
        return f"No pude armar el video: {e}."
    except Exception as e:
        tarea.fallar("Error")
        return f"No pude armar el video: {e}"
    tarea.terminar(ruta)
    j.recordar_archivo(ruta)
    j.emitir("archivo", ruta)
    abrir(ruta)
    sin_imagen = sum(1 for e in escenas if e.get("sin_imagen"))
    return (f"Listo, hice el {tipo} «{titulo}»: {len(escenas)} escenas, {duracion_texto(dur)}. Lo guardé en "
            f"documentos\\videos y lo abrí." + (" Algunas escenas quedaron sin imagen (no pude pintarlas)."
                                                 if sin_imagen else ""))


def abrir(ruta):
    try:
        os.startfile(ruta)
    except Exception:
        pass


# =========================================================================
#  EDITAR VIDEOS
# =========================================================================

def info(ruta):
    import av

    with av.open(ruta) as c:
        v = c.streams.video[0] if c.streams.video else None
        dur = float(c.duration / 1e6) if c.duration else (float(v.duration * v.time_base) if v and v.duration else 0)
        fps = float(v.average_rate) if v is not None and v.average_rate else 30.0
        return {"dur": dur, "W": v.width if v is not None else 0, "H": v.height if v is not None else 0,
                "fps": min(30.0, max(10.0, fps)), "audio": bool(c.streams.audio)}


def cuadros(ruta, fps, desde=0.0, hasta=None, velocidad=1.0):
    """Los cuadros del video, a 'fps' cuadros por segundo parejos, entre 'desde' y 'hasta' (segundos del original).
    Con velocidad 2 saltea la mitad; con 0.5 repite cada uno."""
    import av

    with av.open(ruta) as c:
        vs = c.streams.video[0]
        vs.thread_type = "AUTO"
        if desde > 2:
            c.seek(int((desde - 1) / vs.time_base), stream=vs)
        siguiente_t = desde
        actual = None
        for f in c.decode(vs):
            t = float(f.pts * vs.time_base) if f.pts is not None else siguiente_t
            if hasta is not None and t > hasta + 1 / fps:
                break
            if t + 1e-6 < desde:
                actual = f
                continue
            actual = f
            while siguiente_t <= t + 1e-6 and (hasta is None or siguiente_t <= hasta):
                yield actual.to_image()
                siguiente_t += velocidad / fps
        if actual is not None and hasta is not None:
            while siguiente_t <= hasta:  # si el original termina antes, repite el último
                yield actual.to_image()
                siguiente_t += velocidad / fps


def audio_de(ruta, desde=0.0, hasta=None):
    """El audio de un video o de una canción como números entre -1 y 1 (un canal, 44.100 por segundo)."""
    import av

    with av.open(ruta) as c:
        if not c.streams.audio:
            return None
        a = c.streams.audio[0]
        cambio = av.AudioResampler(format="flt", layout="mono", rate=TASA)
        trozos, inicio = [], None
        for f in c.decode(a):
            if inicio is None:
                inicio = float(f.pts * a.time_base) if f.pts is not None else 0.0
            for g in cambio.resample(f):
                trozos.append(g.to_ndarray().reshape(-1))
        for g in cambio.resample(None):
            trozos.append(g.to_ndarray().reshape(-1))
    if not trozos:
        return None
    pista = np.concatenate(trozos).astype(np.float32)
    corrimiento = int(max(0.0, inicio or 0.0) * TASA)  # si el audio empieza un poco después que el video
    pista = np.concatenate([silencio(corrimiento / TASA), pista])
    a0 = int(desde * TASA)
    a1 = len(pista) if hasta is None else int(hasta * TASA)
    return pista[a0:a1]


def transcribir(pista, tarea=None, desde=0, hasta=100):
    """[(inicio, fin, texto)]: lo que se dice, en pedazos de ~5 s cortados en los silencios (Google, con internet)."""
    import speech_recognition as sr

    voz = cambiar_tasa(pista, TASA, 16000)
    energia = np.convolve(np.abs(voz), np.ones(1600) / 1600, mode="same")  # 0,1 s
    partes, i = [], 0
    while i < len(voz):
        fin = min(len(voz), i + 16000 * 5)
        if fin < len(voz):  # corta en el momento más silencioso entre los 4 y los 6,5 segundos
            ventana = energia[i + 16000 * 4: min(len(voz), i + int(16000 * 6.5))]
            if len(ventana):
                fin = i + 16000 * 4 + int(np.argmin(ventana))
        partes.append((i, fin))
        i = fin
    reconocedor = sr.Recognizer()
    salida = []
    for k, (a, b) in enumerate(partes):
        if tarea:
            tarea.avance("Escuchando lo que se dice", desde + int((hasta - desde) * k / max(1, len(partes))))
        trozo = voz[a:b]
        if float(np.sqrt(np.mean(trozo ** 2))) < 0.01:
            continue  # silencio
        datos = (np.clip(trozo, -1, 1) * 32767).astype(np.int16).tobytes()
        try:
            texto = reconocedor.recognize_google(sr.AudioData(datos, 16000, 2), language=getattr(jarvis, "IDIOMA", "es-UY"))
        except sr.UnknownValueError:
            continue
        except sr.RequestError as e:
            raise RuntimeError(f"no pude usar el reconocimiento de voz de Google ({e}); hace falta internet")
        if texto:
            salida.append((a / 16000, b / 16000, texto[:1].upper() + texto[1:]))
    return salida


def editar(ruta, salida, tarea, desde=0.0, hasta=None, quitar_audio=False, vertical=False, velocidad=1.0,
           subtitulos=False, musica=None):
    """Hace los cambios pedidos y escribe el video nuevo. Devuelve su duración."""
    datos = info(ruta)
    fps = round(datos["fps"])
    hasta = datos["dur"] if hasta is None or hasta > datos["dur"] else hasta
    desde = max(0.0, min(desde, hasta - 0.5))
    W, H = (720, 1280) if vertical else (datos["W"] - datos["W"] % 2, datos["H"] - datos["H"] % 2)
    dur_salida = (hasta - desde) / velocidad
    pista = None if quitar_audio else audio_de(ruta, desde, hasta)
    textos = []
    if subtitulos:
        if pista is None or not len(pista):
            raise RuntimeError("el video no tiene audio para sacarle subtítulos")
        textos = [(a / velocidad, b / velocidad, t) for a, b, t in transcribir(pista, tarea, 5, 35)]
        if not textos:
            raise RuntimeError("no entendí lo que se dice en el video (¿tiene voz?)")
    if pista is not None and velocidad != 1.0:
        pista = cambiar_tasa(pista, TASA, int(TASA / velocidad))  # (cambia también el tono, como en un casete)
    if musica:
        fondo = audio_de(musica)
        if fondo is None or not len(fondo):
            raise RuntimeError("no pude leer la canción")
        largo = int(dur_salida * TASA)
        fondo = np.tile(fondo, int(np.ceil(largo / len(fondo))))[:largo]
        fundido = min(len(fondo), TASA * 2)
        fondo[-fundido:] *= np.linspace(1, 0, fundido)
        if pista is not None and len(pista) and float(np.max(np.abs(pista))) > 0.02:
            pista = np.pad(pista, (0, max(0, largo - len(pista))))[:largo] + fondo * 0.22  # la voz manda
        else:
            pista = fondo * 0.85
    capas = {}
    escritor = Escritor(salida, W, H, fps=fps, con_audio=pista is not None)
    total = max(1, int(dur_salida * fps))
    for n, img in enumerate(cuadros(ruta, fps, desde, hasta, velocidad)):
        if vertical:
            img = encajar(img, W, H, fondo_borroso=True)
        elif img.size != (W, H):
            img = img.resize((W, H), Image.BILINEAR)
        if textos:
            t = n / fps
            actual = next((x for x in textos if x[0] <= t < x[1] + 0.3), None)
            if actual:
                if actual not in capas:
                    capas[actual] = cartel(actual[2], W, H, "tiktok" if vertical else "subtitulo")
                img = img.convert("RGBA")
                img.alpha_composite(capas[actual])
                img = img.convert("RGB")
        escritor.cuadro(img)
        if n % 30 == 0:
            tarea.avance("Armando el video", 40 + int(58 * n / total))
    if pista is not None:
        escritor.audio(pista)
    escritor.cerrar()
    return dur_salida


def unir(rutas, salida, tarea):
    """Une varios videos en uno (del tamaño del primero; los otros, encajados con franjas)."""
    primero = info(rutas[0])
    W, H = primero["W"] - primero["W"] % 2, primero["H"] - primero["H"] % 2
    fps = round(primero["fps"])
    con_audio = any(info(r)["audio"] for r in rutas)
    escritor = Escritor(salida, W, H, fps=fps, con_audio=con_audio)
    pistas, total = [], 0.0
    for k, ruta in enumerate(rutas):
        d = info(ruta)
        n = 0
        for img in cuadros(ruta, fps, 0.0, d["dur"]):
            escritor.cuadro(img if img.size == (W, H) else encajar(img, W, H))
            n += 1
        tarea.avance(f"Uniendo el video {k + 1} de {len(rutas)}", 10 + int(85 * (k + 1) / len(rutas)))
        if con_audio:
            pista = audio_de(ruta) if d["audio"] else None
            largo = int(n / fps * TASA)
            pista = silencio(largo / TASA) if pista is None else np.pad(pista, (0, max(0, largo - len(pista))))[:largo]
            pistas.append(pista)
        total += n / fps
    if con_audio:
        escritor.audio(np.concatenate(pistas))
    escritor.cerrar()
    return total


# =========================================================================
#  ¿QUÉ VIDEO? (el adjunto, el último, uno por su nombre)
# =========================================================================

def _carpetas_de_videos():
    home = os.path.expanduser("~")
    rutas = [CARPETA_VIDEOS, os.path.join(BASE, "grabaciones")] + jarvis.carpetas_busqueda()
    rutas += [os.path.join(home, "Videos"), os.path.join(home, "OneDrive", "Videos")]
    return [r for r in dict.fromkeys(rutas) if os.path.isdir(r)]


def videos_recientes(cantidad=5, palabras=None):
    """Los videos más nuevos (o los que tienen esas palabras en el nombre), del más nuevo al más viejo."""
    encontrados = []
    for raiz in _carpetas_de_videos():
        nivel = raiz.rstrip(os.sep).count(os.sep)
        for carpeta, subs, archivos in os.walk(raiz):
            subs[:] = [s for s in subs if not s.startswith(".") and s.lower() not in ("node_modules", "appdata")]
            if carpeta.count(os.sep) - nivel >= 3:
                subs[:] = []
            for a in archivos:
                nombre, ext = os.path.splitext(a)
                if ext.lower() in EXT_VIDEO and (not palabras or all(p in jarvis.normalizar(nombre) for p in palabras)):
                    ruta = os.path.join(carpeta, a)
                    try:
                        encontrados.append((os.path.getmtime(ruta), ruta))
                    except OSError:
                        pass
    return [r for _, r in sorted(set(encontrados), reverse=True)[:cantidad]]


def video_elegido(t):
    """La ruta del video del que hablás, o None."""
    j = jarvis
    m = re.search(r"\b(?:el |mi )?video (?:de |del |que se llama |llamado )(?:la |el |los |las )?(.+?)"
                  r"(?:\s+(?:del|desde|al|hasta|y|con|a|para|en)\b.*)?$", t)
    if m and not re.match(r"(?:minuto|segundo|\d|recien|hoy|ayer)", m.group(1)):
        palabras = [w for w in m.group(1).split() if len(w) > 2][:4]
        hallados = videos_recientes(1, palabras) if palabras else []
        if hallados:
            return hallados[0]
        if palabras:
            return None  # nombraste uno que no está: mejor decirlo que editar otro
    v = j.adjuntos.video_activo
    if v and v.get("ruta") and os.path.exists(v["ruta"]) and time.time() - v.get("cuando", 0) < 3600:
        return v["ruta"]
    if re.search(r"\bgrabacion\b", t):
        grabaciones = [r for r in videos_recientes(10) if os.path.basename(os.path.dirname(r)) == "grabaciones"]
        if grabaciones:
            return grabaciones[0]
    ultimo = j.ultimo_archivo.get("ruta")
    if ultimo and os.path.splitext(ultimo)[1].lower() in EXT_VIDEO and os.path.exists(ultimo):
        return ultimo
    recientes = videos_recientes(1)
    return recientes[0] if recientes else None


def musica_elegida(t):
    """'ponele de fondo la canción X' -> un archivo de audio tuyo con ese nombre (Música, Descargas, Escritorio...)."""
    m = re.search(r"\b(?:cancion|tema|musica|audio)\s+(?:de fondo\s+)?(?:que se llama |llamad[oa] |de |del )?(.+)$", t)
    if not m:
        return None
    palabras = [w for w in re.sub(r"\b(?:de fondo|al video|a este video|al ultimo video)\b", "", m.group(1)).split()
                if len(w) > 2][:4]
    if not palabras:
        return None
    home = os.path.expanduser("~")
    raices = [os.path.join(home, "Music"), os.path.join(home, "OneDrive", "Music")] + jarvis.carpetas_busqueda()
    hallados = []
    for raiz in [r for r in dict.fromkeys(raices) if os.path.isdir(r)]:
        for carpeta, subs, archivos in os.walk(raiz):
            if carpeta.count(os.sep) - raiz.count(os.sep) >= 3:
                subs[:] = []
            for a in archivos:
                nombre, ext = os.path.splitext(a)
                if ext.lower() in EXT_AUDIO and all(p in jarvis.normalizar(nombre) for p in palabras):
                    hallados.append(os.path.join(carpeta, a))
    return hallados[0] if hallados else None


# =========================================================================
#  FRASES
# =========================================================================

VERBO_CREAR = (r"(?:haceme|hace|hacer|hacerme|hazme|haz|crea|creame|crear|arma|armame|armar|genera|generame|generar|produci|"
               r"producime|edita(?:me)? un|quiero|quisiera|necesito|preciso|me (?:haces|armas|creas|haria)s?|"
               r"(?:podes|podrias|puedes) (?:hacer|crear|armar|generar)(?:me)?)")
CREAR = re.compile(rf"^(?:(?:che|jarvis|dale|bueno|porfa|si|sip|ok|pues|pero|y|ahora)[\s,]+)*{VERBO_CREAR}\s+(?:un |una |el |otro )?(?:(?:nuevo|corto|lindo)\s+)?"
                   rf"(?P<que>video(?:\s+(?:corto|explicativo|vertical|educativo))?|tik ?tok|reel|short|videito)"
                   rf"(?:\s+(?:tipo|como|estilo|para)\s+(?P<para>tik ?tok|reels?|shorts?|instagram|youtube|la expo\w*|la escuela))?"
                   rf"\s*(?:(?:sobre|de|del|acerca de|que explique|explicando|con)\s+(?P<tema>.+))?$")
CORTAR = re.compile(r"\b(?:corta\w*|recorta\w*|deja(?:me|le)?|saca(?:le)?|quita(?:le)?)\b")
TIEMPO = r"(\d+(?::\d{1,2}){0,2}|\d+(?:[.,]\d+)?\s*(?:segundos?|seg|s|minutos?|min|m)\b|(?:el )?minuto \d+(?:[.,]\d+)?|(?:el )?segundo \d+)"


def segundos(texto):
    """'1:10' -> 70, '30 segundos' -> 30, 'minuto 2' -> 120, '1 minuto 10' -> 70."""
    texto = texto.strip()
    m = re.fullmatch(r"(\d+):(\d{1,2})(?::(\d{1,2}))?", texto)
    if m:
        partes = [int(x) for x in m.groups() if x is not None]
        return partes[0] * 3600 + partes[1] * 60 + partes[2] if len(partes) == 3 else partes[0] * 60 + partes[1]
    m = re.fullmatch(r"(?:el )?minuto (\d+(?:[.,]\d+)?)", texto)
    if m:
        return float(m.group(1).replace(",", ".")) * 60
    m = re.fullmatch(r"(?:el )?segundo (\d+)", texto)
    if m:
        return float(m.group(1))
    m = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*(segundos?|seg|s|minutos?|min|m)", texto)
    if m:
        n = float(m.group(1).replace(",", "."))
        return n * 60 if m.group(2).startswith("m") else n
    return float(texto) if re.fullmatch(r"\d+(?:[.,]\d+)?", texto) else None


def tramo_pedido(t, dur):
    """(desde, hasta) de 'cortá del 1:10 al 2:30', 'dejá los primeros 30 segundos', 'sacale los últimos 5 segundos'."""
    m = re.search(rf"\b(?:desde|del|de)\s+{TIEMPO}\s+(?:hasta|al|a)\s+(?:el\s+)?{TIEMPO}", t)
    if m:
        a, b = segundos(m.group(1)), segundos(m.group(2))
        if a is not None and b is not None and b > a:
            return a, b
    m = re.search(rf"\b(?:deja(?:me|le)?|quedate con|solo)\s+(?:solo\s+)?(?:con\s+)?(?:los|el)\s+(primeros?|ultimos?)\s+{TIEMPO}", t)
    if m:
        n = segundos(m.group(2))
        if n:
            return (0.0, min(dur, n)) if m.group(1).startswith("primer") else (max(0.0, dur - n), dur)
    m = re.search(rf"\b(?:saca(?:le)?|quita(?:le)?|corta(?:le)?|borra(?:le)?)\s+(?:los|el)\s+(primeros?|ultimos?)\s+{TIEMPO}", t)
    if m:
        n = segundos(m.group(2))
        if n:
            return (min(dur, n), dur) if m.group(1).startswith("primer") else (0.0, max(0.0, dur - n))
    return None


def velocidad_pedida(t):
    m = re.search(r"\b(?:a |al |x)\s*(\d+(?:[.,]\d+)?)\s*x?\b(?:\s+de velocidad)?", t)
    if re.search(r"\bal doble\b|\bx ?2\b|\bdos veces mas rapido\b", t):
        return 2.0
    if re.search(r"\b(?:camara lenta|a la mitad|mitad de velocidad|mas lento)\b", t):
        return 0.5
    if re.search(r"\b(?:aceler\w*|mas rapido)\b", t):
        return float(m.group(1).replace(",", ".")) if m and 1 < float(m.group(1).replace(",", ".")) <= 4 else 1.5
    return None


def manejar(texto, t):
    """None si el pedido no es de videos."""
    t = t.strip(" ¿?¡!.,")
    m = CREAR.match(jarvis.sin_insultos(t))
    if m and not re.search(r"\b(?:llamada|videollamada)\b", t):
        tema = (m.group("tema") or "").strip()
        vertical = bool(re.search(r"tik ?tok|reel|short|vertical|corto|videito", (m.group("que") or "") + " " +
                                  (m.group("para") or "")))
        de_la_charla = bool(re.search(r"\b(?:lo que hablamos|lo que me (?:dijiste|explicaste)|esta charla)\b", tema))
        del_texto = bool(re.search(r"\b(?:el texto|del texto|mi texto|lo que te (?:pase|pegue|mande)|persona \d+|"
                                   r"parte \d+)\b", tema))
        if not tema:
            tema = tema_de_la_charla()  # "hazme un video" -> "¿sobre qué?" -> "enzimas" -> "sip pero haz el video"
        if not tema:
            jarvis.esperar_complemento(f"haceme un {'tiktok' if vertical else 'video'} sobre ")
            return "¿Sobre qué tema hago el video?"
        if de_la_charla:
            tema = " ".join(jarvis._ultimo_tema_hablado[0]) or tema
        return crear_video(tema, vertical, de_la_charla, del_texto)
    ultimo = jarvis.ultimo_archivo
    recien = bool(ultimo.get("ruta")) and os.path.splitext(ultimo["ruta"])[1].lower() in EXT_VIDEO and \
        time.time() - ultimo.get("cuando", 0) < 1800
    if not re.search(r"\b(?:videos?|grabacion|clip)\b", t) and not (recien and re.match(
            r"^(?:ponele|agregale|sumale|sacale|quitale|pasalo|ponelo|hacelo|aceleralo|cortale|cortalo|convertilo)\b", t)):
        return None
    if re.search(r"\b(?:uni|une|unime|junta|juntame|pega|pegame)\b", t):
        return pedir_union(t)
    if re.search(r"\bsubtitul\w*\b", t):
        return pedir_edicion(t, "subtitulos", subtitulos=True)
    if re.search(r"\b(?:saca(?:le)?|quita(?:le)?|borra(?:le)?) (?:el )?(?:audio|sonido)\b|\bmute\w*\b|\bsin (?:audio|sonido)\b", t):
        return pedir_edicion(t, "sin audio", quitar_audio=True)
    if re.search(r"\b(?:vertical|para tik ?tok|formato tik ?tok|9:16|para (?:reels?|historias|shorts|instagram))\b", t) and \
            re.search(r"\b(?:pasa\w*|converti\w*|ponelo|ponela|hace\w*|deja\w*|transforma\w*|cambia\w*)\b", t):
        return pedir_edicion(t, "vertical", vertical=True)
    v = velocidad_pedida(t)
    if v and re.search(r"\b(?:ponelo|ponela|hace\w*|pasa\w*|acelera\w*|deja\w*|camara lenta)\b", t):
        return pedir_edicion(t, "acelerado" if v > 1 else "lento", velocidad=v)
    if re.search(r"\b(?:musica|cancion|tema)\b", t) and re.search(r"\b(?:ponele|agregale|sumale|ponerle|agregar|con)\b", t):
        musica = musica_elegida(t)
        if not musica:
            return ("Decime el nombre de la canción (un archivo de audio tuyo, por ejemplo en Música o Descargas): "
                    "«ponele al video la canción chamamé».")
        return pedir_edicion(t, "con musica", musica=musica)
    if CORTAR.search(t) and (re.search(TIEMPO, t) or re.search(r"\b(?:primeros?|ultimos?)\b", t)):
        return pedir_edicion(t, "cortado", cortar=True)
    return None


def tema_de_la_charla():
    """Si recién preguntó de qué hacer el video (o hablaban de algo puntual), el tema: lo último corto que dijiste."""
    with jarvis.lock:
        ultimos = list(jarvis.historial[-6:])
    pregunto = any(m["role"] == "assistant" and re.search(r"(?i)video", m["content"]) and "?" in m["content"]
                   for m in ultimos)
    for m in reversed(ultimos):
        if m["role"] != "user":
            continue
        t = jarvis.normalizar(m["content"]).strip(" ¿?¡!.,")
        if CREAR.match(t) or re.search(r"\bvideo\b", t):
            continue
        if pregunto and 0 < len(t.split()) <= 5:
            return m["content"].strip(" ¿?¡!.,")
    return ""


def pedir_edicion(t, sufijo, cortar=False, **cambios):
    j = jarvis
    ruta = video_elegido(t)
    if not ruta:
        return "No encontré el video. Pasámelo con el clip o decime cómo se llama: «cortá el video de la expo del 0:10 al 0:40»."
    try:
        datos = info(ruta)
    except Exception as e:
        return f"No pude abrir el video «{os.path.basename(ruta)}»: {e}"
    if not datos["W"]:
        return f"«{os.path.basename(ruta)}» no tiene imagen."
    desde, hasta = 0.0, None
    if cortar:
        tramo = tramo_pedido(t, datos["dur"])
        if not tramo:
            return ("¿Qué parte dejo? Decímelo así: «cortá del 1:10 al 2:30», «dejá los primeros 30 segundos» o "
                    "«sacale los últimos 5 segundos».")
        desde, hasta = tramo
    nombre = os.path.splitext(os.path.basename(ruta))[0]
    salida = ruta_libre(f"{nombre} ({sufijo})")
    j.emitir("progreso", f"Editando «{os.path.basename(ruta)}»...")
    tarea = j.Tarea("video", f"{nombre} ({sufijo})")
    try:
        tarea.avance("Leyendo el video", 5)
        dur = editar(ruta, salida, tarea, desde=desde, hasta=hasta, **cambios)
    except j.Cancelado:
        tarea.fallar("Cancelado")
        _borrar(salida)
        return "Listo, cancelé la edición."
    except Exception as e:
        tarea.fallar("Error")
        _borrar(salida)
        return f"No pude editar el video: {e}"
    tarea.terminar(salida)
    j.recordar_archivo(salida)
    j.emitir("archivo", salida)
    abrir(salida)
    que = {"cortado": f"lo corté (del {mmss(desde)} al {mmss(hasta if hasta is not None else datos['dur'])})",
           "subtitulos": "le puse subtítulos", "sin audio": "le saqué el audio", "vertical": "lo pasé a vertical",
           "acelerado": "lo aceleré", "lento": "lo puse en cámara lenta", "con musica": "le puse música de fondo"}[sufijo]
    return (f"Listo, {que}: «{os.path.basename(salida)}» ({duracion_texto(dur)}). El original quedó igual. Lo guardé "
            "en documentos\\videos y lo abrí.")


def pedir_union(t):
    j = jarvis
    m = re.search(r"\b(?:los )?ultimos (\d+|dos|tres|cuatro|cinco) videos\b", t)
    if m:
        n = int(m.group(1)) if m.group(1).isdigit() else {"dos": 2, "tres": 3, "cuatro": 4, "cinco": 5}[m.group(1)]
        rutas = list(reversed(videos_recientes(n)))  # en el orden en que se hicieron
    else:
        nombres = re.split(r"\s+(?:y|con)\s+(?:el\s+)?(?:video\s+)?(?:de\s+)?", re.sub(
            r"^.*?\b(?:uni|une|unime|junta|juntame|pega|pegame)\s+(?:el\s+)?(?:video\s+)?(?:de\s+)?", "", t))
        rutas = []
        for nombre in nombres:
            hallados = videos_recientes(1, [w for w in nombre.split() if len(w) > 2 and w != "videos"][:4])
            if hallados and hallados[0] not in rutas:
                rutas.append(hallados[0])
    if len(rutas) < 2:
        return "¿Cuáles uno? Decímelo así: «uní los últimos 2 videos» o «uní el video de la intro y el de la expo»."
    salida = ruta_libre("Videos unidos")
    j.emitir("progreso", f"Uniendo {len(rutas)} videos...")
    tarea = j.Tarea("video", f"Unir {len(rutas)} videos")
    try:
        dur = unir(rutas, salida, tarea)
    except j.Cancelado:
        tarea.fallar("Cancelado")
        _borrar(salida)
        return "Listo, cancelé la unión."
    except Exception as e:
        tarea.fallar("Error")
        _borrar(salida)
        return f"No pude unir los videos: {e}"
    tarea.terminar(salida)
    j.recordar_archivo(salida)
    j.emitir("archivo", salida)
    abrir(salida)
    lista = ", ".join(f"«{os.path.basename(r)}»" for r in rutas)
    return f"Listo, uní {lista} en «{os.path.basename(salida)}» ({duracion_texto(dur)}) y lo abrí."


def _borrar(ruta):
    try:
        os.remove(ruta)
    except OSError:
        pass
