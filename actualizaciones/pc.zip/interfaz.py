"""Interfaz gráfica de JARVIS (estilo HUD).

Ejecutá:  python interfaz.py   (o doble clic en "JARVIS.pyw" para abrirla sin terminal)
La lógica está toda en main.py; acá solo se conecta con la ventana (carpeta "interfaz").
"""
import base64
import datetime
import json
import os
import queue
import sys
import threading
import time
import traceback

import webview

try:   # si quedó bajada una versión nueva (firmada), se pone antes de cargar el resto; si la anterior no arrancó, vuelve
    import actualizador
    actualizador.al_arrancar()
except Exception:
    actualizador = None

import main as jarvis  # noqa: E402

CARPETA_UI = os.path.join(jarvis.BASE, "interfaz")
ARCHIVO_ERRORES = os.path.join(jarvis.BASE, "errores_interfaz.log")

# Abierto con pythonw (sin terminal) no hay dónde escribir: se manda a un archivo
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(ARCHIVO_ERRORES, "a", encoding="utf-8")

ventana = None
lista = threading.Event()  # la página ya cargó y puede recibir eventos
cola = queue.Queue()
maximizada = False
nucleo = {"en_linea": None, "modelo_instalado": None}  # estado de Ollama

TIPOS = {
    ".docx": "word", ".doc": "word", ".odt": "word", ".rtf": "word", ".txt": "word",
    ".xlsx": "excel", ".xls": "excel", ".ods": "excel", ".csv": "excel",
    ".pptx": "powerpoint", ".ppt": "powerpoint", ".odp": "powerpoint",
    ".png": "imagen", ".jpg": "imagen", ".jpeg": "imagen", ".webp": "imagen",
    ".pdf": "pdf",
    **{ext: "codigo" for ext in (".py", ".js", ".jsx", ".ts", ".html", ".css", ".java", ".c", ".cpp", ".cs", ".php",
                                 ".sql", ".sh", ".ps1", ".bat", ".json", ".go", ".rs", ".kt", ".lua", ".rb", ".xml",
                                 ".yml", ".md", ".swift", ".dart")},
}


def registrar_error(texto):
    try:
        with open(ARCHIVO_ERRORES, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {texto}\n")
    except OSError:
        pass


# ---------- Archivos ----------

def info_archivo(ruta, con_imagen=False):
    nombre, ext = os.path.splitext(os.path.basename(ruta))
    tipo = TIPOS.get(ext.lower(), "otro")
    info = {
        "ruta": ruta,
        "nombre": nombre.replace("_", " ").strip().capitalize(),
        "ext": ext.lower().lstrip("."),
        "tipo": tipo,
        "fecha": os.path.getmtime(ruta) if os.path.exists(ruta) else time.time(),
    }
    if con_imagen and tipo == "imagen":
        info["imagen"] = miniatura(ruta)
    return info


def miniatura(ruta, lado=560):
    """Versión chiquita de la imagen para el chat (la original queda intacta en la carpeta).
    Mandar la imagen completa hacía que la ventana ocupara cada vez más memoria."""
    import io

    from PIL import Image

    try:
        with Image.open(ruta) as img:
            img = img.convert("RGB")
            img.thumbnail((lado, lado))
            buffer = io.BytesIO()
            img.save(buffer, "JPEG", quality=80)
        return "data:image/jpeg;base64," + base64.b64encode(buffer.getvalue()).decode()
    except Exception:
        return None


def ruta_permitida(ruta):
    ruta = os.path.realpath(ruta)
    return any(ruta.startswith(os.path.realpath(c) + os.sep)
               for c in (jarvis.CARPETA_DOCS, jarvis.CARPETA_IMAGENES))


def a_la_papelera(ruta):
    """Manda un archivo a la Papelera de reciclaje de Windows (se puede recuperar). True si salió bien."""
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", ctypes.c_uint), ("pFrom", wintypes.LPCWSTR),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]

    FO_DELETE, FOF_SILENT, FOF_NOCONFIRMATION, FOF_ALLOWUNDO, FOF_NOERRORUI = 3, 0x4, 0x10, 0x40, 0x400
    op = SHFILEOPSTRUCTW(None, FO_DELETE, os.path.abspath(ruta) + "\0", None,
                         FOF_SILENT | FOF_NOCONFIRMATION | FOF_ALLOWUNDO | FOF_NOERRORUI, False, None, None)
    return ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) == 0 and not os.path.exists(ruta)


# ---------- Eventos de JARVIS hacia la ventana ----------

dormida = threading.Event()  # ventana escondida y suspendida (modo juego): no se le mandan eventos
VOLATILES = {"nivel", "umbral", "mic", "parcial", "estado", "detalle", "ventana", "oido", "camara_vivo", "musica",
             "pantalla_vivo"}  # se descartan si duerme


def poner_icono():
    """El logo de JARVIS en la barra de tareas y en Alt+Tab (antes salía el de Python: la ventana no tenía ícono propio)."""
    ico = os.path.join(CARPETA_UI, "jarvis.ico")
    if not os.path.exists(ico):
        return
    try:
        from System.Drawing import Icon

        def poner():
            ventana.native.Icon = Icon(ico)
        en_ui(poner)
    except Exception:
        pass


def en_ui(funcion):
    """Ejecuta funcion() en el hilo de la ventana (el control WebView2 solo se puede tocar desde ahí)."""
    from System import Func, Object

    return ventana.native.Invoke(Func[Object](funcion))


def dormir_ventana():
    """Modo juego: esconde la ventana y pone WebView2 en memoria baja (deja de dibujar y de usar la placa de video)."""
    if dormida.is_set():
        return
    time.sleep(2.5)  # que se alcance a ver/escuchar la respuesta
    if not jarvis.herramientas.modo_juego.is_set():
        return
    dormida.set()
    try:
        ventana.hide()
        wv = ventana.native.browser.webview

        def bajar_consumo():
            # (TrySuspendAsync choca con la voz de Windows en el mismo proceso: alcanza con esto)
            from Microsoft.Web.WebView2.Core import CoreWebView2MemoryUsageTargetLevel

            wv.Visible = False  # el control invisible no dibuja nada
            wv.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Low
            return True
        en_ui(bajar_consumo)
    except Exception as e:
        registrar_error(f"No pude dormir la ventana: {e}")


def despertar_ventana(mostrar=True):
    """Sale del modo juego (o abrís JARVIS de nuevo): reanuda WebView2 y muestra la ventana."""
    try:
        if dormida.is_set():
            wv = ventana.native.browser.webview

            def reanudar():
                from Microsoft.Web.WebView2.Core import CoreWebView2MemoryUsageTargetLevel

                wv.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Normal
                wv.Visible = True
                return True
            en_ui(reanudar)
            dormida.clear()
        if mostrar:
            ventana.show()
            ventana.restore()
        cola.put(("despertar", None))  # destraba el envío de eventos guardados
        jarvis.musica._emitir()  # mientras dormía no le llegaban los cambios de la música
    except Exception as e:
        dormida.clear()
        registrar_error(f"No pude despertar la ventana: {e}")


def al_minimizar():
    """Minimizado: la ventana pasa a memoria baja y Windows recupera lo que no usa (todo sigue funcionando)."""
    if dormida.is_set():
        return
    try:
        wv = ventana.native.browser.webview

        def bajar():
            from Microsoft.Web.WebView2.Core import CoreWebView2MemoryUsageTargetLevel

            wv.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Low
            return True
        en_ui(bajar)
        threading.Timer(5, jarvis.herramientas.recortar_memoria).start()
    except Exception as e:
        registrar_error(f"No pude bajar la memoria al minimizar: {e}")


def al_restaurar():
    if dormida.is_set():
        return
    try:
        wv = ventana.native.browser.webview

        def normal():
            from Microsoft.Web.WebView2.Core import CoreWebView2MemoryUsageTargetLevel

            wv.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Normal
            return True
        en_ui(normal)
    except Exception:
        pass


def oyente(evento, datos):
    if evento == "cerrar":  # "apagate": cierra la ventana
        threading.Timer(0.3, ventana.destroy).start()
        return
    if evento == "modo_juego":
        threading.Thread(target=dormir_ventana if datos else despertar_ventana, daemon=True).start()
    if evento == "archivo":
        try:
            datos = info_archivo(datos, con_imagen=True)
        except OSError:
            return
    cola.put((evento, datos))


def enviar_eventos():
    """Un solo hilo le manda los eventos a la página, en orden y agrupados."""
    lista.wait()
    guardados = []  # eventos importantes que llegaron mientras la ventana dormía
    while True:
        lote = [cola.get()]
        time.sleep(0.03)
        while True:
            try:
                lote.append(cola.get_nowait())
            except queue.Empty:
                break
        lote = [(e, d) for e, d in lote if e != "despertar"]
        if dormida.is_set():
            guardados += [(e, d) for e, d in lote if e not in VOLATILES]
            continue
        if guardados:
            lote, guardados = guardados + lote, []
        if not lote:
            continue
        # del volumen del micrófono y del texto a medio escribir alcanza con el último
        vistos, limpio = set(), []
        for evento, datos in reversed(lote):
            if evento in ("nivel", "parcial", "camara_vivo", "pantalla_vivo"):  # de estos alcanza con el último
                if evento in vistos:
                    continue
                vistos.add(evento)
            elif evento == "tarea" and datos["estado"] == "activa":
                clave = ("tarea", datos["id"])  # del porcentaje alcanza con el último
                if clave in vistos:
                    continue
                vistos.add(clave)
            elif evento == "jarvis":
                vistos.add("parcial")  # el texto final reemplaza al parcial anterior
            limpio.append({"evento": evento, "datos": datos})
        limpio.reverse()
        try:
            ventana.run_js(f"window.jarvisEventos && window.jarvisEventos({json.dumps(limpio)})")
        except Exception as e:
            registrar_error(f"No pude mandar eventos a la ventana: {e}")


def vigilar_nucleo():
    """Cada tanto revisa si Ollama responde y si el modelo está instalado."""
    while True:
        if jarvis.herramientas.modo_juego.is_set():
            time.sleep(10)  # en modo juego Ollama está cerrado a propósito: no hay nada que revisar
            continue
        try:
            modelos = jarvis.ollama.list()
            nombres = [getattr(m, "model", None) or m.get("model") or m.get("name")
                       for m in (modelos.models if hasattr(modelos, "models") else modelos["models"])]
            nucleo["en_linea"] = True
            nucleo["modelo_instalado"] = any(n and n.split(":")[0] == jarvis.MODELO.split(":")[0]
                                             and (":" not in jarvis.MODELO or n == jarvis.MODELO)
                                             for n in nombres)
        except Exception:
            nucleo["en_linea"] = False
        revisar_conexiones()
        time.sleep(20)


_conexiones_previas = {}


def estado_conexiones():
    """Gmail e imágenes: qué está conectado (para los botones de Configuraciones, el panel y los protocolos)."""
    usuario, clave = jarvis.conexiones.credenciales()
    local = jarvis.GeneradorLocal.disponible()
    pollinations = bool(jarvis.clave_pollinations())
    motor = ("PC + Pollinations" if local and pollinations else "Tu PC" if local else
             "Pollinations" if pollinations else "Básico")
    return {"gmail": {"conectado": bool(usuario and clave), "usuario": usuario or ""},
            "imagenes": {"local": local, "pollinations": pollinations, "motor": motor,
                         "calidad": "alta" if local or pollinations else "baja"},
            "nube": jarvis.cerebro_nvidia.resumen()}


def revisar_conexiones():
    """Si cambió algo (por ejemplo terminaste de conectar Gmail), avisa a la página al momento."""
    global _conexiones_previas
    try:
        estado = estado_conexiones()
    except Exception:
        return
    nucleo["gmail"] = estado["gmail"]["conectado"]
    if estado != _conexiones_previas:
        cambio = bool(_conexiones_previas)
        _conexiones_previas = estado
        jarvis.emitir("conexiones", estado)
        if cambio:
            if estado["gmail"]["conectado"] and not nucleo.get("gmail_avisado"):
                nucleo["gmail_avisado"] = True
                jarvis.aviso(f"Gmail conectado ({estado['gmail']['usuario']}). Ya podés decirme «revisá mis mails».")


def vigilar_conexiones_un_rato():
    """Después de abrir la ventana para conectar algo, mira seguido (3 s) si ya quedó conectado."""
    def mirar():
        for _ in range(100):
            time.sleep(3)
            revisar_conexiones()
    threading.Thread(target=mirar, daemon=True).start()


def al_soltar(evento):
    """Al soltar archivos en la ventana, pywebview da la ruta real: los videos se usan desde donde están
    (pueden pesar cientos de MB). El resto lo sigue manejando la interfaz como siempre."""
    for f in (evento.get("dataTransfer") or {}).get("files", []):
        ruta = f.get("pywebviewFullPath")
        if ruta and jarvis.video.es_video(ruta):
            info = jarvis.adjuntos.agregar_ruta(ruta)
            info.pop("ruta", None)
            jarvis.emitir("adjunto_listo", {**info, "original": f.get("name")})
            if info.get("ok"):
                jarvis.precarga_rapida()


def escuchar_soltar():
    from webview.dom import DOMEventHandler

    try:
        ventana.dom.document.events.drop += DOMEventHandler(al_soltar)
    except Exception:
        pass  # sin esto, los videos chicos igual entran por la interfaz


def excluir_de_capturas(excluir):
    """Pantalla compartida: JARVIS no sale en las capturas (Windows lo saca de la imagen; en el monitor se ve igual).
    Así podés tenerlo abierto encima y ve lo que hay atrás."""
    import ctypes

    hwnd = ctypes.windll.user32.FindWindowW(None, "J.A.R.V.I.S.")
    if hwnd:
        ctypes.windll.user32.SetWindowDisplayAffinity(hwnd, 0x11 if excluir else 0)


def ocultar_un_momento(esconder):
    """Para que la captura de '¿qué hay en mi pantalla?' no salga JARVIS tapando todo."""
    if ventana is None or dormida.is_set():
        return
    if esconder:
        ventana.hide()
    else:
        ventana.show()


def medir_cpu():
    """Mide la CPU cada segundo en segundo plano (la página solo lee el último valor)."""
    try:
        import psutil
    except ImportError:
        return
    while True:
        if dormida.is_set():
            time.sleep(5)  # en modo juego nadie mira el panel: no mide nada
            continue
        nucleo["cpu"] = psutil.cpu_percent(interval=1)


# ---------- Una sola instancia ----------
# Si JARVIS ya está abierto (por ejemplo escondido en modo juego) y lo abrís de nuevo,
# no se abre otro: se despierta el que ya estaba.
PUERTO_INSTANCIA = 47321


def avisar_instancia_abierta():
    import socket

    try:
        with socket.create_connection(("127.0.0.1", PUERTO_INSTANCIA), timeout=1) as s:
            s.sendall(b"mostrar")
        return True
    except OSError:
        return False


def escuchar_otras_instancias():
    import socket

    servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        servidor.bind(("127.0.0.1", PUERTO_INSTANCIA))
    except OSError:
        return
    servidor.listen(2)
    while True:
        conexion, _ = servidor.accept()
        with conexion:
            if conexion.recv(16) == b"mostrar":
                if jarvis.herramientas.modo_juego.is_set():
                    texto = jarvis.herramientas.desactivar_modo_juego()  # también despierta la ventana
                    jarvis.mostrar(texto, jarvis.nueva_orden())
                else:
                    despertar_ventana()


def saludo():
    h = datetime.datetime.now().hour
    parte = "Buenos días" if 6 <= h < 13 else "Buenas tardes" if 13 <= h < 20 else "Buenas noches"
    trato = f", {jarvis.TRATAMIENTO}" if jarvis.TRATAMIENTO else ""
    return f"{parte}{trato}. Todos los sistemas están en línea. ¿En qué te ayudo?"


# ---------- Funciones que llama la página (window.pywebview.api.*) ----------

class Api:
    def iniciar(self):
        with jarvis.lock:
            hist = list(jarvis.historial[-16:])
        lista.set()
        if jarvis.MANOS_LIBRES_AL_INICIAR:
            jarvis.activar_manos_libres()
        return {
            "historial": hist,
            "manos_libres": jarvis.manos_libres.is_set(),
            "voz": jarvis.voz_activada.is_set(),
            "modelo": jarvis.MODELO,
            "archivos": self.archivos(),
            "musica": dict(jarvis.musica.estado),
            "conexiones": estado_conexiones(),
            "tema": jarvis.TEMA,
        }

    def error_js(self, texto):
        registrar_error("JS: " + str(texto)[:2000])

    def saludar(self):
        parar = jarvis.nueva_orden()
        threading.Thread(target=jarvis.mostrar, args=(saludo(), parar), daemon=True).start()

    def enviar(self, texto):
        texto = (texto or "").strip()
        parar = jarvis.nueva_orden()  # corta lo que estaba haciendo
        if not texto:
            jarvis.emitir("estado", "libre")
            return
        t = jarvis.normalizar(texto)
        if t in ("salir", "exit", "cerrar"):
            self.cerrar()
            return
        if t == "microfonos":
            jarvis.listar_microfonos()
            return
        if t in ("manos libres", "manoslibres"):
            self.alternar_manos_libres()
            return
        threading.Thread(target=jarvis.despachar, args=(texto, parar), daemon=True).start()

    def confirmar(self, si, texto=None, asunto=None):
        """Botones ENVIAR / CANCELAR de la tarjeta (con el texto como haya quedado si lo editaste)."""
        def responder():
            parar = jarvis.nueva_orden()
            jarvis.emitir("estado", "pensando")
            if si:
                jarvis.conexiones.editar_pendiente(texto, asunto)
            respuesta = jarvis.conexiones.responder_confirmacion("si" if si else "no")
            if respuesta:
                jarvis.mostrar(respuesta, parar)
            if not parar.is_set():
                jarvis.emitir("estado", "libre")
        threading.Thread(target=responder, daemon=True).start()

    def alarma(self, accion):
        """Botones LISTO / POSPONER de la tarjeta de alarma."""
        def responder():
            respuesta = jarvis.herramientas.responder_alarma("listo" if accion == "listo" else "posponer 10 minutos")
            if respuesta:
                jarvis.mostrar(respuesta, jarvis.nueva_orden())
        threading.Thread(target=responder, daemon=True).start()

    # --- Exámenes ---
    def examen_responder(self, respuesta):
        def hacer():
            ex = jarvis.examenes
            texto = ex.responder(str(respuesta))
            if ex.LEER_EN_VOZ and texto:  # tocaste una opción: te dice si estuvo bien y por qué
                ex.decir(texto.replace("Decime «siguiente».", "").replace("decime «terminar»", "tocá «terminar»"))
        threading.Thread(target=hacer, daemon=True).start()

    def examen_accion(self, accion):
        """Botones del examen: pista, siguiente, terminar, repasar."""
        def hacer():
            ex = jarvis.examenes
            if accion == "pista":
                ex.decir(ex.pista())
            elif accion == "siguiente":
                ex.siguiente(leer=True)
            elif accion == "terminar":
                jarvis.mostrar(ex.terminar(), jarvis.nueva_orden())  # la nota sí la dice en voz alta
            elif accion == "repasar":
                jarvis.mostrar(ex.repasar_errores(), jarvis.nueva_orden())
        threading.Thread(target=hacer, daemon=True).start()

    # --- Memoria (la red neuronal) ---
    def memoria_datos(self):
        return jarvis.memoria.datos_para_la_red()

    def memoria_olvidar(self, id_):
        return jarvis.memoria.olvidar_id(int(id_))

    def memoria_agregar(self, texto, categoria=None):
        """Agregar un recuerdo desde la pantalla de Memoria (también queda en la lista de control)."""
        texto = str(texto or "").strip()
        if not texto:
            return None
        texto, cat = jarvis.memoria.pulir(texto, categoria if categoria in jarvis.memoria.CATEGORIAS else None)
        cat = jarvis.memoria.guardar(texto, categoria=cat)
        entrada = jarvis.control.registrar("recuerdo", texto, lambda: jarvis.memoria.existe(texto))
        return {"categoria": cat, "verificado": entrada["verificado"]}

    def memoria_editar(self, id_, texto, categoria=None):
        return jarvis.memoria.editar(int(id_), str(texto or ""), categoria)

    def memoria_confirmar(self, id_):
        """Un recuerdo que aprendió solo: «sí, es así»."""
        return jarvis.memoria.confirmar(int(id_))

    def memoria_candidato(self, texto, guardar=True):
        """Lo que está en observación: guardarlo ya o descartarlo para siempre."""
        texto = str(texto or "")
        if guardar:
            cat = jarvis.memoria.aprobar_candidato(texto)
            if cat:
                jarvis.control.registrar("recuerdo", texto, lambda: jarvis.memoria.existe(texto))
            return {"categoria": cat}
        return {"descartado": jarvis.memoria.descartar_candidato(texto)}

    # --- Control: lo que JARVIS dijo que hizo, y si de verdad quedó hecho ---
    def control_datos(self):
        return jarvis.control.lista()

    def control_revisado(self, id_, revisado=True):
        return jarvis.control.marcar_revisado(int(id_), bool(revisado))

    def control_revisar_todo(self):
        return jarvis.control.revisar_todo()

    def control_borrar(self, id_):
        return jarvis.control.borrar(int(id_))

    def precargar(self):
        """La página avisa cuando empezás a escribir: la IA va cargando mientras tipeás."""
        jarvis.precarga_rapida()

    def precargar_imagen(self):
        """Estás escribiendo un pedido de imagen: el generador va cargando mientras terminás de escribir."""
        threading.Thread(target=jarvis.generador_local.precargar, daemon=True).start()

    def callar(self, cancelar_tareas=False):
        """Esc / Enter vacío: solo lo calla. El botón ■ (cancelar_tareas=True) además cancela lo que se está
        creando (antes Enter vacío cancelaba sin querer un quiz que se estaba armando)."""
        if cancelar_tareas:
            jarvis.detener_todo()
        else:
            jarvis.nueva_orden()
            jarvis.herramientas.parar_alarmas()
        jarvis.emitir("estado", "libre")

    def microfono(self):
        """Botón del micrófono: escucha una orden sin tener que decir 'Jarvis'."""
        parar = jarvis.nueva_orden()
        if jarvis.manos_libres.is_set():
            jarvis.esperar_orden(10)
        elif not jarvis.mic_lock.locked():
            threading.Thread(target=jarvis.escuchar, args=(parar,), daemon=True).start()

    # --- Barra espaciadora apretada = grabar ---
    def grabar_inicio(self):
        jarvis.empezar_a_grabar()

    def grabar_fin(self):
        jarvis.terminar_de_grabar()

    # --- Archivos e imágenes que arrastrás a la ventana o subís con el clip ---
    def adjuntar(self, nombre, datos_b64):
        import base64

        try:
            datos = base64.b64decode(datos_b64.split(",", 1)[-1])
        except Exception:
            return {"ok": False, "error": "No pude recibir el archivo."}
        info = jarvis.adjuntos.agregar(str(nombre), datos)
        info.pop("ruta", None)
        if info.get("ok"):
            jarvis.precarga_rapida()  # mientras escribís qué querés, la IA va cargando
        return info

    def quitar_adjunto(self, nombre):
        jarvis.adjuntos.quitar(nombre)

    def elegir_archivos(self):
        """El clip: abre el selector de Windows (así un video grande no tiene que pasar entero por la interfaz).
        Devuelve la lista de adjuntos, [] si cancelaste, o None si no se pudo abrir (la interfaz usa el suyo)."""
        import webview

        a = jarvis.adjuntos
        extensiones = sorted(a.EXT_IMAGEN | a.EXT_OFFICE | a.EXT_TEXTO | jarvis.video.EXT_VIDEO)
        tipos = ("Archivos imágenes y videos (" + ";".join("*" + e for e in extensiones) + ")",
                 "Videos (" + ";".join("*" + e for e in sorted(jarvis.video.EXT_VIDEO)) + ")", "Todos (*.*)")
        try:
            rutas = ventana.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=True, file_types=tipos)
        except Exception:
            return None
        resultado = []
        for ruta in rutas or []:
            info = a.agregar_ruta(ruta)
            info.pop("ruta", None)
            resultado.append(info)
        if any(i.get("ok") for i in resultado):
            jarvis.precarga_rapida()
        return resultado

    def alternar_manos_libres(self):
        if jarvis.manos_libres.is_set():
            jarvis.manos_libres.clear()
            jarvis.aviso("Escucha continua desactivada. Usá el botón del micrófono para hablarme.")
        else:
            jarvis.activar_manos_libres()
            jarvis.aviso("Escucha continua activada. Decí 'Jarvis' y tu pedido.")
        return jarvis.manos_libres.is_set()

    def alternar_voz(self):
        if jarvis.voz_activada.is_set():
            jarvis.voz_activada.clear()
            jarvis.nueva_orden()  # si estaba hablando, se calla
            jarvis.emitir("estado", "libre")
        else:
            jarvis.voz_activada.set()
        threading.Thread(target=jarvis.ajustes.guardar, args=({},), daemon=True).start()  # que se acuerde
        return jarvis.voz_activada.is_set()

    def archivos(self):
        lista_archivos = []
        for carpeta in (jarvis.CARPETA_DOCS, jarvis.CARPETA_IMAGENES, jarvis.CARPETA_CODIGO):
            if not os.path.isdir(carpeta):
                continue
            for a in os.listdir(carpeta):
                ruta = os.path.join(carpeta, a)
                if os.path.isfile(ruta) and os.path.splitext(a)[1].lower() in TIPOS and not a.startswith("~$"):
                    lista_archivos.append(info_archivo(ruta))
        lista_archivos.sort(key=lambda x: x["fecha"], reverse=True)
        return lista_archivos[:120]

    def borrar_archivo(self, ruta):
        """La ✕ de cada archivo: lo manda a la Papelera de reciclaje (se puede recuperar desde ahí)."""
        ruta = str(ruta or "")
        real = os.path.realpath(ruta)
        permitido = any(real.startswith(os.path.realpath(c) + os.sep)
                        for c in (jarvis.CARPETA_DOCS, jarvis.CARPETA_IMAGENES, jarvis.CARPETA_CODIGO))
        if not permitido:
            return {"ok": False, "mensaje": "Solo puedo borrar archivos que generé yo.", "lista": self.archivos()}
        if not os.path.isfile(real):
            return {"ok": False, "mensaje": "Ese archivo ya no existe.", "lista": self.archivos()}
        nombre = os.path.basename(real)
        try:
            ok = a_la_papelera(real)
        except Exception:
            ok = False
        mensaje = (f"Mandé «{nombre}» a la Papelera de reciclaje (si fue sin querer, lo recuperás desde ahí)." if ok
                   else f"No pude borrar «{nombre}»: puede que esté abierto en otro programa.")
        return {"ok": ok, "mensaje": mensaje, "lista": self.archivos()}

    # --- Secciones de Archivos: Quiz y Código ---
    def quizzes(self):
        return jarvis.examenes.listar_quizzes()

    def quiz_borrar(self, id_):
        jarvis.examenes.borrar_quiz(int(id_))
        return jarvis.examenes.listar_quizzes()

    def quiz_repetir(self, id_):
        def hacer():
            jarvis.mostrar(jarvis.examenes.repetir(int(id_)), jarvis.nueva_orden())
        threading.Thread(target=hacer, daemon=True).start()

    def leer_codigo(self, ruta):
        """Para la vista previa de un código guardado."""
        if not ruta_permitida(ruta) or not os.path.exists(ruta) or TIPOS.get(os.path.splitext(ruta)[1].lower()) != "codigo":
            return None
        with open(ruta, encoding="utf-8", errors="replace") as f:
            codigo = f.read(400_000)
        return {"titulo": os.path.basename(ruta), "ruta": ruta,
                "bloques": [{"lenguaje": os.path.splitext(ruta)[1].lstrip(".").lower(), "codigo": codigo}]}

    def abrir_en_editor(self, ruta):
        if ruta_permitida(ruta) and os.path.exists(ruta):
            jarvis.abrir_codigo(ruta)

    def guardar_codigo(self):
        def hacer():
            jarvis.mostrar(jarvis.guardar_codigo("guarda el codigo"), jarvis.nueva_orden())
        threading.Thread(target=hacer, daemon=True).start()

    # --- Configuraciones ---
    def ajustes_datos(self):
        return jarvis.ajustes.para_la_pantalla()

    def ajustes_guardar(self, cambios):
        campos = jarvis.ajustes.guardar(dict(cambios or {}))
        jarvis.emitir("estado", "libre")
        return campos

    def configurar_cuenta(self, cual):
        if cual in ("gmail", "pollinations"):
            jarvis.aviso(jarvis.conexiones.abrir_configuracion(cual))
            vigilar_conexiones_un_rato()  # apenas termines de conectarlo, los botones cambian solos

    # --- Segundo cerebro en la nube: Gemini, Groq o NVIDIA ("pensar más") ---
    def enviar_pensando(self, texto):
        """Igual que enviar, pero ESTA pregunta la responde la nube (si falla, Gemma y avisa)."""
        jarvis.cerebro_nvidia.pensar_mas(str(texto or ""))
        self.enviar(texto)

    def pensar_proxima(self, activar=True):
        """Botón 'pensar más' armado antes de hablar por voz: la próxima pregunta va a la nube."""
        jarvis.cerebro_nvidia.pensar_mas(None, bool(activar))

    def nube_configurar(self, proveedor="gemini"):
        jarvis.aviso(jarvis.cerebro_nvidia.abrir_configuracion(str(proveedor)))
        vigilar_conexiones_un_rato()  # apenas guardes la clave, el botón cambia solo

    def nube_probar(self, proveedor=None):
        ok, mensaje = jarvis.cerebro_nvidia.probar(proveedor or None)
        jarvis.aviso(mensaje)
        revisar_conexiones()
        return {"ok": ok, "mensaje": mensaje}

    def nube_quitar(self, proveedor):
        nube = jarvis.cerebro_nvidia
        if proveedor not in nube.PROVEEDORES:
            return estado_conexiones()
        nube.quitar_clave(proveedor)
        if not nube.configurado():  # sin ninguna nube, todo vuelve a Gemma
            nube.CEREBRO = "local"
            jarvis.ajustes.guardar({"cerebro": "local"})
            jarvis.aviso(f"Quité la clave de {nube.PROVEEDORES[proveedor]['nombre']}. Respondo solo con Gemma, en tu PC.")
        else:
            jarvis.aviso(f"Quité la clave de {nube.PROVEEDORES[proveedor]['nombre']}. "
                         f"Para «pensar más» uso {nube.nombre_completo()}.")
        revisar_conexiones()
        return estado_conexiones()

    def desconectar_cuenta(self, cual):
        import keyring

        try:
            if cual == "gmail":
                usuario, _ = jarvis.conexiones.credenciales()
                if usuario:
                    keyring.delete_password(jarvis.conexiones.SERVICIO_CLAVE, usuario)
                keyring.delete_password(jarvis.conexiones.SERVICIO_CLAVE, "usuario")
                nucleo["gmail_avisado"] = False
                jarvis.aviso("Desconecté Gmail y borré la contraseña de esta computadora.")
            elif cual == "pollinations":
                keyring.delete_password("JARVIS-Pollinations", "clave")
                jarvis.aviso("Quité la clave de Pollinations. Las imágenes se hacen en tu PC (o con el servicio básico).")
        except Exception as e:
            jarvis.aviso(f"No pude desconectarlo: {e}")
        revisar_conexiones()
        return estado_conexiones()

    def conexiones(self):
        return estado_conexiones()

    # --- Charlas (el botón Chats) ---
    def chats(self):
        return jarvis.chats.lista()

    def chat_nuevo(self):
        jarvis.chats.nueva("boton")
        return True

    def chat_abrir(self, id_):
        return jarvis.chats.abrir(str(id_))

    def chat_borrar(self, id_):
        return jarvis.chats.borrar(str(id_))

    # --- Barra "Hoy", pendientes y modo estudio ---
    def hoy(self):
        return jarvis.habilidades.datos_de_hoy()

    def pendientes(self):
        return jarvis.habilidades.pendientes()

    def pendiente_agregar(self, texto):
        if str(texto or "").strip():
            return jarvis.habilidades.agregar_pendiente(str(texto))
        return jarvis.habilidades.pendientes()

    def pendiente_marcar(self, id_):
        return jarvis.habilidades.marcar_pendiente(int(id_))

    def pendiente_borrar(self, id_=None, solo_hechos=False):
        return jarvis.habilidades.borrar_pendiente(int(id_) if id_ is not None else None, bool(solo_hechos))

    def finanzas_datos(self):
        return jarvis.finanzas.para_la_pantalla()

    def finanza(self, datos):
        return jarvis.finanzas.desde_la_pantalla(datos)

    def estudio(self, accion, minutos=25):
        frases = {"empezar": f"modo estudio {int(minutos)} minutos", "pausa": "pausa el estudio",
                  "seguir": "segui con el estudio", "terminar": "termina el modo estudio", "saltear": "saltea el descanso"}
        if accion not in frases:
            return

        def hacer():
            r = jarvis.habilidades.manejar(frases[accion], jarvis.normalizar(frases[accion]))
            if r:
                jarvis.mostrar(r, jarvis.nueva_orden())
        threading.Thread(target=hacer, daemon=True).start()

    # --- Música ---
    def musica_control(self, accion, valor=None):
        def hacer():
            r = jarvis.musica.control(accion, valor)
            if r and accion not in ("volumen",):
                jarvis.emitir("detalle", r)
        threading.Thread(target=hacer, daemon=True).start()

    def musica_poner(self, texto):
        def hacer():
            jarvis.mostrar(jarvis.musica.reproducir(str(texto)), jarvis.nueva_orden())
        threading.Thread(target=hacer, daemon=True).start()

    def musica_estado(self):
        return dict(jarvis.musica.estado)

    def abrir(self, ruta):
        if not ruta_permitida(ruta) or not os.path.exists(ruta):
            jarvis.aviso("Ese archivo ya no existe.")
            return
        if TIPOS.get(os.path.splitext(ruta)[1].lower()) == "imagen":
            os.startfile(ruta)
        else:
            jarvis.abrir_archivo(ruta)

    def abrir_carpeta(self, cual):
        carpeta = {"imagenes": jarvis.CARPETA_IMAGENES, "codigo": jarvis.CARPETA_CODIGO}.get(cual, jarvis.CARPETA_DOCS)
        os.makedirs(carpeta, exist_ok=True)
        os.startfile(carpeta)

    def sistema(self):
        datos = {"cpu": None, "ram": None, "bateria": None, "enchufado": None,
                 "nucleo": nucleo["en_linea"], "modelo_instalado": nucleo["modelo_instalado"],
                 "gmail": nucleo.get("gmail"),
                 "modo_juego": jarvis.herramientas.modo_juego.is_set(),
                 "manos_libres": jarvis.manos_libres.is_set()}
        try:
            import psutil

            datos["cpu"] = nucleo.get("cpu")
            datos["ram"] = psutil.virtual_memory().percent
            bat = psutil.sensors_battery()
            if bat:
                datos["bateria"], datos["enchufado"] = round(bat.percent), bat.power_plugged
        except Exception:
            pass
        return datos

    # --- ventana sin bordes ---
    def minimizar(self):
        ventana.minimize()

    def maximizar(self):
        global maximizada
        if maximizada:
            ventana.restore()
        else:
            ventana.maximize()
        maximizada = not maximizada

    def cerrar(self):
        jarvis.manos_libres.clear()
        jarvis.nueva_orden()
        threading.Timer(0.2, ventana.destroy).start()  # al cerrarse, libera la IA de la placa de video

    def apagar(self):
        """Botón ⏻: apaga JARVIS por completo (también cierra Ollama)."""
        threading.Thread(target=jarvis.apagar_jarvis, args=(jarvis.nueva_orden(),), daemon=True).start()


def al_cerrar_principal():
    """Al cerrar la ventana principal se cierran también las demás (la barrita de música, el reproductor):
    webview.start() recién termina cuando no queda ninguna, y si quedaba una escondida, JARVIS seguía
    abierto sin ventana y no se podía volver a abrir (el acceso directo le pedía que se mostrara)."""
    def cerrar_resto():
        try:
            jarvis.pildora.cerrar()   # (primero la píldora: si no, a veces quedaba sola en la pantalla)
        except Exception:
            pass
        for otra in list(webview.windows):
            if otra is not ventana:
                try:
                    otra.destroy()
                except Exception:
                    pass
        time.sleep(15)  # si igual quedó trabado, que no bloquee el próximo inicio
        try:
            jarvis.liberar_ia()
        finally:
            os._exit(0)
    threading.Thread(target=cerrar_resto, daemon=True).start()


def revisar_puentes():
    """Las funciones de Api que llama la página y acá no existen (la página no dice nada: el botón deja de andar).
    Pasó una vez: este archivo volvió solo a una versión vieja (OneDrive) y se perdió la nube, Control, etc."""
    import re

    usadas = set()
    for nombre in os.listdir(CARPETA_UI):
        if nombre.endswith((".js", ".html")) and nombre not in ("barra_musica.html", "pildora.html"):  # tienen su propia Api
            with open(os.path.join(CARPETA_UI, nombre), encoding="utf-8") as f:
                texto = f.read()
            usadas |= set(re.findall(r"api\(\s*['\"]([a-z_0-9]+)['\"]", texto))
            usadas |= {n for par in re.findall(r"api\(\w+\s*\?\s*\"([a-z_0-9]+)\"\s*:\s*\"([a-z_0-9]+)\"", texto)
                       for n in par}  # api(pensarMas ? "enviar_pensando" : "enviar", ...)
    faltan = sorted(n for n in usadas if not hasattr(Api, n))
    if faltan:
        registrar_error("La página llama a funciones que no están en interfaz.py: " + ", ".join(faltan))
        jarvis.aviso(f"Ojo: a interfaz.py le faltan {len(faltan)} funciones que usa la pantalla ({', '.join(faltan[:6])}"
                     f"{'...' if len(faltan) > 6 else ''}). Algunos botones no van a andar: puede que el archivo haya "
                     "vuelto a una versión vieja.")
    return faltan


def iniciar():
    global ventana
    if avisar_instancia_abierta():
        return  # ya había un JARVIS abierto: lo despertamos y este no abre otra ventana
    threading.Thread(target=escuchar_otras_instancias, daemon=True).start()
    jarvis.ajustes.cargar()  # lo que elegiste en Configuraciones
    revisar_puentes()  # si la pantalla llama a algo que acá no existe, avisa
    # la ventana de música de YouTube tiene que poder arrancar sola (sin tocar play)
    os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = (
        "--disable-features=ElasticOverscroll --autoplay-policy=no-user-gesture-required")
    jarvis.memoria.migrar()  # la primera vez pasa recuerdos.txt a recuerdos.json (con categorías)
    jarvis.historial.extend(jarvis.cargar_historial())
    jarvis.chats.migrar()  # la primera vez, lo de antes (todo mezclado) queda como una charla guardada
    jarvis.oyentes.append(oyente)
    jarvis.oyentes.append(jarvis.pildora.oyente)  # la píldora flotante también se entera de todo
    jarvis.habilidades.ocultar_ventana = ocultar_un_momento
    jarvis.pantalla.excluir_de_capturas = excluir_de_capturas
    jarvis.precalentar()  # el modelo y la voz se cargan mientras se abre la ventana
    jarvis.iniciar_voz()
    jarvis.herramientas.iniciar()  # recordatorios y vigilancia de juegos
    jarvis.actividad.iniciar()  # anota qué apps usás (solo en esta compu)
    jarvis.rutinas.iniciar()  # las rutinas: al abrir una app o a una hora
    jarvis.escritorio.iniciar()  # mira qué ventana usás (para dictar y hacer clics ahí)
    jarvis.consejos.iniciar()  # los consejos por su cuenta (nunca mientras jugás)
    jarvis.finanzas.iniciar()  # jarv2: los avisos de pagos y de pendientes con fecha
    jarvis.celular.iniciar()  # el bot de Telegram: se pasan pendientes, recordatorios, órdenes (antes faltaba acá)
    jarvis.barra_musica.iniciar_atajos()  # Ctrl+Alt+Espacio, Ctrl+Alt+. ... (manejan la música, también jugando)
    jarvis.automejora.iniciar()  # se revisa solo cuando no lo usás y arregla lo que salió mal
    if actualizador:
        actualizador.iniciar(jarvis)  # las versiones nuevas que publica quien lo armó (no en la PC de quien publica)

    # tamaño según la pantalla (deja un margen y la centra)
    try:
        import ctypes

        escala = ctypes.windll.shcore.GetScaleFactorForDevice(0) / 100  # ej: 1.25 si Windows está al 125%
        pantalla = webview.screens[0]
        ancho_p, alto_p = int(pantalla.width / escala), int(pantalla.height / escala)
    except Exception:
        ancho_p, alto_p = 1366, 768
    ancho, alto = min(1500, int(ancho_p * 0.94)), min(940, int(alto_p * 0.9))

    try:   # que Windows la agrupe como «JARVIS» (con su logo) y no como «python»
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Rusty.JARVIS")
    except Exception:
        pass
    ventana = webview.create_window(
        "J.A.R.V.I.S.",
        url=os.path.join(CARPETA_UI, "index.html"),
        js_api=Api(),
        width=ancho,
        height=alto,
        x=(ancho_p - ancho) // 2,
        y=(alto_p - alto) // 2,
        min_size=(1000, 620),
        frameless=True,
        easy_drag=False,
        background_color="#02070d",
    )
    ventana.events.shown += lambda: threading.Thread(target=poner_icono, daemon=True).start()
    ventana.events.minimized += lambda: threading.Thread(target=al_minimizar, daemon=True).start()
    ventana.events.restored += lambda: threading.Thread(target=al_restaurar, daemon=True).start()
    ventana.events.loaded += escuchar_soltar
    ventana.events.closed += al_cerrar_principal
    threading.Thread(target=enviar_eventos, daemon=True).start()
    threading.Thread(target=vigilar_nucleo, daemon=True).start()
    threading.Thread(target=medir_cpu, daemon=True).start()
    jarvis.pildora.crear()  # la carita flotante arriba de la pantalla
    threading.Timer(90, jarvis.precargar_voz_local).start()  # la voz sin internet, lista por si se corta
    jarvis.pildora.iniciada = True
    webview.start()
    jarvis.pantalla.terminar()  # con la ventana cerrada, deja de mirar la pantalla
    jarvis.manos_libres.clear()
    jarvis.camara.apagar_todo()
    jarvis.generador_local.cerrar()
    jarvis.liberar_ia()  # con la ventana cerrada, la IA no sigue ocupando la placa de video


if __name__ == "__main__":
    try:
        iniciar()
    except Exception:
        registrar_error(traceback.format_exc())
        raise
