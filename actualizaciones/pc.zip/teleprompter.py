"""Teleprompter: una franja arriba de la pantalla con tu texto, que avanza mientras hablás y frena cuando te callás.

Clic: pausa / sigue.  Rueda del mouse: adelanta o vuelve.  Esc o clic derecho: cierra.
No sale en capturas ni grabaciones de pantalla (así no se ve en una videollamada o un video).
Uso: pythonw teleprompter.py archivo.txt
"""
import ctypes
import sys
import tkinter as tk

import numpy
import sounddevice

ctypes.windll.shcore.SetProcessDpiAwareness(2)

with open(sys.argv[1], encoding="utf-8") as f:
    TEXTO = f.read()

ANCHO, ALTO, VELOCIDAD = 1000, 190, 1.4  # píxeles por cuadro mientras hablás
estado = {"nivel": 0.0, "pausa": False, "y": ALTO * 0.45}

ventana = tk.Tk()
ventana.title("JARVIS · Teleprompter")
ventana.overrideredirect(True)
ventana.attributes("-topmost", True)
ventana.attributes("-alpha", 0.93)
x = (ventana.winfo_screenwidth() - ANCHO) // 2
ventana.geometry(f"{ANCHO}x{ALTO}+{x}+12")
lienzo = tk.Canvas(ventana, width=ANCHO, height=ALTO, bg="#06101c", highlightthickness=2,
                   highlightbackground="#29d9ff")
lienzo.pack()
texto = lienzo.create_text(ANCHO // 2, estado["y"], text=TEXTO, width=ANCHO - 80, fill="#e6f8ff",
                           font=("Segoe UI", 22, "bold"), justify="center", anchor="n")
lienzo.create_line(20, ALTO * 0.45, 40, ALTO * 0.45, fill="#29d9ff", width=4)  # la línea de lectura
aviso = lienzo.create_text(ANCHO - 16, ALTO - 12, text="", fill="#7fa9bf", font=("Segoe UI", 10), anchor="e")

ventana.update_idletasks()
hwnd = ctypes.windll.user32.GetParent(ventana.winfo_id())
ctypes.windll.user32.SetWindowDisplayAffinity(hwnd, 0x11)  # WDA_EXCLUDEFROMCAPTURE


def oir(datos, cuadros, tiempo, st):
    estado["nivel"] = float(numpy.sqrt(numpy.mean(numpy.square(datos.astype(numpy.float32)))))


try:
    mic = sounddevice.InputStream(samplerate=16000, channels=1, dtype="int16", callback=oir, blocksize=1600)
    mic.start()
except Exception:
    mic = None  # sin micrófono: avanza solo, a ritmo fijo


def cuadro():
    hablando = mic is None or estado["nivel"] > 450
    if not estado["pausa"] and hablando:
        estado["y"] -= VELOCIDAD
        lienzo.coords(texto, ANCHO // 2, estado["y"])
    alto_texto = lienzo.bbox(texto)[3] - lienzo.bbox(texto)[1]
    if estado["y"] + alto_texto < 0:
        estado["pausa"] = True
    lienzo.itemconfigure(aviso, text="pausa · clic para seguir" if estado["pausa"] else
                         ("" if hablando else "esperando que hables..."))
    ventana.after(33, cuadro)


def pausa(_e=None):
    estado["pausa"] = not estado["pausa"]


def rueda(e):
    estado["y"] += 40 if e.delta > 0 else -40
    lienzo.coords(texto, ANCHO // 2, estado["y"])


def cerrar(_e=None):
    if mic is not None:
        mic.close()
    ventana.destroy()


lienzo.bind("<Button-1>", pausa)
lienzo.bind("<Button-3>", cerrar)
lienzo.bind("<MouseWheel>", rueda)
ventana.bind("<Escape>", cerrar)
ventana.focus_force()
cuadro()
ventana.mainloop()
