"""Exámenes y tareas interactivas: JARVIS arma preguntas sobre un tema, te las toma, te corrige y te explica.

  "armame un examen de sucesiones geométricas"      "tomame una prueba de 10 preguntas sobre la Revolución Francesa"
  "preparame ejercicios de ecuaciones"              "haceme un examen de lo que hablamos"
Mientras hay un examen:  "la b", "verdadero", "la respuesta es 32", "pista", "siguiente", "terminá el examen".
Al final: nota, porcentaje y repaso de los errores ("repasá mis errores" arma otro con lo que te costó).
"""
import datetime
import difflib
import json
import os
import re
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_RESULTADOS = os.path.join(BASE, "examenes.json")
# Modelo para armar y revisar exámenes. None = el mismo del chat (gemma3:4b). Uno más grande se equivoca menos
# en las preguntas, por ejemplo "qwen2.5:7b" (hay que bajarlo antes con: ollama pull qwen2.5:7b).
MODELO_EXAMENES = None

ESQUEMA = {
    "type": "object",
    "properties": {
        "titulo": {"type": "string"},
        "preguntas": {"type": "array", "items": {
            "type": "object",
            # el orden importa: primero RESUELVE (explicacion) y recién después escribe la respuesta (correcta)
            "properties": {
                "tipo": {"type": "string", "enum": ["multiple", "vf", "corta"]},
                "enunciado": {"type": "string"},
                "opciones": {"type": "array", "items": {"type": "string"}},
                "explicacion": {"type": "string"},
                "correcta": {"type": "string"},
                "pista": {"type": "string"},
            },
            "required": ["tipo", "enunciado", "opciones", "explicacion", "correcta", "pista"],
        }},
    },
    "required": ["titulo", "preguntas"],
}

PROMPT_EXAMEN = """Sos un profesor que arma un examen para practicar, en español rioplatense (con "vos").
Armá {n} preguntas sobre el tema, de dificultad {nivel}, que evalúen que se ENTIENDA el tema (no solo de memoria).
Tipos: más o menos 60% "multiple" (4 opciones, UNA sola correcta, las incorrectas creíbles), 20% "vf" (opciones
["Verdadero", "Falso"]) y 20% "corta" (la respuesta es un número, una palabra o una expresión corta; opciones vacías).
- En "vf" el enunciado es UNA AFIRMACIÓN SIMPLE, sin pregunta y sin negaciones dobles
  (bien: "La razón de una sucesión geométrica puede ser negativa." / mal: "¿Es falso que la razón no puede...?").
- Las opciones van SIN letras adelante (nada de "A)"), solo el texto.
- "explicacion": resolvé la pregunta paso a paso (con la cuenta si hay cálculo, haciéndola con cuidado).
- "correcta": DESPUÉS de resolverla: en multiple y vf, el TEXTO EXACTO de la opción correcta; en corta, la respuesta.
  Tiene que coincidir con lo que te dio en la explicación.
- "pista": una ayuda que oriente SIN decir la respuesta, hablándole de vos ("fijate", "pensá").
- Variá las preguntas (definiciones, aplicación, ejemplos, errores comunes) y no repitas ideas.
- No pongas "todas las anteriores" ni "ninguna de las anteriores".
- PROHIBIDO: preguntas cuya respuesta ya está escrita en el enunciado ("si la razón es 0.5, ¿cuál es la razón?"),
  y verdadero/falso que sean solo datos sueltos ("el segundo término es 8 y el quinto es 128").
  Un buen V/F afirma una propiedad o un resultado: "Si a1 = 2 y r = 3, el tercer término es 18." """

PROMPT_TAREA = """Sos un profesor particular que arma una tarea interactiva para practicar, en español rioplatense.
Armá {n} ejercicios sobre el tema, de dificultad {nivel}, que vayan de más fácil a más difícil.
Casi todos de tipo "corta" (la respuesta es un número, palabra o expresión corta; opciones vacías); podés incluir
alguno "multiple" (4 opciones, una correcta). Resolvé cada ejercicio vos mismo y verificá la respuesta antes de escribirla.
- "correcta": la respuesta esperada (en multiple, el texto exacto de la opción correcta).
- "explicacion": la resolución paso a paso, corta (con las cuentas).
- "pista": el primer paso para resolverlo, SIN dar el resultado."""

PROMPT_CON_MATERIAL = """
MUY IMPORTANTE: el mensaje trae un MATERIAL DE REFERENCIA (de internet o del archivo del alumno). Sacá cada pregunta y
su respuesta correcta SOLO de ese material: no preguntes nada que no esté escrito ahí y no agregues datos de memoria
(nombres, parentescos, fechas, lugares, motivos). Las opciones incorrectas tienen que ser claramente falsas según el
material. En "explicacion" explicá el dato en UNA oración y de dónde sale ("según {fuente}..."), sin decir "el texto"
ni "el material". La "pista" también es UNA oración corta."""

PROMPT_DESDE_DATOS = """
CÓMO USAR LOS DATOS: cada dato se CONVIERTE en una pregunta; NUNCA copies el dato como enunciado ni como opción.
- multiple / corta: una pregunta con signos ¿? cuya respuesta es una parte del dato (un número, un nombre, un lugar,
  una causa). Ejemplo: dato "El Sol concentra el 99,86 % de la masa del sistema solar" -> "¿Qué porcentaje de la masa
  del sistema solar concentra el Sol?", opciones ["99,86 %", "50 %", "75 %", "10 %"], correcta "99,86 %".
- vf: una afirmación. Más o menos la MITAD tienen que ser FALSAS: cambiale al dato un número, un nombre o un lugar
  (ej: "El Sol concentra el 50 % de la masa del sistema solar." -> correcta "Falso")."""

# Temas de cálculo: ahí no hace falta buscar en internet (la IA resuelve y la verificación rehace las cuentas)
MATEMATICA = re.compile(r"\b(?:matematic|algebra|aritmetic|ecuacion|inecuacion|derivad|integral|sucesion|progresion|"
                        r"fraccion|porcentaje|geometri|trigonometri|logaritm|exponencial|funcion|polinomi|matriz|"
                        r"matrices|vector|limite|probabilidad|estadistic|calculo|potenciacion|radicacion|"
                        r"raiz cuadrada|teorema|pitagoras|perimetro|regla de tres|factoriz|divisib|multiplicacion|"
                        r"sumas y restas|tabla del|numeros? (?:primos|enteros|racionales|reales|naturales))\w*")

PROMPT_CORREGIR = """Corregís la respuesta de un alumno. Decí si es correcta aunque esté escrita distinto (sinónimos,
otra forma equivalente, un número igual con otro formato). Si es incorrecta o incompleta, explicá en una oración qué
le faltó, con tono amable. Respondé en español rioplatense."""

activo = None  # el examen que se está tomando
_lock = threading.Lock()


class Examen:
    def __init__(self, tema, modo, datos):
        self.tema, self.modo = tema, modo
        self.titulo = datos.get("titulo") or tema
        self.preguntas = [p for p in (_limpiar(p) for p in datos.get("preguntas", [])) if p]
        self.i = 0
        self.respuestas = [None] * len(self.preguntas)
        self.pistas_usadas = set()
        self.inicio = time.time()
        self.id = int(self.inicio)

    def pregunta(self, i=None):
        i = self.i if i is None else i
        p = self.preguntas[i]
        return {"indice": i, "total": len(self.preguntas), "tipo": p["tipo"], "enunciado": p["enunciado"],
                "opciones": p["opciones"] if p["tipo"] != "corta" else [], "respondida": self.respuestas[i]}

    def corregir(self, respuesta):
        p = self.preguntas[self.i]
        r = respuesta.strip()
        n = jarvis.normalizar(r).strip(" .")
        correcta, comentario = False, ""
        if p["tipo"] in ("multiple", "vf"):
            elegida = None
            letra = re.fullmatch(r"(?:la |opcion |respuesta )?([a-d])", n)
            if letra:  # tocaste un botón (o dijiste "la b"): sirve también en verdadero/falso (A = Verdadero)
                idx = "abcd".index(letra.group(1))
                elegida = p["opciones"][idx] if idx < len(p["opciones"]) else None
            elif p["tipo"] == "vf" and re.fullmatch(r"(?:es )?(?:verdadero|v|cierto|si|true)", n):
                elegida = "Verdadero"
            elif p["tipo"] == "vf" and re.fullmatch(r"(?:es )?(?:falso|f|no|false)", n):
                elegida = "Falso"
            else:
                normalizadas = {jarvis.normalizar(o): o for o in p["opciones"]}
                parecida = difflib.get_close_matches(n, list(normalizadas), n=1, cutoff=0.6)
                elegida = normalizadas[parecida[0]] if parecida else None
            if elegida is None:
                return None  # no se entendió cuál eligió
            r = elegida
            correcta = jarvis.normalizar(elegida) == jarvis.normalizar(p["correcta"])
        else:
            correcta = _iguales(r, p["correcta"])
            if not correcta:
                correcta, comentario = _corregir_con_ia(p, r)
        self.respuestas[self.i] = {"respuesta": r, "correcta": correcta, "comentario": comentario}
        return {"indice": self.i, "correcta": correcta, "respuesta": r, "respuesta_correcta": p["correcta"],
                "explicacion": p["explicacion"], "comentario": comentario,
                "ultima": self.i == len(self.preguntas) - 1}

    def resultado(self):
        bien = sum(1 for r in self.respuestas if r and r["correcta"])
        total = len(self.preguntas)
        porcentaje = round(100 * bien / total) if total else 0
        nota = max(1, round(1 + 11 * bien / total)) if total else 1  # escala de 1 a 12 (como en Uruguay)
        errores = [{"enunciado": p["enunciado"], "tu_respuesta": (r or {}).get("respuesta", "(sin responder)"),
                    "correcta": p["correcta"], "explicacion": p["explicacion"]}
                   for p, r in zip(self.preguntas, self.respuestas) if not (r and r["correcta"])]
        return {"bien": bien, "total": total, "porcentaje": porcentaje, "nota": nota, "errores": errores,
                "minutos": round((time.time() - self.inicio) / 60, 1), "titulo": self.titulo, "tema": self.tema,
                "modo": self.modo}


def _limpiar(p):
    """Arregla lo que el modelo chico suele hacer mal. Devuelve la pregunta o None si no sirve."""
    if not p.get("enunciado") or not str(p.get("correcta", "")).strip():
        return None
    p["opciones"] = [re.sub(r"^\s*(?:[A-Da-d]|[1-4])\s*[).:\-]\s*", "", str(o)).strip() for o in (p.get("opciones") or [])]
    # "Según Wikipedia, ..." adelante de una opción delata cuál es la buena: se saca
    p["opciones"] = [re.sub(r"(?i)^(?:según|de acuerdo con|de acuerdo a)\s[^,]{1,30},\s*", "", o) for o in p["opciones"]]
    p["opciones"] = [o[:1].upper() + o[1:] for o in p["opciones"]]
    p["correcta"] = re.sub(r"(?i)^(?:según|de acuerdo con|de acuerdo a)\s[^,]{1,30},\s*", "", str(p.get("correcta", "")))
    p["correcta"] = p["correcta"][:1].upper() + p["correcta"][1:]
    # sin repetidas ni vacías, y sin basura que a veces se le escapa al modelo ('explicacion":', '{', 'undefined')
    p["opciones"] = [o for o in dict.fromkeys(p["opciones"])
                     if o and not re.search(r'":|[{}\[\]]|^\W+$|^(?:explicacion|correcta|enunciado|opciones|pista|'
                                            r'tipo|undefined|null)\b', jarvis.normalizar(o))]
    correcta = re.sub(r"^\s*(?:la |opcion )?([A-Da-d])\s*[).:\-]\s*", "", str(p["correcta"])).strip()
    letra = re.fullmatch(r"(?:la |opcion )?([A-Da-d])[).]?", str(p["correcta"]).strip())
    if letra and p["opciones"]:  # vino solo la letra: "B"
        idx = "abcd".index(letra.group(1).lower())
        correcta = p["opciones"][idx] if idx < len(p["opciones"]) else correcta
    p["correcta"] = correcta
    if p["tipo"] == "vf":
        p["opciones"] = ["Verdadero", "Falso"]
        p["correcta"] = "Verdadero" if jarvis.normalizar(correcta).startswith(("v", "si", "cierto")) else "Falso"
        e = p["enunciado"].strip()
        if re.match(r"¿?\s*(?:es falso que|no es (?:cierto|verdad) que)", jarvis.normalizar(e)):
            return None  # "¿Es falso que...?" confunde: mejor descartarla
        m = re.match(r"¿?\s*(?:es (?:verdadero|verdad|cierto) que|verdadero o falso:?)\s*(.+?)\??$", e, re.I)
        if m:  # "¿Es verdadero que X?" -> "X." (una afirmación, como corresponde)
            p["enunciado"] = m.group(1)[:1].upper() + m.group(1)[1:].rstrip(" ?.") + "."
        elif re.match(r"^¿.+\?$", e) and not re.match(r"^¿\s*(?:que|cual|cuales|quien|quienes|como|donde|cuando|cuanto|"
                                                       r"cuantos|cuanta|cuantas|por que)\b", jarvis.normalizar(e)):
            p["enunciado"] = e.strip("¿? ")[:1].upper() + e.strip("¿? ")[1:] + "."  # "¿La X es Y?" -> "La X es Y."
        p["enunciado"] = re.sub(r"\.{2,}$", ".", p["enunciado"])
    elif p["tipo"] == "corta" and len(p["opciones"]) >= 3 and correcta in p["opciones"]:
        p["tipo"] = "multiple"  # tenía opciones: mejor como opción múltiple
    elif p["tipo"] == "multiple":
        if len(p["opciones"]) < 2:
            p["tipo"], p["opciones"] = "corta", []
        elif correcta not in p["opciones"]:
            parecida = difflib.get_close_matches(correcta, p["opciones"], n=1, cutoff=0.6)
            if not parecida:
                return None  # la respuesta no es ninguna opción: pregunta rota
            p["correcta"] = parecida[0]
        if len(p["opciones"]) > 4:  # como mucho A-D, sin perder la correcta
            otras = [o for o in p["opciones"] if o != p["correcta"]][:3]
            p["opciones"] = [o for o in p["opciones"] if o == p["correcta"] or o in otras]
    if p["tipo"] == "corta":
        p["opciones"] = []
    # la pregunta no puede regalar la respuesta (copiar el dato tal cual como enunciado u opción)
    if p["tipo"] in ("multiple", "corta"):
        en, cn = jarvis.normalizar(p["enunciado"]), jarvis.normalizar(p["correcta"]).strip(" .")
        # una afirmación larga como "pregunta" de opción múltiple: es el dato copiado, no una pregunta
        if not re.search(r"[?:_]|\.\.\.", p["enunciado"]) and len(en.split()) > 9 and not re.match(
                r"(?:indica|elegi|elige|selecciona|nombre|numero|completa|cual|que|quien|cuanto|como|donde)\b", en):
            return None
        if len(cn) > 6 and cn in en:
            return None
        if any(difflib.SequenceMatcher(None, en, jarvis.normalizar(o)).ratio() > 0.8 for o in p["opciones"]):
            return None
    p["explicacion"] = re.sub(r"\b[Ss]egún tus apuntes\b", "Según el material", p.get("explicacion", ""))
    # la pista tampoco puede decir la respuesta
    cn = jarvis.normalizar(str(p["correcta"])).strip(" .")
    if p["tipo"] != "vf" and len(cn) > 2 and cn in jarvis.normalizar(p.get("pista") or ""):
        p["pista"] = "Releé la pregunta con calma y descartá primero las opciones que seguro no son."
    # se contradice sola ("...¡Error! El cálculo correcto es...")
    if re.search(r"\berror\b|\bcorrijo\b|\bme equivoque\b|\ben realidad\b|\bperdon\b", jarvis.normalizar(p.get("explicacion", ""))):
        return None
    return p


def _tiene_cuentas(p):
    return len(re.findall(r"\d", p["enunciado"])) >= 2


PROMPT_VERIFICAR = """Sos un profesor que revisa una pregunta de examen ANTES de tomarla.
1) "bien_planteada": true solo si la pregunta tiene UNA única respuesta correcta, no le falta ningún dato, la
   respuesta NO está ya escrita en el enunciado y sirve para estudiar (false si es rebuscada, sobre un detalle sin
   importancia, o usa una palabra suelta del texto fuera de contexto). Una afirmación de verdadero/falso tiene que afirmar una propiedad o
   un resultado que se pueda comprobar (no un dato suelto como "el primer término es 3").
2) Resolvela vos, paso a paso, breve y con cuidado ("pasos"), y escribí tu respuesta final ("respuesta_final"):
   si hay opciones, copiá el texto de la opción que elegís."""


PROMPT_VERIFICAR_LOTE = """Sos un profesor que revisa preguntas de examen ANTES de tomarlas. Para CADA pregunta numerada:
- "bien_planteada": true solo si tiene UNA única respuesta correcta, no le falta ningún dato, la respuesta NO está ya
  escrita en el enunciado y sirve para estudiar (false si es rebuscada o sobre un detalle sin importancia).
- "respuesta_final": resolvela vos (si hay opciones, copiá el texto EXACTO de la que elegís; en verdadero/falso,
  "Verdadero" o "Falso")."""


def verificar_lote(preguntas, material=""):
    """Todas las preguntas de una tanda en UNA sola llamada (antes, una por pregunta: la mitad del tiempo del quiz).
    Devuelve las aprobadas, o None si la respuesta no se pudo leer (y se revisan de a una)."""
    sistema_txt = PROMPT_VERIFICAR_LOTE
    if material:
        sistema_txt += ("\nResolvelas usando SOLO este MATERIAL DE REFERENCIA. Si el material no confirma cuál es la respuesta "
                        "correcta, \"bien_planteada\" = false.\n\nMATERIAL DE REFERENCIA:\n" + material)
    lista = "\n\n".join(f"{i + 1}. {p['enunciado']}" + "".join(f"\n   - {o}" for o in p["opciones"])
                        for i, p in enumerate(preguntas))
    try:
        r = jarvis.pedir_json(sistema_txt, lista, {
            "type": "object", "properties": {"revisiones": {"type": "array", "items": {
                "type": "object", "properties": {"numero": {"type": "integer"}, "bien_planteada": {"type": "boolean"},
                                                 "respuesta_final": {"type": "string"}},
                "required": ["numero", "bien_planteada", "respuesta_final"]}}},
            "required": ["revisiones"]}, temperatura=0.0, largo=60 + 45 * len(preguntas), modelo=MODELO_EXAMENES)
    except jarvis.Cancelado:
        raise
    except Exception:
        return None
    revisiones = {int(x.get("numero", 0)): x for x in r.get("revisiones", []) if isinstance(x, dict)}
    if len(revisiones) < len(preguntas) * 0.8:
        return None  # se salteó preguntas: mejor revisarlas de a una
    buenas = []
    for i, p in enumerate(preguntas, 1):
        x = revisiones.get(i)
        if not x:
            continue
        final = str(x.get("respuesta_final", ""))
        if not x.get("bien_planteada", True) and not (p["tipo"] == "vf" and _iguales(final, p["correcta"])):
            continue
        if p["opciones"]:
            elegida = difflib.get_close_matches(final, p["opciones"], n=1, cutoff=0.5)
            coincide = bool(elegida and elegida[0] == p["correcta"]) or _iguales(final, p["correcta"])
        else:
            coincide = _iguales(final, p["correcta"])
        if coincide:
            buenas.append(p)
    return buenas


def verificar_rapido(preguntas, material=""):
    """Las de cuentas, de a una y paso a paso (ahí el modelo chico se equivoca); el resto, todas juntas."""
    con_cuentas = [p for p in preguntas if _tiene_cuentas(p)]
    resto = [p for p in preguntas if not _tiene_cuentas(p)]
    aprobadas = verificar(con_cuentas, None, material) if con_cuentas else []
    if resto:
        lote = verificar_lote(resto, material)
        aprobadas += lote if lote is not None else verificar(resto, None, material)
    return [p for p in preguntas if p in aprobadas]  # en el orden original


def verificar(preguntas, tarea=None, material=""):
    """Cada pregunta se revisa por separado: la IA la resuelve como un alumno y juzga si está bien planteada.
    Si no está bien planteada o no le da la misma respuesta, se descarta (el modelo chico a veces se equivoca).
    Con material (internet o tu archivo), además la respuesta tiene que estar confirmada ahí."""
    sistema_txt = PROMPT_VERIFICAR
    if material:  # el material va en el mensaje del sistema, igual para todas: Ollama lo reusa y va más rápido
        sistema_txt += ("\n3) Resolvela usando SOLO este MATERIAL DE REFERENCIA. Si el material no confirma cuál es la "
                        "respuesta correcta, \"bien_planteada\" = false.\n\nMATERIAL DE REFERENCIA:\n" + material)
    buenas = []
    for k, p in enumerate(preguntas):
        if tarea:
            tarea.avance("Comprobando las respuestas" + (" con el material" if material else ""),
                         85 + int(13 * (k + 1) / len(preguntas)))
        opciones = "".join(f"\n- {o}" for o in p["opciones"])
        try:
            r = jarvis.pedir_json(sistema_txt, p["enunciado"] + (f"\nOpciones:{opciones}" if opciones else ""),
                                  {"type": "object", "properties": {"bien_planteada": {"type": "boolean"},
                                                                    "pasos": {"type": "string"},
                                                                    "respuesta_final": {"type": "string"}},
                                   "required": ["bien_planteada", "pasos", "respuesta_final"]},
                                  temperatura=0.0, largo=260, modelo=MODELO_EXAMENES)
        except jarvis.Cancelado:
            raise
        except Exception:
            buenas.append(p)  # si no se puede revisar, se deja
            continue
        final = str(r.get("respuesta_final", ""))
        # una afirmación FALSA nunca está "confirmada" en el material: si el revisor también dice Falso, sirve
        if not r.get("bien_planteada", True) and not (p["tipo"] == "vf" and _iguales(final, p["correcta"])):
            continue
        if p["opciones"]:
            elegida = difflib.get_close_matches(final, p["opciones"], n=1, cutoff=0.5)
            coincide = bool(elegida and elegida[0] == p["correcta"]) or _iguales(final, p["correcta"])
        else:
            coincide = _iguales(final, p["correcta"])
        if coincide:
            buenas.append(p)
    return buenas


def _numero(texto):
    t = texto.replace(",", ".").replace(" ", "")
    m = re.fullmatch(r"[-+]?\d+(?:\.\d+)?(?:/\d+)?", t)
    if not m:
        return None
    if "/" in t:
        a, b = t.split("/")
        return float(a) / float(b) if float(b) else None
    return float(t)


def _iguales(respuesta, esperada):
    a, b = jarvis.normalizar(respuesta).strip(" ."), jarvis.normalizar(esperada).strip(" .")
    a = re.sub(r"^(?:la respuesta es|es|da|el resultado es)\s+", "", a)
    if a == b or (len(b) > 3 and b in a and len(a) < len(b) * 2):
        return True
    na, nb = _numero(a), _numero(b)
    if na is not None and nb is not None:
        return abs(na - nb) <= max(1e-6, abs(nb) * 0.01)
    return difflib.SequenceMatcher(None, a, b).ratio() > 0.88


def _corregir_con_ia(pregunta, respuesta):
    try:
        r = jarvis.pedir_json(PROMPT_CORREGIR,
                              f"Pregunta: {pregunta['enunciado']}\nRespuesta correcta: {pregunta['correcta']}\n"
                              f"Respuesta del alumno: {respuesta}",
                              {"type": "object", "properties": {"correcta": {"type": "boolean"},
                                                                "comentario": {"type": "string"}},
                               "required": ["correcta", "comentario"]}, temperatura=0.0, largo=150)
        return bool(r.get("correcta")), (r.get("comentario") or "").strip()
    except Exception:
        return False, ""




# ======================= Crear =======================

def buscar_material(tema, tarea, usar_documento=False, n=8, usar_conversacion=False):
    """De dónde salen las preguntas: tu archivo, o internet (Wikipedia + buscador). Así no inventa datos.
    Para más preguntas hace falta más material (si no, no hay de dónde sacarlas). Devuelve (material, de_donde)."""
    largo = min(13000, 4500 + 450 * n)
    doc = jarvis.adjuntos.documento_activo
    if usar_documento and doc:
        jarvis.adjuntos.pendientes.clear()  # el archivo ya se usó para esto
        doc["cuando"] = time.time()  # mientras lo sigas usando, no se vence
        parte, _parte_pedida["texto"] = _parte_pedida["texto"], None
        if parte:
            return parte, "esa parte de tu texto"
        return doc["texto"][:largo + 2000], ("tu texto" if doc.get("pegado") else doc["nombre"])
    if MATEMATICA.search(jarvis.normalizar(tema)):
        if usar_conversacion:  # la explicación que te dio JARVIS sirve de referencia (así se detectan fórmulas mal)
            explicado = "\n\n".join(m["content"] for m in jarvis.historial[-12:] if m["role"] == "assistant"
                                    and len(m["content"]) > 200)[-6000:]
            if explicado:
                return explicado, "lo que hablamos"
        return "", ""
    tarea.avance("Buscando información en internet", 4)
    buscar = expandir_sigla(tema)
    try:
        # para quizzes largos, dos artículos completos (el segundo suele ser un subtema: más preguntas distintas)
        material, fuentes = jarvis.herramientas.material_web(buscar, largo, con_paginas=True, completos=2 if n > 10 else 1)
    except Exception:
        material, fuentes = "", []
    if not material and not jarvis.herramientas.hay_internet():
        # SOLO si no hay internet: se arma y se comprueba con el texto que pegaste (si habla de esto)
        vigente = jarvis.adjuntos.documento_vigente()
        if vigente and (vigente.get("pegado") or jarvis.adjuntos.palabras_en_documento(tema, vigente)):
            tarea.avance("Sin internet: uso el texto que me pasaste", 6)
            return vigente["texto"][:largo + 2000], "tu texto, porque no hay internet"
        return "", ""
    if not material:
        return "", ""
    # ¿el artículo es del tema? ("rdr2" encontraba un gen de plantas): si no comparte ninguna palabra, no sirve
    titulo = re.search(r"\[Wikipedia: ([^\]]+)\]", material)
    claves = {w for w in re.findall(r"[a-z0-9]{3,}", jarvis.normalizar(buscar))} - {"los", "las", "del", "una", "que"}
    if titulo and claves and not claves & set(re.findall(r"[a-z0-9]{3,}", jarvis.normalizar(titulo.group(1)))) and \
            not any(c in jarvis.normalizar(material[:1500]) for c in claves if len(c) > 3):
        return "", ""
    return material, ", ".join(fuentes[:2])


def expandir_sigla(tema):
    """'rdr2' -> 'Red Dead Redemption 2', 'gta' -> 'Grand Theft Auto' (para buscar el artículo correcto)."""
    tn = jarvis.normalizar(tema).strip()
    if not re.fullmatch(r"[a-z0-9 ]{2,9}", tn) or (len(tn) > 5 and not re.search(r"\d", tn) and " " not in tn):
        return tema
    gustos = "; ".join(r["texto"] for r in jarvis.memoria.todos()[:20])
    try:
        r = jarvis.pedir_json(
            "El usuario pidió un quiz sobre algo escrito con una sigla o abreviatura. Si lo es, decí el nombre completo "
            "(ej: rdr2 -> Red Dead Redemption 2; gta -> Grand Theft Auto; lol -> League of Legends; ww2 -> Segunda "
            "Guerra Mundial). Si no es una sigla, devolvelo igual." + (f" Datos del usuario: {gustos}" if gustos else ""),
            tema, {"type": "object", "properties": {"nombre_completo": {"type": "string"}}, "required": ["nombre_completo"]},
            temperatura=0.0, largo=30)
        completo = (r.get("nombre_completo") or "").strip(" .\"")
        return completo if 2 <= len(completo) <= 60 else tema
    except Exception:
        return tema


def crear(tema, modo="examen", n=None, nivel="media", usar_conversacion=False, enfocar_en=None, usar_documento=False):
    """Genera el examen con la IA (con la ruedita de progreso) y lo deja activo."""
    n = n or (PREGUNTAS_POR_DEFECTO if modo == "examen" else max(3, PREGUNTAS_POR_DEFECTO - 3))
    if nivel == "media":
        nivel = NIVEL_POR_DEFECTO
    jarvis.emitir("progreso", f"Dame un momento, estoy armando {'el quiz' if modo == 'examen' else 'la tarea'} de {tema}...")
    tarea = jarvis.Tarea("examen", tema)
    contexto = f"Tema: {tema}."
    if usar_conversacion and not usar_documento:
        contexto += "\nBasate en lo que se explicó en esta conversación:\n" + jarvis.conversacion_reciente(6000)
    if enfocar_en:
        contexto += "\nEnfocate en estos puntos donde el alumno se equivocó:\n" + enfocar_en
    try:
        material, de_donde = buscar_material(tema, tarea, usar_documento, n, usar_conversacion)
    except jarvis.Cancelado:
        tarea.fallar("Cancelado")
        return "Listo, cancelé el examen."
    de_la_charla = de_donde == "lo que hablamos"
    fuente = ("Wikipedia" if "wikipedia" in de_donde else "tu texto" if "tu texto" in de_donde else
              "tu archivo" if usar_documento else
              "lo que te expliqué" if de_la_charla else "internet")
    if de_la_charla:  # la explicación ya va como material: no repetirla
        contexto = contexto.split("\nBasate en lo que se explicó")[0]
    if material:
        contexto += "\n\nMATERIAL DE REFERENCIA:\n" + material
    try:
        preguntas, titulo = _generar_hasta(n, modo, nivel, contexto, material, fuente, tarea, usar_hechos=not de_la_charla)
    except jarvis.Cancelado:
        tarea.fallar("Cancelado")
        return "Listo, cancelé el quiz."
    except Exception as e:
        tarea.fallar("Error")
        return f"No pude armar el quiz: {e}"
    if not preguntas:
        tarea.fallar("Error")
        return "No me salieron bien las preguntas. Probá pedírmelo de nuevo, o con un tema más concreto."
    tarea.terminar("")
    examen = Examen(tema, modo, {"titulo": titulo or tema, "preguntas": []})
    examen.preguntas, examen.respuestas, examen.de_donde = preguntas, [None] * len(preguntas), de_donde
    examen.nivel = nivel
    guardar_quiz(examen)
    empezar(examen)
    tipo = "examen" if modo == "examen" else "tarea"
    faltaron = n - len(preguntas)
    return (f"¡Listo! Te armé {'un quiz' if tipo == 'examen' else 'una tarea'} de {len(preguntas)} preguntas "
            f"sobre {tema}" + (f" (con datos de {de_donde})" if de_donde else "") + "."
            + (f" Me pediste {n}, pero descarté {faltaron} que no pude comprobar que estuvieran bien." if faltaron > 0 else "")
            + " Respondé tocando las opciones o diciéndome «la b», «verdadero» o la respuesta. Si te trabás, pedime una pista.")


POR_TANDA = 7  # el modelo chico escribe bien hasta ~7-8 preguntas por vez (más no entra en su memoria)

PROMPT_HECHOS = """Del material, sacá {k} DATOS distintos e importantes para estudiar el tema: fechas, nombres, lugares,
cifras, causas, consecuencias, definiciones, características y comparaciones. Cada dato es UNA oración completa,
verdadera según el material y entendible sola (con el sujeto, nada de "esto" o "él"). Nada de datos repetidos ni de
datos triviales. Variá: que no sean todos sobre lo mismo."""
ESQUEMA_HECHOS = {"type": "object", "properties": {"hechos": {"type": "array", "items": {"type": "string"}}},
                  "required": ["hechos"]}


def _extraer_hechos(material, cantidad, tarea):
    """Lista de datos distintos del material: cada pregunta va a salir de un dato diferente (así no se repiten)."""
    hechos = []
    trozos = _partir(material, max(1, -(-cantidad // 10)))
    for i, trozo in enumerate(trozos):
        tarea.avance(f"Leyendo el material ({i + 1} de {len(trozos)})", 5 + int(10 * (i + 1) / len(trozos)))
        _sumar_hechos(hechos, trozo, min(14, -(-cantidad // len(trozos)) + 3))
    if len(hechos) < cantidad * 0.75:  # salieron pocos (a veces el modelo devuelve casi nada): una vuelta más
        _sumar_hechos(hechos, material[:7000], min(14, cantidad - len(hechos) + 3))
    return hechos


def _sospechosos(texto):
    """Lo que el modelo chico suele inventar: números (fechas, cifras) y nombres propios."""
    numeros = re.findall(r"\d{2,}", texto)
    nombres = [m.group(1) for m in re.finditer(r"(?<![.!?¿¡]\s)(?<!^)\b([A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}|[A-Z]{2,}[A-Za-z0-9-]*)",
                                                texto.strip())]
    return [jarvis.normalizar(x) for x in numeros + nombres]


def _anclado(texto, material_n):
    """True si cada número y nombre propio del texto aparece en el material (si no, lo sacó de memoria o lo inventó)."""
    return all(s in material_n for s in _sospechosos(texto))


def _sumar_hechos(hechos, trozo, k):
    """Le pide k datos de ese pedazo del material (de a poco: pedirle muchos juntos a veces devuelve casi nada) y
    suma los que no repiten a los que ya hay. Solo datos que estén en el material (números y nombres incluidos)."""
    prompt = PROMPT_HECHOS.format(k=k) + ("\nSOLO datos que estén ESCRITOS en el texto que te paso: nada de memoria. "
                                          "Si ya no quedan datos nuevos, devolvé menos (o ninguno).")
    if hechos:
        prompt += "\n\nYa tenés estos datos: sacá OTROS distintos.\n" + "\n".join(f"- {h}" for h in hechos[-25:])
    trozo_n = jarvis.normalizar(trozo)
    try:
        r = jarvis.pedir_json(prompt, trozo, ESQUEMA_HECHOS, temperatura=0.2, largo=max(700, 60 * k),
                              modelo=MODELO_EXAMENES)
    except (jarvis.Cancelado, jarvis.IAPausada):
        raise
    except Exception:
        return
    for h in r.get("hechos", []):
        h = str(h).strip()
        if 5 <= len(h.split()) <= 50 and _anclado(h, trozo_n) and not any(
                len(_palabras_clave(h) & _palabras_clave(x)) / max(1, len(_palabras_clave(h) | _palabras_clave(x))) > 0.5
                for x in hechos):
            hechos.append(h)


def _generar_hasta(n, modo, nivel, contexto, material, fuente, tarea, usar_hechos=True):
    """Genera de a tandas, verifica cada pregunta y repite hasta llegar a las n pedidas (o rendirse)."""
    buenas, titulo = [], None
    rondas = 0
    # Con material: primero se sacan datos distintos y cada pregunta sale de uno (el modelo chico, si no, repite
    # las mismas preguntas tanda tras tanda aunque se le pida que no)
    # (en matemática con la explicación de la charla no: ahí sirven más los ejercicios con cuentas)
    hechos = _extraer_hechos(material, int(n * 1.35) + 2, tarea) if material and n >= 4 and usar_hechos else []
    usados = 0
    base_contexto = contexto.split("\n\nMATERIAL DE REFERENCIA:\n")[0]
    recargados, sin_nada = False, 0
    while len(buenas) < n and rondas < 3 + n // 5:
        rondas += 1
        faltan = n - len(buenas)
        # algunas de más: la verificación descarta las dudosas (y en las tandas siguientes, más todavía)
        pedir = min(POR_TANDA + 2, faltan + max(2, faltan // 3) + (2 if buenas else 0))
        extra = ""
        if hechos and usados >= len(hechos) and not recargados:
            # se acabaron los datos: unos cuantos más (sin datos, el modelo chico repite las mismas preguntas)
            recargados = True
            tarea.avance(f"Buscando más datos en el material ({len(buenas)} de {n} listas)", 5 + int(90 * len(buenas) / n))
            _sumar_hechos(hechos, material[:7000], min(14, faltan + 4))
        if usados < len(hechos):
            tanda = hechos[usados:usados + pedir]
            usados += len(tanda)
            pedir = len(tanda)
            contexto = base_contexto + ("\n\nDATOS (hacé EXACTAMENTE una pregunta por cada dato, en el mismo orden; las "
                                        "opciones incorrectas tienen que ser falsas según el dato):\n"
                                        + "\n".join(f"{i + 1}. {h}" for i, h in enumerate(tanda)))
        else:
            contexto = base_contexto + ("\n\nMATERIAL DE REFERENCIA:\n" + material if material else "")
            if buenas:  # que no repita lo que ya preguntó
                extra = "\n\nYa hay estas preguntas (hacé OTRAS, sobre otros aspectos del tema):\n" + \
                        "\n".join(f"- {p['enunciado']}" for p in buenas)
        prompt = (PROMPT_EXAMEN if modo == "examen" else PROMPT_TAREA).format(n=pedir, nivel=nivel)
        if material:
            prompt += PROMPT_CON_MATERIAL.format(fuente=fuente)
            if "DATOS (" in contexto:
                prompt += PROMPT_DESDE_DATOS
        texto, esperado = "", 330 * pedir
        try:
            for parte in jarvis.chat_modelo([{"role": "system", "content": prompt},
                                              {"role": "user", "content": contexto + extra}],
                                             stream=True, esquema=ESQUEMA, modelo=MODELO_EXAMENES,
                                             temperature=0.3 if material else 0.4, num_predict=600 * pedir,
                                             repeat_penalty=1.08):
                texto += parte["message"]["content"]
                hecho = (len(buenas) + min(1.0, len(texto) / esperado) * faltan * 0.85) / n
                tarea.avance(f"Redactando preguntas ({len(buenas)} de {n} listas)", 5 + int(min(0.97, hecho) * 90))
        except (jarvis.Cancelado, jarvis.IAPausada):
            raise
        except Exception as e:  # una tanda que se trabó (p. ej. "token repeat limit") no tira abajo todo el quiz
            if os.environ.get("JARVIS_DEBUG"):
                print(f"[quiz] tanda {rondas}: falló ({e})")
            continue
        try:
            datos = json.loads(texto)
        except ValueError:
            if os.environ.get("JARVIS_DEBUG"):
                print(f"[quiz] tanda {rondas}: JSON roto ({len(texto)} letras)")
            continue
        titulo = titulo or datos.get("titulo")
        nuevas = [p for p in (_limpiar(p) for p in datos.get("preguntas", [])) if p]
        sin_repetir = []
        material_n = jarvis.normalizar(material) if material else ""
        for p in nuevas:  # sin repetidas (aunque estén dichas de otra forma), ni con las anteriores ni entre ellas
            igual = next((b for b in buenas + sin_repetir if _parecidas(p, b)), None)
            # con material, la pregunta tiene que hablar de algo que está ahí (no del ejemplo del prompt ni de memoria)
            fuera = material_n and (not any(w[:6] in material_n for w in _palabras_clave(p["enunciado"]))
                                    # la respuesta correcta (y el enunciado de un V/F) no pueden traer fechas ni
                                    # nombres que no estén en el material: eso es inventado
                                    or not _anclado(p["correcta"] + " " + (p["enunciado"] if p["tipo"] == "vf" else ""),
                                                    material_n))
            if os.environ.get("JARVIS_DEBUG") and (igual or fuera):
                print(f"    descartada ({'fuera del material' if fuera else 'repetida'}): {p['enunciado'][:70]}"
                      + (f"  ==  {igual['enunciado'][:60]}" if igual else ""))
            if not igual and not fuera:
                sin_repetir.append(p)
        nuevas = sin_repetir
        if not nuevas:  # repitió todo: otra tanda igual sería tiempo perdido (antes insistía hasta 7 veces)
            sin_nada += 1
            if sin_nada >= 2 or (not material and sin_nada >= 1 and buenas):
                break
            continue
        sin_nada = 0
        for p in nuevas:  # "según el texto" no le dice nada al alumno: se nombra la fuente
            p["enunciado"] = re.sub(r"^(?:¿\s*)?[Ss]egún (?:el|este) (?:texto|material),?\s*", lambda m: "¿" if "¿" in m.group(0) else "",
                                    p["enunciado"])
            p["enunciado"] = re.sub(r"^(¿?\s*)(\w)", lambda m: m.group(1) + m.group(2).upper(), p["enunciado"])
            p["explicacion"] = re.sub(r"\b[Ss]egún (?:el|este) (?:texto|material)", f"Según {fuente}", p["explicacion"])
            p["explicacion"] = re.sub(r"\b[Ee]l (?:texto|material) (indica|menciona|afirma|establece|dice|explica|señala|"
                                      r"describe|cuenta|aclara|muestra|habla de)",
                                      lambda m: f"{fuente[:1].upper() + fuente[1:]} {m.group(1)}", p["explicacion"])
        tarea.avance(f"Comprobando las respuestas ({len(buenas)} de {n} listas)",
                     5 + int(min(0.97, (len(buenas) + faltan * 0.9) / n) * 90))
        aprobadas = verificar_rapido(nuevas, material)
        if os.environ.get("JARVIS_DEBUG"):
            print(f"[quiz] tanda {rondas}: pedí {pedir}, llegaron {len(datos.get('preguntas', []))}, "
                  f"limpias y sin repetir {len(nuevas)}, aprobadas {len(aprobadas)}")
        buenas += aprobadas[:faltan]
    return buenas[:n], titulo


def _palabras_clave(texto):
    return {w for w in re.findall(r"[a-z0-9]+", jarvis.normalizar(texto)) if len(w) > 3} - {
        "cual", "cuales", "cuantos", "cuantas", "como", "donde", "cuando", "segun", "texto", "material", "nombre",
        "escribe", "indica", "principal", "aproximado", "aproximadamente", "verdadero", "falso", "tiene", "tienen"}


def _parecidas(a, b):
    """¿Preguntan lo mismo? ('¿Cuál es la fuente de energía del Sol?' y 'Nombre del proceso que da energía al Sol')"""
    ea, eb = jarvis.normalizar(a["enunciado"]), jarvis.normalizar(b["enunciado"])
    if difflib.SequenceMatcher(None, ea, eb).ratio() > 0.75:
        return True
    pa, pb = _palabras_clave(a["enunciado"]), _palabras_clave(b["enunciado"])
    if not pa or not pb:
        return False
    parecido = len(pa & pb) / len(pa | pb)
    if parecido >= 0.45:
        return True
    misma = a["tipo"] != "vf" and b["tipo"] != "vf" and (
        _iguales(a["correcta"], b["correcta"]) or _iguales(b["correcta"], a["correcta"]))
    # misma respuesta y algo de tema en común; o un V/F cuya afirmación contiene la respuesta de la otra
    respuesta_b = _palabras_clave(b["correcta"]) if b["tipo"] != "vf" else set()
    respuesta_a = _palabras_clave(a["correcta"]) if a["tipo"] != "vf" else set()
    return bool((misma and parecido >= 0.2) or (respuesta_b and respuesta_b <= pa and parecido >= 0.2) or
                (respuesta_a and respuesta_a <= pb and parecido >= 0.2))


def _partir(texto, cantidad):
    """Divide el material en 'cantidad' partes parecidas, cortando entre párrafos."""
    if cantidad <= 1:
        return [texto]
    parrafos = [p for p in texto.split("\n") if p.strip()]
    objetivo = len(texto) / cantidad
    partes, actual = [], ""
    for p in parrafos:
        if actual and len(actual) + len(p) > objetivo and len(partes) < cantidad - 1:
            partes.append(actual)
            actual = ""
        actual += p + "\n"
    if actual:
        partes.append(actual)
    partes = [p for p in partes if len(p) > 400]
    if len(partes) < cantidad and len(texto) > 800 * cantidad:  # casi sin párrafos (un texto pegado): por oraciones
        oraciones = re.split(r"(?<=[.!?])\s+", texto)
        partes, actual = [], ""
        for o in oraciones:
            if actual and len(actual) + len(o) > objetivo and len(partes) < cantidad - 1:
                partes.append(actual)
                actual = ""
            actual += o + " "
        if actual:
            partes.append(actual)
    return [p for p in partes if len(p) > 400] or [texto]


def empezar(examen):
    global activo
    with _lock:
        activo = examen
    jarvis.emitir("examen", {"accion": "iniciar", "titulo": examen.titulo, "total": len(examen.preguntas),
                             "modo": examen.modo, "tema": examen.tema, "fuente": getattr(examen, "de_donde", "")})
    mostrar_pregunta(leer=True, demora=0.6)  # después de "¡Listo! Te armé un quiz..."


# ======================= Quizzes guardados (para repetirlos) =======================

def _cargar_resultados():
    try:
        with open(ARCHIVO_RESULTADOS, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _guardar_resultados(lista):
    temporal = ARCHIVO_RESULTADOS + ".tmp"
    with open(temporal, "w", encoding="utf-8") as f:
        json.dump(lista[-200:], f, ensure_ascii=False, indent=1)
    os.replace(temporal, ARCHIVO_RESULTADOS)


def guardar_quiz(examen, resultado=None):
    """Guarda el quiz (con sus preguntas, para poder repetirlo) y, al terminar, la nota."""
    with _lock:
        lista = _cargar_resultados()
        previo = next((r for r in lista if r.get("id") == examen.id), None)
        datos = previo or {"id": examen.id, "fecha": datetime.datetime.now().isoformat(timespec="minutes")}
        datos.update(tema=examen.tema, titulo=examen.titulo, modo=examen.modo, total=len(examen.preguntas),
                     fuente=getattr(examen, "de_donde", ""), estado="en curso",
                     preguntas=[{k: p.get(k) for k in ("tipo", "enunciado", "opciones", "correcta", "explicacion", "pista")}
                                for p in examen.preguntas])
        if resultado:
            datos.update(estado="terminado", bien=resultado["bien"], porcentaje=resultado["porcentaje"],
                         nota=resultado["nota"], minutos=resultado["minutos"], errores=len(resultado["errores"]),
                         fecha_fin=datetime.datetime.now().isoformat(timespec="minutes"))
        if not previo:
            lista.append(datos)
        _guardar_resultados(lista)
    jarvis.emitir("quizzes_cambio", True)


def listar_quizzes():
    """Para la sección Quiz de la interfaz (lo más nuevo primero, sin las preguntas)."""
    salida = []
    for r in reversed(_cargar_resultados()):
        if not r.get("id"):
            continue
        salida.append({k: r.get(k) for k in ("id", "titulo", "tema", "modo", "fecha", "total", "bien", "porcentaje",
                                             "nota", "estado", "fuente")} | {"repetible": bool(r.get("preguntas"))})
    return salida[:60]


def borrar_quiz(id_):
    """La ✕ de un quiz en Archivos > Quiz: lo saca de la lista (y de tu progreso)."""
    lista = _cargar_resultados()
    quedan = [r for r in lista if r.get("id") != id_]
    if len(quedan) != len(lista):
        _guardar_resultados(quedan)
    return len(quedan) != len(lista)


def repetir(id_):
    """Vuelve a tomar un quiz guardado (las mismas preguntas, sin generarlas de nuevo)."""
    r = next((x for x in _cargar_resultados() if x.get("id") == id_ and x.get("preguntas")), None)
    if not r:
        return "Ese quiz no tiene las preguntas guardadas (es de antes de esta versión)."
    examen = Examen(r.get("tema", ""), r.get("modo", "examen"), {"titulo": r.get("titulo"), "preguntas": []})
    examen.preguntas = [dict(p) for p in r["preguntas"]]
    examen.respuestas = [None] * len(examen.preguntas)
    examen.de_donde = r.get("fuente", "")
    examen.id = r["id"]  # el mismo: al terminar se actualiza su nota
    empezar(examen)
    return f"Repetimos el quiz de {examen.tema}: {len(examen.preguntas)} preguntas. ¡Suerte!"


# ======================= El quiz en voz alta (se desactiva en Configuraciones > Quiz) =======================
LEER_EN_VOZ = True
_parar_voz = [threading.Event()]


def decir(texto, demora=0.0):
    """Lee en voz alta algo del quiz (la pregunta, la pista, la corrección). Lo nuevo corta lo que estaba leyendo
    (si respondés antes de que termine de leer las opciones, no tenés que esperar). demora: para que primero
    termine de decir otra cosa ("¡Listo! Te armé un quiz...")."""
    if not LEER_EN_VOZ or not texto:
        return
    _parar_voz[0].set()
    parar = _parar_voz[0] = threading.Event()

    def hablar():
        if demora:
            time.sleep(demora)
        if not parar.is_set():
            jarvis.hablar(texto, parar)
    threading.Thread(target=hablar, daemon=True).start()


def callar():
    _parar_voz[0].set()


def pregunta_para_voz(p):
    """'Pregunta 3 de 20. ¿Qué es...? a: ..., b: ...' (como se lee en voz alta)."""
    texto = f"Pregunta {p['indice'] + 1} de {p['total']}. {p['enunciado']}"
    if p["tipo"] == "vf":
        return texto + " ¿Verdadero o falso?"
    if p["opciones"]:
        texto += " " + " ".join(f"{'abcd'[i]}: {o}." for i, o in enumerate(p["opciones"]))
    return texto


def mostrar_pregunta(leer=False, demora=0.0):
    if not activo:
        return
    p = activo.pregunta()
    jarvis.emitir("examen", {"accion": "pregunta", **p})
    if leer:
        decir(pregunta_para_voz(p), demora)
    if not jarvis.oyentes:  # en la terminal se muestra como texto
        opciones = "".join(f"\n   {'abcd'[i]}) {o}" for i, o in enumerate(p["opciones"]))
        jarvis.aviso(f"Pregunta {p['indice'] + 1} de {p['total']}: {p['enunciado']}{opciones}")


# ======================= Durante el examen =======================

def responder(respuesta):
    if not activo:
        return "No hay ningún examen en curso. Pedime uno: «armame un examen de...»."
    callar()  # si todavía estaba leyendo las opciones, se calla: ya respondiste
    fb = activo.corregir(respuesta)
    if fb is None:
        jarvis.emitir("examen", {"accion": "reintentar"})  # la pantalla vuelve a habilitar las opciones
        return "No entendí cuál elegís. Decime la letra (a, b, c o d) o el texto de la opción."
    jarvis.emitir("examen", {"accion": "feedback", **fb})
    if fb["correcta"]:
        texto = "¡Bien! " + fb["explicacion"]
    else:
        texto = (f"No. La respuesta correcta es {fb['respuesta_correcta']}. "
                 + (fb["comentario"] + " " if fb["comentario"] else "") + fb["explicacion"])
    return texto + (" Esa era la última: decime «terminar» para ver tu nota." if fb["ultima"] else " Decime «siguiente».")


def siguiente(leer=False):
    """leer=True: desde el botón de la pantalla (la lee en voz alta). Por voz, la lee JARVIS con lo que devuelve."""
    if not activo:
        return None
    callar()
    if activo.i < len(activo.preguntas) - 1:
        activo.i += 1
        mostrar_pregunta(leer=leer)
        if LEER_EN_VOZ:
            return pregunta_para_voz(activo.pregunta())
        return f"Pregunta {activo.i + 1}: {activo.preguntas[activo.i]['enunciado']}"
    return terminar()


def pista():
    if not activo:
        return "No hay ningún examen en curso."
    callar()
    activo.pistas_usadas.add(activo.i)
    texto = activo.preguntas[activo.i]["pista"]
    jarvis.emitir("examen", {"accion": "pista", "indice": activo.i, "pista": texto})
    return "Pista: " + texto


def terminar():
    global activo
    with _lock:
        examen, activo = activo, None
    if not examen:
        return "No hay ningún examen en curso."
    res = examen.resultado()
    try:
        guardar_quiz(examen, res)
    except Exception:
        pass
    jarvis.emitir("examen", {"accion": "resultado", **res})
    ultimo_resultado.update(res)
    if res["bien"] == res["total"]:
        frase = "¡Perfecto, todas bien!"
    elif res["porcentaje"] >= 70:
        frase = "¡Muy bien!"
    elif res["porcentaje"] >= 50:
        frase = "Vas bien, pero hay cosas para repasar."
    else:
        frase = "Hay que repasar este tema, pero para eso está la práctica."
    return (f"{frase} Sacaste {res['bien']} de {res['total']} ({res['porcentaje']}%), un {res['nota']} de 12."
            + (" Si querés, decime «repasá mis errores» y te armo otro con lo que te costó." if res["errores"] else ""))


def repasar_errores():
    if not ultimo_resultado.get("errores"):
        return "No tengo errores para repasar. ¡Pedime otro examen!"
    puntos = "\n".join(f"- {e['enunciado']} (correcta: {e['correcta']})" for e in ultimo_resultado["errores"])
    return crear(ultimo_resultado["tema"], ultimo_resultado.get("modo", "examen"),
                 n=max(4, len(ultimo_resultado["errores"]) + 2), enfocar_en=puntos)


def mi_progreso():
    terminados = [r for r in _cargar_resultados() if r.get("bien") is not None]
    if not terminados:
        return "Todavía no terminaste ningún quiz conmigo."
    lineas = [f"- {r['fecha'][:10]} · {r['tema']}: {r['bien']}/{r['total']} ({r['porcentaje']}%)"
              + (f", un {r['nota']}" if r.get("nota") else "") for r in terminados[-6:]]
    return "Tus últimos quizzes:\n" + "\n".join(lineas) + "\n\nEstán todos en la sección Quiz de Archivos (los podés repetir)."


ultimo_resultado = {}
PREGUNTAS_POR_DEFECTO = 8  # se cambia en Configuraciones
NIVEL_POR_DEFECTO = "media"
MAXIMO_PREGUNTAS = 30


# ======================= Frases =======================
NUMEROS = {"un": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7, "ocho": 8,
           "nueve": 9, "diez": 10, "once": 11, "doce": 12, "trece": 13, "catorce": 14, "quince": 15,
           "dieciseis": 16, "diecisiete": 17, "dieciocho": 18, "diecinueve": 19, "veinte": 20, "veintiuno": 21,
           "veintidos": 22, "veinticinco": 25, "treinta": 30}
# "de 20 preguntas", "con quince preguntas", "20 preguntas" en cualquier parte de la frase
CANTIDAD = re.compile(r"(?:\s*,\s*|\s+)?(?:\b(?:de|con|y|unas?|que tenga|que sean)\s+)?\b(\d{1,2}|" +
                      "|".join(sorted(NUMEROS, key=len, reverse=True)) + r")\s+(?:preguntas|ejercicios|items|consignas)\b")
SUSTANTIVO = (r"(examen|examenes|pruebas?|evaluacion|quizz?e?s?|quis|tests?|cuestionarios?|parcial|simulacro|"
              r"ejercicios?|tareas? interactivas?|tarea|practica|preguntas)")
_NUM = "|".join(sorted(NUMEROS, key=len, reverse=True))
# lo que puede pedir el quiz: "hazme", "me haces", "dame", "quiero hacer", "empecemos", "¿podés armarme?"...
VERBO_PEDIR = (r"(?:arma|armame|armalo|hace|haceme|hazme|haz|hacer|hacerme|crea|creame|crear|prepara|preparame|genera|"
               r"generame|dame|da|pasame|tirame|mandame|tomame|toma|ponme|poneme|abrime|abreme|"
               r"(?:quiero|quisiera|necesito|preciso|me gustaria)(?: (?:hacer|tener|practicar con|un|una|"
               r"que me (?:armes|hagas|prepares|tomes|des|pases|tires)))|"
               r"me (?:haces|armas|das|preparas|tomas|creas|generas|pasas|tiras)|"
               r"(?:podes|puedes|podrias|podras) (?:armarme|hacerme|prepararme|tomarme|darme|crearme|pasarme|generarme)|"
               r"empeza|empezemos|empecemos|arranca|arranquemos|hagamos|vamos con|probemos)")
# entre el verbo y "quiz" solo pueden ir palabritas así (si no, "preciso estudiar para el examen" sería un pedido)
_ENTRE = (r"(?:\s+(?:me|un|una|unos|unas|el|la|los|las|otro|otra|nuevo|nueva|mini|lindo|linda|buen|rapido|rapida|"
          rf"corto|corta|chico|chica|\d{{1,2}}|{_NUM}))*")
CREAR = re.compile(rf"\b{VERBO_PEDIR}{_ENTRE}\s+{SUSTANTIVO}\b|^(?:un |una |el |otro |otra )?(?:\d{{1,2}} )?"
                   rf"(?:quiz|examen|prueba|cuestionario|test)\s+(?:de|sobre)\s+\S")
ADJETIVOS = re.compile(r"^(?:\s*(?:faciles|facil|dificiles|dificil|basicos|basico|avanzados|avanzado|cortos|corto|"
                       r"rapidos|rapido|simples|interactivos|interactiva|interactivo|practicos|completos|completo|"
                       r"nuevos?|nuevas?|de practica|para practicar|para repasar|,))+")
EVALUAME = re.compile(r"\b(?:evaluame|examiname|ponme a prueba|poneme a prueba)\s+(?:en|sobre|de)\s+(.+)$")
REFIERE_CHARLA = re.compile(r"\b(?:eso|esto|esto ultimo|lo mismo|lo que (?:\w+ )?(?:hablamos|hablabamos|hablando|vimos|"
                            r"me explicaste|me dijiste|me ensenaste|estudiamos)|lo anterior|lo de (?:recien|antes)|"
                            r"(?:este|ese|el mismo) tema|el tema de (?:recien|antes)|lo ultimo)\b")
REFIERE_ARCHIVO = re.compile(r"\b(?:archivo|documento|pdf|word|folleto|apuntes?|material|texto|guion|lectura|"
                             r"lo que dice|lo que te (?:pase|mande|di|adjunte|envie|pegue))\b")
# "otro quiz", "otra vez", "de nuevo": lo mismo que el anterior (si fue de tu texto, otra vez de tu texto)
OTRA_VEZ = re.compile(r"\b(?:otr[oa]s?|otra vez|de nuevo|nuevamente|mas preguntas|uno mas|repeti\w*)\b")
OTRO_QUIZ = re.compile(r"(?:(?:dame|haceme|hazme|armame|quiero|hace|haz|arma|y)\s+)?(?:otro|otra|uno mas|una mas)"
                       r"(?:\s+(?:quiz|examen|prueba|tarea|ronda|igual|mas|parecido|distinto|diferente|por favor))*"
                       r"|(?:(?:hace(?:lo|me)?|haz(?:lo|me)?|dale|quiero)\s+)?(?:otra vez|de nuevo)(?:\s+(?:el|un) (?:quiz|examen))?")
REABRIR = re.compile(r"^(?:(?:si|dale|ok|bueno|listo|ya)[\s,]*)?(?:empie?z\w*|empec\w*|arranc\w*|comien?z\w*|"
                     r"abri\w*|mostra\w*|vamos|dale|si|continu\w*|donde esta|no (?:lo )?veo|no aparece)"
                     r"(?:\s+(?:el|con el|la|con la|lo))?(?:\s+(?:quiz|examen|prueba|tarea|cuestionario))?$")
# "no, de lo que hablábamos": corrige el tema de un quiz que acabás de pedir
CORRIGE_TEMA = re.compile(r"^(?:no+[\s,.!]*)+(?:(?:de|sobre|del)\s+)?(?:eso|lo que (?:\w+ )?(?:hablamos|hablabamos|hablando|"
                          r"vimos|estudiamos)|el tema (?:de antes|de recien|que hablamos)|lo de (?:antes|recien))\b"
                          r"|^(?:no+[\s,.!]*)+(?:de|sobre)\s+(.+)$")
_ultimo_pedido = {"cuando": 0.0, "modo": "examen", "n": None}
_parte_pedida = {"texto": None}  # "la parte de la persona 4": el quiz sale solo de ahí


def _tema_y_cantidad(m_tema, m_cant1, m_cant2):
    n = None
    for c in (m_cant1, m_cant2):
        if c:
            n = int(c) if c.isdigit() else NUMEROS.get(c)
    return (m_tema or "").strip(" .?"), (min(max(n, 3), MAXIMO_PREGUNTAS) if n else None)


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    if activo:
        # --- Durante el examen ---
        if re.fullmatch(r"(?:dame una |una |la )?pista|ayuda|ayudame|no se|no tengo idea", t):
            return pista()
        if re.fullmatch(r"(?:la )?siguiente|sigamos|segui|proxima|otra pregunta|saltea(?:la)?|paso", t):
            return siguiente()
        if re.fullmatch(r"(?:termina\w*|finaliza\w*|corta\w*|basta|listo)(?: (?:el|la) (?:examen|prueba|tarea))?|"
                        r"(?:quiero )?(?:ver )?(?:mi )?nota", t):
            return terminar()
        if re.fullmatch(r"(?:repeti(?:la|me)?|repetime la pregunta|cual era la pregunta|lee(?:la|me la pregunta)?)", t):
            p = activo.pregunta()
            opciones = " ".join(f"{'abcd'[i]}: {o}." for i, o in enumerate(p["opciones"]))
            return f"Pregunta {p['indice'] + 1}: {p['enunciado']} {opciones}"
        m = re.fullmatch(r"(?:(?:es |elijo |me quedo con |creo que (?:es )?)?(?:la )?(?:opcion |respuesta )?([a-d])|"
                         r"(?:es )?(verdadero|falso)|(?:la respuesta es|respuesta|es|da)\s+(.+))", t)
        if m:
            return responder(m.group(1) or m.group(2) or jarvis.parte_original(texto, m.start(3)))
        # "sí, empezá", "dale", "abrilo": el quiz ya está armado -> se vuelve a mostrar (antes el chat inventaba uno en texto)
        if REABRIR.match(t):
            return reabrir()
    if re.search(r"\b(?:repasa|repasemos|practica)\w*\s+(?:mis|los)\s+errores\b", t):
        return repasar_errores()
    if re.search(r"\b(?:mi progreso|como vengo|mis notas|mis resultados|mis examenes|mis quiz\w*)\b", t):
        return mi_progreso()

    # "otro quiz", "otra vez", "uno más": como el anterior (si salió de tu texto, otra vez de tu texto)
    if OTRO_QUIZ.fullmatch(t) and time.time() - _ultimo_pedido["cuando"] < 2 * 3600:
        if activo:
            terminar_sin_nota()
        _ultimo_pedido["cuando"] = time.time()
        return crear_pedido(texto, _ultimo_pedido["modo"], "", _ultimo_pedido["n"], NIVEL_POR_DEFECTO)
    pedido = entender_pedido_quiz(texto, t)
    if pedido:
        _ultimo_pedido.update(cuando=time.time(), modo=pedido[0], n=pedido[2])
        return crear_pedido(texto, *pedido)
    # "no, de lo que hablábamos" / "no, de química": corrige el tema del quiz que acabás de pedir
    m = CORRIGE_TEMA.match(t)
    if m and time.time() - _ultimo_pedido["cuando"] < 300:
        tema = (jarvis.parte_original(texto, m.start(1)) or m.group(1)).strip(" .") if m.group(1) else ""
        if activo:
            terminar_sin_nota()
        return crear_pedido(texto, _ultimo_pedido["modo"], tema, _ultimo_pedido["n"], NIVEL_POR_DEFECTO)
    m = EVALUAME.search(t)
    if m:
        tema, n = sacar_cantidad(jarvis.parte_original(texto, m.start(1)).strip(" .?"))
        return crear(tema, n=n)
    return None


def entender_pedido_quiz(texto, t):
    """'bro hazme el quiz', 'dame una tarea interactiva de rdr2', 'quiero hacer un quiz de 15 preguntas de eso'
    -> (modo, tema, n, nivel), o None si no está pidiendo un quiz."""
    m = CREAR.search(t)
    if not m:
        return None
    sustantivo = m.group(1) or ""
    modo = "tarea" if re.match(r"ejercicio|tarea|practica", sustantivo) else "examen"
    n = cantidad_en(t)
    resto_n = t[m.end():] if m.group(1) else t[m.start():]
    # el tema: lo que viene después de "quiz" (sin adjetivos, cantidad ni "de"/"sobre")
    if m.group(1):
        resto = jarvis.parte_original(texto, m.end()) or resto_n
    else:  # "quiz de historia" (sin verbo)
        resto = re.sub(r"(?i)^.*?\b(?:quiz|examen|prueba|cuestionario|test)\b", "", jarvis.parte_original(texto, m.start()) or resto_n)
    resto, n2 = sacar_cantidad(resto.strip(" .,¿?¡!"))
    n = n or n2
    resto_n = jarvis.normalizar(resto)
    adj = ADJETIVOS.match(resto_n)
    if adj:  # "fáciles de ecuaciones" -> "de ecuaciones"
        resto = resto[adj.end():] if len(resto_n) == len(resto) else resto_n[adj.end():]
    tema =re.sub(r"(?i)^\s*(?:,\s*)?(?:sobre|de|del|de la|de los|de las|acerca de|para|con|en)\s+", "", resto or "").strip(" .,¿?¡!")
    tema = re.sub(r"(?i)^(?:el|la|los|las)\s+tema\s+(?:de\s+)?", "", tema)
    nivel = "alta" if re.search(r"\b(?:dificil\w*|avanzad\w*|complicad\w*)\b", t) else \
        "baja" if re.search(r"\b(?:facil\w*|basic\w*|simple\w*)\b", t) else NIVEL_POR_DEFECTO
    return modo, tema, n, nivel


def crear_pedido(texto, modo, tema, n, nivel):
    """Decide de dónde sale el tema (lo que dijiste, tu archivo o la charla) y arma el quiz."""
    tn = jarvis.normalizar(tema)
    doc = jarvis.adjuntos.documento_vigente()
    recien_adjuntado = any(a["tipo"] == "documento" for a in jarvis.adjuntos.pendientes)
    pegado = bool(doc and doc.get("pegado"))
    # "armame un quiz" / "de eso" sin decir de qué: el texto solo si lo estuvieron usando hace poco (si la charla
    # siguió con otro tema, el quiz es de ese tema)
    reciente = bool(doc) and jarvis.adjuntos._turno[0] - doc.get("usado", -99) <= 6
    otra_vez = bool(OTRA_VEZ.search(jarvis.normalizar(texto)))
    # el archivo o el texto que pegaste: si lo nombrás ("del texto", "de mis apuntes"), si lo acabás de pasar, si el
    # tema está en él ("de enzimas" con un guion de enzimas), o si pedís otro como el anterior que salió de ahí.
    # Así un quiz pedido un rato después sigue saliendo de TU texto, no de cualquier página de internet.
    usar_doc = doc and (
        (tema and REFIERE_ARCHIVO.search(tn))
        or (not tema and (recien_adjuntado or (pegado and reciente)))
        or (not tema and otra_vez and _ultimo_pedido.get("documento"))
        or (pegado and tema and REFIERE_CHARLA.search(tn) and len(tn.split()) <= 7 and reciente)
        or (pegado and tema and jarvis.adjuntos.palabras_en_documento(tema, doc)))
    if usar_doc:
        _ultimo_pedido["documento"] = True
        titulo = doc.get("tema") or os.path.splitext(doc["nombre"])[0].replace("_", " ")
        # "de la parte de la persona 4": el quiz sale SOLO de esa parte del texto
        parte = jarvis.adjuntos.seccion_del_texto(jarvis.normalizar(texto), doc["texto"])
        if parte and len(parte[0]) > 300:
            _parte_pedida["texto"] = parte[0]
            titulo = f"{parte[1]} ({titulo})"
        return crear(titulo, modo, n, nivel, usar_documento=True)
    _ultimo_pedido["documento"] = False
    if tema and REFIERE_ARCHIVO.search(tn) and not doc:
        return ("No tengo ningún texto ni archivo tuyo guardado. Pegá el texto en el chat (o arrastrá el archivo) y "
                "pedime el quiz de nuevo.")
    if not tema or (REFIERE_CHARLA.search(tn) and len(tn.split()) <= 7):
        # "hazme el quiz", "de eso", "de lo que hablábamos": el tema de lo ÚLTIMO que se habló
        tema_charla = ultimo_tema_de_charla()
        if tema_charla:
            return crear(tema_charla, modo, n, nivel, usar_conversacion=True)
        jarvis.esperar_complemento((texto.strip(" .,¿?¡!") + " de") if not tema else "armame un quiz de")
        return ("¿De qué tema hago el " + ("quiz" if modo == "examen" else "ejercicio") + "?"
                + ("" if n else " Si querés, decime también cuántas preguntas (por ejemplo: «la Segunda Guerra Mundial, "
                                f"15 preguntas»; si no, hago {PREGUNTAS_POR_DEFECTO})."))
    return crear(tema, modo, n, nivel)


def reabrir():
    """Vuelve a mostrar el quiz en curso (por si se cerró la ventana o pediste 'empezá')."""
    if not activo:
        return None
    jarvis.emitir("examen", {"accion": "iniciar", "titulo": activo.titulo, "total": len(activo.preguntas),
                             "modo": activo.modo, "tema": activo.tema, "fuente": getattr(activo, "de_donde", "")})
    mostrar_pregunta(leer=True, demora=0.6)
    return f"Ahí lo tenés en pantalla: vamos por la pregunta {activo.i + 1} de {len(activo.preguntas)}."


def cantidad_en(t):
    m = CANTIDAD.search(jarvis.normalizar(t))
    if not m:
        return None
    c = m.group(1)
    n = int(c) if c.isdigit() else NUMEROS.get(c)
    return max(3, min(MAXIMO_PREGUNTAS, n)) if n else None


def sacar_cantidad(tema):
    """('segunda guerra mundial de 20 preguntas') -> ('segunda guerra mundial', 20)."""
    if not tema:
        return tema, None
    n = cantidad_en(tema)
    norm = jarvis.normalizar(tema)
    if len(norm) == len(tema):
        m = CANTIDAD.search(norm)
        if m:
            tema = tema[:m.start()] + tema[m.end():]
    else:
        tema = CANTIDAD.sub("", norm)
    return tema.strip(" ,.;:-"), n


def ultimo_tema_de_charla():
    """Para 'hazme el quiz' o 'de eso': el tema de lo ÚLTIMO que se habló (si cambió de tema, manda el más nuevo).
    None si en la charla reciente no hay ningún tema de estudio."""
    with jarvis.lock:
        mensajes = [m for m in jarvis.historial[-11:] if not re.match(
            r"(?:¡?listo|te arme|no pude|no entendi|ahi lo tenes|mejor te lo armo)", jarvis.normalizar(m["content"][:40]))]
    # el pedido mismo ("hazme el quiz") no cuenta: si no, el "tema" sale de ahí ("preguntitas")
    while mensajes and mensajes[-1]["role"] == "user" and CREAR.search(jarvis.normalizar(mensajes[-1]["content"])) or \
            (mensajes and mensajes[-1]["role"] == "user" and re.search(r"\b(?:quiz|examen|prueba|preguntas?|preguntitas|"
                                                                        r"tarea|ejercicios)\b", jarvis.normalizar(mensajes[-1]["content"]))):
        mensajes.pop()
    if not mensajes:
        return None
    charla = "\n".join(f"{'Usuario' if m['role'] == 'user' else 'JARVIS'}: {m['content'][:700]}" for m in mensajes[-8:])
    try:
        r = jarvis.pedir_json(
            "Leé la conversación y decí cuál es el TEMA DE ESTUDIO o de conocimiento de lo MÁS RECIENTE que se habló "
            "(si cambiaron de tema, el último). Máximo 6 palabras, por ejemplo: \"progresiones aritméticas\". "
            "Ignorá los pedidos de quiz y los saludos. Si no se habló de ningún tema, devolvé tema vacío.",
            charla, {"type": "object", "properties": {"tema": {"type": "string"}}, "required": ["tema"]},
            temperatura=0.0, largo=30)
        tema = (r.get("tema") or "").strip(" .\"'")
    except Exception:
        return None
    if not tema or re.fullmatch(r"(?:ninguno|vacio|nada|saludo|quiz|examen|charla)", jarvis.normalizar(tema)) or \
            re.search(r"\b(?:quiz|examen|prueba|pdf|archivo|tarea|pedido|saludo|pregunt\w*|ejercicios?)\b",
                      jarvis.normalizar(tema)):
        return None
    return tema


def terminar_sin_nota():
    """Cierra el quiz en curso sin guardar nota (porque pediste otro)."""
    global activo
    with _lock:
        activo = None
    jarvis.emitir("examen", {"accion": "cerrar"})
