"""Abrir cualquier programa o juego de la PC: "abrí el Red Dead 2", "jugar a Among Us", "abrí CapCut".

Arma un índice de lo instalado y lo guarda en programas.json (Windows tarda ~5 s en listarlo, así que se arma en
segundo plano al arrancar y se renueva cada 12 horas, o al momento si pedís algo que no encuentra):
  - todas las apps del menú Inicio (también las de la Microsoft Store y Xbox),
  - los accesos directos del Escritorio (los juegos de Steam, Rockstar, Ubisoft... suelen estar ahí),
  - la biblioteca de Steam y la de Epic Games.
Solo abre cosas de ese índice (nunca una ruta escrita en el mensaje).
"""
import difflib
import glob
import json
import os
import re
import subprocess
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "programas.json")
RENOVAR_CADA = 12 * 3600
# cosas que no son para abrir (desinstaladores, ayudas, páginas web de los programas...)
NO_SIRVE = re.compile(r"uninstall|desinstal|readme|leeme|help|ayuda|manual|website|sitio web|release notes|license|"
                      r"licencia|redistributable|runtime|steamworks|proton|vcredist|directx|setup|instalador|repair|"
                      r"reparar|documentation|documentacion|changelog|crash reporter|benchmark")
SIN_SENTIDO = {"el", "la", "los", "las", "un", "una", "juego", "videojuego", "programa", "aplicacion", "app", "de", "al",
               "a", "mi", "el juego", "abri", "abre"}
ROMANOS = {"i": "1", "ii": "2", "iii": "3", "iv": "4", "v": "5", "vi": "6", "vii": "7", "viii": "8", "ix": "9", "x": "10"}
PRIORIDAD = {"steam": 4, "epic": 4, "escritorio": 3, "inicio": 2}  # si el mismo nombre está en varios lados

_lock = threading.Lock()
_indice = {"cuando": 0.0, "programas": []}
_ultima_renovacion = [0.0]  # para no rearmar el índice en cada pedido que no encuentra


# ---------------------------------------------------------------- armar el índice

def _norm(texto):
    t = jarvis.normalizar(texto) if jarvis else texto.lower()
    t = re.sub(r"[®™©:_\-–.,!'()\[\]]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def _de_inicio():
    """Todo lo del menú Inicio (incluye apps de la Store): (nombre, AppID)."""
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            "Get-StartApps | Select-Object Name, AppID | ConvertTo-Json -Compress"],
                           capture_output=True, text=True, timeout=40, creationflags=0x08000000, encoding="utf-8",
                           errors="replace")
        datos = json.loads(r.stdout or "[]")
    except Exception:
        return []
    if isinstance(datos, dict):
        datos = [datos]
    return [{"nombre": d["Name"], "tipo": "app", "destino": d["AppID"], "origen": "inicio"}
            for d in datos if d.get("Name") and d.get("AppID")]


def _escritorios():
    carpetas = {os.path.join(os.environ.get("PUBLIC", r"C:\Users\Public"), "Desktop")}
    try:
        import ctypes
        from ctypes import wintypes

        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(None, 0x10, None, 0, buf)  # el Escritorio de verdad (puede ser OneDrive)
        carpetas.add(buf.value)
    except Exception:
        carpetas.add(os.path.join(os.path.expanduser("~"), "Desktop"))
    return [c for c in carpetas if c and os.path.isdir(c)]


def _de_escritorio():
    salida = []
    for carpeta in _escritorios():
        for ruta in glob.glob(os.path.join(carpeta, "*.lnk")) + glob.glob(os.path.join(carpeta, "*.url")):
            salida.append({"nombre": os.path.splitext(os.path.basename(ruta))[0], "tipo": "archivo", "destino": ruta,
                           "origen": "escritorio"})
    return salida


def _de_steam():
    """Los juegos instalados en Steam (de todas las bibliotecas)."""
    raices = [os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), "Steam"),
              os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "Steam")]
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
            raices.insert(0, winreg.QueryValueEx(k, "SteamPath")[0])
    except Exception:
        pass
    bibliotecas = set()
    for raiz in raices:
        vdf = os.path.join(raiz, "steamapps", "libraryfolders.vdf")
        if os.path.exists(vdf):
            bibliotecas.add(os.path.join(raiz, "steamapps"))
            with open(vdf, encoding="utf-8", errors="replace") as f:
                for ruta in re.findall(r'"path"\s+"([^"]+)"', f.read()):
                    bibliotecas.add(os.path.join(ruta.replace("\\\\", "\\"), "steamapps"))
    juegos = []
    for biblioteca in bibliotecas:
        for acf in glob.glob(os.path.join(biblioteca, "appmanifest_*.acf")):
            try:
                with open(acf, encoding="utf-8", errors="replace") as f:
                    texto = f.read()
            except OSError:
                continue
            nombre = re.search(r'"name"\s+"([^"]+)"', texto)
            appid = re.search(r'"appid"\s+"(\d+)"', texto)
            if nombre and appid:
                juegos.append({"nombre": nombre.group(1), "tipo": "url", "destino": f"steam://rungameid/{appid.group(1)}",
                               "origen": "steam"})
    return juegos


def _de_epic():
    juegos = []
    carpeta = os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), "Epic", "EpicGamesLauncher", "Data", "Manifests")
    for item in glob.glob(os.path.join(carpeta, "*.item")):
        try:
            with open(item, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            continue
        if d.get("DisplayName") and d.get("AppName"):
            juegos.append({"nombre": d["DisplayName"], "tipo": "url", "origen": "epic",
                           "destino": f"com.epicgames.launcher://apps/{d['AppName']}?action=launch&silent=true"})
    return juegos


def armar_indice():
    """Junta todo, sin repetidos (si un juego está en Steam y en el Escritorio, queda el de Steam)."""
    inicio = _de_inicio()
    if not inicio:  # si Windows no contestó esta vez, se conservan las apps que ya estaban (no se pierden)
        with _lock:
            inicio = [p for p in _indice["programas"] if p["origen"] == "inicio"]
    todos = _de_steam() + _de_epic() + _de_escritorio() + inicio
    mejores = {}
    for p in todos:
        if NO_SIRVE.search(_norm(p["nombre"])):
            continue
        clave = _norm(p["nombre"])
        if clave not in mejores or PRIORIDAD[p["origen"]] > PRIORIDAD[mejores[clave]["origen"]]:
            mejores[clave] = p
    programas = sorted(mejores.values(), key=lambda p: p["nombre"].lower())
    with _lock:
        _indice.update(cuando=time.time(), programas=programas)
    try:
        with open(ARCHIVO, "w", encoding="utf-8") as f:
            json.dump(_indice, f, ensure_ascii=False, indent=1)
    except OSError:
        pass
    return programas


def indice(renovar=False):
    with _lock:
        if not _indice["programas"] and os.path.exists(ARCHIVO):
            try:
                with open(ARCHIVO, encoding="utf-8") as f:
                    _indice.update(json.load(f))
            except (OSError, ValueError):
                pass
        viejo = time.time() - _indice["cuando"] > RENOVAR_CADA
    if renovar or not _indice["programas"]:
        return armar_indice()
    if viejo:
        threading.Thread(target=armar_indice, daemon=True).start()  # se renueva sin hacerte esperar
    return _indice["programas"]


def preparar():
    """Al arrancar JARVIS: arma o renueva el índice en segundo plano."""
    threading.Thread(target=indice, daemon=True).start()


# ---------------------------------------------------------------- buscar

def _sigla(nombre_n):
    """'red dead redemption 2' -> 'rdr2'; 'grand theft auto v' -> 'gta5'."""
    partes = []
    for w in nombre_n.split():
        w = ROMANOS.get(w, w)
        partes.append(w if w.isdigit() else w[0])
    return "".join(partes)


def _puntaje(pedido, nombre):
    p, n = _norm(pedido), _norm(nombre)
    if not p:
        return 0
    if p == n:
        return 100
    p_num = " ".join(ROMANOS.get(w, w) for w in p.split())
    n_num = " ".join(ROMANOS.get(w, w) for w in n.split())
    if p_num == n_num:
        return 98
    compacto = p.replace(" ", "")
    if len(compacto) >= 2 and compacto in (_sigla(n), _sigla(n).rstrip("0123456789")):
        return 92  # "rdr2", "gta"
    if n_num.startswith(p_num + " ") or n.startswith(p + " "):
        return 88  # "far cry" -> "Far Cry 4"
    if len(p) >= 4 and (f" {p_num} " in f" {n_num} "):
        return 82  # "among" -> "Among Us"
    palabras_p, palabras_n = set(p_num.split()), set(n_num.split())
    comunes = palabras_p & palabras_n
    if comunes and len(comunes) == len(palabras_p):
        return 78
    parecido = difflib.SequenceMatcher(None, p_num, n_num).ratio()
    return int(parecido * 75)


def buscar(pedido, renovar_si_falta=True):
    """(mejor, parecidos): el programa que más se parece, y si hay empate, los candidatos para preguntar."""
    pedido = " ".join(w for w in _norm(pedido).split() if w not in SIN_SENTIDO)
    if not pedido:
        return None, []
    candidatos = sorted(((_puntaje(pedido, p["nombre"]), p) for p in indice()), key=lambda x: -x[0])
    if (not candidatos or candidatos[0][0] < 70) and renovar_si_falta and time.time() - _ultima_renovacion[0] > 600:
        _ultima_renovacion[0] = time.time()
        indice(renovar=True)  # quizás lo instalaste recién (como mucho una vez cada 10 minutos)
        return buscar(pedido, renovar_si_falta=False)
    if not candidatos or candidatos[0][0] < 70:
        return None, [p["nombre"] for s, p in candidatos[:3] if s >= 50]
    mejor = candidatos[0]
    empatados = [p for s, p in candidatos[1:4] if s >= 70 and s >= mejor[0] - 3]
    if empatados and mejor[0] < 95:
        return None, [mejor[1]["nombre"]] + [p["nombre"] for p in empatados]
    return mejor[1], []


def abrir(p):
    if p["tipo"] == "app":
        subprocess.Popen(["explorer.exe", f"shell:AppsFolder\\{p['destino']}"])
    else:
        os.startfile(p["destino"])  # acceso directo o steam://... (siempre del índice, nunca del mensaje)


def abrir_por_nombre(pedido):
    """Devuelve la respuesta para el usuario, o None si no encontró nada parecido."""
    mejor, parecidos = buscar(pedido)
    if mejor:
        abrir(mejor)
        es_juego = mejor["origen"] in ("steam", "epic") or mejor["destino"].startswith("steam://")
        return f"Abriendo {mejor['nombre']}." + (" ¡Que lo disfrutes!" if es_juego else "")
    if parecidos:
        return "¿Cuál querés abrir? Encontré: " + ", ".join(parecidos) + "."
    return None


def lista_de_juegos():
    juegos = [p["nombre"] for p in indice() if p["origen"] in ("steam", "epic") or p["destino"].startswith(("steam://", "com.epicgames"))
              or (p["origen"] == "escritorio" and p["destino"].lower().endswith(".url"))]
    return sorted(set(juegos))
