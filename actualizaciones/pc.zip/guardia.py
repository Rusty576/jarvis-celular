"""Guardia de vueltas: corta a un agente que se queda dando vueltas (de OpenJarvis: agents/loop_guard.py).

Tres cosas, como allá:
  1. la MISMA llamada (misma herramienta con lo mismo) repetida más de `max_iguales` veces;
  2. el ida y vuelta: A-B-A-B (o A-B-C-A-B-C) con lo mismo, que no avanza;
  3. demasiadas llamadas a una misma herramienta en una tarea (`presupuesto`).
La primera vez que detecta una vuelta solo avisa (`aviso`); si sigue trabado, frena (`seguir` = False). Así una repetición con sentido
(«pausá la música» después de «poné música» y otra vez «pausá») no se corta de entrada.
"""
import hashlib
import json
import re
from collections import deque


def _clave(nombre, args):
    try:
        texto = json.dumps(args, sort_keys=True, ensure_ascii=False)
    except (TypeError, ValueError):
        texto = str(args)
    texto = re.sub(r"\s+", " ", texto.lower()).strip()
    return hashlib.sha256(f"{nombre}:{texto}".encode()).hexdigest()[:16]


class Guardia:
    def __init__(self, max_iguales=2, ventana=6, presupuesto=8):
        self.max_iguales = max_iguales
        self.ventana = ventana
        self.presupuesto = presupuesto
        self._iguales = {}
        self._por_herramienta = {}
        self._secuencia = deque(maxlen=ventana * 2)
        self._avisados = set()

    def revisar(self, nombre, args=None):
        """{"seguir": bool, "aviso": bool, "motivo": str}. Anotá la llamada ANTES de hacerla."""
        ciclo, motivo = self._motivo(nombre, args)
        if not motivo:
            return {"seguir": True, "aviso": False, "motivo": ""}
        # la primera vuelta trabada, solo un aviso; la siguiente (sea la misma u otra: repetir A, repetir B, ida y
        # vuelta), frena. Con un aviso por cada tipo, un agente que alterna nunca llegaba a frenar
        if not self._avisados:
            self._avisados.add(ciclo)
            return {"seguir": True, "aviso": True, "motivo": motivo}
        return {"seguir": False, "aviso": False, "motivo": motivo}

    def _motivo(self, nombre, args):
        clave = _clave(nombre, args)
        self._iguales[clave] = self._iguales.get(clave, 0) + 1
        if self._iguales[clave] > self.max_iguales:
            return "igual:" + clave, f"repite «{nombre}» con lo mismo ({self._iguales[clave]} veces)"
        self._por_herramienta[nombre] = self._por_herramienta.get(nombre, 0) + 1
        if self.presupuesto and self._por_herramienta[nombre] > self.presupuesto:
            return "tope:" + nombre, f"usó «{nombre}» demasiadas veces ({self._por_herramienta[nombre]})"
        self._secuencia.append(clave)
        s = list(self._secuencia)
        for largo in (2, 3):  # A-B-A-B o A-B-C-A-B-C, con lo mismo: no avanza
            if len(s) >= 2 * largo and s[-largo:] == s[-2 * largo:-largo] and len(set(s[-largo:])) == largo:
                # (A-B y B-A son la misma vuelta)
                return "vaiven:" + "-".join(sorted(s[-largo:])), f"va y viene entre {largo} pasos sin avanzar"
        return "", ""
