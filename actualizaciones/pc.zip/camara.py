"""Webcam de JARVIS: le mostrás algo a la cámara y le preguntás ("¿qué tengo en la mano?", "¿de qué color es?").

La imagen la analiza la misma IA local (gemma3 sabe ver imágenes): no sale de la computadora.
Las fotos NO se guardan en el disco; solo se muestran chiquitas en el chat.
La cámara se prende cuando hace falta y se apaga sola a los 2 minutos sin preguntas.
"""
import base64
import re
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

APAGAR_SOLA = 120  # segundos sin preguntas antes de apagarse
CAMARA = 0  # si tenés varias cámaras, probá 1, 2...

PROMPT_VISION = """Estás viendo una foto de la webcam del usuario, tomada recién. Lo que ves es lo que EL USUARIO tiene o
muestra: hablale de vos ("tenés en la mano una banana", "estás usando una remera azul"), nunca digas "tengo".
Respondé lo que te pregunta sobre la imagen en español rioplatense (decí "banana", "auto", "celular"), en 1 a 3
oraciones, directo y concreto. Describí solo lo que realmente se ve.
Solo si de verdad NO podés responder (muy oscuro, muy borroso o tapado), pedí que lo acerque o mejore la luz; si se
entiende, no lo pidas. No inventes marcas, textos, nombres de personas ni detalles que no se vean."""

_lock = threading.Lock()
_cam = None
_ultimo_cuadro = None
_ultimo_uso = 0.0
_activa = threading.Event()


def activa():
    return _activa.is_set()


def _leer_continuo():
    """Mientras está prendida: guarda el último cuadro, lo muestra EN VIVO en la ventana (~8 por segundo)
    y se apaga sola si no se usa."""
    import cv2

    global _ultimo_cuadro
    while _activa.is_set():
        with _lock:
            if _cam is None:
                break
            ok, cuadro = _cam.read()
        if ok:
            _ultimo_cuadro = cuadro
            if jarvis.oyentes:
                vista = cv2.resize(cv2.flip(cuadro, 1), (384, 216))
                jpg = cv2.imencode(".jpg", vista, [cv2.IMWRITE_JPEG_QUALITY, 70])[1].tobytes()
                jarvis.emitir("camara_vivo", {"imagen": "data:image/jpeg;base64," + base64.b64encode(jpg).decode(),
                                              "estado": "en vivo"})
        if time.time() - _ultimo_uso > APAGAR_SOLA:
            apagar("Apagué la cámara porque no la estabas usando.")
            break
        time.sleep(0.12)


def prender():
    global _cam, _ultimo_uso
    import cv2

    _ultimo_uso = time.time()
    if _activa.is_set():
        return True
    with _lock:
        _cam = cv2.VideoCapture(CAMARA, cv2.CAP_DSHOW)
        if not _cam.isOpened():
            _cam = None
            return False
        _cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        _cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        for _ in range(8):  # los primeros cuadros salen oscuros mientras la cámara ajusta la luz
            _cam.read()
    _activa.set()
    threading.Thread(target=_leer_continuo, daemon=True).start()
    jarvis.emitir("camara_estado", True)
    return True


def mantener_prendida():
    """La videollamada la usa todo el tiempo: que no se apague sola por no tener preguntas."""
    global _ultimo_uso
    _ultimo_uso = time.time()


def apagar(aviso=None):
    global _cam, _ultimo_cuadro
    _activa.clear()
    with _lock:
        if _cam is not None:
            _cam.release()
        _cam = None
    _ultimo_cuadro = None
    jarvis.emitir("camara_estado", False)
    if aviso:
        jarvis.aviso(aviso)


def foto():
    """Saca una foto ahora. Devuelve (jpg para la IA, miniatura para el chat) o (None, None)."""
    import cv2
    import numpy as np

    global _ultimo_uso
    _ultimo_uso = time.time()
    if gestos_activos():  # la cámara la tiene el control por gestos: se la pide a él
        datos = _gestos.pedir_foto()
        if not datos:
            return None, None
        cuadro = cv2.imdecode(np.frombuffer(datos, np.uint8), cv2.IMREAD_COLOR)
    else:
        with _lock:
            if _cam is None:
                return None, None
            ok, cuadro = _cam.read()  # un cuadro nuevo, no el de hace un rato
        if not ok:
            cuadro = _ultimo_cuadro
    if cuadro is None:
        return None, None
    alto, ancho = cuadro.shape[:2]
    escala = 1024 / max(alto, ancho)
    para_ia = cv2.resize(cuadro, (int(ancho * escala), int(alto * escala))) if escala < 1 else cuadro
    miniatura = cv2.resize(cuadro, (480, int(480 * alto / ancho)))
    jpg = cv2.imencode(".jpg", para_ia, [cv2.IMWRITE_JPEG_QUALITY, 88])[1].tobytes()
    mini = cv2.imencode(".jpg", miniatura, [cv2.IMWRITE_JPEG_QUALITY, 75])[1].tobytes()
    return jpg, "data:image/jpeg;base64," + base64.b64encode(mini).decode()


# ---------- Control por gestos (gestos.py, en un proceso aparte) ----------

class Gestos:
    def __init__(self):
        self.proceso = None
        self.fotos = []
        self.foto_lista = threading.Event()

    def activo(self):
        return self.proceso is not None and self.proceso.poll() is None

    def prender(self):
        import os
        import subprocess
        import sys

        if self.activo():
            return "El control por gestos ya está activo."
        if activa():
            apagar()  # la cámara la va a usar gestos.py (no la pueden tener dos a la vez)
        python = sys.executable.replace("pythonw.exe", "python.exe")
        base = os.path.dirname(os.path.abspath(__file__))
        self.proceso = subprocess.Popen(
            [python, os.path.join(base, "gestos.py")], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8", bufsize=1, creationflags=0x08000000)
        listo = threading.Event()
        error = []
        threading.Thread(target=self._leer, args=(self.proceso, listo, error), daemon=True).start()
        jarvis.emitir("detalle", "Prendiendo el control por gestos...")
        if not listo.wait(40) or error:
            self.apagar()
            return f"No pude activar los gestos: {error[0] if error else 'tardó demasiado en arrancar'}."
        jarvis.emitir("camara_estado", True)
        jarvis.emitir("gestos_estado", True)
        return ("Control por gestos activado, como un touchpad: despacio es preciso y rápido cruza la pantalla. "
                "Si te quedás sin espacio, cerrá el puño, acomodá la mano al centro y seguí. Juntá bien pulgar e índice: "
                "clic, y si los mantenés juntos, arrastrás. Dos dedos levantados con la mano quieta un momento: "
                "scroll (subí o bajá la mano). Mano abierta y quieta unos segundos: pausa. "
                "Decime «desactivá los gestos» para terminar.")

    def _leer(self, proceso, listo, error):
        import json

        for linea in proceso.stdout:
            try:
                d = json.loads(linea)
            except ValueError:
                continue
            if d.get("listo"):
                listo.set()
            elif "error" in d:
                error.append(d["error"])
                listo.set()
            elif "vivo" in d:
                jarvis.emitir("camara_vivo", {"imagen": d["vivo"], "estado": "gestos: " + d.get("estado", "")})
            elif "foto" in d:
                self.fotos.append(base64.b64decode(d["foto"]))
                self.foto_lista.set()
            elif "gesto" in d:
                jarvis.emitir("detalle", f"Gesto: {d['gesto']}")
        if proceso is self.proceso:  # se cerró solo (o se cayó)
            self.proceso = None
            jarvis.emitir("gestos_estado", False)
            jarvis.emitir("camara_estado", False)

    def pedir_foto(self):
        if not self.activo():
            return None
        self.foto_lista.clear()
        self.proceso.stdin.write("foto\n")
        self.proceso.stdin.flush()
        if self.foto_lista.wait(5) and self.fotos:
            return self.fotos.pop()
        return None

    def apagar(self):
        p, self.proceso = self.proceso, None
        if p and p.poll() is None:
            try:
                p.stdin.write("salir\n")
                p.stdin.flush()
                p.wait(3)
            except Exception:
                p.kill()
        jarvis.emitir("gestos_estado", False)
        jarvis.emitir("camara_estado", False)


_gestos = Gestos()


def gestos_activos():
    return _gestos.activo()


def apagar_todo():
    """Apaga cámara y gestos (modo juego, apagar JARVIS)."""
    if gestos_activos():
        _gestos.apagar()
    if activa():
        apagar()


def mirar(pregunta):
    """Saca una foto y le pregunta a la IA sobre ella."""
    if not gestos_activos() and not prender():
        return "No pude prender la cámara. Fijate que ninguna otra app la esté usando (Zoom, Teams, la app Cámara)."
    jpg, miniatura = foto()
    if jpg is None:
        return "La cámara está prendida pero no me llega imagen. Probá de nuevo en un segundo."
    jarvis.emitir("camara_foto", {"imagen": miniatura, "pregunta": pregunta})
    jarvis.emitir("detalle", "Mirando la imagen...")
    try:
        r = jarvis.chat_modelo([{"role": "system", "content": PROMPT_VISION},
                                {"role": "user", "content": pregunta, "images": [jpg]}],
                               temperature=0.2, num_predict=200)
    except jarvis.IAPausada as e:
        return f"Ahora no puedo mirar: {e}."
    return r["message"]["content"].strip()


# ---------- Qué frases son para la cámara ----------
PRENDER = re.compile(r"\b(?:activa|activame|prende|prendeme|encende|enciende|abri|abre|usa|conecta|pone)\s+"
                     r"(?:la\s+)?(?:camara|webcam|cam)\b")
APAGAR = re.compile(r"\b(?:apaga|apagame|desactiva|cerra|corta|saca)\s+(?:la\s+)?(?:camara|webcam|cam)\b")
# Preguntas que siempre son para la cámara
VER_EXPLICITO = re.compile(
    r"\b(?:que ves|que estas viendo|que (?:se ve|ves) en la camara|mira(?:me)? (?:esto|lo que|que)|fijate (?:que|lo que) tengo|"
    r"que (?:tengo|hay|llevo) en (?:la|mi|las|mis) manos?|reconoce(?:me)? (?:esto|este|esta|lo que)|identifica(?:me)? (?:esto|este|esta)|"
    r"como me veo|que llevo puesto|que tengo puesto|que hay (?:atras|detras) (?:mio|de mi)|"
    r"(?:mira|fijate|decime) (?:con|por|en) la camara)\b")
# Preguntas que son para la cámara solo si está prendida ("¿y esto qué es?")
VER_SI_ACTIVA = re.compile(
    r"\b(?:que es esto|que es eso|y esto|y eso|de que color|que color|cuantos|cuantas|que dice|leeme|lee esto|"
    r"que marca|que tamano|es (?:un|una)|esta bien|que objeto|que animal|que planta|que fruta)\b")


GESTOS_ON = re.compile(r"\b(?:activa|activame|prende|prendeme|encende|pone|inicia|usa)\s+(?:el\s+|los\s+|la\s+)?"
                       r"(?:control (?:por|con) (?:gestos|la mano|las manos)|gestos|modo gestos|mouse con la mano)\b|"
                       r"^modo gestos$|\b(?:controla|mover|move|maneja)\s+(?:el\s+)?(?:mouse|cursor|la pantalla|las cosas)\s+"
                       r"con (?:la|mi|las|mis) manos?\b")
GESTOS_OFF = re.compile(r"\b(?:desactiva|desactivame|apaga|apagame|saca|corta|termina|frena)\s+(?:el\s+|los\s+)?"
                        r"(?:control (?:por|con) (?:gestos|la mano|las manos)|gestos|modo gestos)\b|^basta de gestos$")


AJUSTAR_GESTOS = re.compile(r"\b(?:gestos?|cursor|mouse|control por gestos)\b.*\b(?:mas|menos|muy)\s+"
                            r"(sensibles?|nerviosos?|rapidos?|lentos?|suaves?|tranquilos?|precisos?)\b|"
                            r"\bsensibilidad (?:de (?:los )?gestos )?(?:en|a) ([1-5])\b|\bvelocidad (?:del cursor )?(?:en|a) ([1-5])\b")


MODO_GESTOS = re.compile(r"\b(?:gestos?|cursor|mouse)\b.*\bmodo (absoluto|relativo|trackpad|touchpad|fijo|normal)\b|"
                         r"\bmodo (absoluto|relativo|trackpad|touchpad) (?:de |en |para )?(?:los )?gestos\b")


def cambiar_modo_gestos(t):
    import json
    import os

    m = MODO_GESTOS.search(t)
    palabra = m.group(1) or m.group(2)
    modo = "absoluto" if palabra in ("absoluto", "fijo") else "relativo"
    archivo = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gestos_config.json")
    try:
        with open(archivo, encoding="utf-8") as f:
            ajustes = json.load(f)
    except (OSError, ValueError):
        ajustes = {}
    ajustes["modo"] = modo
    with open(archivo, "w", encoding="utf-8") as f:
        json.dump(ajustes, f)
    if gestos_activos():
        try:
            _gestos.proceso.stdin.write("config\n")
            _gestos.proceso.stdin.flush()
        except Exception:
            pass
    if modo == "absoluto":
        return "Listo, modo absoluto: cada punto de la cámara es un punto fijo de la pantalla."
    return ("Listo, modo relativo: como un touchpad. Despacio es preciso, rápido cruza la pantalla, y con el puño "
            "cerrado acomodás la mano sin mover el cursor.")


def ajustar_gestos(t):
    """'gestos menos sensibles', 'cursor más rápido', 'sensibilidad de gestos en 1'. Se guarda y aplica al momento."""
    import json
    import os

    archivo = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gestos_config.json")
    try:
        with open(archivo, encoding="utf-8") as f:
            ajustes = json.load(f)
    except (OSError, ValueError):
        ajustes = {}
    ajustes.setdefault("sensibilidad", 2)
    ajustes.setdefault("velocidad", 2)
    m = AJUSTAR_GESTOS.search(t)
    if m.group(2):
        ajustes["sensibilidad"] = int(m.group(2))
    elif m.group(3):
        ajustes["velocidad"] = int(m.group(3))
    else:
        mas = re.search(r"\bmas\b", t) is not None
        palabra = m.group(1)
        if re.match(r"(?:rapido|lento)", palabra):
            ajustes["velocidad"] += 1 if (mas == palabra.startswith("rapido")) else -1
        else:  # sensible/nervioso suben la sensibilidad; suave/tranquilo/preciso la bajan
            sube = palabra.startswith(("sensible", "nervioso"))
            ajustes["sensibilidad"] += 1 if (mas == sube) else -1
    ajustes = {k: max(1, min(5, v)) for k, v in ajustes.items()}
    with open(archivo, "w", encoding="utf-8") as f:
        json.dump(ajustes, f)
    if gestos_activos():
        try:
            _gestos.proceso.stdin.write("config\n")
            _gestos.proceso.stdin.flush()
        except Exception:
            pass
    return (f"Listo: sensibilidad {ajustes['sensibilidad']} de 5 y velocidad {ajustes['velocidad']} de 5. "
            "Si sigue muy nervioso decime «gestos menos sensibles»; si te cuesta llegar a los bordes, «cursor más rápido».")


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    if MODO_GESTOS.search(t):
        return cambiar_modo_gestos(t)
    if AJUSTAR_GESTOS.search(t):
        return ajustar_gestos(t)
    if GESTOS_OFF.search(t):
        if not gestos_activos():
            return "El control por gestos no estaba activo."
        _gestos.apagar()
        return "Listo, desactivé el control por gestos y apagué la cámara."
    if GESTOS_ON.search(t):
        return _gestos.prender()
    if APAGAR.search(t):
        if gestos_activos():
            _gestos.apagar()
            return "Listo, apagué la cámara y el control por gestos."
        if not activa():
            return "La cámara ya estaba apagada."
        apagar()
        return "Listo, apagué la cámara."
    if PRENDER.search(t) and gestos_activos():
        return "La cámara ya está prendida (la está usando el control por gestos). Preguntame lo que quieras que mire."
    if PRENDER.search(t):
        pregunta = re.sub(PRENDER, "", t).strip(" ,y")
        if pregunta and len(pregunta.split()) >= 2:  # "prendé la cámara y decime qué tengo en la mano"
            return mirar(texto)
        if not prender():
            return "No pude prender la cámara. Fijate que ninguna otra app la esté usando (Zoom, Teams, la app Cámara)."
        _, miniatura = foto()
        if miniatura:
            jarvis.emitir("camara_foto", {"imagen": miniatura, "pregunta": ""})
        return ("Cámara activada. Mostrame algo y preguntame, por ejemplo: «¿qué tengo en la mano?» o "
                "«¿de qué color es esto?». Se apaga sola si no la usás, o decime «apagá la cámara».")
    if VER_EXPLICITO.search(t) or ((activa() or gestos_activos()) and VER_SI_ACTIVA.search(t)):
        return mirar(texto)
    return None
