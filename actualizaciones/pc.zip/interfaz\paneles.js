"use strict";
// Protocolos (botones hexagonales), música, secciones de Archivos, vista previa de código y configuraciones.
// Usa $, api, escapar, formatear, resaltar, plantilla, enviarTexto... de app.js

// ======================= PROTOCOLOS =======================
// Íconos de línea (viewBox 24x24) dentro de un hexágono del color de cada herramienta
const ICONOS = {
  documento: '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M9.5 11h6M9.5 14h6M9.5 17h4"/>',
  planilla: '<rect x="4" y="5" width="16" height="14" rx="1"/><path d="M4 10h16M4 14.5h16M10 5v14"/>',
  presentacion: '<path d="M3 4h18M5 4v10h14V4M12 14v3M8.5 20l3.5-3 3.5 3"/><path d="M8 11l2.5-2.5 2 2L16 7"/>',
  imagen: '<rect x="3.5" y="5" width="17" height="14" rx="1.5"/><circle cx="9" cy="10" r="1.6"/><path d="M5 17l4.5-4.5 3 3 2.5-2.5L19 17"/>',
  whatsapp: '<path d="M5 19l1.2-3.6A7.5 7.5 0 1 1 9 18.4z"/><path d="M9.5 9.5c.3 1.9 2.4 4 4.5 4.6l1-1.1 1.8.8"/>',
  correo: '<rect x="3.5" y="6" width="17" height="12" rx="1.5"/><path d="M4 7l8 6 8-6"/>',
  clima: '<circle cx="9" cy="9" r="3"/><path d="M9 3v1.5M3 9h1.5M4.8 4.8l1 1M13.2 4.8l-1 1"/><path d="M8 18h9a3 3 0 0 0 0-6 4.5 4.5 0 0 0-8.4 1.5A2.3 2.3 0 0 0 8 18z"/>',
  recordar: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  juego: '<path d="M7 8h10a4 4 0 0 1 3.8 5.3l-1 3a2 2 0 0 1-3.4.6L14.5 15h-5l-1.9 1.9a2 2 0 0 1-3.4-.6l-1-3A4 4 0 0 1 7 8z"/><path d="M8 10.5v3M6.5 12h3M15.5 11h.01M17 13h.01"/>',
  camara: '<path d="M4 8h3l1.5-2h7L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  gestos: '<path d="M8 13V6a1.4 1.4 0 0 1 2.8 0v5M10.8 10V4.8a1.4 1.4 0 0 1 2.8 0V10M13.6 10V6a1.4 1.4 0 0 1 2.8 0v5"/><path d="M16.4 9.5a1.4 1.4 0 0 1 2.8 0V14a7 7 0 0 1-7 7h-.5a6 6 0 0 1-5.2-3L4.4 15a1.4 1.4 0 0 1 2.3-1.6L8 15"/>',
  quiz: '<path d="M5 4h14v16H5z"/><path d="M8 9l1.2 1.2L11.5 8M8 15l1.2 1.2 2.3-2.2M13.5 9.5H16M13.5 15.5H16"/>',
  musica: '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
  codigo: '<path d="M8.5 7 3.5 12l5 5M15.5 7l5 5-5 5M13.5 4.5l-3 15"/>',
  precios: '<path d="M3.5 12.5 12 4h7.5v7.5L11 20z"/><circle cx="15.5" cy="8" r="1.5"/>',
  pensar: '<path d="M9.5 4.5a3 3 0 0 0-3 3 3 3 0 0 0-2 5.2 3.2 3.2 0 0 0 2.5 5.3 2.8 2.8 0 0 0 5 1V6a2.5 2.5 0 0 0-2.5-1.5zM14.5 4.5a3 3 0 0 1 3 3 3 3 0 0 1 2 5.2 3.2 3.2 0 0 1-2.5 5.3 2.8 2.8 0 0 1-5 1"/><path d="M12 9h2M12 13h2.5M7.5 10.5h1.5M8 15h1.5"/>',
  video: '<rect x="3" y="6" width="13" height="12" rx="1.5"/><path d="M16 10.5 21 7.5v9l-5-3z"/>',
  fiesta: '<circle cx="12" cy="13" r="6.5"/><path d="M12 3v3.5M5.6 13h12.8M12 6.5c-2.2 2-2.2 11 0 13M12 6.5c2.2 2 2.2 11 0 13M6.6 10h10.8M6.6 16h10.8"/><path d="M19 3.5l.7 1.3 1.3.7-1.3.7-.7 1.3-.7-1.3-1.3-.7 1.3-.7z"/>',
  // llamada y videollamada están en la barra de texto, al lado de "pensar más" (index.html)
  llamada: '<path d="M6.5 3.5h3l1.5 4.5-2 1.5a11 11 0 0 0 5.5 5.5l1.5-2 4.5 1.5v3a2 2 0 0 1-2 2A16 16 0 0 1 4.5 5.5a2 2 0 0 1 2-2z"/>',
  videollamada: '<rect x="3" y="6.5" width="12.5" height="11" rx="1.5"/><path d="M15.5 10.5 21 7.5v9l-5.5-3z"/><circle cx="9.2" cy="10.6" r="1.8"/><path d="M6.2 15.5a3.2 3.2 0 0 1 6 0"/>',
  pantalla: '<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M9 20h6M12 16v4"/><circle cx="12" cy="10" r="2.6"/><path d="M14 12l2 2"/>',
};

const PROTOCOLOS = [
  { id: "documento", nombre: "Documento", color: "#4f9dff", accion: () => plantilla("Creame un documento sobre "), ayuda: "Un Word sobre el tema que quieras" },
  { id: "planilla", nombre: "Planilla", color: "#3fe0a0", accion: () => plantilla("Creame un Excel de "), ayuda: "Un Excel con datos y cuentas" },
  { id: "presentacion", nombre: "Presentación", color: "#ff8a4c", accion: () => plantilla("Armame una presentación sobre "), ayuda: "Un PowerPoint listo para exponer" },
  { id: "imagen", nombre: "Imagen", color: "#c58bff", estado: "imagenes", accion: () => { plantilla("Creame una imagen de "); api("precargar_imagen"); }, ayuda: "Generar o editar imágenes" },
  { id: "musica", nombre: "Música", color: "#ff4f7b", accion: () => plantilla("Poné "), ayuda: "Poner música o videos de YouTube" },
  { id: "quiz", nombre: "Quiz", color: "#ff7ad9", accion: () => plantilla("Armame un quiz de "), ayuda: "Un quiz para practicar (podés decir cuántas preguntas)" },
  { id: "codigo", nombre: "Código", color: "#f2c94c", accion: () => plantilla("Haceme un programa en Python que "), ayuda: "Programas y páginas web (con vista previa)" },
  { id: "precios", nombre: "Precios", color: "#7ae9c8", accion: () => plantilla("¿Cuánto sale "), ayuda: "Comparar precios en tiendas de Uruguay" },
  { id: "whatsapp", nombre: "WhatsApp", color: "#3fe07a", accion: () => plantilla("Decile a "), ayuda: "Mandar un mensaje (siempre te pregunto antes)" },
  { id: "correo", nombre: "Correo", color: "#ff6b5a", estado: "gmail", accion: () => clicMails(), ayuda: "Revisar o mandar mails de Gmail" },
  { id: "fiesta", nombre: "Menea chapa", color: "#ff4fd8", boton: "boton-fiesta",
    accion: () => enviarTexto(fiestaActiva ? "Basta de fiesta" : "Menea tu chapa"),
    ayuda: "Modo fiesta: pongo «Menea tu chapa» y me pongo a bailar. Tocá de nuevo para cortar la fiesta" },
  { id: "pantalla", nombre: "Pantalla", color: "#ffd34d", boton: "boton-pantalla",
    accion: () => enviarTexto(pantallaCompartida ? "Dejá de compartir la pantalla" : "Compartí mi pantalla"),
    ayuda: "Compartí tu pantalla en vivo: preguntame lo que necesites sobre lo que estás haciendo. Tocá de nuevo para dejar de compartir" },
  { id: "recordar", nombre: "Recordar", color: "#7ab8ff", accion: () => plantilla("Recordame en 10 minutos "), ayuda: "Recordatorios y alarmas" },
  { id: "juego", nombre: "Modo juego", color: "#ffb547", boton: "boton-juego", ayuda: "Libera la compu para jugar",
    accion: () => enviarTexto(modoJuego ? "Desactivá el modo juego" : "Modo juego") },
  { id: "camara", nombre: "Cámara", color: "#ff7aa8", boton: "boton-camara", ayuda: "Que mire lo que le mostrás",
    accion: () => enviarTexto(camaraActiva ? "Apagá la cámara" : "Prendé la cámara") },
  { id: "gestos", nombre: "Gestos", color: "#ffe066", boton: "boton-gestos", ayuda: "Manejar el mouse con la mano",
    accion: () => enviarTexto(gestosActivos ? "Desactivá los gestos" : "Activá los gestos") },
];

function hexIcono(id, color) {
  return `<span class="hex" style="--c:${color}"><svg viewBox="0 0 24 24">${ICONOS[id] || ""}</svg></span>`;
}

function pintarProtocolos() {
  const caja = $("protocolos");
  caja.innerHTML = "";
  PROTOCOLOS.forEach((p, i) => {
    const b = document.createElement("button");
    if (p.boton) b.id = p.boton;
    b.className = "protocolo";
    b.style.setProperty("--c", p.color);
    b.style.animationDelay = (i * 35) + "ms";
    b.title = p.ayuda;
    b.innerHTML = `${hexIcono(p.id, p.color)}<span class="protocolo-nombre">${p.nombre}</span>`
      + (p.estado ? `<i class="protocolo-estado" data-servicio="${p.estado}"></i>` : "");
    b.dataset.ayuda = p.ayuda;
    b.onclick = p.accion;
    caja.appendChild(b);
  });
}
pintarProtocolos();

// ======================= MÚSICA =======================
let musica = {};

function eventoMusica(d) {
  musica = d || {};
  const barra = $("musica-barra");
  barra.hidden = !musica.modo;
  if (!musica.modo) return;
  $("musica-titulo").textContent = musica.titulo || "Cargando...";
  $("musica-canal").textContent = (musica.canal || "") + (musica.modo === "navegador" ? " · en tu navegador" : "");
  $("musica-volumen").textContent = musica.modo === "navegador" ? "" : (musica.volumen ?? 100) + "%";
  barra.classList.toggle("pausado", !!musica.pausado);
  $("musica-play").innerHTML = musica.pausado
    ? '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>'
    : '<svg viewBox="0 0 24 24"><path d="M8 5h3v14H8zM13 5h3v14h-3z"/></svg>';
  const pct = musica.duracion ? Math.min(100, 100 * (musica.actual || 0) / musica.duracion) : 0;
  $("musica-progreso").style.width = pct + "%";
}

function controlMusica(accion) {
  if (accion === "alternar") { musica.pausado = !musica.pausado; eventoMusica(musica); }
  api("musica_control", accion);
}

// ======================= ARCHIVOS POR SECCIÓN =======================
let seccionArchivos = "todo";
let ultimaListaArchivos = [];
const TIPOS_DOC = new Set(["word", "excel", "powerpoint", "pdf"]);

function filtrarArchivos(lista) {
  if (seccionArchivos === "imagen") return lista.filter((a) => a.tipo === "imagen");
  if (seccionArchivos === "doc") return lista.filter((a) => TIPOS_DOC.has(a.tipo));
  if (seccionArchivos === "codigo") return lista.filter((a) => a.tipo === "codigo");
  return lista.slice(0, 40);
}

// íconos chiquitos (los mismos de los protocolos) en las pestañas de Archivos
document.querySelectorAll("#pestanas-archivos button[data-icono]").forEach((b) => {
  b.insertAdjacentHTML("afterbegin", `<svg viewBox="0 0 24 24" class="pestana-icono">${ICONOS[b.dataset.icono] || ""}</svg>`);
});

document.querySelectorAll("#pestanas-archivos button").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll("#pestanas-archivos button").forEach((x) => x.classList.toggle("activa", x === b));
    seccionArchivos = b.dataset.seccion;
    if (seccionArchivos === "quiz") pintarQuizzes();
    else pintarArchivos(ultimaListaArchivos, false);
  };
});

function abrirCarpetaSeccion() {
  api("abrir_carpeta", { imagen: "imagenes", codigo: "codigo" }[seccionArchivos] || "documentos");
}

function abrirArchivo(a) {
  if (a.tipo === "codigo") abrirCodigoGuardado(a.ruta);
  else api("abrir", a.ruta);
}

async function pintarQuizzes() {
  const caja = $("archivos");
  const lista = (await api("quizzes")) || [];
  if (seccionArchivos !== "quiz") return;
  caja.innerHTML = lista.length ? "" : '<div class="vacio">Todavía no hiciste ningún quiz. Tocá el protocolo Quiz o decime «armame un quiz de...».</div>';
  for (const q of lista) {
    const fila = document.createElement("div");
    fila.className = "archivo quiz-fila";
    const terminado = q.estado === "terminado";
    const nota = terminado ? `<span class="quiz-nota ${q.porcentaje >= 70 ? "bien" : q.porcentaje >= 50 ? "medio" : "mal"}">${q.nota}</span>` : "";
    fila.innerHTML = `${badge("examen")}<span class="nombre">${escapar(q.tema || q.titulo || "Quiz")}
        <small>${q.total} preg. · ${terminado ? `${q.bien}/${q.total} bien` : "sin terminar"}</small></span>
      ${nota}<span class="accion-fila">${q.repetible ? "REPETIR" : ""}</span>
      <button class="borrar-fila" title="Borrar este quiz">✕</button>`;
    fila.title = q.repetible ? "Tocá para volver a hacerlo" : "Es de antes: no tiene las preguntas guardadas";
    if (q.repetible) fila.onclick = () => api("quiz_repetir", q.id);
    fila.querySelector(".borrar-fila").onclick = (e) => {
      e.stopPropagation();
      confirmarBorrado(e.currentTarget, async () => { await api("quiz_borrar", q.id); pintarQuizzes(); });
    };
    caja.appendChild(fila);
  }
}

// ======================= VISTA PREVIA DE CÓDIGO =======================
let codigoActual = { bloques: [], ruta: null };
const LENGUAJES_WEB = new Set(["html", "htm", "css", "js", "javascript"]);

function armarPagina(bloques) {
  // junta HTML + CSS + JS (de la misma respuesta) en una sola página
  let html = bloques.filter((b) => b.lenguaje === "html" || b.lenguaje === "htm").map((b) => b.codigo).join("\n");
  const css = bloques.filter((b) => b.lenguaje === "css").map((b) => b.codigo).join("\n");
  const js = bloques.filter((b) => b.lenguaje === "js" || b.lenguaje === "javascript").map((b) => b.codigo).join("\n");
  if (!html) html = "<!doctype html><html><head><meta charset='utf-8'></head><body></body></html>";
  if (css) html = /<\/head>/i.test(html) ? html.replace(/<\/head>/i, `<style>${css}</style></head>`) : `<style>${css}</style>` + html;
  if (js) html = /<\/body>/i.test(html) ? html.replace(/<\/body>(?![\s\S]*<\/body>)/i, `<script>${js}<\/script></body>`) : html + `<script>${js}<\/script>`;
  return html;
}

function mostrarCodigo(d) {
  codigoActual = { bloques: d.bloques || [], ruta: d.ruta || null };
  $("codigo-titulo").textContent = d.titulo || "Código";
  const web = codigoActual.bloques.some((b) => LENGUAJES_WEB.has(b.lenguaje));
  $("pestana-previa").hidden = !web;
  $("codigo-fuente").innerHTML = codigoActual.bloques.map((b) =>
    `<div class="codigo"><div class="codigo-cabeza"><span>${escapar(b.lenguaje || "código")}</span>`
    + `<button type="button" onclick="copiarCodigo(this)">COPIAR</button></div><pre><code>${resaltar(b.codigo, b.lenguaje)}</code></pre></div>`).join("");
  $("boton-editor").hidden = !codigoActual.ruta;
  $("boton-guardar-codigo").hidden = !!codigoActual.ruta;
  $("boton-recargar").hidden = !web;
  $("codigo-ayuda").textContent = web ? "La página corre aislada: no puede tocar tu compu."
    : "Este lenguaje no se puede ver funcionando acá: copialo o guardalo y correlo en tu compu.";
  verVistaCodigo(web ? "previa" : "codigo");
  if (web) recargarPrevia();
  $("modal-codigo").hidden = false;
}

function verVistaCodigo(vista) {
  document.querySelectorAll("#pestanas-codigo button").forEach((b) => b.classList.toggle("activa", b.dataset.vista === vista));
  $("codigo-iframe").hidden = vista !== "previa";
  $("codigo-fuente").hidden = vista !== "codigo";
}
document.querySelectorAll("#pestanas-codigo button").forEach((b) => { b.onclick = () => verVistaCodigo(b.dataset.vista); });

function recargarPrevia() {
  $("codigo-iframe").srcdoc = armarPagina(codigoActual.bloques);
}

function cerrarCodigo() {
  $("modal-codigo").hidden = true;
  $("codigo-iframe").srcdoc = ""; // corta la página (por si tenía animaciones o sonido)
}

function copiarTodoElCodigo() {
  const texto = codigoActual.bloques.map((b) => b.codigo).join("\n\n");
  navigator.clipboard.writeText(texto).then(() => {
    $("boton-copiar-todo").textContent = "✓ COPIADO";
    setTimeout(() => ($("boton-copiar-todo").textContent = "COPIAR"), 1500);
  });
}

function abrirCodigoEnEditor() {
  if (codigoActual.ruta) api("abrir_en_editor", codigoActual.ruta);
}

async function abrirCodigoGuardado(ruta) {
  const d = await api("leer_codigo", ruta);
  if (d) mostrarCodigo(d);
}

// Vista previa desde el bloque de código del chat
function previaDesdeChat(boton) {
  const msg = boton.closest(".msg");
  const bloques = [...msg.querySelectorAll(".codigo")].map((c) => ({
    lenguaje: (c.querySelector(".codigo-cabeza span").textContent || "").toLowerCase(),
    codigo: c.querySelector("code").innerText,
  }));
  mostrarCodigo({ titulo: "Código de la respuesta", bloques });
}

// ======================= CONFIGURACIONES =======================
const NOMBRES_OPCION = { jarvis: "Ventana de JARVIS (con controles)", navegador: "Mi navegador", baja: "Fácil", media: "Media", alta: "Difícil",
  local: "Gemma en tu PC (predeterminado, sin internet)", nube: "IA en la nube (todas las respuestas)",
  sin_internet: "Google; sin internet, en la compu", siempre: "Siempre en la compu (privado)", nunca: "Solo Google",
  ninguno: "Por tu nombre (sin señor/señora)", "señor": "Señor", "señora": "Señora",
  azul: "Azul JARVIS (el de siempre)", oscuro: "Oscuro (negro, como la píldora)",
  celeste: "Normal (celeste)", blanco: "Blanca", halloween: "Halloween", navidad: "Navidad", temporada: "Según la fecha" };
const GRUPOS_AJUSTES = [
  ["Cerebro de IA", ["cerebro", "modelo", "nube", "modelo_gemini", "modelo_groq", "modelo_nvidia"]],
  ["Automejora", ["automejora_sola", "automejora_nube"]],
  ["Voz y micrófono", ["tratamiento", "voz_local", "teclas_hablar", "voz_activada", "velocidad_voz", "sonidos", "manos_libres_al_iniciar", "sensibilidad_mic", "silencio_fin"]],
  ["Respuestas", ["verificar_internet", "ciudad"]],
  ["Quiz", ["quiz_preguntas", "quiz_nivel", "quiz_voz"]],
  ["Música", ["musica_en", "barra_musica", "barra_auto"]],
  ["Tu día", ["registro_actividad", "rutinas", "consejos_solos"]],
  ["Celular", ["celular_actividad", "celular_ias"]],
  ["Apariencia", ["tema", "pildora", "pildora_look", "pildora_seguir", "pildora_opacidad"]],
  ["Sistema", ["modo_juego_auto", "inicio_con_windows"]],
];

async function abrirAjustes() {
  const [campos, cx] = await Promise.all([api("ajustes_datos"), api("conexiones")]);
  if (!campos) return;
  if (cx) conexiones = cx;
  pintarCuentas();
  pintarAjustes(campos);
  $("modal-ajustes").hidden = false;
}

function cerrarAjustes() { $("modal-ajustes").hidden = true; }

function pintarAjustes(campos) {
  const porClave = Object.fromEntries(campos.map((c) => [c.clave, c]));
  $("ajustes-cuerpo").innerHTML = GRUPOS_AJUSTES.map(([titulo, claves]) => `
    <section class="ajustes-grupo"><h3>${titulo}</h3>${claves.filter((k) => porClave[k]).map((k) => campoAjuste(porClave[k])).join("")}</section>`).join("");
  $("ajustes-cuerpo").querySelectorAll("[data-clave]").forEach((el) => {
    const evento = el.type === "range" ? "input" : "change";
    el.addEventListener(evento, () => {
      const salida = el.parentElement.querySelector("output");
      if (salida) salida.textContent = el.value;
    });
    el.addEventListener("change", () => guardarAjuste(el));
  });
}

function campoAjuste(c) {
  let control;
  if (c.tipo === "bool") {
    control = `<label class="ajuste-switch"><input type="checkbox" data-clave="${c.clave}" ${c.valor ? "checked" : ""}><span></span></label>`;
  } else if (c.tipo === "rango") {
    const [min, max] = c.extra;
    const paso = max - min <= 3 ? 0.1 : 1;
    control = `<span class="ajuste-rango"><input type="range" data-clave="${c.clave}" min="${min}" max="${max}" step="${paso}" value="${c.valor}"><output>${c.valor}</output></span>`;
  } else if (c.tipo === "opcion") {
    const opciones = (c.extra && c.extra.length ? c.extra : [c.valor]);
    control = `<select data-clave="${c.clave}">${opciones.map((o) =>
      `<option value="${escapar(String(o))}" ${o === c.valor ? "selected" : ""}>${escapar((c.nombres && c.nombres[o]) || NOMBRES_OPCION[o] || String(o))}</option>`).join("")}</select>`;
  } else {
    control = `<input type="text" data-clave="${c.clave}" value="${escapar(String(c.valor || ""))}" placeholder="(automático)" spellcheck="false">`;
  }
  return `<div class="ajuste"><span class="ajuste-texto">${escapar(c.texto)}</span>${control}</div>`;
}

async function guardarAjuste(el) {
  const valor = el.type === "checkbox" ? el.checked : el.type === "range" ? Number(el.value) : el.value;
  $("ajustes-estado").textContent = "Guardando...";
  const campos = await api("ajustes_guardar", { [el.dataset.clave]: valor });
  $("ajustes-estado").textContent = campos ? "✓ Guardado" : "No se pudo guardar";
  setTimeout(() => ($("ajustes-estado").textContent = ""), 1800);
  if (el.dataset.clave === "voz_activada") marcar("sw-voz", valor);
  if (el.dataset.clave === "modelo") $("modelo").textContent = valor;
  // elegir un cerebro cambia otras opciones (la nube de «pensar más», qué modelos se ven): se vuelve a dibujar
  if (campos && ["cerebro", "nube", "modelo"].includes(el.dataset.clave)) pintarAjustes(campos);
}

// ======================= CHATS: las charlas separadas (chats.py) =======================
async function abrirChats() {
  pintarChats((await api("chats")) || []);
  $("modal-chats").hidden = false;
}

function cerrarChats() { $("modal-chats").hidden = true; }

function pintarChats(lista) {
  const caja = $("chats-lista");
  caja.innerHTML = lista.map((c) => `
    <div class="chat-item${c.actual ? " actual" : ""}" data-id="${escapar(c.id)}" title="${c.actual ? "La charla de ahora" : "Volver a esta charla"}">
      <div class="chat-item-texto">
        <div class="chat-item-titulo">${escapar(c.titulo || "Charla nueva")}</div>
        <div class="chat-item-info">${c.actual ? "AHORA · " : ""}${escapar(c.cuando)} · ${c.mensajes} mensajes</div>
      </div>
      ${c.actual ? "" : '<button class="chat-borrar" title="Borrar esta charla">✕</button>'}
    </div>`).join("");
  caja.querySelectorAll(".chat-item:not(.actual)").forEach((el) => {
    el.addEventListener("click", (e) => {
      if (e.target.closest(".chat-borrar")) return;
      cerrarChats();
      api("chat_abrir", el.dataset.id);
    });
    const borrar = el.querySelector(".chat-borrar");
    borrar.addEventListener("click", (e) => {
      e.stopPropagation();
      confirmarBorrado(borrar, async () => { await api("chat_borrar", el.dataset.id); abrirChats(); });
    });
  });
}

async function nuevoChat() { cerrarChats(); await api("chat_nuevo"); }

function eventoChatNuevo(d) {
  if (d && d.motivo === "pausa") {
    // pasó un rato: lo de antes queda arriba, y la raya va justo antes de lo que acabás de mandar
    const ultimo = chat.lastElementChild;
    separador("Charla nueva · la anterior quedó en Chats");
    if (ultimo) chat.insertBefore(chat.lastElementChild, ultimo);
    return;
  }
  chat.innerHTML = "";
  separador("Charla nueva");
}

function eventoChatCargado(d) {
  chat.innerHTML = "";
  separador(d.titulo || "Charla");
  d.mensajes.forEach((m) => agregarMensaje(m.role === "user" ? "usuario" : "jarvis", m.content, { animar: false }));
}

// Esc cierra la vista previa, las configuraciones y los pendientes
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!$("modal-chats").hidden) { e.stopPropagation(); cerrarChats(); return; }
  if (!$("modal-codigo").hidden) { e.stopPropagation(); cerrarCodigo(); }
  else if (!$("modal-ajustes").hidden) { e.stopPropagation(); cerrarAjustes(); }
  else if (!$("modal-pendientes").hidden) { e.stopPropagation(); cerrarPendientes(); }
  else if (!$("modal-finanzas").hidden) { e.stopPropagation(); cerrarFinanzas(); }
}, true);

// ======================= CONEXIONES (Gmail e imágenes): los botones cambian solos =======================
let conexiones = { gmail: { conectado: false, usuario: "" }, imagenes: { local: false, pollinations: false, motor: "", calidad: "baja" },
                   nube: { clave: false, proveedor: "", nombre: "", cerebro: "local", nubes: [] } };

function eventoConexiones(d) {
  if (!d) return;
  const recienConectado = d.gmail.conectado && !conexiones.gmail.conectado;
  conexiones = d;
  if (recienConectado) refrescarHoy();  // apenas conectás Gmail, aparecen tus mails sin leer
  const g = $("gmail-estado");
  g.textContent = d.gmail.conectado ? "Conectado" : "Sin conectar";
  g.className = d.gmail.conectado ? "ok" : "tenue";
  g.title = d.gmail.usuario || "";
  const im = $("imagenes-estado");
  im.textContent = d.imagenes.motor;
  im.className = d.imagenes.calidad === "alta" ? "ok" : "tenue";
  // el puntito de estado de los protocolos Correo e Imagen
  document.querySelectorAll(".protocolo-estado").forEach((el) => {
    const ok = el.dataset.servicio === "gmail" ? d.gmail.conectado : d.imagenes.calidad === "alta";
    el.className = "protocolo-estado " + (ok ? "ok" : "falta");
    const boton = el.closest(".protocolo");
    boton.title = el.dataset.servicio === "gmail"
      ? (ok ? `Gmail conectado (${d.gmail.usuario}). Tocá para revisar tus mails.` : "Gmail sin conectar: tocá para conectarlo.")
      : `Imágenes: ${d.imagenes.motor}` + (ok ? "" : " (baja calidad: conectá Pollinations en Configuraciones)");
  });
  pintarMailsHoy();
  pintarBotonPensar();
  if (!$("modal-ajustes").hidden) pintarCuentas();
}

function clicMails() {
  if (conexiones.gmail.conectado) enviarTexto("Revisá mis mails");
  else { abrirAjustes(); lineaSistema("Gmail todavía no está conectado: tocá CONECTAR en «Cuentas y servicios»."); }
}

function tarjetaCuenta({ icono, color, titulo, estado, ok, detalle, botones }) {
  return `<div class="cuenta ${ok ? "conectada" : ""}" style="--c:${color}">
    ${hexIcono(icono, color)}
    <div class="cuenta-info"><b>${titulo}</b><span class="cuenta-estado">${ok ? "● " : "○ "}${escapar(estado)}</span>
      <small>${detalle}</small></div>
    <div class="cuenta-botones">${botones.map(([texto, accion, clase]) =>
      `<button class="${clase || ""}" onclick="${accion}">${texto}</button>`).join("")}</div>
  </div>`;
}

function pintarCuentas() {
  const g = conexiones.gmail, im = conexiones.imagenes;
  $("ajustes-cuentas").innerHTML = [
    tarjetaCuenta({
      icono: "correo", color: "#ff6b5a", titulo: "Gmail", ok: g.conectado,
      estado: g.conectado ? `Conectado como ${g.usuario}` : "Sin conectar",
      detalle: g.conectado ? "Puedo revisar, resumir y mandar mails (siempre te pregunto antes de enviar)."
        : "Conectalo para que pueda leer y mandar mails. Te guío paso a paso (unos 5 minutos).",
      botones: g.conectado
        ? [["REVISAR MAILS", "cerrarAjustes();enviarTexto('Revisá mis mails')", "principal"],
           ["CAMBIAR CUENTA", "api('configurar_cuenta','gmail')"], ["DESCONECTAR", "desconectarCuenta('gmail', this)", "peligro"]]
        : [["CONECTAR GMAIL", "api('configurar_cuenta','gmail')", "principal"]],
    }),
    tarjetaCuenta({
      icono: "imagen", color: "#c58bff", titulo: "Generador de imágenes", ok: im.calidad === "alta",
      estado: `Motor: ${im.motor}`,
      detalle: (im.local ? "✓ Tu PC genera imágenes con la placa de video (y puede editarlas). " : "✗ Tu PC no tiene el generador instalado. ")
        + (im.pollinations ? "✓ Pollinations conectado: se usa en modo juego o si la PC no puede."
          : "Con una clave gratis de Pollinations las imágenes salen bien aunque la PC no pueda."),
      botones: im.pollinations
        ? [["PROBAR", "cerrarAjustes();enviarTexto('Creame una imagen de un atardecer en Montevideo')", "principal"],
           ["CAMBIAR CLAVE", "api('configurar_cuenta','pollinations')"], ["QUITAR CLAVE", "desconectarCuenta('pollinations', this)", "peligro"]]
        : [["CONECTAR POLLINATIONS", "api('configurar_cuenta','pollinations')", im.local ? "" : "principal"],
           ...(im.local ? [["PROBAR", "cerrarAjustes();enviarTexto('Creame una imagen de un atardecer en Montevideo')", "principal"]] : [])],
    }),
    tarjetaNube(),
  ].join("");
}

// La IA en la nube: Gemini (Google), Groq o NVIDIA. Cada una con su clave; "pensar más" usa la elegida en «Cerebro de IA».
function tarjetaNube() {
  const n = conexiones.nube || {}, nubes = n.nubes || [];
  const lineas = nubes.map((q) => `${q.clave ? "✓" : "○"} <b>${q.nombre}</b> (${escapar(q.detalle)})`).join(" · ");
  return tarjetaCuenta({
    icono: "pensar", color: "#4f8cff", titulo: "IA en la nube (opcional)", ok: !!n.clave,
    estado: n.clave ? `Pensar más usa ${n.nombre}` + (n.cerebro === "nube" ? " · responde TODO" : " · solo con «pensar más»")
      : "Sin conectar (te recomiendo Gemini: es gratis con tu cuenta de Google)",
    detalle: (n.clave ? "Tocá el cerebrito al lado del texto antes de una pregunta difícil: SOLO esa la piensa la nube. "
      : "Un modelo mucho más grande para las preguntas difíciles. Gemma sigue siendo el predeterminado y todo anda sin internet. ")
      + "Si no hay internet o la API falla, contesta Gemma y te avisa. El modelo se elige abajo, en «Cerebro de IA».<br>" + lineas
      + (n.ultimo_error ? `<br>Último problema: ${escapar(n.ultimo_error)}.` : ""),
    botones: [
      ...(n.clave ? [["PROBAR", "probarNube(this)", "principal"]] : []),
      ...nubes.map((q) => q.clave ? [`QUITAR ${q.nombre.toUpperCase()}`, `desconectarCuenta('nube:${q.id}', this)`, "peligro"]
        : [`CONECTAR ${q.nombre.toUpperCase()}`, `api('nube_configurar','${q.id}')`, !n.clave && q.id === "gemini" ? "principal" : ""]),
    ],
  });
}

async function probarNube(boton) {
  boton.textContent = "PROBANDO...";
  boton.disabled = true;
  const r = await api("nube_probar");
  if (boton.isConnected) { boton.textContent = r && r.ok ? "✓ ANDA" : "✗ NO ANDA"; boton.disabled = false; }
}

// ======================= "PENSAR MÁS": la próxima pregunta la piensa la IA en la nube =======================
let pensarMas = false, cerebroUsado = null;

function alternarPensar() {
  if (!conexiones.nube || !conexiones.nube.clave) {
    abrirAjustes();
    lineaSistema("Para «pensar más» conectá una IA en la nube en «Cuentas y servicios» (Gemini es gratis con tu cuenta de Google).");
    return;
  }
  pensarMas = !pensarMas;
  api("pensar_proxima", pensarMas);  // así también vale si la pregunta la hacés hablando
  pintarBotonPensar();
  if (pensarMas) entrada.focus();
}

function desarmarPensar() {
  pensarMas = false;
  api("pensar_proxima", false);
  pintarBotonPensar();
}

// El color característico de cada IA de la nube (el botón y el borde de la caja se pintan así)
const COLORES_NUBE = {
  gemini: {ia: "#4f8cff", claro: "#a9c8ff", rgb: "66, 133, 244", rgb2: "155, 114, 203"},   // la estrella azul y violeta
  groq: {ia: "#f55036", claro: "#ffa38f", rgb: "245, 80, 54", rgb2: "245, 80, 54"},         // naranja
  nvidia: {ia: "#76b900", claro: "#b6ff4d", rgb: "118, 185, 0", rgb2: "118, 185, 0"},      // verde
};

function pintarBotonPensar() {
  const b = $("boton-pensar"), hay = !!(conexiones.nube && conexiones.nube.clave);
  const color = COLORES_NUBE[conexiones.nube && conexiones.nube.proveedor] || COLORES_NUBE.nvidia;
  const campo = b.closest(".comando-campo");
  if (campo) {
    campo.style.setProperty("--ia", color.ia);
    campo.style.setProperty("--ia-claro", color.claro);
    campo.style.setProperty("--ia-rgb", color.rgb);
    campo.style.setProperty("--ia2-rgb", color.rgb2);
  }
  b.classList.toggle("activo", pensarMas);
  b.classList.toggle("sin-clave", !hay);
  b.title = !hay ? "Pensar más (IA en la nube): todavía sin conectar. Tocá para configurarlo."
    : pensarMas ? `Pensar más ACTIVADO: tu próxima pregunta la responde ${conexiones.nube.nombre}. Tocá de nuevo para cancelar.`
    : `Pensar más: la próxima pregunta la responde ${conexiones.nube.nombre} (en la nube)`;
  entrada.placeholder = pensarMas ? `Pensando más con ${conexiones.nube.nombre}... escribí o hablá tu pregunta`
    : (typeof adjuntosPendientes !== "undefined" && adjuntosPendientes.length ? entrada.placeholder : "Escribí una orden...");
}

async function desconectarCuenta(cual, boton) {
  if (boton.dataset.armado !== "1") {  // doble toque, para no desconectar sin querer
    boton.dataset.armado = "1";
    boton.textContent = "¿SEGURO? TOCÁ OTRA VEZ";
    setTimeout(() => { if (boton.isConnected) { boton.dataset.armado = ""; pintarCuentas(); } }, 4000);
    return;
  }
  eventoConexiones(cual.startsWith("nube:") ? await api("nube_quitar", cual.slice(5)) : await api("desconectar_cuenta", cual));
}

// ======================= HOY: clima, próximo, pendientes, mails =======================
async function refrescarHoy() {
  const d = await api("hoy");
  if (!d) return;
  if (d.clima) {
    $("hoy-temp").textContent = `${d.clima.temp}°`;
    $("hoy-clima-texto").textContent = `${d.clima.min}°/${d.clima.max}°` + (d.clima.lluvia >= 30 ? ` · ☂ ${d.clima.lluvia}%` : "");
    $("hoy-clima").title = `${d.clima.ciudad}: ${d.clima.estado}, mínima ${d.clima.min}°, máxima ${d.clima.max}°, lluvia ${d.clima.lluvia}%`;
  }
  $("hoy-proximo-hora").textContent = d.proximo ? d.proximo.hora : "Hoy";
  $("hoy-proximo-texto").textContent = d.proximo ? d.proximo.texto : "Nada agendado";
  pintarContadorPendientes(d.pendientes);
  api("finanzas_datos").then(pintarHoyFinanzas);   // (jarv2: lo gastado en el mes y si vence algo)
  hoyMails = d.mails;
  pintarMailsHoy();
  if (d.estudio) eventoEstudio(d.estudio);
}
let hoyMails = null;
setInterval(refrescarHoy, 10 * 60 * 1000);

function pintarContadorPendientes(n) {
  $("hoy-pendientes-n").textContent = n;
  $("hoy-pendientes").classList.toggle("alerta", n > 0);
}

function pintarMailsHoy() {
  const conectado = conexiones.gmail.conectado;
  $("hoy-mails-n").textContent = conectado ? (hoyMails === null || hoyMails === undefined ? "✓" : hoyMails) : "+";
  $("hoy-mails-texto").textContent = conectado ? (hoyMails ? "Sin leer" : "Gmail al día") : "Conectar Gmail";
  $("hoy-mails").classList.toggle("alerta", !!(conectado && hoyMails));
  $("hoy-mails").classList.toggle("apagado", !conectado);
}

// ======================= MODO ESTUDIO =======================
let estudio = { activo: false };

function eventoEstudio(d) {
  estudio = d || { activo: false };
  const caja = $("hoy-estudio");
  caja.classList.toggle("activo", !!estudio.activo);
  caja.classList.toggle("descanso", estudio.fase === "descanso");
  caja.classList.toggle("pausado", estudio.restante !== null && estudio.restante !== undefined && estudio.activo);
  $("estudio-play").hidden = estudio.activo && (estudio.restante === null || estudio.restante === undefined);
  $("estudio-pausa").hidden = !estudio.activo || (estudio.restante !== null && estudio.restante !== undefined);
  $("estudio-stop").hidden = !estudio.activo;
  document.body.classList.toggle("estudiando", !!estudio.activo && estudio.fase === "foco");
  tickEstudio();
}

function tickEstudio() {
  if (!estudio.activo) {
    $("estudio-tiempo").textContent = "Estudiar";
    $("estudio-texto").textContent = "Pomodoro 25 min";
    $("estudio-arco").style.strokeDashoffset = 94.25;
    return;
  }
  const pausado = estudio.restante !== null && estudio.restante !== undefined;
  const resto = Math.max(0, pausado ? estudio.restante : estudio.fin - Date.now() / 1000);
  const total = (estudio.fase === "foco" ? estudio.foco : estudio.descanso) * 60;
  $("estudio-tiempo").textContent = `${String(Math.floor(resto / 60)).padStart(2, "0")}:${String(Math.floor(resto % 60)).padStart(2, "0")}`;
  $("estudio-texto").textContent = pausado ? "En pausa" : estudio.fase === "foco" ? `Foco · bloque ${estudio.bloque}` : "Descanso";
  $("hoy-estudio").title = "Modo estudio" + (estudio.tema ? `: ${estudio.tema}` : "") + ` · bloque ${estudio.bloque}`;
  $("estudio-arco").style.strokeDashoffset = 94.25 * (1 - Math.min(1, (total - resto) / total));
}
setInterval(() => { if (estudio.activo) tickEstudio(); }, 1000);

function accionEstudio(accion) {
  if (accion === "empezar" && estudio.activo) accion = "seguir";
  api("estudio", accion, 25);
}

// ======================= PENDIENTES =======================
async function abrirPendientes() {
  pintarListaPendientes((await api("pendientes")) || []);
  $("modal-pendientes").hidden = false;
  setTimeout(() => $("pendiente-input").focus(), 50);
}

function cerrarPendientes() { $("modal-pendientes").hidden = true; }

const DIAS_CORTOS = ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"];

// "para el jueves": la etiqueta de la fecha (ámbar si es hoy o mañana, rojo si ya pasó)
function etiquetaFecha(para) {
  if (!para) return "";
  const [a, m, d] = para.split("-").map(Number);
  const fecha = new Date(a, m - 1, d), hoy = new Date();
  hoy.setHours(0, 0, 0, 0);
  const dias = Math.round((fecha - hoy) / 86400000);
  const texto = dias < 0 ? "venció" : dias === 0 ? "hoy" : dias === 1 ? "mañana"
    : dias < 7 ? `${DIAS_CORTOS[fecha.getDay()]} ${d}` : `${d}/${m}`;
  const clase = dias < 0 ? "vencido" : dias <= 1 ? "pronto" : "";
  return `<span class="pendiente-fecha ${clase}" title="Para el ${d}/${m}">${texto}</span>`;
}

function pintarListaPendientes(lista) {
  const sinHacer = lista.filter((p) => !p.hecho).sort((a, b) => (a.para || "9999").localeCompare(b.para || "9999") || a.id - b.id);
  const hechos = lista.filter((p) => p.hecho);
  pintarContadorPendientes(sinHacer.length);
  $("pendientes-resumen").textContent = `${sinHacer.length} por hacer · ${hechos.length} hechos`;
  const fila = (p) => `<div class="pendiente ${p.hecho ? "hecho" : ""}">
      <button class="pendiente-check" onclick="marcarPendiente(${p.id})" title="${p.hecho ? "Desmarcar" : "¡Hecho!"}">${p.hecho ? "✓" : ""}</button>
      <span class="pendiente-texto">${escapar(p.texto)}</span>${etiquetaFecha(p.para)}
      <button class="pendiente-borrar" onclick="borrarPendiente(${p.id})" title="Borrar">✕</button></div>`;
  $("pendientes-lista").innerHTML = lista.length
    ? sinHacer.map(fila).join("") + (hechos.length ? `<div class="pendientes-separador">HECHOS</div>` + hechos.map(fila).join("") : "")
    : '<div class="vacio">No tenés pendientes. Escribí uno arriba o decime «agregá estudiar física a mis pendientes».</div>';
}

async function marcarPendiente(id) { pintarListaPendientes((await api("pendiente_marcar", id)) || []); }
async function borrarPendiente(id) { pintarListaPendientes((await api("pendiente_borrar", id)) || []); }
async function borrarHechos() { pintarListaPendientes((await api("pendiente_borrar", null, true)) || []); }

$("pendiente-nuevo").addEventListener("submit", async (e) => {
  e.preventDefault();
  const texto = $("pendiente-input").value.trim();
  if (!texto) return;
  $("pendiente-input").value = "";
  pintarListaPendientes((await api("pendiente_agregar", texto)) || []);
});

function eventoPendientes(lista) {
  if (!$("modal-pendientes").hidden) pintarListaPendientes(lista);
  else pintarContadorPendientes(lista.filter((p) => !p.hecho).length);
}
// ======================= FINANZAS (jarv2: lo mismo que en el celular; se sincroniza con el bot) =======================
let finTipoPc = "gasto";
const MESES_FIN = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
                   "noviembre", "diciembre"];

function plata(monto) {
  // $ 1.250 · $ 99,50 (como lo dice JARVIS)
  const m = Math.round(Number(monto || 0) * 100) / 100, abs = Math.abs(m);
  const entero = String(Math.floor(abs)).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const resto = Math.round((abs % 1) * 100);
  return (m < 0 ? "-" : "") + "$ " + entero + (resto ? "," + String(resto).padStart(2, "0") : "");
}

function montoEscrito(texto) {
  // «1.500», «1500,50», «2 mil», «$ 300» -> número
  let t = String(texto || "").toLowerCase().replace(/\$|\s/g, "");
  let por = 1;
  if (/(mil|k|lucas?)$/.test(t)) { por = 1000; t = t.replace(/(mil|k|lucas?)$/, ""); }
  if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(t)) t = t.replace(/\./g, "").replace(",", ".");
  else t = t.replace(",", ".");
  const n = parseFloat(t);
  return isNaN(n) ? 0 : Math.round(n * por * 100) / 100;
}

function diasHasta(iso) {
  const [a, m, d] = iso.split("-").map(Number);
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);
  return Math.round((new Date(a, m - 1, d) - hoy) / 86400000);
}

function pintarHoyFinanzas(f) {
  if (!f) return;
  $("hoy-finanzas-n").textContent = plata(f.gastos);
  const pago = (f.pagos || [])[0];
  const dias = pago ? diasHasta(pago.vence) : 99;
  $("hoy-finanzas-texto").textContent = !pago || dias > 3 ? "Gastado este mes"
    : dias < 0 ? `Venció: ${pago.nombre}` : dias === 0 ? `Hoy vence: ${pago.nombre}` : `${pago.nombre}: en ${dias} día${dias === 1 ? "" : "s"}`;
  $("hoy-finanzas").classList.toggle("alerta", !!pago && dias <= 3);
  $("hoy-finanzas").title = "Tus finanzas: " + plata(f.gastos) + " gastado este mes"
    + (pago ? ` · próximo pago: ${pago.nombre} el ${pago.vence.slice(8, 10)}/${pago.vence.slice(5, 7)}` : "");
}

async function abrirFinanzas() {
  pintarFinanzasPc(await api("finanzas_datos"));
  $("modal-finanzas").hidden = false;
  setTimeout(() => $("fin-pc-monto").focus(), 50);
}

function cerrarFinanzas() { $("modal-finanzas").hidden = true; }

function botonBorrarFin(datos, titulo) {
  // dos clics: el primero lo arma (en rojo), el segundo lo borra (como en Chats)
  return `<button class="chat-borrar fin-pc-borrar" title="${escapar(titulo)}" data-fin='${escapar(JSON.stringify(datos))}'>✕</button>`;
}

function pintarFinanzasPc(f) {
  if (!f) return;
  pintarHoyFinanzas(f);
  $("fin-pc-mes").textContent = MESES_FIN[Number(f.mes.slice(5, 7)) - 1] + " " + f.mes.slice(0, 4);
  $("fin-pc-gastos").textContent = plata(f.gastos);
  $("fin-pc-ingresos").textContent = plata(f.ingresos);
  const balance = f.ingresos - f.gastos;
  $("fin-pc-balance").textContent = plata(balance);
  $("fin-pc-balance").classList.toggle("negativo", balance < 0);
  const vacio = (texto) => `<div class="vacio">${texto}</div>`;
  const repite = {mensual: "cada mes", anual: "cada año", semanal: "cada semana"};

  $("fin-pc-pagos").innerHTML = f.pagos.length ? f.pagos.map((p) => {
    const dias = diasHasta(p.vence);
    const clase = dias < 0 ? "vencido" : dias <= 2 ? "pronto" : "";
    const cuando = dias < 0 ? "venció" : dias === 0 ? "hoy" : dias === 1 ? "mañana" : `${p.vence.slice(8, 10)}/${p.vence.slice(5, 7)}`;
    return `<div class="pendiente fin-pc-fila">
      <span class="pendiente-texto">${escapar(p.nombre)}<small>${p.monto ? plata(p.monto) + " · " : ""}${repite[p.repetir] || "una vez"}</small></span>
      <span class="pendiente-fecha ${clase}">${cuando}</span>
      <button class="fin-pc-pagado" data-fin='${escapar(JSON.stringify({que: "pagado", id: p.id}))}' title="Lo pagué: anota el gasto">PAGADO</button>
      ${botonBorrarFin({que: "borrar_pago", id: p.id}, "Sacar este pago")}</div>`;
  }).join("") : vacio("No tenés pagos agendados. Te aviso antes de que venzan, acá y en el celular.");

  $("fin-pc-categorias").innerHTML = f.categorias.length ? f.categorias.map((c) => {
    const por = c.presupuesto ? Math.min(100, Math.round(c.gastado / c.presupuesto * 100)) : 0;
    const pasado = c.presupuesto && c.gastado > c.presupuesto, cerca = c.presupuesto && !pasado && c.gastado >= 0.8 * c.presupuesto;
    return `<div class="pendiente fin-pc-fila fin-pc-cat">
      <span class="pendiente-texto"><span class="fin-pc-cat-fila"><b>${escapar(c.categoria)}</b>
        <span>${plata(c.gastado)}${c.presupuesto ? ` <small>de ${plata(c.presupuesto)}</small>` : ""}</span></span>
        ${c.presupuesto ? `<span class="fin-pc-barra ${pasado ? "pasado" : cerca ? "cerca" : ""}"><i style="width:${por}%"></i></span>
        <small>${pasado ? "Te pasaste " + plata(c.gastado - c.presupuesto) : "Quedan " + plata(c.presupuesto - c.gastado)}</small>` : ""}</span>
      ${c.presupuesto ? botonBorrarFin({que: "presupuesto", categoria: c.categoria, monto: 0}, "Sacar el presupuesto") : ""}</div>`;
  }).join("") : vacio("Todavía no gastaste nada este mes.");

  const cuentas = Object.keys(f.cuentas);
  $("fin-pc-cuentas").innerHTML = cuentas.length ? cuentas.map((n) => `<div class="pendiente fin-pc-fila">
      <span class="pendiente-texto"><b>${escapar(n)}</b></span><b class="fin-pc-saldo ${f.cuentas[n] < 0 ? "negativo" : ""}">${plata(f.cuentas[n])}</b>
      ${botonBorrarFin({que: "cuenta", nombre: n, borrar: true}, "Sacar la cuenta")}</div>`).join("")
    : vacio("Anotá cuánto tenés en cada cuenta y lo que gastes ahí se descuenta solo.");

  $("fin-pc-ultimos").innerHTML = (f.ultimos || []).length ? f.ultimos.map((m) => `<div class="pendiente fin-pc-fila">
      <span class="pendiente-fecha">${m.fecha.slice(8, 10)}/${m.fecha.slice(5, 7)}</span>
      <span class="pendiente-texto">${escapar(m.categoria)}<small>${escapar([m.nota && m.nota.toLowerCase() !== m.categoria.toLowerCase() ? m.nota : "", m.cuenta].filter(Boolean).join(" · "))}</small></span>
      <b class="fin-pc-saldo ${m.monto > 0 ? "positivo" : ""}">${m.monto > 0 ? "+" : ""}${plata(m.monto)}</b>
      ${botonBorrarFin({que: "borrar_mov", id: m.id}, "Borrar este movimiento")}</div>`).join("")
    : vacio("Nada anotado todavía.");
}

async function finanzaPc(datos) {
  const r = await api("finanza", datos);
  if (!r) return false;
  if (!r.ok) { lineaSistema(r.error || "No pude."); return false; }
  pintarFinanzasPc(r.finanzas);
  return true;
}

function eventoFinanzas(r) {
  // cambió algo (por voz, en el celular o acá): la franja de Hoy y, si está abierto, el panel
  pintarHoyFinanzas(r);
  if (!$("modal-finanzas").hidden) api("finanzas_datos").then(pintarFinanzasPc);
}

$("modal-finanzas").addEventListener("click", (e) => {
  const boton = e.target.closest("[data-fin]");
  if (!boton) return;
  if (boton.classList.contains("fin-pc-borrar") && !boton.classList.contains("armado")) {
    boton.classList.add("armado");
    boton.textContent = "¿Seguro?";
    setTimeout(() => { boton.classList.remove("armado"); boton.textContent = "✕"; }, 3000);
    return;
  }
  finanzaPc(JSON.parse(boton.dataset.fin));
});

document.querySelectorAll(".fin-pc-tipo button").forEach((b) => {
  b.onclick = () => {
    finTipoPc = b.dataset.tipo;
    document.querySelectorAll(".fin-pc-tipo button").forEach((x) => x.classList.toggle("activo", x === b));
    $("fin-pc-sobre").placeholder = finTipoPc === "gasto" ? "¿En qué? (super, nafta…)" : "¿De qué? (sueldo, venta…)";
    $("fin-pc-monto").focus();
  };
});

function formFin(id, armar, limpiar) {
  $(id).addEventListener("submit", async (e) => {
    e.preventDefault();
    const datos = armar();
    if (!datos) return;
    if (await finanzaPc(datos)) limpiar.forEach((x) => ($(x).value = ""));
  });
}

formFin("fin-pc-anotar", () => {
  const monto = montoEscrito($("fin-pc-monto").value);
  if (!monto) { lineaSistema("Poné cuánto."); return null; }
  return {que: finTipoPc, monto: monto, sobre: $("fin-pc-sobre").value.trim(), cuenta: $("fin-pc-cuenta").value.trim()};
}, ["fin-pc-monto", "fin-pc-sobre", "fin-pc-cuenta"]);
formFin("fin-pc-pago", () => {
  const nombre = $("fin-pc-pago-nombre").value.trim(), vence = $("fin-pc-pago-vence").value;
  if (!nombre || !vence) { lineaSistema("Poné qué es y cuándo vence."); return null; }
  return {que: "pago", nombre: nombre, monto: montoEscrito($("fin-pc-pago-monto").value), vence: vence, repetir: $("fin-pc-pago-repetir").value};
}, ["fin-pc-pago-nombre", "fin-pc-pago-monto", "fin-pc-pago-vence"]);
formFin("fin-pc-presupuesto", () => {
  const cat = $("fin-pc-pres-cat").value.trim(), monto = montoEscrito($("fin-pc-pres-monto").value);
  if (!cat || !monto) { lineaSistema("Poné la categoría y cuánto por mes."); return null; }
  return {que: "presupuesto", categoria: cat, monto: monto};
}, ["fin-pc-pres-cat", "fin-pc-pres-monto"]);
formFin("fin-pc-cuenta-form", () => {
  const nombre = $("fin-pc-cuenta-nombre").value.trim();
  if (!nombre || !$("fin-pc-cuenta-saldo").value.trim()) { lineaSistema("Poné la cuenta y cuánto tenés hoy."); return null; }
  return {que: "cuenta", nombre: nombre, saldo: montoEscrito($("fin-pc-cuenta-saldo").value)};
}, ["fin-pc-cuenta-nombre", "fin-pc-cuenta-saldo"]);
