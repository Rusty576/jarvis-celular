"""Graba frases con la voz de Windows en archivos WAV (para los videos que arma JARVIS).

Corre aparte (videos.py lo abre como otro programa): así no se pisa con la voz de JARVIS, que usa el mismo
motor de Windows. Recibe por la entrada un JSON: {"velocidad": 0, "frases": [{"texto": "...", "ruta": "x.wav"}]}
y contesta una línea JSON por frase grabada: {"ok": true, "ruta": "x.wav"} o {"ok": false, "error": "..."}.
"""
import json
import sys

ESPANOL = ("spanish", "español", "sabina", "raul", "helena", "pablo", "laura", "jorge")
SAFT44kHz16BitMono = 34  # formato del audio: 44.100 muestras por segundo, 16 bits, un canal
SSFM_CREAR = 3           # abrir el archivo para escribirlo (lo crea o lo pisa)
SIN_XML = 16             # el texto se lee tal cual (los "<" no se toman como órdenes)


def main():
    import comtypes
    import comtypes.client

    pedido = json.loads(sys.stdin.read())
    comtypes.CoInitialize()
    voz = comtypes.client.CreateObject("SAPI.SpVoice")
    for v in voz.GetVoices():
        if any(p in v.GetDescription().lower() for p in ESPANOL):
            voz.Voice = v
            break
    voz.Rate = int(pedido.get("velocidad", 0))
    for frase in pedido["frases"]:
        try:
            archivo = comtypes.client.CreateObject("SAPI.SpFileStream")
            formato = comtypes.client.CreateObject("SAPI.SpAudioFormat")
            formato.Type = SAFT44kHz16BitMono
            archivo.Format = formato
            archivo.Open(frase["ruta"], SSFM_CREAR, False)
            voz.AudioOutputStream = archivo
            voz.Speak(frase["texto"], SIN_XML)
            archivo.Close()
            print(json.dumps({"ok": True, "ruta": frase["ruta"]}), flush=True)
        except Exception as e:
            print(json.dumps({"ok": False, "ruta": frase.get("ruta"), "error": str(e)}), flush=True)


if __name__ == "__main__":
    main()
