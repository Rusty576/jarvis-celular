"""Configuraciones de JARVIS (el botón del engranaje). Se guardan en ajustes.json y se aplican al momento,
sin tener que reiniciar. Si el archivo no existe, se usan los valores que están escritos en el código."""
import json
import os
import subprocess
import threading

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "ajustes.json")
CARPETA_INICIO = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
ACCESO_INICIO = os.path.join(CARPETA_INICIO, "JARVIS.lnk")
_lock = threading.Lock()

# clave -> (tipo, descripción para la pantalla, opciones/rango)
DEFINICION = {
    "voz_activada": ("bool", "Respuesta por voz", None),
    "velocidad_voz": ("rango", "Velocidad de la voz", (-5, 8)),
    "voz_motor": ("opcion", "Voz de JARVIS en la compu (la humana anda sin internet; la de Windows es la de antes)",
                  ["humana", "windows"]),
    "voz_humana": ("opcion", "Cuál voz humana", []),   # (las opciones salen de voz_humana.VOCES)
    "sonidos": ("bool", "Pitidos de aviso del micrófono", None),
    "manos_libres_al_iniciar": ("bool", "Escucha continua al abrir JARVIS", None),
    "sensibilidad_mic": ("rango", "Sensibilidad al ruido (más alto = ignora más ruido)", (1.2, 3.0)),
    "silencio_fin": ("rango", "Pausa para dar por terminada una frase (décimas de segundo)", (4, 15)),
    "verificar_internet": ("bool", "Verificar datos en internet antes de responder", None),
    "ciudad": ("texto", "Ciudad para el clima (vacía = la detecta sola)", None),
    "quiz_preguntas": ("rango", "Preguntas por defecto en un quiz", (3, 25)),
    "quiz_nivel": ("opcion", "Dificultad por defecto del quiz", ["baja", "media", "alta"]),
    "quiz_voz": ("bool", "Leer el quiz en voz alta (preguntas, pistas y si respondiste bien o mal)", None),
    "musica_en": ("opcion", "Dónde reproducir la música de YouTube", ["jarvis", "navegador"]),
    "tema": ("opcion", "Colores de JARVIS", ["azul", "oscuro"]),
    "pildora": ("bool", "Píldora flotante: la carita de JARVIS arriba de la pantalla (Ctrl+Alt+J abre el chat)", None),
    "tratamiento": ("opcion", "Cómo te trata JARVIS", ["ninguno", "señor", "señora"]),
    "voz_local": ("opcion", "Reconocer tu voz en la compu (sin internet, con Parakeet)", ["sin_internet", "siempre", "nunca"]),
    "teclas_hablar": ("bool", "Mantené Alt derecho para dictar en cualquier app y Ctrl derecho para darme una orden", None),
    "pildora_seguir": ("bool", "Después de contestarte, la píldora te sigue escuchando unos segundos (para seguir la charla)", None),
    "pildora_opacidad": ("rango", "Opacidad de la píldora (%)", (30, 100)),
    "pildora_look": ("opcion", "Cara de la píldora", ["celeste", "blanco", "halloween", "navidad", "temporada"]),
    # Los cerebros: Gemma en tu PC o cualquiera de tus nubes con clave (las opciones se arman en para_la_pantalla)
    "cerebro": ("opcion", "Cerebro para responder", []),
    "modelo": ("opcion", "Modelo de tu PC (Gemma)", []),  # los modelos instalados en Ollama
    "nube": ("opcion", "Nube para «pensar más» (si una falla, usa la otra)", []),
    "modelo_gemini": ("opcion", "Modelo de Gemini", []),
    "modelo_groq": ("opcion", "Modelo de Groq", []),
    "modelo_nvidia": ("opcion", "Modelo de NVIDIA", []),
    "nube_modelo": ("opcion", "IA en la nube (como se guardaba antes)", []),  # no se muestra: solo para leerlo
    "modo_juego_auto": ("bool", "Modo juego automático al abrir un juego en pantalla completa", None),
    "registro_actividad": ("bool", "Registrar qué apps uso y cuánto (queda solo en esta compu)", None),
    "rutinas": ("bool", "Rutinas automáticas («cuando abra X, hacé Y»)", None),
    "consejos_solos": ("bool", "Consejos por su cuenta (nunca mientras jugás)", None),
    "automejora_nube": ("bool", "Automejora con la IA de la nube (escribe mejor código; si no, Gemma)", None),
    "automejora_sola": ("bool", "Que se mejore solo: revisa la charla, encuentra lo que salió mal y lo arregla", None),
    "celular_actividad": ("bool", "Pasarle al bot del celular cómo usás la PC (si jugás y cuánto), para cuidarte", None),
    "celular_ias": ("bool", "Pasarle al bot del celular las claves de otras IAs (Groq): contesta cuando Gemini no puede", None),
    "inicio_con_windows": ("bool", "Abrir JARVIS al prender la compu", None),
}


def actuales():
    """Los valores que está usando JARVIS ahora mismo."""
    return {
        "voz_activada": jarvis.voz_activada.is_set(),
        "velocidad_voz": jarvis.VELOCIDAD_VOZ,
        "voz_motor": jarvis.VOZ_MOTOR,
        "voz_humana": jarvis.VOZ_HUMANA,
        "sonidos": jarvis.SONIDOS,
        "manos_libres_al_iniciar": jarvis.MANOS_LIBRES_AL_INICIAR,
        "sensibilidad_mic": jarvis.SENSIBILIDAD,
        "silencio_fin": jarvis.SILENCIO_FIN,
        "verificar_internet": jarvis.herramientas.VERIFICAR_EN_INTERNET,
        "ciudad": jarvis.herramientas.CIUDAD,
        "quiz_preguntas": jarvis.examenes.PREGUNTAS_POR_DEFECTO,
        "quiz_nivel": jarvis.examenes.NIVEL_POR_DEFECTO,
        "quiz_voz": jarvis.examenes.LEER_EN_VOZ,
        "musica_en": jarvis.musica.REPRODUCIR_EN,
        "barra_musica": jarvis.barra_musica.ACTIVA,
        "barra_auto": jarvis.barra_musica.AUTO_ESCONDER,
        "pildora": jarvis.pildora.ACTIVA,
        "tema": jarvis.TEMA,
        "pildora_look": jarvis.pildora.LOOK,
        "pildora_seguir": jarvis.pildora.SEGUIR,
        "pildora_opacidad": jarvis.pildora.OPACIDAD,
        "teclas_hablar": jarvis.escritorio.TECLAS_ACTIVAS,
        "voz_local": jarvis.VOZ_LOCAL,
        "tratamiento": jarvis.TRATAMIENTO or "ninguno",
        "modelo": jarvis.MODELO,
        "cerebro": "local" if jarvis.cerebro_nvidia.CEREBRO == "local" else jarvis.cerebro_nvidia.PROVEEDOR,
        "nube": jarvis.cerebro_nvidia.PROVEEDOR,
        "modelo_gemini": jarvis.cerebro_nvidia.MODELOS["gemini"],
        "modelo_groq": jarvis.cerebro_nvidia.MODELOS["groq"],
        "modelo_nvidia": jarvis.cerebro_nvidia.MODELOS["nvidia"],
        "nube_modelo": f"{jarvis.cerebro_nvidia.PROVEEDOR}|{jarvis.cerebro_nvidia.MODELOS[jarvis.cerebro_nvidia.PROVEEDOR]}",
        "modo_juego_auto": jarvis.herramientas.MODO_JUEGO_AUTO,
        "registro_actividad": jarvis.actividad.ACTIVO,
        "rutinas": jarvis.rutinas.ACTIVAS,
        "consejos_solos": jarvis.consejos.ACTIVOS,
        "automejora_nube": jarvis.automejora.USAR_NUBE,
        "automejora_sola": jarvis.automejora.SOLA,
        "celular_actividad": jarvis.celular.COMPARTIR_ACTIVIDAD,
        "celular_ias": jarvis.celular.COMPARTIR_IAS,
        "inicio_con_windows": os.path.exists(ACCESO_INICIO),
    }


def modelos_instalados():
    try:
        return sorted(m.model for m in jarvis.ollama.list().models)
    except Exception:
        return [jarvis.MODELO]


def nombre_local(modelo):
    """'gemma4:12b-it-qat' -> 'Gemma 4 12B (más inteligente, más lento)'."""
    import re

    m = re.match(r"gemma(\d+)n?:(e?\d+b)", modelo)
    if not m:
        return modelo
    tamano = m.group(2).upper()
    nota = " (rápido)" if tamano in ("E2B", "E4B", "1B", "4B") else " (más inteligente, más lento)"
    return f"Gemma {m.group(1)} {tamano}{nota}"


def para_la_pantalla():
    nube = jarvis.cerebro_nvidia
    con_clave = [p for p in nube.ORDEN if nube._tiene_clave(p)]
    valores = actuales()
    campos = []
    for clave, (tipo, texto, extra) in DEFINICION.items():
        nombres = None
        if clave == "nube_modelo":
            continue  # solo para leer lo guardado antes
        if clave.startswith("modelo_") and clave[7:] not in con_clave:
            continue  # el selector de modelo de una nube aparece solo si tenés su clave
        if clave == "nube" and not con_clave:
            continue
        if clave == "voz_motor":
            nombres = {"humana": "Humana (sin internet)", "windows": "La de Windows (la de antes)"}
        elif clave == "voz_humana":
            if valores["voz_motor"] != "humana":
                continue
            extra = list(jarvis.voz_humana.VOCES)
            nombres = {k: v[1] for k, v in jarvis.voz_humana.VOCES.items()}
        elif clave == "cerebro":
            extra = ["local"] + con_clave
            nombres = {"local": f"{nombre_local(jarvis.MODELO)} en tu PC (sin internet)"}
            for p in con_clave:
                nombres[p] = f"{nube.PROVEEDORES[p]['nombre']} · {nube.nombre_modelo(proveedor=p)} (nube)"
        elif clave == "modelo":
            extra = modelos_instalados()
            nombres = {m: nombre_local(m) for m in extra}
        elif clave == "nube":
            extra = con_clave
            nombres = {p: nube.PROVEEDORES[p]["nombre"] for p in con_clave}
        elif clave.startswith("modelo_"):
            p = clave[7:]
            extra = [v.split("|", 1)[1] for v in nube.modelos_disponibles(solo=p)]
            nombres = {v.split("|", 1)[1]: n.split(" · ", 1)[-1] for v, n in nube.nombres_de_modelos().items()
                       if v.startswith(p + "|")}
        campo = {"clave": clave, "tipo": tipo, "texto": texto, "extra": extra, "valor": valores[clave]}
        if nombres:
            campo["nombres"] = nombres
        campos.append(campo)
    return campos


def _aplicar(clave, valor):
    j = jarvis
    if clave == "voz_activada":
        (j.voz_activada.set if valor else j.voz_activada.clear)()
    elif clave == "velocidad_voz":
        j.VELOCIDAD_VOZ = int(round(float(valor)))
        threading.Thread(target=j.reiniciar_voz, daemon=True).start()  # la voz toma la velocidad nueva
    elif clave == "voz_motor" and valor in ("humana", "windows"):
        j.VOZ_MOTOR = valor
        j.preparar_voz_humana()   # (si es la humana, la carga aparte; mientras, la de Windows)
    elif clave == "voz_humana" and valor in j.voz_humana.VOCES:
        j.VOZ_HUMANA = valor
        j.preparar_voz_humana()
    elif clave == "sonidos":
        j.SONIDOS = bool(valor)
    elif clave == "manos_libres_al_iniciar":
        j.MANOS_LIBRES_AL_INICIAR = bool(valor)
    elif clave == "sensibilidad_mic":
        j.SENSIBILIDAD = round(float(valor), 2)
    elif clave == "silencio_fin":
        j.SILENCIO_FIN = int(round(float(valor)))
    elif clave == "verificar_internet":
        j.herramientas.VERIFICAR_EN_INTERNET = bool(valor)
    elif clave == "ciudad":
        j.herramientas.CIUDAD = str(valor or "").strip()
    elif clave == "quiz_preguntas":
        j.examenes.PREGUNTAS_POR_DEFECTO = int(round(float(valor)))
    elif clave == "quiz_voz":
        j.examenes.LEER_EN_VOZ = bool(valor)
        if not valor:
            j.examenes.callar()
    elif clave == "quiz_nivel" and valor in ("baja", "media", "alta"):
        j.examenes.NIVEL_POR_DEFECTO = valor
    elif clave == "musica_en" and valor in ("jarvis", "navegador"):
        j.musica.REPRODUCIR_EN = valor
    elif clave == "barra_musica":
        j.barra_musica.ACTIVA = bool(valor)
        (j.barra_musica.mostrar if valor else j.barra_musica.cerrar)()
    elif clave == "tratamiento" and valor in ("ninguno", "señor", "señora"):
        j.TRATAMIENTO = "" if valor == "ninguno" else valor
    elif clave == "voz_local" and valor in ("sin_internet", "siempre", "nunca"):
        j.VOZ_LOCAL = valor
        if valor == "siempre":
            threading.Thread(target=j.modelo_voz_local, daemon=True).start()  # que ya esté cargado
    elif clave == "teclas_hablar":
        j.escritorio.TECLAS_ACTIVAS = bool(valor)
    elif clave == "pildora_seguir":
        j.pildora.SEGUIR = bool(valor)
    elif clave == "pildora_opacidad":
        j.pildora.poner_opacidad(valor)
    elif clave == "pildora_look" and valor in jarvis.pildora.LOOKS:
        j.pildora.poner_look(valor)
    elif clave == "tema" and valor in ("azul", "oscuro"):
        j.TEMA = valor
        j.emitir("tema", valor)
    elif clave == "pildora":
        j.pildora.aplicar_ajuste(bool(valor))
    elif clave == "barra_auto":
        j.barra_musica.AUTO_ESCONDER = bool(valor)
        j.barra_musica.despertar()   # que se vea el cambio
    elif clave == "modelo" and valor:
        if str(valor) != j.MODELO:
            threading.Thread(target=_sacar_de_la_placa, args=(j.MODELO,), daemon=True).start()  # no entran los dos
        j.MODELO = str(valor)
        j.KEEP_ALIVE_NORMAL = j.KEEP_ALIVE
    elif clave == "cerebro" and valor:
        if valor in j.cerebro_nvidia.PROVEEDORES:  # una nube: todas las respuestas van a esa
            j.cerebro_nvidia.CEREBRO = "nube"
            j.cerebro_nvidia.PROVEEDOR = valor
        elif valor in ("local", "nube"):
            j.cerebro_nvidia.CEREBRO = valor
    elif clave == "nube" and valor in j.cerebro_nvidia.PROVEEDORES:
        j.cerebro_nvidia.PROVEEDOR = valor
    elif clave.startswith("modelo_") and valor and clave[7:] in j.cerebro_nvidia.PROVEEDORES:
        j.cerebro_nvidia.MODELOS[clave[7:]] = str(valor)
    elif clave == "nube_modelo" and valor:
        j.cerebro_nvidia.elegir(valor)  # como se guardaba antes (una sola nube con su modelo)
    elif clave == "automejora_sola":
        j.automejora.SOLA = bool(valor)
    elif clave == "modo_juego_auto":
        j.herramientas.MODO_JUEGO_AUTO = bool(valor)
    elif clave == "registro_actividad":
        j.actividad.ACTIVO = bool(valor)
    elif clave == "rutinas":
        j.rutinas.ACTIVAS = bool(valor)
    elif clave == "consejos_solos":
        j.consejos.ACTIVOS = bool(valor)
    elif clave == "automejora_nube":
        j.automejora.USAR_NUBE = bool(valor)
    elif clave == "celular_actividad":
        j.celular.COMPARTIR_ACTIVIDAD = bool(valor)
    elif clave == "celular_ias":
        j.celular.COMPARTIR_IAS = bool(valor)
    elif clave == "inicio_con_windows":
        inicio_con_windows(bool(valor))


def _sacar_de_la_placa(modelo):
    """Al cambiar de modelo: si el anterior está cargado en la placa de video, lo saca (si no, quedan los dos)."""
    try:
        cargados = [m.model for m in jarvis.ollama.ps().models]
        if modelo in cargados:
            jarvis.ollama.generate(model=modelo, prompt="", keep_alive=0)
    except Exception:
        pass


def inicio_con_windows(activar):
    """Crea o borra el acceso directo de JARVIS en la carpeta de Inicio de Windows."""
    if not activar:
        if os.path.exists(ACCESO_INICIO):
            os.remove(ACCESO_INICIO)
        return
    if os.path.exists(ACCESO_INICIO):
        return
    pyw = os.path.join(BASE, "JARVIS.pyw")
    destino = pyw if os.path.exists(pyw) else os.path.join(BASE, "interfaz.py")
    pythonw = jarvis.sys.executable.replace("python.exe", "pythonw.exe")
    icono = os.path.join(BASE, "interfaz", "jarvis.ico")
    comando = (f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{ACCESO_INICIO}');"
               f"$s.TargetPath='{pythonw}';$s.Arguments='\"{destino}\"';$s.WorkingDirectory='{BASE}';"
               + (f"$s.IconLocation='{icono}';" if os.path.exists(icono) else "") + "$s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-Command", comando], capture_output=True, timeout=20,
                   creationflags=0x08000000)


def cargar():
    """Al arrancar: aplica lo que habías elegido la última vez."""
    try:
        with open(ARCHIVO, encoding="utf-8") as f:
            guardados = json.load(f)
    except (OSError, ValueError):
        return
    if guardados.get("nvidia_modelo") and "nube_modelo" not in guardados:  # como se guardaba antes
        jarvis.cerebro_nvidia.MODELOS["nvidia"] = str(guardados["nvidia_modelo"])
    for clave, valor in guardados.items():
        if clave in DEFINICION and clave != "inicio_con_windows":
            try:
                _aplicar(clave, valor)
            except Exception:
                pass


def guardar(cambios):
    """Aplica y guarda los cambios que hiciste en la pantalla de configuraciones."""
    with _lock:
        for clave, valor in cambios.items():
            if clave in DEFINICION:
                _aplicar(clave, valor)
        valores = actuales()
        valores.pop("inicio_con_windows", None)
        temporal = ARCHIVO + ".tmp"
        with open(temporal, "w", encoding="utf-8") as f:
            json.dump(valores, f, ensure_ascii=False, indent=2)
        os.replace(temporal, ARCHIVO)
    return para_la_pantalla()
