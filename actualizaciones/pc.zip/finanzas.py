"""Finanzas de jarv2 (la PC y el celular juntos): gastos e ingresos, presupuestos por categoría, cuentas con su saldo y
pagos que vencen (con aviso antes).

Cómo se mantiene igual en los dos lados: cada cambio es una «operación» con su número ({id, tipo, ...}). La PC las
aplica acá (anda sin internet) y las manda al bot en la sincronización de siempre (celular.py); el bot las aplica
igual (Codigo.gs, aplicarFinanza_) y devuelve el estado entero, que reemplaza al de acá. Como cada operación tiene
número, aplicarla dos veces no duplica nada. Las reglas de aplicar y de los avisos están copiadas tal cual en el bot y
en la app del celular (se prueba que den lo mismo).

Por voz o escrito:
  «gasté 500 en comida» · «gasté 1200 de nafta con la tarjeta» · «cobré 30000 de sueldo»
  «¿cuánto gasté este mes?» · «¿cuánto gasté en comida?» · «¿cómo vengo con la plata?»
  «presupuesto de 8000 para comida» · «el banco tiene 50000» (el saldo de una cuenta)
  «agendá el pago de la luz de 2500 el 10 de cada mes» · «pagué la luz» · «¿qué pagos tengo?»
  «borrá el último gasto»
"""
import datetime
import os
import random
import re
import threading
import time

import disco

jarvis = None   # main (lo pone main al arrancar)
BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "finanzas.json")
ARCHIVO_AVISADOS = os.path.join(BASE, "vencimientos_avisados.json")
_lock = threading.Lock()
MAX_VISTAS = 600   # números de operaciones que se recuerdan (para no aplicar dos veces la misma)
MAX_MOVIMIENTOS = 600   # (el bot los guarda en sus Propiedades, que tienen lugar limitado: más o menos un año)

# las categorías de siempre (lo demás queda con su nombre)
CATEGORIAS = {
    "Comida": "comida super supermercado almuerzo cena desayuno merienda delivery pedidosya rappi restaurante pizza "
              "hamburguesa almacen feria carniceria verduleria panaderia kiosco",
    "Transporte": "nafta combustible taxi uber cabify bondi omnibus boleto stm estacionamiento peaje auto moto",
    "Servicios": "luz ute agua ose internet antel telefono celular gas alquiler expensas",
    "Suscripciones": "netflix spotify youtube disney prime hbo max suscripcion suscripciones icloud chatgpt",
    "Salud": "farmacia medico remedios dentista mutualista emergencia",
    "Ropa": "ropa championes zapatillas remera pantalon campera",
    "Juegos": "juegos juego steam playstation xbox nintendo epic",
    "Estudio": "liceo facultad libros cuadernos curso utiles fotocopias",
    "Salidas": "salida salidas cine boliche bar cerveza fiesta",
    "Regalos": "regalo regalos cumple cumpleanos",
}
_CATEGORIA_DE = {palabra: cat for cat, palabras in CATEGORIAS.items() for palabra in palabras.split()}


# ======================= Las reglas (iguales en el bot y en la app) =======================

def vacio():
    return {"movimientos": [], "pagos": [], "presupuestos": {}, "cuentas": {}, "vistas": []}


def _sumar_dias(fecha, dias):
    return (datetime.date.fromisoformat(fecha) + datetime.timedelta(days=dias)).isoformat()


def siguiente_vencimiento(fecha, repetir):
    """La próxima vez que vence un pago que se repite (mensual: el mismo día del mes que viene, o el último si no hay)."""
    d = datetime.date.fromisoformat(fecha)
    if repetir == "semanal":
        return (d + datetime.timedelta(days=7)).isoformat()
    if repetir == "anual":
        try:
            return d.replace(year=d.year + 1).isoformat()
        except ValueError:   # (29 de febrero)
            return d.replace(year=d.year + 1, day=28).isoformat()
    if repetir == "mensual":
        anio, mes = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
        ultimo = (datetime.date(anio + (mes == 12), mes % 12 + 1, 1) - datetime.timedelta(days=1)).day
        return datetime.date(anio, mes, min(d.day, ultimo)).isoformat()
    return None


def aplicar(estado, op):
    """Aplica una operación (si no se aplicó ya). Devuelve True si cambió algo."""
    if not isinstance(op, dict) or not op.get("id") or op["id"] in estado["vistas"]:
        return False
    estado["vistas"].append(op["id"])
    del estado["vistas"][:-MAX_VISTAS]
    tipo = op.get("tipo")
    if tipo in ("gasto", "ingreso"):
        monto = abs(float(op.get("monto") or 0))
        if not monto:
            return False
        estado["movimientos"].append({
            "id": op["id"], "fecha": op.get("fecha") or "", "monto": monto if tipo == "ingreso" else -monto,
            "categoria": op.get("categoria") or ("Ingresos" if tipo == "ingreso" else "Otros"),
            "cuenta": op.get("cuenta") or "", "nota": op.get("nota") or "", "pago": op.get("pago") or ""})
        estado["movimientos"].sort(key=lambda m: (m["fecha"], m["id"]))
        del estado["movimientos"][:-MAX_MOVIMIENTOS]
    elif tipo == "borrar_mov":
        estado["movimientos"] = [m for m in estado["movimientos"] if m["id"] != op.get("mov")]
    elif tipo == "pago":
        if not op.get("nombre") or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(op.get("vence") or "")):
            return False
        estado["pagos"].append({"id": op["id"], "nombre": op["nombre"], "monto": abs(float(op.get("monto") or 0)),
                                "vence": op["vence"], "repetir": op.get("repetir") or "",
                                "avisar": int(op.get("avisar", 2)), "categoria": op.get("categoria") or "Servicios",
                                "cuenta": op.get("cuenta") or "", "dia": int(op["vence"][8:10])})
    elif tipo == "pagado":
        pago = next((p for p in estado["pagos"] if p["id"] == op.get("pago")), None)
        if not pago:
            return False
        monto = abs(float(op.get("monto") or pago["monto"] or 0))
        if monto:
            estado["movimientos"].append({"id": op["id"], "fecha": op.get("fecha") or pago["vence"], "monto": -monto,
                                          "categoria": pago["categoria"], "cuenta": op.get("cuenta") or pago["cuenta"],
                                          "nota": pago["nombre"], "pago": pago["id"]})
            estado["movimientos"].sort(key=lambda m: (m["fecha"], m["id"]))
        siguiente = _siguiente_del_pago(pago)
        if siguiente:
            pago["vence"] = siguiente
        else:
            estado["pagos"] = [p for p in estado["pagos"] if p["id"] != pago["id"]]
    elif tipo == "borrar_pago":
        estado["pagos"] = [p for p in estado["pagos"] if p["id"] != op.get("pago")]
    elif tipo == "presupuesto":
        cat, monto = op.get("categoria"), abs(float(op.get("monto") or 0))
        if not cat:
            return False
        if monto:
            estado["presupuestos"][cat] = monto
        else:
            estado["presupuestos"].pop(cat, None)
    elif tipo == "cuenta":
        if not op.get("nombre"):
            return False
        if op.get("borrar"):
            estado["cuentas"].pop(op["nombre"], None)
        else:   # el saldo de hoy: lo que ya se movió en esa cuenta se descuenta del de arranque
            movido = sum(m["monto"] for m in estado["movimientos"] if m["cuenta"] == op["nombre"])
            estado["cuentas"][op["nombre"]] = round(float(op.get("saldo") or 0) - movido, 2)
    else:
        return False
    return True


def _siguiente_del_pago(pago):
    # (mensual: vuelve al día del mes que elegiste, aunque un mes corto lo haya corrido: el 31 → 30 → 31)
    if pago["repetir"] != "mensual":
        return siguiente_vencimiento(pago["vence"], pago["repetir"])
    d = datetime.date.fromisoformat(pago["vence"])
    anio, mes = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
    ultimo = (datetime.date(anio + (mes == 12), mes % 12 + 1, 1) - datetime.timedelta(days=1)).day
    return datetime.date(anio, mes, min(int(pago.get("dia") or d.day), ultimo)).isoformat()


def resumen(estado, hoy=None):
    """Lo del mes: ingresos, gastos, por categoría (con su presupuesto), el saldo de cada cuenta y los próximos pagos."""
    hoy = hoy or datetime.date.today().isoformat()
    mes = hoy[:7]
    del_mes = [m for m in estado["movimientos"] if m["fecha"][:7] == mes]
    gastos = -sum(m["monto"] for m in del_mes if m["monto"] < 0)
    ingresos = sum(m["monto"] for m in del_mes if m["monto"] > 0)
    por_cat = {}
    for m in del_mes:
        if m["monto"] < 0:
            por_cat[m["categoria"]] = por_cat.get(m["categoria"], 0) + -m["monto"]
    categorias = sorted(set(por_cat) | set(estado["presupuestos"]), key=lambda c: -por_cat.get(c, 0))
    cuentas = {c: round(inicial + sum(m["monto"] for m in estado["movimientos"] if m["cuenta"] == c), 2)
               for c, inicial in estado["cuentas"].items()}
    proximos = sorted(estado["pagos"], key=lambda p: p["vence"])
    return {"mes": mes, "gastos": round(gastos, 2), "ingresos": round(ingresos, 2),
            "categorias": [{"categoria": c, "gastado": round(por_cat.get(c, 0), 2),
                            "presupuesto": estado["presupuestos"].get(c, 0)} for c in categorias],
            "cuentas": cuentas, "pagos": proximos,
            "vencidos": [p for p in proximos if p["vence"] < hoy]}


def vencimientos(estado, pendientes=()):
    """Los avisos que tocan (iguales en la PC, el bot y el celular, con el mismo número): [{id, cuando, texto}].
    Pagos: unos días antes a las 9, el día a las 9 y, si no lo marcaste pagado, al otro día a las 10.
    Pendientes con fecha: el día antes a las 20 y el día a las 9."""
    avisos = []
    for p in estado["pagos"]:
        plata = f" ({plata_linda(p['monto'])})" if p["monto"] else ""
        if p["avisar"] > 0:
            avisos.append({"id": f"pago-{p['id']}-{p['vence']}-antes", "fecha": p["vence"], "cuando": _sumar_dias(p["vence"], -p["avisar"]) + "T09:00",
                           "texto": f"💸 En {p['avisar']} día{'s' if p['avisar'] != 1 else ''} vence {p['nombre']}{plata}"})
        avisos.append({"id": f"pago-{p['id']}-{p['vence']}-hoy", "fecha": p["vence"], "cuando": p["vence"] + "T09:00",
                       "texto": f"💸 Hoy vence {p['nombre']}{plata}"})
        avisos.append({"id": f"pago-{p['id']}-{p['vence']}-tarde", "fecha": p["vence"], "cuando": _sumar_dias(p["vence"], 1) + "T10:00",
                       "texto": f"⚠️ Se te pasó {p['nombre']}{plata}: venció ayer. Si ya lo pagaste, decime «pagué {p['nombre']}»"})
    for p in pendientes:
        if p.get("hecho") or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(p.get("para") or "")):
            continue
        avisos.append({"id": f"pen-{p['id']}-{p['para']}-antes", "fecha": p["para"], "cuando": _sumar_dias(p["para"], -1) + "T20:00",
                       "texto": f"📌 Mañana vence: {p['texto']}"})
        avisos.append({"id": f"pen-{p['id']}-{p['para']}-hoy", "fecha": p["para"], "cuando": p["para"] + "T09:00",
                       "texto": f"📌 Hoy vence: {p['texto']}"})
    return sorted(avisos, key=lambda a: (a["cuando"], a["id"]))


def toca_avisar(a, ahora):
    """Si ese aviso sale ahora (ahora: «AAAA-MM-DDTHH:MM»): ya es la hora, no pasaron más de 12 horas, y uno de «antes»
    solo si todavía no es el día (agendaste un pago para mañana: «en 2 días vence» ya no tiene sentido)."""
    if a["cuando"] > ahora[:16]:
        return False
    if datetime.datetime.fromisoformat(ahora[:16]) - datetime.datetime.fromisoformat(a["cuando"]) > datetime.timedelta(hours=12):
        return False
    return not (a["id"].endswith("-antes") and a["fecha"] <= ahora[:10])


def plata_linda(monto):
    # $ 1.250 · $ 99,50
    monto = round(float(monto), 2)
    entero = f"{int(abs(monto)):,}".replace(",", ".")
    decimales = f"{abs(monto) % 1:.2f}"[1:].replace(".", ",") if monto % 1 else ""
    return ("-" if monto < 0 else "") + "$ " + entero + decimales


# ======================= El archivo (y la cola para el bot) =======================

def cargar():
    datos = disco.leer(ARCHIVO, {"estado": vacio(), "para_el_bot": []})
    for clave, valor in vacio().items():
        datos["estado"].setdefault(clave, valor)
    datos.setdefault("para_el_bot", [])
    return datos


def _guardar(datos):
    disco.guardar(ARCHIVO, datos)
    if jarvis is not None:
        try:
            jarvis.emitir("finanzas", resumen(datos["estado"]))
        except Exception:
            pass


def nuevo_id():
    return "f" + format(int(time.time() * 1000), "x") + format(random.randrange(16 ** 4), "04x")


def hacer(op):
    """Aplica una operación nueva de esta PC y la deja en la cola para el bot."""
    op = dict(op, id=op.get("id") or nuevo_id(), en=int(time.time() * 1000))
    with _lock:
        datos = cargar()
        if aplicar(datos["estado"], op):
            datos["para_el_bot"].append(op)
            del datos["para_el_bot"][:-500]
            _guardar(datos)
            return op
    return None


def para_el_bot():
    """Lo que celular.py manda en «subir» (lo que se hizo acá y el bot todavía no tiene)."""
    with _lock:
        return list(cargar()["para_el_bot"])


def del_bot(estado_bot):
    """Lo que vino del bot en «bajar» (el estado entero): reemplaza al de acá, y lo de acá que el bot todavía no vio se
    vuelve a aplicar encima (así no se pierde lo que hiciste sin internet)."""
    if not isinstance(estado_bot, dict):
        return
    with _lock:
        datos = cargar()
        estado = vacio()
        estado.update({k: estado_bot.get(k, v) for k, v in vacio().items()})
        vistas = set(estado["vistas"])
        quedan = [op for op in datos["para_el_bot"] if op["id"] not in vistas]
        for op in quedan:
            aplicar(estado, op)
        datos["estado"], datos["para_el_bot"] = estado, quedan
        _guardar(datos)


# ======================= Por voz =======================

RE_MONTO = r"(\d{1,3}(?:[.\s]\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(mil|k|lucas?)?"
GASTO = re.compile(r"^(?:anota\w*\s+(?:un\s+)?gasto\s+de|gaste|gasto|pague|compre|me\s+gaste|se\s+me\s+fueron)\s+(?:como\s+)?"
                   r"(?:\$\s*)?" + RE_MONTO + r"\s*(?:pesos|\$|dolares|usd)?\s*(?:(?:en|de|del|para|por)\s+(?:el\s+|la\s+|los\s+|las\s+|un\s+|una\s+)?(.+?))?"
                   r"(?:\s+(?:con|en|de)\s+(?:la\s+|el\s+|mi\s+)?(tarjeta|debito|credito|efectivo|banco|cuenta\s+\w+|mercado\s*pago|prex|brou|itau|santander|bbva|scotia))?\s*$")
INGRESO = re.compile(r"^(?:anota\w*\s+(?:un\s+)?ingreso\s+de|cobre|me\s+pagaron|ingrese|gane|me\s+entraron|me\s+depositaron|recibi)\s+"
                     r"(?:\$\s*)?" + RE_MONTO + r"\s*(?:pesos|\$)?\s*(?:(?:de|del|por|en)\s+(?:el\s+|la\s+)?(.+?))?"
                     r"(?:\s+(?:en|a)\s+(?:la\s+|el\s+|mi\s+)?(tarjeta|efectivo|banco|cuenta\s+\w+|mercado\s*pago|prex|brou|itau|santander|bbva|scotia))?\s*$")
PRESUPUESTO = re.compile(r"(?:pone\w*\s+|fija\w*\s+|quiero\s+)?(?:un\s+)?presupuesto\s+(?:de\s+)?(?:(?:\$\s*)?" + RE_MONTO
                         + r"\s*(?:pesos)?\s+(?:para|en|de)\s+(.+)|(?:para\s+|de\s+)?([a-z ]+?)\s+(?:de|en)\s+(?:\$\s*)?"
                         + r"(\d+(?:[.,]\d+)?)\s*(mil|k)?)(?:\s+(?:por|al)\s+mes)?\s*$")
CUENTA = re.compile(r"^(?:(?:en\s+)?(?:la\s+|el\s+|mi\s+)?(?:cuenta\s+(?:del?\s+)?)?(banco|efectivo|tarjeta|mercado\s*pago|prex|brou|itau|"
                    r"santander|bbva|scotia|ahorros?)\s+(?:tengo|hay|tiene|quedan?)\s+|(?:tengo|hay)\s+)(?:\$\s*)?" + RE_MONTO
                    + r"(?:\s+(?:en\s+(?:la\s+|el\s+|mi\s+)?(?:cuenta\s+(?:del?\s+)?)?(banco|efectivo|tarjeta|mercado\s*pago|prex|brou|"
                      r"itau|santander|bbva|scotia|ahorros?)))?\s*$")
PAGO_NUEVO = re.compile(r"(?:agenda\w*|anota\w*|recorda\w*|avisame\w*\s+(?:del?|cuando\s+venc\w*))?\s*(?:el\s+)?(?:pago\s+(?:de\s+|del\s+)?"
                        r"(?:la\s+|el\s+)?|tengo\s+que\s+pagar\s+(?:la\s+|el\s+)?)(.+?)\s+(?:de\s+)?(?:\$\s*)?" + RE_MONTO
                        + r"?\s*(?:pesos)?\s*(?:el|los|todos\s+los|cada)\s+(\d{1,2})(?:\s+de\s+(?:cada\s+mes|(\w+)))?(.*)$")
PREGUNTA = re.compile(r"\b(cuanto (?:llevo )?gaste|cuanto (?:llevo )?gastado|como vengo con (?:la plata|el presupuesto|los gastos|la guita)|"
                      r"resumen de (?:gastos|plata|finanzas|la plata)|mis (?:gastos|finanzas|cuentas)|en que (?:gaste|se me fue)|"
                      r"cuanta plata (?:tengo|me queda)|cuanto (?:tengo|me queda) (?:en|de)|como estan? mis (?:cuentas|finanzas))\b")
PAGOS = re.compile(r"\b(que pagos tengo|que tengo que pagar|proximos pagos|pagos pendientes|que (?:me )?vence|cuando vence)\b")
PAGUE = re.compile(r"^(?:ya\s+)?(?:pague|pagamos|abone)\s+(?:la\s+|el\s+|los\s+|las\s+)?(.+?)(?:\s+(?:\$\s*)?" + RE_MONTO + r")?\s*$")
BORRAR = re.compile(r"\b(?:borra\w*|saca\w*|elimina\w*)\s+(?:el\s+)?ultimo\s+(gasto|ingreso|movimiento)\b")
MESES = {"enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6, "julio": 7, "agosto": 8,
         "septiembre": 9, "setiembre": 9, "octubre": 10, "noviembre": 11, "diciembre": 12}


def a_monto(numero, multiplicador=None):
    s = numero.replace(" ", "")
    if re.fullmatch(r"\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?", s):   # 1.500 · 1.500,50
        s = s.replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", ".")
    valor = float(s)
    if multiplicador in ("mil", "k", "luca", "lucas"):
        valor *= 1000
    return round(valor, 2)


def categoria_de(texto):
    palabras = re.findall(r"[a-z]+", jarvis.normalizar(texto) if jarvis else texto.lower())
    for p in palabras:
        if p in _CATEGORIA_DE:
            return _CATEGORIA_DE[p]
    limpio = " ".join(w for w in palabras if w not in {"el", "la", "los", "las", "un", "una", "unos", "unas", "mi", "mis"})
    return limpio[:1].upper() + limpio[1:] if limpio else "Otros"


def nombre_de_cuenta(texto):
    if not texto:
        return ""
    t = re.sub(r"^cuenta\s+(?:del?\s+)?", "", texto.strip())
    return {"debito": "Tarjeta", "credito": "Tarjeta", "mercadopago": "Mercado Pago"}.get(t.replace(" ", ""), t[:1].upper() + t[1:])


def _buscar_pago(estado, nombre):
    n = jarvis.normalizar(nombre) if jarvis else nombre.lower()
    for p in estado["pagos"]:
        pn = jarvis.normalizar(p["nombre"]) if jarvis else p["nombre"].lower()
        if pn == n or pn in n or n in pn:
            return p
    return None


def texto_resumen(r, categoria=None):
    if categoria:
        c = next((x for x in r["categorias"] if x["categoria"].lower() == categoria.lower()), None)
        if not c:
            return f"Este mes no anotaste gastos de {categoria}."
        extra = f" de {plata_linda(c['presupuesto'])} de presupuesto" if c["presupuesto"] else ""
        return f"Este mes gastaste {plata_linda(c['gastado'])} en {c['categoria']}{extra}."
    if not r["gastos"] and not r["ingresos"] and not r["cuentas"] and not r["pagos"]:
        return "Todavía no anotaste nada. Decime, por ejemplo, «gasté 500 en comida» o «cobré 30000 de sueldo»."
    partes = [f"Este mes: gastaste {plata_linda(r['gastos'])}" + (f" y entraron {plata_linda(r['ingresos'])}" if r["ingresos"] else "") + "."]
    top = [c for c in r["categorias"] if c["gastado"]][:3]
    if top:
        partes.append("Lo que más: " + ", ".join(f"{c['categoria']} {plata_linda(c['gastado'])}" for c in top) + ".")
    pasados = [c for c in r["categorias"] if c["presupuesto"] and c["gastado"] > c["presupuesto"]]
    cerca = [c for c in r["categorias"] if c["presupuesto"] and 0.8 * c["presupuesto"] <= c["gastado"] <= c["presupuesto"]]
    if pasados:
        partes.append("Te pasaste en " + ", ".join(f"{c['categoria']} ({plata_linda(c['gastado'] - c['presupuesto'])} de más)" for c in pasados) + ".")
    if cerca:
        partes.append("Cerca del límite: " + ", ".join(c["categoria"] for c in cerca) + ".")
    if r["cuentas"]:
        partes.append("Saldos: " + ", ".join(f"{c} {plata_linda(v)}" for c, v in r["cuentas"].items()) + ".")
    if r["pagos"]:
        p = r["pagos"][0]
        partes.append(f"Próximo pago: {p['nombre']} el {p['vence'][8:10]}/{p['vence'][5:7]}"
                      + (f" ({plata_linda(p['monto'])})" if p["monto"] else "") + ".")
    return " ".join(partes)


def manejar(texto, t):
    """Lo de plata. Devuelve la respuesta, o None si no es de esto."""
    t = t.strip(" ¿?¡!.,")
    hoy = datetime.date.today()
    if BORRAR.search(t):
        estado = cargar()["estado"]
        ultimo = estado["movimientos"][-1] if estado["movimientos"] else None
        if not ultimo:
            return "No tenés gastos ni ingresos anotados."
        hacer({"tipo": "borrar_mov", "mov": ultimo["id"]})
        return f"Listo, borré: {plata_linda(abs(ultimo['monto']))} de {ultimo['categoria']}" + (f" ({ultimo['nota']})" if ultimo["nota"] else "") + "."
    if PAGOS.search(t):
        pagos = sorted(cargar()["estado"]["pagos"], key=lambda p: p["vence"])
        if not pagos:
            return "No tenés pagos agendados. Decime, por ejemplo, «agendá el pago de la luz de 2500 el 10 de cada mes»."
        return "Tus próximos pagos: " + "; ".join(
            f"{p['nombre']} el {p['vence'][8:10]}/{p['vence'][5:7]}" + (f" ({plata_linda(p['monto'])})" if p["monto"] else "")
            + (" (todos los meses)" if p["repetir"] == "mensual" else "") for p in pagos[:6]) + "."
    m = PAGO_NUEVO.search(t)
    if m and m.group(4):
        nombre = m.group(1).strip()
        nombre = nombre[:1].upper() + nombre[1:]
        monto = a_monto(m.group(2), m.group(3)) if m.group(2) else 0
        dia = int(m.group(4))
        if not 1 <= dia <= 31:
            return "¿Qué día del mes vence?"
        mes = MESES.get(m.group(5) or "")
        anio = hoy.year
        if mes:
            if (mes, dia) < (hoy.month, hoy.day):
                anio += 1
        else:
            mes = hoy.month if dia >= hoy.day else hoy.month % 12 + 1
            anio = hoy.year + (1 if mes < hoy.month else 0)
        ultimo_dia = (datetime.date(anio + (mes == 12), mes % 12 + 1, 1) - datetime.timedelta(days=1)).day
        vence = datetime.date(anio, mes, min(dia, ultimo_dia)).isoformat()
        resto = (m.group(5) or "") + (m.group(6) or "")
        repetir = "" if MESES.get(m.group(5) or "") and "cada" not in t else \
            "anual" if re.search(r"cada ano|todos los anos|anual", resto + t) else \
            "semanal" if re.search(r"cada semana|semanal", t) else "mensual"
        if re.search(r"\b(?:una vez|solo este mes|unica vez)\b", t):
            repetir = ""
        op = hacer({"tipo": "pago", "nombre": nombre, "monto": monto, "vence": vence, "repetir": repetir,
                    "categoria": categoria_de(nombre)})
        if not op:
            return "No pude agendarlo."
        return (f"Listo, agendé {nombre}" + (f" ({plata_linda(monto)})" if monto else "") + f": vence el {vence[8:10]}/{vence[5:7]}"
                + (" y todos los meses" if repetir == "mensual" else " y todos los años" if repetir == "anual" else "")
                + ". Te aviso 2 días antes y ese día.")
    m = PAGUE.match(t)
    if m:
        estado = cargar()["estado"]
        nombre = re.sub(RE_MONTO + r"\s*(?:pesos)?\s*(?:de|del|por)?\s*", " ", m.group(1)).strip()
        num = re.search(RE_MONTO, m.group(1))
        pago = _buscar_pago(estado, nombre) if nombre else None
        if pago:
            monto = a_monto(m.group(2), m.group(3)) if m.group(2) else a_monto(num.group(1), num.group(2)) if num else pago["monto"]
            hacer({"tipo": "pagado", "pago": pago["id"], "monto": monto, "fecha": hoy.isoformat()})
            siguiente = _siguiente_del_pago(pago)
            return (f"Listo, marqué {pago['nombre']} como pagado" + (f" ({plata_linda(monto)})" if monto else "") + "."
                    + (f" El próximo vence el {siguiente[8:10]}/{siguiente[5:7]}." if siguiente else ""))
    m = GASTO.match(t)
    if m:
        monto = a_monto(m.group(1), m.group(2))
        sobre = (m.group(3) or "").strip()
        op = hacer({"tipo": "gasto", "monto": monto, "categoria": categoria_de(sobre) if sobre else "Otros",
                    "cuenta": nombre_de_cuenta(m.group(4)), "nota": sobre, "fecha": hoy.isoformat()})
        if not op:
            return "No pude anotarlo."
        r = resumen(cargar()["estado"])
        c = next((x for x in r["categorias"] if x["categoria"] == op["categoria"]), None)
        extra = ""
        if c and c["presupuesto"]:
            queda = c["presupuesto"] - c["gastado"]
            extra = (f" Te quedan {plata_linda(queda)} de {c['categoria']} este mes." if queda >= 0
                     else f" Ojo: te pasaste {plata_linda(-queda)} del presupuesto de {c['categoria']}.")
        return f"Anotado: {plata_linda(monto)} en {op['categoria']}" + (f" ({op['cuenta']})" if op["cuenta"] else "") + "." + extra
    m = INGRESO.match(t)
    if m:
        monto = a_monto(m.group(1), m.group(2))
        sobre = (m.group(3) or "").strip()
        op = hacer({"tipo": "ingreso", "monto": monto, "categoria": (sobre[:1].upper() + sobre[1:]) if sobre else "Ingresos",
                    "cuenta": nombre_de_cuenta(m.group(4)), "nota": sobre, "fecha": hoy.isoformat()})
        return f"Anotado: entraron {plata_linda(monto)}" + (f" de {op['categoria']}" if sobre else "") + "." if op else "No pude anotarlo."
    m = PRESUPUESTO.search(t)
    if m:
        if m.group(1):
            monto, cat = a_monto(m.group(1), m.group(2)), categoria_de(m.group(3))
        else:
            monto, cat = a_monto(m.group(5), m.group(6)), categoria_de(m.group(4))
        hacer({"tipo": "presupuesto", "categoria": cat, "monto": monto})
        return f"Listo: {plata_linda(monto)} por mes para {cat}. Te aviso cuando te acerques."
    m = CUENTA.match(t)
    if m and (m.group(1) or m.group(4)):
        nombre = nombre_de_cuenta(m.group(1) or m.group(4))
        saldo = a_monto(m.group(2), m.group(3))
        hacer({"tipo": "cuenta", "nombre": nombre, "saldo": saldo})
        return f"Listo: {nombre} con {plata_linda(saldo)}. Lo que gastes o cobres ahí se descuenta o se suma solo."
    m = PREGUNTA.search(t)
    if m:
        r = resumen(cargar()["estado"])
        c = re.search(r"\bgast\w+ (?:este mes )?(?:en|de) (?:la |el |los |las )?([a-z ]+?)(?: este mes)?$", t)
        return texto_resumen(r, categoria_de(c.group(1)) if c else None)
    return None


# ======================= Los avisos (pagos y pendientes con fecha) =======================

def _bucle_avisos():
    """Cada minuto: los vencimientos de pagos y pendientes que tocan (una sola vez cada uno, aunque reinicies)."""
    while True:
        try:
            pendientes = jarvis.habilidades.pendientes() if jarvis else []
            avisados = set(disco.leer(ARCHIVO_AVISADOS, []))
            ahora = datetime.datetime.now().isoformat(timespec="minutes")
            nuevos = []
            for a in vencimientos(cargar()["estado"], pendientes):
                if a["id"] in avisados or a["cuando"] > ahora:
                    continue
                avisados.add(a["id"])   # (los de hace mucho, con la PC apagada, se marcan sin avisar)
                if toca_avisar(a, ahora):
                    nuevos.append(a)
            if nuevos:
                disco.guardar(ARCHIVO_AVISADOS, sorted(avisados)[-800:])
                for a in nuevos:
                    jarvis.herramientas.notificar("J.A.R.V.I.S. · Aviso", a["texto"])
                    jarvis.aviso(a["texto"])
        except disco.ArchivoOcupado:
            pass
        except Exception:
            pass
        time.sleep(60)


def iniciar():
    threading.Thread(target=_bucle_avisos, daemon=True, name="finanzas-avisos").start()
# ======================= El panel Finanzas de la pantalla =======================

def para_la_pantalla():
    """Lo del panel: el resumen del mes y los últimos movimientos."""
    estado = cargar()["estado"]
    r = resumen(estado)
    r["ultimos"] = list(reversed(estado["movimientos"][-15:]))
    return r


def desde_la_pantalla(c):
    """Lo que se toca en el panel (lo mismo que finApp_ en el bot del celular)."""
    c = c if isinstance(c, dict) else {}
    que = c.get("que")
    try:
        monto = abs(float(c.get("monto") or 0))
    except (TypeError, ValueError):
        monto = 0
    nombre = str(c.get("nombre") or "").strip()[:60]
    hoy = datetime.date.today().isoformat()
    estado = cargar()["estado"]
    if que in ("gasto", "ingreso"):
        if not monto:
            return {"ok": False, "error": "Poné cuánto."}
        sobre = str(c.get("sobre") or "").strip()[:80]
        op = {"tipo": que, "monto": monto, "nota": sobre, "cuenta": nombre_de_cuenta(str(c.get("cuenta") or "").strip()[:40]),
              "fecha": hoy, "categoria": (categoria_de(sobre) if sobre else "Otros") if que == "gasto"
              else ((sobre[:1].upper() + sobre[1:]) if sobre else "Ingresos")}
    elif que == "borrar_mov":
        op = {"tipo": "borrar_mov", "mov": str(c.get("id") or "")}
    elif que == "pago":
        vence = str(c.get("vence") or "")
        if not nombre or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", vence):
            return {"ok": False, "error": "Poné qué es y cuándo vence."}
        op = {"tipo": "pago", "nombre": nombre[:1].upper() + nombre[1:], "monto": monto, "vence": vence,
              "repetir": c.get("repetir") if c.get("repetir") in ("mensual", "semanal", "anual") else "",
              "categoria": categoria_de(nombre)}
    elif que in ("pagado", "borrar_pago"):
        if not any(p["id"] == c.get("id") for p in estado["pagos"]):
            return {"ok": False, "error": "Ese pago ya no está."}
        op = ({"tipo": "pagado", "pago": c["id"], "monto": monto or None, "fecha": hoy} if que == "pagado"
              else {"tipo": "borrar_pago", "pago": c["id"]})
    elif que == "presupuesto":
        if not str(c.get("categoria") or "").strip():
            return {"ok": False, "error": "Poné la categoría."}
        op = {"tipo": "presupuesto", "categoria": categoria_de(str(c["categoria"])), "monto": monto}
    elif que == "cuenta":
        if not nombre:
            return {"ok": False, "error": "Poné el nombre de la cuenta."}
        try:
            saldo = float(c.get("saldo") or 0)
        except (TypeError, ValueError):
            saldo = 0
        op = {"tipo": "cuenta", "nombre": nombre_de_cuenta(nombre), "saldo": saldo, "borrar": bool(c.get("borrar"))}
    else:
        return {"ok": False, "error": "No sé hacer eso."}
    if not hacer(op):
        return {"ok": False, "error": "No cambió nada."}
    return {"ok": True, "finanzas": para_la_pantalla()}
