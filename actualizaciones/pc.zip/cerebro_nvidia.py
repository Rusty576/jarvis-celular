"""Segundo cerebro OPCIONAL: un modelo grande en la nube (Google Gemini, Groq o NVIDIA; todas con API
compatible con OpenAI).

- Gemma en tu PC (Ollama) sigue siendo el cerebro de siempre: todo funciona sin internet como antes.
- Con el botón "pensar más" (el cerebrito al lado del campo de texto), SOLO la pregunta siguiente va a la nube.
  En Configuraciones también se puede elegir la nube para todas las respuestas, y qué modelo usar.
- Si no hay internet, falta la clave o la API falla, responde Gemma y te avisa.
- Las claves se leen de variables de entorno (nunca se escriben en el código): GEMINI_API_KEY, GROQ_API_KEY o
  NVIDIA_API_KEY. Para crearlas: Configuraciones > Cuentas y servicios > IA en la nube > CONECTAR, o en una
  terminal:  setx GEMINI_API_KEY "..."
"""
import json
import os
import re
import socket
import time
import urllib.error
import urllib.request

jarvis = None  # main.py se anota acá al arrancar

# Cada nube: dónde está, de qué variable sale la clave y los modelos que conviene mostrar primero
PROVEEDORES = {
    "gemini": {
        "nombre": "Gemini", "empresa": "Google", "url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "variable": "GEMINI_API_KEY", "pagina": "https://aistudio.google.com/apikey",
        # Google retira modelos seguido: si el elegido da 404, se busca solo uno que tu cuenta tenga (mejor_modelo)
        # (2026-10-08: el 3.8 Flash daba 503 "mucha demanda" y el 2.5 ya no se da a cuentas nuevas)
        "modelo": "gemini-3.5-flash", "detalle": "gratis con tu cuenta de Google",
        "recomendados": [("gemini-3.5-flash", "Gemini 3.5 Flash (rápido y estable, recomendado)"),
                         ("gemini-flash-latest", "Gemini Flash (la última versión; a veces saturado)"),
                         ("gemini-pro-latest", "Gemini Pro (el más inteligente; menos usos por día)"),
                         ("gemini-flash-lite-latest", "Gemini Flash-Lite (el más rápido)")],
        "nuevos": r"^gemini-\d[\w.]*-(?:pro|flash)[\w.-]*$",  # versiones que salgan después también se muestran
    },
    "groq": {
        "nombre": "Groq", "empresa": "Groq", "url": "https://api.groq.com/openai/v1",
        "variable": "GROQ_API_KEY", "pagina": "https://console.groq.com/keys",
        "modelo": "openai/gpt-oss-120b", "detalle": "gratis, muy rápido",
        # el plan gratis rechaza pedidos grandes (error 413): cuenta lo que mandás MÁS el lugar pedido para la
        # respuesta, y el tope es de unos 8000 tokens por minuto. Con más letras que esto no se le manda (ej.: código)
        "max_letras": 20000, "max_tokens_total": 7800,
        "recomendados": [("openai/gpt-oss-120b", "GPT-OSS 120B (recomendado)"),
                         ("llama-3.3-70b-versatile", "Llama 3.3 70B"),
                         ("moonshotai/kimi-k2-instruct-0905", "Kimi K2"),
                         ("qwen/qwen3-32b", "Qwen3 32B")],
        "nuevos": r"^(?!.*(?:whisper|guard|tts|playai|orpheus)).+$",
    },
    "nvidia": {
        "nombre": "NVIDIA", "empresa": "NVIDIA", "url": "https://integrate.api.nvidia.com/v1",
        "variable": "NVIDIA_API_KEY", "pagina": "https://build.nvidia.com/settings/api-keys",
        "modelo": "nvidia/nemotron-3-super-120b-a12b", "detalle": "build.nvidia.com",
        "recomendados": [("nvidia/nemotron-3-super-120b-a12b", "Nemotron 3 Super 120B (rápido, recomendado)"),
                         ("moonshotai/kimi-k2.6", "Kimi K2.6"),
                         ("moonshotai/kimi-k3", "Kimi K3"),
                         ("deepseek-ai/deepseek-v4.1-flash", "DeepSeek V4.1 Flash"),
                         ("z-ai/glm-5.3", "GLM 5.3"),
                         ("google/gemma-4-31b-it", "Gemma 4 31B (el hermano mayor de tu Gemma)"),
                         ("mistralai/mistral-large-2-instruct", "Mistral Large 2"),
                         ("nvidia/llama-3.1-nemotron-ultra-253b-v1", "Nemotron Ultra 253B"),
                         ("nvidia/nemotron-3-ultra-550b-a55b", "Nemotron 3 Ultra 550B (el más grande, más lento)")],
        "nuevos": None,
    },
}
ORDEN = ["gemini", "groq", "nvidia"]  # si la elegida no tiene clave, se usa la primera que sí tenga

PROVEEDOR = "gemini"  # la nube elegida en Configuraciones
MODELOS = {p: d["modelo"] for p, d in PROVEEDORES.items()}  # el modelo elegido de cada nube
CEREBRO = "local"  # "local" (Gemma, predeterminado) o "nube" (todas las respuestas a la nube)
ESPERA_CONEXION = 25  # segundos para que empiece a contestar (si no, Gemma)
MAX_RESPUESTA = 2048  # tokens

estado = {"ultimo": "local", "ultimo_error": None}
_proxima = {"armada": False, "texto": None, "hasta": 0.0}  # "pensar más" para la próxima pregunta
_cache_modelos = {}  # proveedor -> (cuando, ids)


# ---------- Las claves (solo desde variables de entorno) ----------

def clave(proveedor=None):
    """La clave de esa nube, de su variable de entorno; si la creaste con setx después de abrir JARVIS, se lee de
    tus variables de usuario de Windows (así no hace falta reiniciar)."""
    variable = PROVEEDORES[proveedor or activo()]["variable"]
    valor = os.environ.get(variable)
    if valor:
        return valor.strip()
    try:
        import winreg

        for raiz, ruta in ((winreg.HKEY_CURRENT_USER, "Environment"),
                           (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")):
            try:
                with winreg.OpenKey(raiz, ruta) as k:
                    valor, _ = winreg.QueryValueEx(k, variable)
                    if valor:
                        return str(valor).strip()
            except OSError:
                continue
    except ImportError:
        pass
    return None


def activo():
    """La nube que se usa: la elegida si tiene clave; si no, la primera que tenga."""
    if _tiene_clave(PROVEEDOR):
        return PROVEEDOR
    return next((p for p in ORDEN if _tiene_clave(p)), PROVEEDOR)


def _tiene_clave(proveedor):
    variable = PROVEEDORES[proveedor]["variable"]
    if os.environ.get(variable):
        return True
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
            return bool(winreg.QueryValueEx(k, variable)[0])
    except (ImportError, OSError):
        return False


def configurado():
    return any(_tiene_clave(p) for p in ORDEN)


def modelo_actual():
    return MODELOS[activo()]


def nombre_modelo(modelo=None, proveedor=None):
    proveedor = proveedor or activo()
    modelo = modelo or MODELOS[proveedor]
    return next((n.split(" (")[0] for m, n in PROVEEDORES[proveedor]["recomendados"] if m == modelo),
                modelo.split("/")[-1])


def nombre_completo(modelo=None):
    """'Gemini · Gemini 3.5 Flash' (para la burbuja del chat). modelo: el que respondió de verdad, si fue otro."""
    p = activo()
    nombre = nombre_modelo(modelo, proveedor=p)
    return nombre if nombre.lower().startswith(PROVEEDORES[p]["nombre"].lower()) else f"{PROVEEDORES[p]['nombre']} · {nombre}"


# ---------- ¿Esta pregunta va a la nube? ----------

def pensar_mas(texto=None, activar=True):
    """El botón 'pensar más': la próxima pregunta (o esa en particular) se manda a la nube."""
    _proxima.update(armada=bool(activar), texto=texto, hasta=time.time() + 120)


def usar_para(pregunta):
    """True si ESTA pregunta va a la nube (botón 'pensar más' o la nube elegida en Configuraciones)."""
    if _proxima["armada"] and time.time() < _proxima["hasta"]:
        if _proxima["texto"] is None or jarvis.normalizar(_proxima["texto"]) == jarvis.normalizar(pregunta):
            _proxima.update(armada=False, texto=None)  # solo esa pregunta
            return True
    return CEREBRO == "nube"


# ---------- Hablar con la API ----------

def _a_formato_openai(mensajes):
    """Los mensajes de Ollama al formato OpenAI. Todos los de sistema se juntan en uno al principio y los
    seguidos del mismo rol se unen (algunos modelos de la API lo exigen)."""
    sistema = "\n\n".join(m["content"] for m in mensajes if m["role"] == "system")
    salida = [{"role": "system", "content": sistema}] if sistema else []
    for m in mensajes:
        if m["role"] == "system":
            continue
        if salida and salida[-1]["role"] == m["role"]:
            salida[-1]["content"] += "\n\n" + m["content"]
        else:
            salida.append({"role": m["role"], "content": m["content"]})
    return salida


def _error_lindo(e, proveedor=None):
    p = PROVEEDORES[proveedor or activo()]
    if isinstance(e, urllib.error.HTTPError):
        return {400: "la API rechazó el pedido (¿el modelo existe?)", 401: f"la clave {p['variable']} no es válida",
                403: "la clave no tiene permiso para ese modelo (o la cuenta está en revisión)",
                404: f"el modelo {MODELOS[proveedor or activo()]} no está disponible",
                429: "llegaste al límite de uso gratis por ahora",
                503: f"{p['nombre']} está saturado en este momento (pasa en el plan gratis; en un rato vuelve)"}.get(
            e.code, f"la API respondió error {e.code}")
    if isinstance(e, (socket.timeout, TimeoutError)) or "timed out" in str(e):
        return f"{p['nombre']} tardó demasiado en contestar"
    if isinstance(e, urllib.error.URLError):
        return f"no hay conexión a internet (o no llego a {p['nombre']})"
    return str(e)[:120]


def _sin_pensamientos(trozos):
    """Algunos modelos piensan en voz alta entre <think>...</think>: eso no se muestra."""
    adentro, buffer = False, ""
    for t in trozos:
        buffer += t
        while True:
            if adentro:
                fin = buffer.find("</think>")
                if fin < 0:
                    buffer = buffer[-8:]
                    break
                buffer, adentro = buffer[fin + 8:].lstrip(), False
            else:
                ini = buffer.find("<think>")
                if ini < 0:
                    # puede venir cortado "<thi": se guarda el final por las dudas
                    corte = max(0, len(buffer) - 7) if "<" in buffer[-7:] else len(buffer)
                    if corte:
                        yield buffer[:corte]
                    buffer = buffer[corte:]
                    break
                if ini:
                    yield buffer[:ini]
                buffer, adentro = buffer[ini + 7:], True
    if buffer and not adentro:
        yield buffer


def listar_modelos(proveedor, k):
    """Los modelos que esa cuenta puede usar hoy (con la clave). Lista vacía si no se pudo ver."""
    headers = {"User-Agent": "JARVIS"}
    if k:
        headers["Authorization"] = f"Bearer {k}"
    try:
        pedido = urllib.request.Request(PROVEEDORES[proveedor]["url"] + "/models", headers=headers)
        with urllib.request.urlopen(pedido, timeout=10) as r:
            return [str(m.get("id", "")).removeprefix("models/") for m in json.load(r).get("data", [])]
    except Exception:
        return []


def _version(modelo):
    m = re.search(r"-(\d+(?:\.\d+)*)-", modelo + "-")
    return tuple(int(x) for x in m.group(1).split(".")) if m else (0,)


def mejor_modelo(proveedor, ids):
    """De los modelos que hay, el mejor para charlar: primero los recomendados; si no está ninguno (Google los
    retira seguido), el Flash de versión más nueva (gratis y rápido), después Pro."""
    if not ids:
        return None
    for m, _ in PROVEEDORES[proveedor]["recomendados"]:
        if m in ids:
            return m
    if proveedor == "gemini":
        chat = [i for i in ids if re.match(r"^gemini-[\d.]+-(?:flash|pro)\b", i)
                and not re.search(r"lite|image|tts|live|audio|embedding|vision|exp\b|thinking", i)]
        if chat:
            return max(chat, key=lambda i: ("flash" in i, "preview" not in i, _version(i)))
    regla = PROVEEDORES[proveedor]["nuevos"]
    otros = [i for i in ids if not regla or re.match(regla, i)]
    return otros[0] if otros else None


def chat_stream(mensajes, temperatura=0.6, proveedor=None, largo=None, espera=None):
    """Va devolviendo el texto de la respuesta de la nube a medida que llega. Si esa nube falla antes de decir algo
    (sin cupo, saturada, sin respuesta), prueba con tus otras nubes que tengan clave (ej.: Gemini -> Groq); recién si
    fallan todas, el error sube y responde Gemma. largo: tokens máximos (código: más); espera: segundos para que
    empiece a contestar (escribir código lleva más)."""
    primera = proveedor or activo()
    letras = sum(len(str(m.get("content", ""))) for m in mensajes)
    # de respaldo, solo las nubes que aceptan un pedido de este tamaño (el gratis de Groq rechaza los grandes)
    fila = [primera] + [p for p in ORDEN if p != primera and _tiene_clave(p)
                        and letras <= PROVEEDORES[p].get("max_letras", 10 ** 9)]
    for i, p in enumerate(fila):
        dijo_algo = False
        try:
            for trozo in _chat_de(mensajes, temperatura, p, largo, espera):
                dijo_algo = True
                yield trozo
            estado["respaldo"] = p if p != primera else None
            return
        except Exception:
            if dijo_algo or i == len(fila) - 1:
                raise  # si ya había empezado a contestar, no se mezclan dos respuestas


def chat_completo(mensajes, temperatura=0.3, largo=None, esquema=None):
    """La respuesta entera de la nube, con la forma de Ollama ({'message': {'content': ...}}), para lo que JARVIS le
    pregunta por dentro (qué protocolo es un pedido, el prompt de una imagen...). Con esquema: un JSON con esa forma
    (se le pide por escrito y se saca de la respuesta aunque venga entre ```)."""
    if esquema:
        pedido = ("\n\nRespondé SOLO con un objeto JSON válido (sin texto antes ni después, sin ```), con esta forma "
                  "(JSON Schema): " + json.dumps(esquema, ensure_ascii=False))
        mensajes = [dict(m) for m in mensajes]
        if mensajes and mensajes[0].get("role") == "system":
            mensajes[0]["content"] = str(mensajes[0].get("content", "")) + pedido
        else:
            mensajes.insert(0, {"role": "system", "content": pedido.strip()})
    texto = "".join(chat_stream(mensajes, temperatura=temperatura, largo=largo)).strip()
    if esquema:
        m = re.search(r"\{.*\}", texto, re.S)
        if not m:
            raise ValueError("la nube no devolvió un JSON")
        texto = m.group(0)
        json.loads(texto)   # (que sea JSON de verdad: si no, que lo haga la IA de la PC)
    if not texto:
        raise RuntimeError("la nube respondió vacío")
    return {"message": {"content": texto}}


def _chat_de(mensajes, temperatura, proveedor, largo=None, espera=None, _reintento=True):
    """Una nube: si el modelo ya no existe (404), elige solo uno que la cuenta tenga y reintenta (y lo deja elegido);
    si está saturado, prueba otros modelos de la misma nube."""
    p = PROVEEDORES[proveedor]
    k = clave(proveedor)
    if not k:
        raise RuntimeError(f"no encontré la variable {p['variable']}")
    estado["modelo_usado"] = MODELOS[proveedor]
    try:
        yield from _chat_stream(mensajes, temperatura, proveedor, k, largo=largo, espera=espera)
    except urllib.error.HTTPError as e:
        if e.code in TEMPORALES and _reintento:
            # saturado ("high demand") o sin usos en ESE modelo: se prueba con otros de la misma nube antes de Gemma
            for alternativo in _alternativas(proveedor, k)[:3]:
                try:
                    estado["modelo_usado"] = alternativo
                    yield from _chat_stream(mensajes, temperatura, proveedor, k, modelo=alternativo, largo=largo,
                                            espera=espera)
                    return
                except urllib.error.HTTPError as e2:
                    if e2.code not in TEMPORALES + (404,):
                        raise
            raise
        if e.code != 404 or not _reintento:
            raise
        nuevo = mejor_modelo(proveedor, [i for i in listar_modelos(proveedor, k) if i != MODELOS[proveedor]])
        if not nuevo:
            raise
        MODELOS[proveedor] = nuevo
        _cache_modelos.pop(proveedor, None)
        if jarvis:
            try:
                jarvis.ajustes.guardar({f"modelo_{proveedor}": nuevo})  # que la próxima vez arranque con este
            except Exception:
                pass
        yield from _chat_de(mensajes, temperatura, proveedor, largo=largo, espera=espera, _reintento=False)


TEMPORALES = (429, 500, 502, 503, 504)  # errores que se arreglan con otro modelo o un rato después


def _alternativas(proveedor, k):
    """Otros modelos de la misma nube para cuando el elegido está saturado: los recomendados que la cuenta tenga y,
    en Gemini, los Flash de versión más nueva primero (los Lite al final)."""
    ids = _modelos_en_vivo(proveedor) or listar_modelos(proveedor, k)
    actual = MODELOS[proveedor]
    lista = [m for m, _ in PROVEEDORES[proveedor]["recomendados"] if m in ids and m != actual]
    if proveedor == "gemini":
        chat = [i for i in ids if re.match(r"^gemini-[\d.]+-flash(?:-lite)?$", i) and i != actual and i not in lista]
        lista += sorted(chat, key=lambda i: ("lite" not in i, _version(i)), reverse=True)
        lista.sort(key=lambda i: ("lite" in i, "pro" in i))  # primero Flash; Pro (pocos usos gratis) y Lite al final
    return lista


def _chat_stream(mensajes, temperatura, proveedor, k, modelo=None, largo=None, espera=None):
    p = PROVEEDORES[proveedor]
    salida = largo or MAX_RESPUESTA
    if p.get("max_tokens_total"):  # que lo pedido + el lugar para la respuesta entren en el tope de esa nube
        entrada = sum(len(str(m.get("content", ""))) for m in mensajes) // 3
        salida = max(256, min(salida, p["max_tokens_total"] - entrada))
    cuerpo = {"model": modelo or MODELOS[proveedor], "messages": _a_formato_openai(mensajes), "temperature": temperatura,
              "top_p": 0.95, "max_tokens": salida, "stream": True}
    pedido = urllib.request.Request(p["url"] + "/chat/completions", data=json.dumps(cuerpo).encode("utf-8"),
                                    headers={"Authorization": f"Bearer {k}", "Content-Type": "application/json",
                                             "Accept": "text/event-stream", "User-Agent": "JARVIS"})

    def crudo():
        with urllib.request.urlopen(pedido, timeout=espera or ESPERA_CONEXION) as r:
            for linea in r:
                linea = linea.decode("utf-8", "replace").strip()
                if not linea.startswith("data:"):
                    continue
                dato = linea[5:].strip()
                if dato == "[DONE]":
                    break
                try:
                    j = json.loads(dato)
                except ValueError:
                    continue
                if isinstance(j, list):  # algunas APIs mandan el error como lista
                    j = j[0] if j and isinstance(j[0], dict) else {}
                if j.get("error"):
                    raise RuntimeError(str(j["error"])[:150])
                for opcion in j.get("choices") or []:
                    texto = (opcion.get("delta") or {}).get("content")
                    if texto:
                        yield texto
    yield from _sin_pensamientos(crudo())


def responder_stream(mensajes, generar_local, avisar):
    """Como el stream de Ollama ({'message': {'content': ...}}), pero con la nube. Si falla antes de decir algo,
    sigue Gemma y avisa; si se corta a la mitad, se queda con lo que llegó y avisa."""
    llego_algo = False
    nombre = PROVEEDORES[activo()]["nombre"]
    try:
        for texto in chat_stream(mensajes):
            llego_algo = True
            yield {"message": {"content": texto}}
        if not llego_algo:
            raise RuntimeError(f"{nombre} respondió vacío")
        estado.update(ultimo="nube", ultimo_error=None)
    except GeneratorExit:
        raise
    except Exception as e:
        motivo = _error_lindo(e)
        estado["ultimo_error"] = f"{nombre}: {motivo}"
        if llego_algo:
            estado["ultimo"] = "nube"
            avisar(f"{nombre} se cortó a mitad de la respuesta ({motivo}).")
            return
        estado["ultimo"] = "local"
        avisar(f"No pude usar {nombre} ({motivo}): te respondo con Gemma, en tu PC.")
        yield from generar_local()


# ---------- Para Configuraciones ----------

def _modelos_en_vivo(proveedor):
    """Los modelos que esa nube tiene hoy (pedido con la clave; no gasta usos). None si no se pudo ver."""
    guardado = _cache_modelos.get(proveedor)
    if guardado and time.time() - guardado[0] < 3600:
        return guardado[1]
    k = clave(proveedor)
    if not k and proveedor != "nvidia":  # la lista de NVIDIA es pública
        return None
    ids = listar_modelos(proveedor, k)
    if not ids:
        return None
    _cache_modelos[proveedor] = (time.time(), ids)
    return ids


NO_ES_DE_CHARLA = re.compile(r"tts|image|imagen|embed|live|audio|whisper|guard|robotics|computer-use|native|"
                             r"orpheus|playai|vision|-exp\b", re.IGNORECASE)


def modelos_disponibles(solo=None):
    """Para el selector de Configuraciones: 'nube|modelo' de cada nube (primero las que tienen clave), solo los que
    sirven para charlar (no los de voz, imágenes, etc.). solo: una sola nube."""
    lista = []
    for p in sorted(ORDEN, key=lambda x: not _tiene_clave(x)):
        if solo and p != solo:
            continue
        d = PROVEEDORES[p]
        vivos = _modelos_en_vivo(p) if _tiene_clave(p) or p == "nvidia" else None
        recomendados = [m for m, _ in d["recomendados"] if not vivos or m in vivos]
        nuevos = [m for m in (vivos or []) if d["nuevos"] and re.match(d["nuevos"], m) and m not in recomendados
                  and not NO_ES_DE_CHARLA.search(m)]
        modelos = recomendados + sorted(nuevos, reverse=True)[:6]
        if MODELOS[p] not in modelos:
            modelos.insert(0, MODELOS[p])
        lista += [f"{p}|{m}" for m in modelos]
    return lista


def nombres_de_modelos():
    """'gemini|gemini-2.5-flash' -> 'Gemini · Gemini 2.5 Flash (rápido, recomendado)' (con aviso si falta la clave)."""
    nombres, todos = {}, modelos_disponibles()
    for p in ORDEN:
        d = PROVEEDORES[p]
        sin = "" if _tiene_clave(p) else " — sin clave"
        for m, n in d["recomendados"]:
            nombres[f"{p}|{m}"] = (n if n.lower().startswith(d["nombre"].lower()) else f"{d['nombre']} · {n}") + sin
        for valor in todos:
            if valor.startswith(p + "|") and valor not in nombres:
                nombres[valor] = f"{d['nombre']} · {valor.split('|', 1)[1]}{sin}"
    return nombres


def elegir(valor):
    """Configuraciones: 'gemini|gemini-2.5-pro' elige la nube y su modelo."""
    global PROVEEDOR
    p, _, modelo = str(valor).partition("|")
    if p in PROVEEDORES:
        PROVEEDOR = p
        if modelo:
            MODELOS[p] = modelo


def probar(proveedor=None):
    """Una pregunta cortita para ver si anda: (ok, mensaje)."""
    proveedor = proveedor or activo()
    p = PROVEEDORES[proveedor]
    if not _tiene_clave(proveedor):
        return False, f"Falta la clave de {p['nombre']}: no encontré la variable {p['variable']}."
    t = time.time()
    try:
        texto = "".join(chat_stream([{"role": "user", "content": "Respondé solo: funciono"}], 0, proveedor))
    except Exception as e:
        return False, f"{p['nombre']} no anduvo: {_error_lindo(e, proveedor)}."
    return True, (f"¡Anda! {nombre_modelo(proveedor=proveedor)} ({p['nombre']}) contestó en {time.time() - t:.1f} s: "
                  f"«{texto.strip()[:60]}».")


def abrir_configuracion(proveedor="gemini"):
    """Ventana para pegar la clave: la guarda como variable de entorno de tu usuario (no en el código)."""
    import subprocess
    import sys

    proveedor = proveedor if proveedor in PROVEEDORES else "gemini"
    python = sys.executable.replace("pythonw.exe", "python.exe")
    subprocess.Popen([python, os.path.join(os.path.dirname(os.path.abspath(__file__)), "configurar.py"), proveedor],
                     creationflags=subprocess.CREATE_NEW_CONSOLE)
    return f"Te abrí una ventana para pegar tu clave de {PROVEEDORES[proveedor]['nombre']}. Seguí los pasos que aparecen ahí."


def quitar_clave(proveedor):
    """Borra la variable de esa nube de tus variables de usuario de Windows."""
    import winreg

    variable = PROVEEDORES[proveedor]["variable"]
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, variable)
    except FileNotFoundError:
        pass
    os.environ.pop(variable, None)
    _cache_modelos.pop(proveedor, None)


def resumen():
    p = activo()
    return {"clave": configurado(), "proveedor": p, "nombre": nombre_completo(), "cerebro": CEREBRO,
            "ultimo_error": estado["ultimo_error"],
            "nubes": [{"id": q, "nombre": PROVEEDORES[q]["nombre"], "detalle": PROVEEDORES[q]["detalle"],
                       "clave": _tiene_clave(q), "variable": PROVEEDORES[q]["variable"]} for q in ORDEN]}
