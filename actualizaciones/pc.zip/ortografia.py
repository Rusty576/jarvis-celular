"""Corrector ortográfico: el mismo que usa Windows (y Word, Edge...), sin internet.

Lo usa la pantalla compartida: «¿qué errores de ortografía tiene el texto?». El modelo de IA no sirve para esto: lee
mal la letra chica y se inventa errores («differencial») que no están. Este corrector revisa el texto de verdad
(el que leyó el OCR de Windows) y dice qué palabra está mal, dónde, y cómo se escribe.
"""
import ctypes
import re
from ctypes import HRESULT, POINTER, c_ulong, c_wchar_p
from ctypes.wintypes import BOOL, LPCWSTR

import comtypes
import comtypes.client
from comtypes import GUID, IUnknown, COMMETHOD

IDIOMAS = ["es-UY", "es-419", "es-MX", "es-ES"]  # el primero que tenga Windows


class IEnumString(IUnknown):
    _iid_ = GUID("{00000101-0000-0000-C000-000000000046}")
    _methods_ = [
        COMMETHOD([], HRESULT, "Next", (["in"], c_ulong, "celt"), (["out"], POINTER(c_wchar_p), "rgelt"),
                  (["out"], POINTER(c_ulong), "pceltFetched")),
        COMMETHOD([], HRESULT, "Skip", (["in"], c_ulong, "celt")),
        COMMETHOD([], HRESULT, "Reset"),
        COMMETHOD([], HRESULT, "Clone", (["out"], POINTER(POINTER(IUnknown)), "ppenum")),
    ]


class ISpellingError(IUnknown):
    _iid_ = GUID("{B7C82D61-FBE8-4B47-9B27-6C0D2E0DE0A3}")
    _methods_ = [
        COMMETHOD([], HRESULT, "get_StartIndex", (["out"], POINTER(c_ulong), "value")),
        COMMETHOD([], HRESULT, "get_Length", (["out"], POINTER(c_ulong), "value")),
        COMMETHOD([], HRESULT, "get_CorrectiveAction", (["out"], POINTER(ctypes.c_int), "value")),
        COMMETHOD([], HRESULT, "get_Replacement", (["out"], POINTER(c_wchar_p), "value")),
    ]


class IEnumSpellingError(IUnknown):
    _iid_ = GUID("{803E3BD4-2828-4410-8290-418D1D73C762}")
    _methods_ = [
        COMMETHOD([], HRESULT, "Next", (["out"], POINTER(POINTER(ISpellingError)), "value")),
    ]


class ISpellChecker(IUnknown):
    _iid_ = GUID("{B6FD0B71-E2BC-4653-8D05-F197E412770B}")
    _methods_ = [
        COMMETHOD([], HRESULT, "get_LanguageTag", (["out"], POINTER(c_wchar_p), "value")),
        COMMETHOD([], HRESULT, "Check", (["in"], LPCWSTR, "text"), (["out"], POINTER(POINTER(IEnumSpellingError)), "value")),
        COMMETHOD([], HRESULT, "Suggest", (["in"], LPCWSTR, "word"), (["out"], POINTER(POINTER(IEnumString)), "value")),
    ]


class ISpellCheckerFactory(IUnknown):
    _iid_ = GUID("{8E018A9D-2415-4677-BF08-794EA61F94BB}")
    _methods_ = [
        COMMETHOD([], HRESULT, "get_SupportedLanguages", (["out"], POINTER(POINTER(IEnumString)), "value")),
        COMMETHOD([], HRESULT, "IsSupported", (["in"], LPCWSTR, "languageTag"), (["out"], POINTER(BOOL), "value")),
        COMMETHOD([], HRESULT, "CreateSpellChecker", (["in"], LPCWSTR, "languageTag"),
                  (["out"], POINTER(POINTER(ISpellChecker)), "value")),
    ]


CLSID_FABRICA = GUID("{7AB36653-1796-484B-BDFA-E74F1DB7C1DC}")
S_OK = 0


def _corrector():
    comtypes.CoInitialize()  # cada hilo que usa COM lo necesita (si ya estaba, no pasa nada)
    fabrica = comtypes.client.CreateObject(CLSID_FABRICA, interface=ISpellCheckerFactory)
    for idioma in IDIOMAS:
        if fabrica.IsSupported(idioma):
            return fabrica.CreateSpellChecker(idioma)
    return None


def _sugerencias(corrector, palabra, cuantas=3):
    lista = corrector.Suggest(palabra)
    salida = []
    while len(salida) < cuantas:
        try:
            texto, traidas = lista.Next(1)
        except comtypes.COMError:
            break
        if not traidas:
            break
        salida.append(texto)
    return salida


def frase_de(texto, inicio, fin):
    """La oración (o el renglón) donde está la palabra, para decir DÓNDE está el error."""
    desde = max(texto.rfind(c, 0, inicio) for c in ".!?\n") + 1
    hasta = min([p for p in (texto.find(c, fin) for c in ".!?\n") if p != -1] or [len(texto)])
    return " ".join(texto[desde:hasta + 1].split())


def revisar(texto):
    """Los errores de ortografía del texto: [{"palabra", "sugerencias", "frase"}]. None si Windows no tiene corrector
    en español. No marca nombres propios (empiezan con mayúscula en medio de la oración), siglas ni números."""
    corrector = _corrector()
    if corrector is None:
        return None
    errores, vistos = [], set()
    enum = corrector.Check(texto)
    while True:
        try:
            error = enum.Next()
        except comtypes.COMError:
            break
        if not error:
            break
        inicio, largo = error.get_StartIndex(), error.get_Length()
        palabra = texto[inicio:inicio + largo]
        antes = texto[:inicio].rstrip()
        en_medio = antes and antes[-1] not in ".!?:\n"
        if (len(palabra) < 3 or any(c.isdigit() for c in palabra) or palabra.isupper()
                or (palabra[0].isupper() and en_medio) or palabra.lower() in vistos):
            continue
        vistos.add(palabra.lower())
        accion = error.get_CorrectiveAction()   # 2: reemplazarla, 3: borrarla (una palabra repetida: «los los»)
        if accion == 3:
            sugerencias = []
        elif accion == 2:
            sugerencias = [error.get_Replacement()]
        else:
            sugerencias = _sugerencias(corrector, palabra)
        errores.append({"palabra": palabra, "sugerencias": sugerencias, "frase": frase_de(texto, inicio, inicio + largo),
                        "repetida": accion == 3})
    return errores


def para_la_ia(errores):
    """Los errores, explicados en texto para pasárselos a la IA (que los cuenta con sus palabras, sin agregar otros)."""
    if not errores:
        return ("El corrector ortográfico de Windows revisó el texto y NO encontró errores de ortografía. Decí eso; no "
                "inventes errores.")
    lineas = []
    for e in errores:
        if e["repetida"]:
            lineas.append(f"- «{e['palabra']}» está repetida, en: «{e['frase']}»")
        else:
            como = " o ".join(f"«{s}»" for s in e["sugerencias"][:2]) or "(sin sugerencia)"
            lineas.append(f"- «{e['palabra']}» (se escribe {como}), en: «{e['frase']}»")
    return ("El corrector ortográfico de Windows revisó el texto y encontró SOLO estos errores (son los de verdad: no "
            "agregues otros ni cambies las palabras). Decilos todos, cada uno con la frase donde está, así lo encuentra:\n"
            + "\n".join(lineas))


def palabras_del_texto(texto):
    return set(w.lower() for w in re.findall(r"\w+", texto))
