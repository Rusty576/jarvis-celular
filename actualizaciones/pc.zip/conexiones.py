"""Conexiones de JARVIS: WhatsApp (escritorio), Gmail, TikTok y la agenda de contactos.

Todo lo que MANDA algo (WhatsApp, mails) pide confirmación antes: JARVIS muestra a quién y qué,
y recién lo envía cuando decís "sí" (o tocás ENVIAR en la interfaz).
"""
import ctypes
import difflib
import email
import imaplib
import os
import re
import smtplib
import subprocess
import sys
import time
import urllib.parse
import webbrowser
from email.header import decode_header, make_header
from email.mime.text import MIMEText
from email.utils import parseaddr, parsedate_to_datetime

import disco

jarvis = None  # main.py se anota acá al arrancar (para usar emitir, el modelo, normalizar, etc.)

PAIS = "598"  # código de país para números sin prefijo (Uruguay). Argentina: "549", España: "34"
BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_CONTACTOS = os.path.join(BASE, "contactos.json")
SERVICIO_CLAVE = "JARVIS-Gmail"  # nombre en el Administrador de credenciales de Windows
SEGUNDOS_CONFIRMAR = 120  # después de esto, un "sí" ya no manda nada
VK_ENTER = 0x0D


def original(texto, m, grupo):
    """El pedazo que capturó la regex, pero del texto original (con tildes y mayúsculas)."""
    return jarvis.parte_original(texto, m.start(grupo))[: len(m.group(grupo))].strip(" .,;:")


# ======================= Contactos =======================

def cargar_contactos():
    return disco.leer(ARCHIVO_CONTACTOS, {})


def guardar_contactos(contactos):
    disco.guardar(ARCHIVO_CONTACTOS, contactos, indent=2)


def buscar_contacto(nombre):
    """Devuelve (nombre, datos, opciones). Tolera tildes, 'a mi mamá' y errores chicos del micrófono."""
    contactos = cargar_contactos()
    completo = re.sub(r"^(?:a |al |a la |a el )+", "", jarvis.normalizar(nombre)).strip(" .,")
    n = re.sub(r"^(?:la |el |mi )+", "", completo)
    claves = {jarvis.normalizar(k): k for k in contactos}
    for candidato in (completo, n, "mi " + n):  # "a mi mamá" encuentra a "Mi Mamá" y a "Mamá"
        if candidato in claves:
            return claves[candidato], contactos[claves[candidato]], []
    parecidos = [k for k in claves if k.split()[0] == n or k.startswith(n + " ")]
    if len(parecidos) == 1:
        return claves[parecidos[0]], contactos[claves[parecidos[0]]], []
    if len(parecidos) > 1:
        return None, None, [claves[k] for k in parecidos]
    cerca = difflib.get_close_matches(n, list(claves), n=1, cutoff=0.75)
    if cerca:
        return claves[cerca[0]], contactos[claves[cerca[0]]], []
    return None, None, []


def normalizar_numero(texto):
    digitos = re.sub(r"\D", "", texto)
    if texto.strip().startswith("+"):
        return digitos
    if digitos.startswith("00"):
        return digitos[2:]
    if digitos.startswith("0"):
        return PAIS + digitos[1:]  # 09X XXX XXX -> 5989XXXXXXX
    if len(digitos) <= 9:
        return PAIS + digitos
    return digitos


def limpiar_mail_dictado(t):
    """'juan arroba gmail punto com' (dictado por voz) -> 'juan@gmail.com'."""
    t = re.sub(r"\s*\barroba\b\s*", "@", t)
    return re.sub(r"\s*\bpunto\b\s*(?=[a-z])", ".", t) if "@" in t else t


VERBO_AGENDAR = r"(?:agenda|agendame|guarda|guardame|anota|anotame|agrega|agregame)"
AGENDAR_NUMERO = re.compile(
    rf"^{VERBO_AGENDAR}\s+(?:a\s+|el contacto (?:de\s+)?)?(.+?)\s+(?:con el |al |el )?"
    r"(?:numero|telefono|celular|cel|whatsapp)\s*(?:es|:)?\s*(\+?\d[\d\s\-]{5,})$"
)
AGENDAR_MAIL = re.compile(
    rf"^(?:{VERBO_AGENDAR}\s+(?:el (?:mail|correo|email) de\s+|a\s+)?|el (?:mail|correo|email) de\s+)(.+?)\s+"
    r"(?:(?:con el )?(?:mail|correo|email)\s*)?(?:es|:)?\s*([\w.+-]+@[\w-]+(?:\.[\w-]+)+)$"
)
BORRAR_CONTACTO = re.compile(r"^(?:borra|borrame|elimina|saca|sacame)\s+(?:a\s+)?(.+?)\s+de (?:mis |los )?contactos$")


def es_agenda(t):
    """Para que 'anotá a Juan con el número...' no se guarde como recuerdo."""
    t = limpiar_mail_dictado(t)
    return bool(AGENDAR_NUMERO.match(t) or AGENDAR_MAIL.match(t))


def manejar_agenda(texto, t):
    t_mail = limpiar_mail_dictado(t)
    m = AGENDAR_NUMERO.match(t)
    if m:
        escrito = original(texto, m, 1)
        nombre = escrito if escrito != escrito.lower() else escrito.title()
        nombre_existente, datos, _ = buscar_contacto(nombre)
        contactos = cargar_contactos()
        clave = nombre_existente if nombre_existente and jarvis.normalizar(nombre_existente) == jarvis.normalizar(nombre) else nombre
        contactos.setdefault(clave, {})["telefono"] = normalizar_numero(m.group(2))
        guardar_contactos(contactos)
        return f"Listo, agendé a {clave} con el número +{contactos[clave]['telefono']}."

    m = AGENDAR_MAIL.match(t_mail)
    if m:
        nombre = m.group(1).strip().title()
        nombre_existente, _, _ = buscar_contacto(nombre)
        clave = nombre_existente or nombre
        contactos = cargar_contactos()
        contactos.setdefault(clave, {})["email"] = m.group(2)
        guardar_contactos(contactos)
        return f"Listo, guardé el mail de {clave}: {m.group(2)}."

    m = BORRAR_CONTACTO.match(t)
    if m:
        nombre, _, opciones = buscar_contacto(m.group(1))
        if not nombre:
            return f"No encontré a {m.group(1)} en tus contactos."
        contactos = cargar_contactos()
        contactos.pop(nombre, None)
        guardar_contactos(contactos)
        return f"Listo, borré a {nombre} de tus contactos."

    if t.strip(" ?") in ("mis contactos", "contactos", "que contactos tengo", "lista de contactos",
                         "mostrame mis contactos", "a quien tengo agendado", "a quienes tengo agendados"):
        contactos = cargar_contactos()
        if not contactos:
            return "Todavía no tenés contactos. Decime por ejemplo: agendá a Juan con el número 099 123 456."
        lineas = []
        for nombre, d in sorted(contactos.items()):
            partes = [f"+{d['telefono']}" if d.get("telefono") else "", d.get("email", "")]
            lineas.append(f"- {nombre}: {', '.join(p for p in partes if p)}")
        return f"Tenés {len(contactos)} contactos:\n" + "\n".join(lineas)
    return None


# ======================= Confirmación antes de enviar =======================

pendiente = None
_contador = 0
_descartado_en = 0.0  # cuándo se canceló el último envío (para avisar si después dicen "sí")

SI = {"si", "dale", "mandalo", "mandala", "manda", "envialo", "enviala", "envia", "enviar", "confirmo",
      "confirmar", "ok", "okay", "de una", "obvio", "claro", "si mandalo", "si dale", "dale mandalo",
      "si envialo", "si por favor", "correcto", "perfecto"}
NO = {"no", "cancela", "cancelalo", "cancelar", "no lo mandes", "no la mandes", "deja", "dejalo",
      "olvidalo", "no gracias", "para", "pará", "no, cancela", "mejor no"}


def pedir_confirmacion(canal, para, texto, accion=None, asunto=None, pregunta=None, hacer=None):
    """Guarda lo que hay que hacer y le pregunta al usuario antes de hacerlo.
    canal: 'whatsapp', 'gmail' o 'sistema' (apagar la compu, etc.).
    hacer(texto, asunto) envía el mensaje; así, si el usuario lo corrige, se manda la versión corregida."""
    global pendiente, _contador
    descartar_pendiente("reemplazado")
    _contador += 1
    pendiente = {"id": _contador, "canal": canal, "para": para, "texto": texto, "asunto": asunto,
                 "hacer": hacer or (lambda _t, _a: accion()), "hasta": time.time() + SEGUNDOS_CONFIRMAR}
    jarvis.emitir("confirmar", {k: v for k, v in pendiente.items() if k != "hacer"})
    if pregunta:
        return pregunta + " Decí sí o no."
    if canal == "gmail":
        return (f'Mail para {para}. Asunto: "{asunto or "sin asunto"}". Texto: "{texto}". '
                "¿Lo mando? Si querés cambiar algo, decime: cambialo a..., o cambiá el asunto a...")
    return f'Para {para} por WhatsApp, tal cual: "{texto}". ¿Lo mando? Si querés cambiarlo, decime: cambialo a...'


def editar_pendiente(texto=None, asunto=None):
    """La interfaz deja editar el texto en la tarjeta antes de tocar ENVIAR."""
    if pendiente and pendiente["canal"] != "sistema":
        if texto and texto.strip():
            pendiente["texto"] = texto.strip()
        if asunto is not None:
            pendiente["asunto"] = asunto.strip()


# Correcciones mientras JARVIS pregunta "¿Lo mando?"
EDITAR = re.compile(r"^(?:no[, ]+)?(?:mejor\s+)?(?:cambia(?:lo|la)?|cambiale el (?:texto|mensaje)|corregi(?:lo|la)?|"
                    r"reemplaza(?:lo|la)?|ponele|en vez de eso (?:decile|ponele)|mejor decile|decile mejor)"
                    r"(?:\s+(?:a|por|que diga|que dice|asi|:))?\s*:?\s+(?:que\s+)?(.+)$")
AGREGAR = re.compile(r"^(?:agregale|agrega|sumale|anadile|ponele tambien|y agregale)\s+(?:al final\s+)?(?:que\s+)?(.+)$")
CAMBIAR_ASUNTO = re.compile(r"^(?:cambia(?:le)?|pone(?:le)?|el)\s+(?:el\s+)?asunto\s*(?:a|por|es|:)?\s+(.+)$")


def _reconfirmar(texto=None, asunto=None):
    p = pendiente
    return pedir_confirmacion(p["canal"], p["para"], texto if texto is not None else p["texto"],
                              asunto=asunto if asunto is not None else p["asunto"], hacer=p["hacer"])


def descartar_pendiente(motivo="cancelado"):
    global pendiente, _descartado_en
    if pendiente:
        jarvis.emitir("confirmacion", {"id": pendiente["id"], "estado": motivo})
        pendiente = None
        _descartado_en = time.time()


def hay_pendiente():
    if pendiente and time.time() > pendiente["hasta"]:
        descartar_pendiente("vencido")
    return pendiente is not None


def responder_confirmacion(t, texto=None):
    """Si hay algo esperando confirmación: 'sí' lo hace, 'no' lo cancela, 'cambialo a...' lo corrige.
    Devuelve la respuesta, o None si no correspondía."""
    global pendiente
    t = t.strip(" ,.!¿?¡")
    palabras = t.split()
    if not hay_pendiente():
        if (t in SI or t in NO) and time.time() - _descartado_en < SEGUNDOS_CONFIRMAR:
            return "No hay nada para mandar: el último mensaje se canceló y no se envió. Si querés, pedímelo de nuevo."
        return None

    if pendiente["canal"] != "sistema" and texto:
        m = CAMBIAR_ASUNTO.match(t)
        if m and pendiente["canal"] == "gmail":
            return _reconfirmar(asunto=limpiar_mensaje(original(texto, m, 1)))
        m = EDITAR.match(t)
        if m:
            return _reconfirmar(texto=limpiar_mensaje(original(texto, m, 1)))
        m = AGREGAR.match(t)
        if m:
            agregado = original(texto, m, 1)
            return _reconfirmar(texto=pendiente["texto"].rstrip(" .") + ". " + agregado[:1].upper() + agregado[1:])

    if t in SI or (palabras and palabras[0] in ("si", "dale") and len(palabras) <= 4):
        p, pendiente = pendiente, None
        try:
            resultado = p["hacer"](p["texto"], p["asunto"])
        except Exception as e:
            jarvis.emitir("confirmacion", {"id": p["id"], "estado": "error"})
            return f"No pude mandarlo: {e}"
        jarvis.emitir("confirmacion", {"id": p["id"], "estado": "enviado"})
        return resultado
    if t in NO or (palabras and palabras[0] == "no" and len(palabras) <= 4):
        era_sistema = pendiente["canal"] == "sistema"
        descartar_pendiente("cancelado")
        return "Listo, no hago nada." if era_sistema else "Listo, no lo mando."
    descartar_pendiente("cancelado")  # dijo otra cosa: por seguridad no se manda nada
    return None


# ======================= El mensaje: tal cual lo dijiste =======================
# JARVIS NO inventa ni reescribe mensajes con la IA. Manda exactamente lo que dijiste, con un solo
# ajuste fijo: "decile que LA AMO" -> "Te amo" (si no, el mensaje llegaría en tercera persona).

PRONOMBRE_INICIAL = re.compile(
    r"^(?:la|lo)\s+(amo|quiero|extraño|extrano|adoro|espero|necesito|busco|llamo|veo|felicito|invito|cuido|"
    r"paso a buscar|voy a buscar|re quiero)\b|^le\s+(mando|envío|envio|aviso|digo|escribo|llamo|deseo|agradezco|pido)\b",
    re.IGNORECASE)
# Pedidos que no dicen QUÉ mandar: JARVIS pregunta en vez de inventar
VAGO = re.compile(r"^(?:algo(?: lindo| bonito| copado| tierno| de mi parte)?|un mensaje|otro mensaje|otro|otra|"
                  r"un whatsapp|otro whatsapp|un mail|otro mail|un correo|otro correo|un mensajito|lo que quieras|"
                  r"lo que se te ocurra|cualquier cosa|lo que vos quieras|algo de mi parte|un texto)$")
REFERENCIA = re.compile(r"^(?:eso|lo mismo|lo anterior|lo de antes|ese mensaje|el mismo mensaje|lo que te dije)$")


def limpiar_mensaje(pedido):
    m = pedido.strip().strip('"“”«»\'').strip()
    m = re.sub(r"(?i)^que\s+", "", m)
    m = re.sub(r"(?i)\s*(?:por|al|via)\s+(?:whatsapp|wsp|wpp|wasap|mail|email|correo|gmail)\s*$", "", m).strip()
    m = PRONOMBRE_INICIAL.sub(lambda x: "te " + (x.group(1) or x.group(2)), m)
    return m[:1].upper() + m[1:] if m else m


# ======================= WhatsApp (app de escritorio) =======================

def ventana_activa():
    h = ctypes.windll.user32.GetForegroundWindow()
    buf = ctypes.create_unicode_buffer(256)
    ctypes.windll.user32.GetWindowTextW(h, buf, 256)
    return buf.value


def whatsapp_abierto():
    try:
        import psutil

        return any("whatsapp" in (p.info["name"] or "").lower() for p in psutil.process_iter(["name"]))
    except Exception:
        return True


def enviar_whatsapp(nombre, numero, texto):
    """Abre el chat en WhatsApp Desktop con el mensaje escrito y aprieta Enter."""
    estaba_abierto = whatsapp_abierto()
    os.startfile("whatsapp://send?" + urllib.parse.urlencode({"phone": numero, "text": texto},
                                                             quote_via=urllib.parse.quote))
    limite = time.time() + (8 if estaba_abierto else 25)
    while "whatsapp" not in ventana_activa().lower():
        if time.time() > limite:
            raise RuntimeError("WhatsApp no se abrió a tiempo, no mandé nada")
        time.sleep(0.25)
    time.sleep(1.5 if estaba_abierto else 5)  # que cargue el chat con el texto
    if "whatsapp" not in ventana_activa().lower():
        raise RuntimeError("otra ventana tapó a WhatsApp, así que no apreté enviar. El mensaje quedó escrito")
    jarvis.tecla(VK_ENTER)
    return f"Listo, le mandé el WhatsApp a {nombre}."


# ======================= Gmail =======================

def credenciales():
    try:
        import keyring

        usuario = keyring.get_password(SERVICIO_CLAVE, "usuario")
        return usuario, keyring.get_password(SERVICIO_CLAVE, usuario) if usuario else None
    except Exception:
        return None, None


def gmail_configurado():
    return all(credenciales())


def abrir_configuracion(cual="gmail"):
    """Abre configurar.py en una ventana de terminal (ahí se escribe la contraseña o clave de forma segura)."""
    python = sys.executable.replace("pythonw.exe", "python.exe")
    subprocess.Popen([python, os.path.join(BASE, "configurar.py"), cual], cwd=BASE,
                     creationflags=subprocess.CREATE_NEW_CONSOLE)
    nombre = "Pollinations (imágenes)" if cual == "pollinations" else "Gmail"
    return f"Te abrí una ventana para conectar {nombre}. Seguí los pasos que aparecen ahí."


def enviar_mail(destino, asunto, cuerpo, adjuntos=None):
    usuario, clave = credenciales()
    if adjuntos:  # con archivos (el video, el Word, la imagen que hizo JARVIS)
        import mimetypes
        from email.mime.base import MIMEBase
        from email.mime.multipart import MIMEMultipart
        from email import encoders

        msg = MIMEMultipart()
        msg.attach(MIMEText(cuerpo, "plain", "utf-8"))
        for ruta in adjuntos:
            tipo = (mimetypes.guess_type(ruta)[0] or "application/octet-stream").split("/", 1)
            parte = MIMEBase(tipo[0], tipo[1])
            with open(ruta, "rb") as f:
                parte.set_payload(f.read())
            encoders.encode_base64(parte)
            parte.add_header("Content-Disposition", "attachment", filename=os.path.basename(ruta))
            msg.attach(parte)
    else:
        msg = MIMEText(cuerpo, "plain", "utf-8")
    msg["Subject"], msg["From"], msg["To"] = asunto, usuario, destino
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=30) as s:
        s.login(usuario, clave)
        s.send_message(msg)
    return f"Listo, mandé el mail a {destino}."


def _decodificar(valor):
    try:
        return str(make_header(decode_header(valor or "")))
    except Exception:
        return valor or ""


def _cuerpo(msg):
    """Texto del mail: prefiere texto plano; si solo hay HTML, le saca las etiquetas."""
    partes = msg.walk() if msg.is_multipart() else [msg]
    html = None
    for p in partes:
        if p.get_content_maintype() != "text" or p.get("Content-Disposition", "").startswith("attachment"):
            continue
        datos = p.get_payload(decode=True) or b""
        texto = datos.decode(p.get_content_charset() or "utf-8", errors="replace")
        if p.get_content_subtype() == "plain":
            return texto.strip()
        html = html or texto
    if html:
        html = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
        return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).strip()
    return ""


def leer_correos(cantidad=5, solo_no_leidos=True, de=None):
    """Devuelve (total, lista de mails). No marca nada como leído."""
    usuario, clave = credenciales()
    with imaplib.IMAP4_SSL("imap.gmail.com", timeout=30) as m:
        m.login(usuario, clave)
        m.select("INBOX", readonly=True)
        consulta = ("is:unread " if solo_no_leidos else "") + (f"from:({de})" if de else "")
        _, datos = m.search(None, "X-GM-RAW", f'"{consulta.strip() or "in:inbox"}"')
        ids = datos[0].split()
        correos = []
        for i in reversed(ids[-cantidad:]):
            _, d = m.fetch(i, "(X-GM-MSGID BODY.PEEK[])")
            msgid = re.search(rb"X-GM-MSGID (\d+)", d[0][0])
            msg = email.message_from_bytes(d[0][1])
            nombre, direccion = parseaddr(_decodificar(msg.get("From")))
            correos.append({"de": nombre or direccion, "direccion": direccion, "msgid": msgid.group(1).decode() if msgid else "",
                            "asunto": _decodificar(msg.get("Subject")) or "(sin asunto)",
                            "cuerpo": _cuerpo(msg)})
    return len(ids), correos


def sin_gmail():
    return "Todavía no conectaste Gmail. Decí 'configurar Gmail' y te guío, son 5 minutos."


PALABRA_MAIL = r"(?:mails?|correos?|emails?|e-mails?|gmail|bandeja)"


def manejar_gmail(texto, t):
    t = _limpio(t)  # "jarvis, revisá mis mails" también (antes el "jarvis" del principio hacía que no lo entienda)
    if re.match(r"^(?:configura|configurar|conecta|conectar|vincula|vincular)\s+(?:mi |el )?(?:gmail|correo|mail)$", t):
        return abrir_configuracion()
    if re.match(r"^(?:desconecta|desconectar|desvincula)\s+(?:mi |el )?(?:gmail|correo|mail)$", t):
        try:
            import keyring

            usuario, _ = credenciales()
            if usuario:
                keyring.delete_password(SERVICIO_CLAVE, usuario)
            keyring.delete_password(SERVICIO_CLAVE, "usuario")
        except Exception:
            pass
        return "Listo, desconecté Gmail y borré la contraseña de esta computadora."

    borrar = manejar_borrar_mails(texto, t)
    if borrar is not None:
        return borrar

    resumir = re.match(rf"^(?:resumi|resumime|resumir|haceme un resumen de)\s+(?:mis |los |el )?{PALABRA_MAIL}", t)
    de = re.search(rf"\b(?:lee|leeme|mostrame|abri|que dice)\s+(?:el )?(?:ultimo )?(?:mail|correo|email)\s+de\s+(.+)$", t)
    revisar = re.search(
        rf"^(?:(?:revisa|revisame|chequea|fijate|mira|lee|leeme|mostrame)\s+(?:si tengo\s+)?(?:mis |el |los |la )?{PALABRA_MAIL}"
        rf"|(?:tengo|hay)\s+(?:algun |algunos |un |nuevos )?{PALABRA_MAIL}"
        rf"|cuantos {PALABRA_MAIL} (?:tengo|hay))", t)
    if not (resumir or de or revisar):
        return None
    if not gmail_configurado():
        return sin_gmail()

    jarvis.emitir("detalle", "Revisando tu correo...")
    try:
        if de:
            _, correos = leer_correos(1, solo_no_leidos=False, de=de.group(1).strip())
            if not correos:
                return f"No encontré mails de {de.group(1)}."
            c = correos[0]
            cuerpo = c["cuerpo"][:1500] + ("..." if len(c["cuerpo"]) > 1500 else "")
            return f"El último mail de {c['de']}, asunto {c['asunto']}:\n\n{cuerpo}"

        total, correos = leer_correos(8 if resumir else 5)
        if not total:
            return "No tenés mails sin leer."
        if resumir:
            material = "\n\n".join(f"De: {c['de']}\nAsunto: {c['asunto']}\n{c['cuerpo'][:600]}" for c in correos)
            r = jarvis.chat_modelo([
                {"role": "system", "content": "Resumí estos mails en español rioplatense, breve: una línea por mail "
                                              "con quién lo manda y qué quiere. Al final decí si alguno parece urgente."},
                {"role": "user", "content": material}], temperature=0.3, num_predict=500)
            return f"Tenés {total} sin leer. " + r["message"]["content"].strip()
        global _ultima_lista
        _ultima_lista = correos  # para "borrá el 2" y "leeme el 2"
        _ultima_vez[0] = time.time()  # para "¿alguno de robótica?" justo después
        lista = "\n".join(f"{i}. De {c['de']}: {c['asunto']}" for i, c in enumerate(correos, 1))
        extra = f" Te muestro los últimos {len(correos)}:" if total > len(correos) else ""
        return f"Tenés {total} {'mail' if total == 1 else 'mails'} sin leer.{extra}\n{lista}"
    except imaplib.IMAP4.error:
        return "Gmail rechazó la contraseña. Volvé a conectarlo diciendo 'configurar Gmail'."
    except Exception as e:
        return f"No pude revisar el correo: {e}"


# ======================= Borrar mails (siempre con confirmación) =======================
# "borrá el último mail", "eliminá los últimos 3 correos", "borrá los mails de Mercado Libre",
# "borrá el mail 2" / "borrá los mails 1 y 3" (de la última lista que te mostré), "borrá los mails con asunto oferta".
# Nunca borra sin que digas "sí", y no los destruye: van a la Papelera de Gmail (se recuperan durante 30 días).
BORRAR_MAIL = re.compile(r"^(?:borra|borrame|borrar|elimina|eliminame|eliminar|tira|tirame|"
                         r"manda a la papelera|mandame a la papelera)\s+(.*?)\b(" + PALABRA_MAIL + r")\b\s*(.*)$")
NUMEROS = {"un": 1, "uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7,
           "ocho": 8, "nueve": 9, "diez": 10}
ORDINALES = {"primer": 1, "primero": 1, "segundo": 2, "tercer": 3, "tercero": 3, "cuarto": 4, "quinto": 5}
MAX_BORRAR = 25  # por seguridad, como mucho 25 por pedido
_ultima_lista = []  # los mails que te mostré la última vez (para "borrá el 2")


def _encabezados(m, ids):
    correos = []
    for i in reversed(ids):
        _, d = m.fetch(i, "(X-GM-MSGID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
        msgid = re.search(rb"X-GM-MSGID (\d+)", d[0][0])
        msg = email.message_from_bytes(d[0][1])
        nombre, direccion = parseaddr(_decodificar(msg.get("From")))
        try:
            fecha = parsedate_to_datetime(msg.get("Date")).strftime("%d/%m/%Y")
        except Exception:
            fecha = ""
        correos.append({"de": nombre or direccion, "direccion": direccion, "msgid": msgid.group(1).decode() if msgid else "",
                        "asunto": _decodificar(msg.get("Subject")) or "(sin asunto)", "fecha": fecha})
    return correos


def buscar_mails(consulta, cantidad):
    """Los últimos 'cantidad' mails de la bandeja que cumplen la búsqueda de Gmail (sin marcar nada como leído)."""
    usuario, clave = credenciales()
    with imaplib.IMAP4_SSL("imap.gmail.com", timeout=30) as m:
        m.login(usuario, clave)
        m.select("INBOX", readonly=True)
        _, datos = m.search(None, "X-GM-RAW", f'"{consulta}"')
        return _encabezados(m, datos[0].split()[-cantidad:])


# ======================= Buscar mails por tema =======================
# "¿tengo algún correo relacionado con la olimpiada de robótica?", "buscá mails de la UTU", y después de una lista:
# "¿alguno de robótica?", "leeme el 2". Busca en TODO el Gmail (también los leídos), sin marcar nada.
# (Antes solo sabía mostrar los últimos 5 sin leer: lo demás terminaba contestado con el texto pegado o con Google.)
VOCATIVO = re.compile(r"^(?:(?:jarvis|che|bro|oye|oiga|hey|ey|dale|bueno|mira|escucha|porfa|por favor)[\s,]+)+")
# hasta 2 palabras entre "correo" y el tema: "correo relaconado con...", "mails nuevos de la UTU", "mail que sea de..."
MAIL_TEMA = re.compile(rf"\b{PALABRA_MAIL}\s+(?:[a-z]+\s+){{0,2}}?(?:relac\w* (?:con|a)|sobre|acerca de|"
                       rf"que (?:hable|hablen|diga|digan|mencione|mencionen)(?: de| sobre)?|"
                       rf"de la|del|de los|de las|de|con|por)\s+(.+)$")
MAIL_PREGUNTA = re.compile(r"\b(?:tengo|tenes|hay|habra|llego|llegaron|mandaron|enviaron|escribieron|busca\w*|encontra\w*|"
                           r"fijate|revisa\w*|mira|chequea\w*|existe)\b")
SEGUIR_BUSQUEDA = re.compile(r"^(?:y\s+)?(?:(?:hay|tengo|tenes)\s+)?(?:al+gun[oa]s?|algo|uno|otro|y)\s+"
                             r"(?:mas\s+)?(?:de|del|de la|sobre|con|que hable de|relacionado con)\s+(.+)$|"
                             r"^y\s+(?:de|del|de la|sobre)\s+(.+)$")
LEER_NUMERO = re.compile(r"^(?:(?:lee|leeme|leer|abri|abrime|mostra|mostrame|que dice|y)\s+)?(?:el |la )?"
                         r"(?:mail |correo )?(?:numero |nro )?(\d+|primero|primer|segundo|tercero|tercer|cuarto|quinto|ultimo)"
                         r"(?:\s+(?:mail|correo))?$")
VACIAS_MAIL = set("algun alguna algunos algunas un una unos unas el la los las lo mi mis tu tus de del al con por para que "
                  "sobre acerca relacionado relacionada relacionados relacionadas y o ese esa eso este esta esto alla aca "
                  "mail mails correo correos email emails gmail".split())
_ultima_vez = [0.0]  # cuándo te mostré mails por última vez (para "¿alguno de robótica?", "leeme el 2")


def _limpio(t):
    """Sin 'jarvis,' al principio ni insultos: 'jarvis tengo algún correo...' y 'mi puto gmail fijate' se entienden."""
    t = VOCATIVO.sub("", t.strip(" ¿?¡!.,"))
    if jarvis and hasattr(jarvis, "sin_insultos"):
        t = jarvis.sin_insultos(t)
    return t.strip(" ¿?¡!.,")


def _carpeta_todos(m):
    """La carpeta con TODOS los mails ("[Gmail]/Todos", "[Gmail]/All Mail"... según el idioma). Si no, la bandeja."""
    try:
        _, carpetas = m.list()
        for c in carpetas:
            linea = c.decode("utf-8", "replace")
            if "\\All" in linea:
                nombre = re.search(r'"([^"]+)"\s*$', linea)
                return nombre.group(1) if nombre else linea.split()[-1]
    except Exception:
        pass
    return "INBOX"


def palabras_del_tema(tema):
    """'alguna olipidada de robotica' -> ['olipidada', 'robotica'] (lo que vale la pena buscar)."""
    t = jarvis.normalizar(tema) if jarvis else tema.lower()
    return [w for w in re.findall(r"[a-z0-9ñ@._-]{3,}", t) if w not in VACIAS_MAIL][:6]


TILDE = {"a": "á", "e": "é", "i": "í", "o": "ó", "u": "ú"}


def con_tilde(w):
    """Gmail NO ignora las tildes ("suscripcion" no encuentra "suscripción"): la forma con tilde de las palabras que
    casi siempre la llevan ('robotica' -> 'robótica', 'inscripcion' -> 'inscripción', 'tecnologia' -> 'tecnología')."""
    m = re.match(r"^(.*?)([aeiou])([^aeiou]+)(ic[oa]s?)$", w)
    if m and len(w) >= 6:
        return m.group(1) + TILDE[m.group(2)] + m.group(3) + m.group(4)
    if w.endswith("ion") and len(w) > 4:
        return w[:-3] + "ión"
    m = re.match(r"^(.*(?:log|erg|graf|metr))ia(s?)$", w)
    if m:
        return m.group(1) + "ía" + m.group(2)
    return w


def corregir_para_buscar(tema):
    """'olipidada de robotica' -> 'olimpiada de robótica' (la IA arregla el dictado y pone las tildes)."""
    if jarvis is None or jarvis.herramientas.modo_juego.is_set():
        return tema
    try:
        r = jarvis.chat_modelo([
            {"role": "system", "content": "Corregí la ortografía de lo que el usuario quiere buscar en su correo: poné las "
                                          "tildes y arreglá los errores de dictado eligiendo la palabra parecida que tenga "
                                          "sentido con las otras. No agregues ni cambies el sentido. Respondé SOLO las "
                                          "palabras corregidas."},
            {"role": "user", "content": "olipiadas de fisica"}, {"role": "assistant", "content": "olimpiadas de física"},
            {"role": "user", "content": "inscripsion a la utu"}, {"role": "assistant", "content": "inscripción a la UTU"},
            {"role": "user", "content": "feria de siensias"}, {"role": "assistant", "content": "feria de ciencias"},
            {"role": "user", "content": tema}], temperature=0.0, num_predict=40)
        nuevo = r["message"]["content"].strip().splitlines()[0].strip(" \"'«».")
        return nuevo if 0 < len(nuevo) <= 3 * len(tema) + 10 else tema
    except Exception:
        return tema


def buscar_mails_tema(tema, cantidad=6):
    """Busca en todo el Gmail: primero con todas las palabras (bien escritas); si no aparece nada, con cualquiera de
    ellas, con y sin tilde. Devuelve (el tema bien escrito, mails)."""
    if not palabras_del_tema(tema):
        return "", []
    corregido = corregir_para_buscar(tema)
    originales = palabras_del_tema(tema)
    buenas = [w for w in re.findall(r"[\wáéíóúüñ@.-]{3,}", corregido.lower()) if jarvis.normalizar(w) not in VACIAS_MAIL][:6] \
        or originales
    todas = list(dict.fromkeys(buenas + [con_tilde(w) for w in buenas] + originales + [con_tilde(w) for w in originales]))
    consultas = [" ".join(buenas)] + ([" OR ".join(todas)] if len(todas) > 1 else [])
    usuario, clave = credenciales()
    with imaplib.IMAP4_SSL("imap.gmail.com", timeout=30) as m:
        m.login(usuario, clave)
        m.select(f'"{_carpeta_todos(m)}"', readonly=True)
        for consulta in consultas:
            m.literal = consulta.encode("utf-8")  # así acepta tildes y eñes
            estado, datos = m.search("UTF-8", "X-GM-RAW")
            m.literal = None
            ids = datos[0].split() if estado == "OK" and datos and datos[0] else []
            if ids:
                return corregido, _encabezados(m, ids[-cantidad:])
    return corregido, []


def mostrar_busqueda(tema):
    global _ultima_lista
    if not gmail_configurado():
        return sin_gmail()
    tema = re.sub(r"^(?:(?:algun|alguna|algunos|algunas|un|una|el|la|los|las|mi|mis)\s+)+", "", tema).strip(" ?.,")
    jarvis.emitir("detalle", f"Buscando en tu Gmail: {tema}...")
    try:
        consulta, correos = buscar_mails_tema(tema)
    except imaplib.IMAP4.error as e:
        if "auth" in str(e).lower() or "credential" in str(e).lower() or "login" in str(e).lower():
            return "Gmail rechazó la contraseña. Volvé a conectarlo diciendo 'configurar Gmail'."
        return f"Gmail no me dejó buscar ({e})."
    except Exception as e:
        return f"No pude buscar en tu correo: {e}"
    _ultima_vez[0] = time.time()
    if not consulta:
        return "¿Sobre qué tema busco los mails?"
    tema = consulta  # bien escrito: «olimpiada de robótica»
    if not correos:
        return f"No encontré ningún mail sobre «{tema}» (busqué en todo tu Gmail, también en los leídos)."
    _ultima_lista = correos
    lista = "\n".join(f"{i}. De {c['de']}{' (' + c['fecha'] + ')' if c.get('fecha') else ''}: {c['asunto']}"
                      for i, c in enumerate(correos, 1))
    cuantos = "un mail" if len(correos) == 1 else f"{len(correos)} mails"
    return (f"Sí, encontré {cuantos} sobre «{tema}»:\n{lista}\n"
            f"Decime «leeme el {'1' if len(correos) == 1 else 'número'}» y te digo qué dice.")


def leer_de_la_lista(n):
    """'leeme el 2': el texto del mail número n de la última lista que te mostré."""
    if not _ultima_lista:
        return "Primero pedime que revise o busque tus mails, así sé cuál es cada número."
    if not 1 <= n <= len(_ultima_lista):
        return f"En la última lista que te mostré había {len(_ultima_lista)} mails."
    c = _ultima_lista[n - 1]
    _ultimo_mail_leido[0] = c  # para "anotalo en mis pendientes"
    cuerpo = c.get("cuerpo")
    if cuerpo is None and c.get("msgid"):
        usuario, clave = credenciales()
        with imaplib.IMAP4_SSL("imap.gmail.com", timeout=30) as m:
            m.login(usuario, clave)
            m.select(f'"{_carpeta_todos(m)}"', readonly=True)
            _, datos = m.search(None, "X-GM-MSGID", c["msgid"])
            ids = datos[0].split()
            if ids:
                _, d = m.fetch(ids[-1], "(BODY.PEEK[])")  # PEEK: no lo marca como leído
                cuerpo = _cuerpo(email.message_from_bytes(d[0][1]))
    _ultima_vez[0] = time.time()
    cuerpo = (cuerpo or "(no tiene texto)").strip()
    cuerpo = cuerpo[:1500] + ("..." if len(cuerpo) > 1500 else "")
    return f"El mail de {c['de']}, asunto «{c['asunto']}»:\n\n{cuerpo}"


def _recien_mostre_mails():
    """¿Lo último que respondió JARVIS fue sobre tus mails (y hace menos de 15 minutos)?"""
    if time.time() - _ultima_vez[0] > 15 * 60 or jarvis is None:
        return False
    with jarvis.lock:
        ultima = next((x["content"] for x in reversed(jarvis.historial[-3:]) if x.get("role") == "assistant"), "")
    return bool(re.search(r"\bmails?\b", ultima))


def manejar_busqueda_mails(texto, t):
    """Buscar mails por tema, seguir una búsqueda o leer uno de la lista. None si no era eso."""
    t = _limpio(t)
    if _recien_mostre_mails():
        m = LEER_NUMERO.match(t)
        if m and _ultima_lista:  # "leeme el 2", "abrí el primero"
            palabra = m.group(1)
            n = int(palabra) if palabra.isdigit() else len(_ultima_lista) if palabra == "ultimo" else ORDINALES.get(palabra)
            try:
                return leer_de_la_lista(n)
            except Exception as e:
                return f"No pude abrir ese mail: {e}"
        m = SEGUIR_BUSQUEDA.match(t)  # "¿alguno de robótica?", "y de la UTU?"
        if m:
            return mostrar_busqueda((m.group(1) or m.group(2)).strip())
    if not re.search(rf"\b{PALABRA_MAIL}\b", t) or es_pedido_de_envio(t) or BORRAR_MAIL.match(t):
        return None  # no habla de mails, o es para MANDAR o BORRAR uno (eso va por otro lado)
    m = MAIL_TEMA.search(t)
    if m and MAIL_PREGUNTA.search(t):
        tema = m.group(1).strip()
        if not re.match(r"^(?:hoy|ayer|esta semana|este mes|sin leer|nuevos?|recientes?|ahora)$", tema):
            return mostrar_busqueda(tema)
    # "mi gmail fijate", "fijate en mi correo" (sin decir nada más): si recién preguntaste por un tema, se busca ESO;
    # si no, se revisan los sin leer
    resto = [w for w in palabras_del_tema(t) if not MAIL_PREGUNTA.fullmatch(w) and w not in ("puedes", "podes", "en")]
    empieza_normal = re.match(r"^(?:revisa|revisame|chequea|fijate|mira|lee|leeme|mostrame|tengo|hay|cuantos)\b", t)
    if MAIL_PREGUNTA.search(t) and not resto and not empieza_normal and jarvis is not None:
        with jarvis.lock:
            anteriores = [x["content"] for x in jarvis.historial[-4:] if x.get("role") == "user"]
        for anterior in reversed(anteriores):
            m = MAIL_TEMA.search(_limpio(jarvis.normalizar(anterior)))
            if m:
                return mostrar_busqueda(m.group(1).strip())
        return manejar_gmail(texto, "revisa mis mails")
    return None


def a_la_papelera(correos):
    """Mueve esos mails a la Papelera de Gmail (no se borran del todo: se recuperan durante 30 días)."""
    global _ultima_lista
    usuario, clave = credenciales()
    movidos = 0
    with imaplib.IMAP4_SSL("imap.gmail.com", timeout=30) as m:
        m.login(usuario, clave)
        m.select("INBOX")
        for c in correos:
            if not c.get("msgid"):
                continue
            _, datos = m.search(None, "X-GM-MSGID", c["msgid"])
            for i in datos[0].split():
                m.store(i, "+X-GM-LABELS", "(\\Trash)")
                movidos += 1
    _ultima_lista = []  # los números de la lista anterior ya no valen
    if not movidos:
        return "No pude borrarlos: parece que ya no están en la bandeja de entrada."
    return (f"Listo, mandé {'el mail' if movidos == 1 else f'{movidos} mails'} a la Papelera. "
            "Si te arrepentís, están ahí durante 30 días.")


def manejar_borrar_mails(texto, t):
    mm = BORRAR_MAIL.match(t)
    if not mm:
        return None
    if not gmail_configurado():
        return sin_gmail()
    antes, palabra, despues = mm.group(1).strip(), mm.group(2), mm.group(3).strip(" .")
    plural = palabra.endswith("s") and palabra != "gmail"

    # de la última lista que te mostré: "el mail 2", "los mails 1 y 3", "el segundo mail"
    numeros = []
    if re.match(r"^(?:numero |nro |n )?\d+(?:\s*(?:,|y)\s*\d+)*$", despues):
        numeros = [int(x) for x in re.findall(r"\d+", despues)]
    numeros += [ORDINALES[w] for w in antes.split() if w in ORDINALES]
    if numeros:
        if not _ultima_lista:
            return "Primero pedime que revise tus mails, así sé cuál es cada número."
        elegidos = [_ultima_lista[n - 1] for n in dict.fromkeys(numeros) if 1 <= n <= len(_ultima_lista)]
        if not elegidos:
            return f"En la última lista que te mostré había {len(_ultima_lista)} mails."
    else:
        consulta = "in:inbox"
        de = re.match(r"^(?:de|del|de la|que me (?:mando|mandaron|envio|enviaron))\s+(.+)$", despues)
        asunto = re.match(r"^(?:con (?:el )?asunto|que (?:dice|dicen|hablan? de)|sobre)\s+(.+)$", despues)
        sin_leer = re.search(r"\b(?:sin leer|no leidos)\b", despues + " " + antes)
        if de:
            consulta += f" from:({de.group(1)})"
        elif asunto:
            consulta += f" subject:({asunto.group(1)})"
        elif despues and not sin_leer:
            return ("¿Cuáles mails borro? Decime, por ejemplo: «borrá el último mail», «borrá los mails de Juan», "
                    "«borrá los mails con asunto oferta» o «borrá el mail 2» (de la lista que te mostré).")
        if sin_leer:
            consulta += " is:unread"
        numero = next((int(w) if w.isdigit() else NUMEROS[w] for w in antes.split() if w.isdigit() or w in NUMEROS), None)
        if numero:
            cantidad = numero
        elif not plural:
            cantidad = 1
        elif de or asunto or sin_leer or "todos" in antes:
            cantidad = MAX_BORRAR
        else:
            return "¿Cuántos borro? Decime, por ejemplo: «borrá los últimos 3 mails»."
        jarvis.emitir("detalle", "Buscando esos mails...")
        try:
            elegidos = buscar_mails(consulta, min(cantidad, MAX_BORRAR))
        except imaplib.IMAP4.error:
            return "Gmail rechazó la contraseña. Volvé a conectarlo diciendo 'configurar Gmail'."
        except Exception as e:
            return f"No pude revisar el correo: {e}"
        if not elegidos:
            return "No encontré mails así en tu bandeja de entrada."

    n = len(elegidos)
    lista = "\n".join(f"- De {c['de']}: {c['asunto']}" for c in elegidos[:8])
    if n > 8:
        lista += f"\n- y {n - 8} más"
    cuales = "este mail" if n == 1 else f"estos {n} mails"
    return pedir_confirmacion("sistema", "Borrar mails", f"A la Papelera de Gmail (se recuperan 30 días):\n{lista}",
                              accion=lambda: a_la_papelera(elegidos),
                              pregunta=f"¿Borro {cuales}?\n{lista}\nVan a la Papelera y se pueden recuperar durante 30 días.")


# ======================= Llamadas y videollamadas de WhatsApp =======================
# "llamá a mi amor", "hacele una videollamada a mamá", "videollamada con Juan por WhatsApp".
# Siempre pregunta antes. Abre el chat en WhatsApp Desktop y toca el botón de llamada (lo busca por su nombre con la
# automatización de Windows, como un lector de pantalla); si no lo encuentra, deja el chat abierto para que lo toques.
LLAMAR = re.compile(
    r"^(?:(?:che|jarvis|bueno|dale|por favor)[\s,]+)*(?:quiero\s+|necesito\s+|podes\s+|podrias\s+)?"
    r"(?:llama|llamale|llamalo|llamala|llamar|llamas|llames|hace(?:le|me)?\s+una\s+(?:video\s*)?llamada|"
    r"video\s*llama(?:le|lo|la)?|(?:una\s+)?(?:video\s*)?llamada)\s+"
    r"(?:de\s+video\s+|por\s+video\s+|de\s+whatsapp\s+|por\s+whatsapp\s+)?(?:a|con|para)\s+(.+?)"
    r"(?:\s+(?:por|de|en)\s+(?:whatsapp|wpp|wsp|whats|video))*$")
BOTON_VOZ = re.compile(r"^(?:llamada(?: de voz)?|llamar|voice call|audio call|call)$", re.I)
BOTON_VIDEO = re.compile(r"^(?:videollamada|video ?llamada|video call)$", re.I)


def _uia():
    import comtypes.client

    comtypes.client.GetModule("UIAutomationCore.dll")
    from comtypes.gen import UIAutomationClient as U

    return U, comtypes.client.CreateObject("{ff48dba4-60ef-4201-aa87-54103eef594e}", interface=U.IUIAutomation)


def tocar_boton(ventana_contiene, patron, espera=8.0):
    """Busca en la ventana (por su título) un botón cuyo nombre coincida y lo toca. True si lo tocó."""
    U, uia = _uia()
    cond = uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_ButtonControlTypeId)
    limite = time.time() + espera
    while time.time() < limite:  # las apps web activan su accesibilidad recién cuando alguien la pide: se reintenta
        hijos = uia.GetRootElement().FindAll(U.TreeScope_Children, uia.CreateTrueCondition())
        for i in range(hijos.Length):
            ventana = hijos.GetElement(i)
            if ventana_contiene not in (ventana.CurrentName or "").lower():
                continue
            botones = ventana.FindAll(U.TreeScope_Descendants, cond)
            for j in range(botones.Length):
                b = botones.GetElement(j)
                if patron.match((b.CurrentName or "").strip()):
                    try:
                        b.GetCurrentPattern(U.UIA_InvokePatternId).QueryInterface(U.IUIAutomationInvokePattern).Invoke()
                    except Exception:
                        r = b.CurrentBoundingRectangle  # sin "Invoke": un clic en el medio del botón
                        ctypes.windll.user32.SetCursorPos((r.left + r.right) // 2, (r.top + r.bottom) // 2)
                        ctypes.windll.user32.mouse_event(0x0002, 0, 0, 0, 0)
                        ctypes.windll.user32.mouse_event(0x0004, 0, 0, 0, 0)
                    return True
        time.sleep(0.6)
    return False


def llamar_whatsapp(nombre, numero, video=False):
    """Abre el chat y toca el botón de llamada (o videollamada)."""
    tipo = "videollamada" if video else "llamada"
    estaba_abierto = whatsapp_abierto()
    os.startfile("whatsapp://send?" + urllib.parse.urlencode({"phone": numero}))
    limite = time.time() + (8 if estaba_abierto else 25)
    while "whatsapp" not in ventana_activa().lower():
        if time.time() > limite:
            raise RuntimeError("WhatsApp no se abrió a tiempo, no llamé a nadie")
        time.sleep(0.25)
    time.sleep(1.5 if estaba_abierto else 4)  # que cargue el chat
    if tocar_boton("whatsapp", BOTON_VIDEO if video else BOTON_VOZ):
        return f"Listo, estoy haciendo la {tipo} de WhatsApp a {nombre}."
    return (f"Te abrí el chat de {nombre} en WhatsApp, pero no encontré el botón de {tipo} para tocarlo yo: "
            f"tocalo arriba a la derecha.")


def manejar_llamada(texto, t):
    m = LLAMAR.match(t)
    if not m:
        return None
    video = "video" in t
    tipo = "videollamada" if video else "llamada"
    quien = re.sub(r"\s+(?:ahora|ya|porfa|por favor)$", "", m.group(1)).strip(" .,")
    nombre, datos, opciones = buscar_contacto(quien)
    if opciones:
        return f"Tengo varios contactos parecidos: {', '.join(opciones)}. ¿A cuál llamo?"
    if not nombre or not (datos or {}).get("telefono"):
        return (f"No tengo el número de {quien}. Agendalo así: «anotá a {quien} con el número 09...» "
                f"y después pedime la {tipo} de nuevo.")
    numero = datos["telefono"]
    return pedir_confirmacion("sistema", f"{tipo.capitalize()} a {nombre}", f"WhatsApp · {tipo} a {nombre}",
                              accion=lambda: llamar_whatsapp(nombre, numero, video),
                              pregunta=f"¿Hago una {tipo} de WhatsApp a {nombre}?")


# ======================= Mandar (WhatsApp o mail) =======================
# Formas de pedirlo (se comparan con el texto sin tildes):
#   "decile / dile / mandale / escribile / avisale a Mamá que la quiero"   "contale a Juan que llegué"
#   "quiero que le digas a Juan que llego tarde"     "podés mandarle a Juan que..."
#   "mandale un whatsapp a Juan: llego tarde"         "mensaje para Juan: llego tarde"   "whatsapp a Juan diciendo..."
#   "decile a mi amor hola" (sin "que": separa usando tu agenda)
#   "dile que la amo" (sin decir a quién: a la última persona; si no hay, pregunta)
#   "mandale un mail a Juan con asunto Reunión diciendo que..."   "escribile al correo de Juan que..."
#   "mandale un mensaje a Juan", "mandá un whatsapp", "mandale otro mensaje", "presentate a mi amor"
#        -> NO inventa: pregunta lo que falta.

PREFIJO = (r"^(?:(?:che|jarvis|dale|bueno|ok|okay|por favor|porfa)[\s,]+)*"
           r"(?:(?:quiero|necesito|preciso|podes|puedes|podrias|haceme el favor de|me haces el favor de|tenes que)\s+(?:que\s+)?)?"
           r"(?:le\s+)?")
VERBO_CLITICO = (r"(?:dile|decile|decirle|digale|contale|comentale|avisale|avisarle|recordale|preguntale|pedile|"
                 r"mandale|mandarle|enviale|enviarle|escribile|escribele|escribirle|respondele|contestale|pasale|"
                 # "que LE digas a Juan" es un mensaje; "que ME digas qué es..." es para el usuario (no cuenta)
                 r"(?<=le )(?:digas|mandes|envies|escribas|avises|preguntes|cuentes|respondas|contestes|pidas|recuerdes))")
VERBO_SIN_DESTINO = (r"(?:dile|decile|decirle|digale|avisale|preguntale|pedile|mandale|mandarle|enviale|enviarle|"
                     r"escribile|escribele|escribirle|respondele|contestale|digas|mandes|envies|escribas|avises)")
VERBO_SIMPLE = r"(?:manda|mande|mandar|envia|envie|enviar|escribi|escriba|escribir|deci|avisa|pregunta|responde|contesta)"
VERBO = rf"(?:{VERBO_CLITICO}|{VERBO_SIMPLE})"
CANAL_WA = r"(?:whatsapp|whatsap|wasap|wassap|wsp|wpp|guasap|mensaje|mensajito|msj|texto)"
CANAL_MAIL = r"(?:mail|email|e-mail|correo|gmail|emilio)"
CANAL = rf"(?:{CANAL_WA}|{CANAL_MAIL})"
CON_CANAL = rf"(?:(?:un|una|otro|otra|el|este)\s+)?(?:{CANAL}(?:\s+|$))?"
POR_CANAL = rf"(?:(?:por|via)\s+(?:el\s+)?{CANAL}(?:\s+|$))?"
A_QUIEN = rf"(?:a|para|al (?:{CANAL}) de|al)"
SEPARADOR = r"(?:,|:|;|diciendo(?:le)?|que diga|que dice|con el (?:mensaje|texto)|el mensaje|que)"

PATRON_COMPLETO = re.compile(rf"{PREFIJO}{VERBO}\s+{CON_CANAL}{POR_CANAL}{A_QUIEN}\s+(.+?)\s*{POR_CANAL}{SEPARADOR}\s+(.+)$")
PATRON_PARA = re.compile(rf"^(?:un |el |otro )?{CANAL}\s+{POR_CANAL}(?:a|para)\s+(.+?)\s*(?:,|:|que diga|diciendo|que)\s+(.+)$")
PATRON_SIN_SEPARADOR = re.compile(rf"{PREFIJO}{VERBO}\s+{CON_CANAL}{POR_CANAL}{A_QUIEN}\s+(.+?)\s*{POR_CANAL}$")
PATRON_SIN_DESTINO = re.compile(rf"{PREFIJO}{VERBO_SIN_DESTINO}(?:\s+(?!a\s|para\s|al\s){CON_CANAL}{POR_CANAL}(?:que\s+)?(.*))?$")
PATRON_SOLO_CANAL = re.compile(rf"{PREFIJO}(?:{VERBO_SIMPLE})\s+(?:un|una|otro|otra)\s+{CANAL}\s*{POR_CANAL}$")
PRESENTATE = re.compile(r"\b(?:presentate|saludalo|saludala|saludale|saluda)\s+(?:a|con)\s+(.+)$")
PARECE_ENVIO = re.compile(rf"\b(?:{VERBO_CLITICO}|presentate)\b|\b(?:{VERBO_SIMPLE})\s+(?:un |una |otro |otra )?{CANAL}\b")
PREGUNTA_GENERAL = re.compile(r"^(?:como|que es|que significa|por que|para que|cual es|cuales son|sabes)\b")
# Pedidos para el propio usuario ("decime", "explicame", "que me digas qué es...") nunca son mensajes a otro
PARA_MI = re.compile(r"\bme (?:digas|expliques|cuentes|ensenes|muestres|ayudes|recomiendes|pases|des)\b|"
                     r"\b(?:decime|explicame|contame|ensename|mostrame|ayudame|recomendame)\b")

borrador = None  # mensaje a medio armar mientras JARVIS pregunta lo que falta
ultimo = {"nombre": None, "texto": None, "cuando": 0.0}  # lo último que se preparó ("decile eso", "dile que...")


def es_mail_pedido(t):
    return bool(re.search(rf"\b{CANAL_MAIL}\b", t))


def separar_asunto(destino):
    """'Juan con asunto Reunión' -> ('Juan', 'Reunión')."""
    m = re.search(r"(?i)\s+con (?:el )?asunto:?\s+(.+)$", destino)
    return (destino[: m.start()].strip(), m.group(1).strip()) if m else (destino, None)


def asunto_en_mensaje(pedido):
    """'asunto Reunión y el texto es nos vemos el lunes' -> ('Reunión', 'nos vemos el lunes')."""
    m = re.match(r"(?i)^(?:con )?(?:el )?asunto:?\s+(.+?)\s+(?:y (?:el )?(?:texto|mensaje|cuerpo)(?: es| dice| que diga)?|"
                 r"diciendo|que diga|que dice|:)\s+(.+)$", pedido)
    return (m.group(1).strip(), m.group(2).strip()) if m else (None, pedido)


def separar_contacto(resto):
    """'mi mamá hola cómo estás' -> ('Mi Mamá', 'hola cómo estás') usando la agenda para saber dónde termina el nombre."""
    palabras = resto.split()
    n = [jarvis.normalizar(p) for p in palabras]
    mejor = 0
    for clave in cargar_contactos():
        k = jarvis.normalizar(clave).split()
        for variante in (k, k[1:] if k and k[0] == "mi" else ["mi"] + k):
            largo = len(variante)
            if largo and n[:largo] == variante and largo > mejor:
                mejor = largo
    if not mejor:  # contacto desconocido: el nombre es la primera palabra ("mi X" = dos)
        mejor = 2 if len(palabras) > 1 and n[0] in ("mi", "la", "el") else 1
    destino = " ".join(palabras[:mejor])
    pedido = " ".join(palabras[mejor:]).strip(" ,:")
    return destino, pedido or None


def contacto_mencionado(t):
    """Busca en la frase el nombre de algún contacto de la agenda."""
    encontrados = [k for k in cargar_contactos() if re.search(rf"\b{re.escape(jarvis.normalizar(k))}\b", t)]
    return max(encontrados, key=len) if encontrados else None


def nuevo_borrador(canal, destino=None, pedido=None, asunto=None):
    global borrador
    borrador = {"canal": canal, "destino": destino, "nombre": None, "datos": None, "pedido": pedido,
                "asunto": asunto, "espera": None, "hasta": time.time() + SEGUNDOS_CONFIRMAR}
    return avanzar_borrador()


def _pedido_util(pedido):
    """None si el pedido no dice QUÉ mandar ('otro mensaje', 'algo lindo'); 'eso' = lo último preparado."""
    if not pedido:
        return None
    n = re.sub(r"^que\s+", "", jarvis.normalizar(pedido).strip(" .,!?¿¡\"'"))
    if not n or VAGO.match(n):
        return None
    if REFERENCIA.match(n):
        return ultimo["texto"] if ultimo["texto"] and time.time() - ultimo["cuando"] < 1800 else None
    return pedido


def avanzar_borrador():
    """Pregunta lo que falta; cuando está todo, muestra el mensaje TAL CUAL y pide confirmación."""
    global borrador
    b = borrador
    b["hasta"] = time.time() + SEGUNDOS_CONFIRMAR
    es_mail = b["canal"] == "gmail"
    if es_mail and not gmail_configurado():
        borrador = None
        return sin_gmail()
    if not b["destino"]:
        b["espera"] = "destino"
        return "¿A quién se lo mando?"
    if not b["nombre"]:
        if es_mail and "@" in b["destino"]:
            b["nombre"], b["datos"] = b["destino"], {"email": b["destino"]}
        else:
            nombre, datos, opciones = buscar_contacto(b["destino"])
            if opciones:
                b["espera"] = "destino"
                return f"Tengo varios contactos parecidos: {', '.join(opciones)}. ¿A cuál?"
            if not nombre or not datos.get("email" if es_mail else "telefono"):
                b["nombre"] = nombre or b["destino"].strip().title()
                b["espera"] = "email" if es_mail else "numero"
                if es_mail:
                    return f"No tengo el mail de {b['nombre']}. ¿Cuál es?"
                return f"No tengo el número de {b['nombre']}. ¿Cuál es? (con el código de país o empezando con 0)"
            b["nombre"], b["datos"] = nombre, datos
    if es_mail and b["pedido"] and b["asunto"] is None:
        b["asunto"], b["pedido"] = asunto_en_mensaje(b["pedido"])
    b["pedido"] = _pedido_util(b["pedido"])
    if not b["pedido"]:
        b["espera"] = "mensaje"
        if es_mail:
            return f"¿Qué le escribo a {b['nombre']}? Decímelo tal cual y lo mando así."
        return f"¿Qué le digo exactamente a {b['nombre']}? Decímelo tal cual y se lo mando así."
    if es_mail and b["asunto"] is None:
        b["espera"] = "asunto"
        return "¿Qué asunto le pongo? (o decí 'sin asunto')"

    borrador = None
    return preparar_envio(b["canal"], b["nombre"], b["datos"], b["pedido"], b["asunto"])


def preparar_envio(canal, nombre, datos, pedido, asunto=None):
    mensaje = limpiar_mensaje(pedido)
    ultimo.update(nombre=nombre, texto=mensaje, cuando=time.time())
    if canal == "gmail":
        direccion = datos["email"]
        para = f"{nombre} <{direccion}>" if nombre != direccion else direccion
        asunto = (asunto or "").strip()
        asunto = asunto[:1].upper() + asunto[1:]
        return pedir_confirmacion("gmail", para, mensaje, asunto=asunto,
                                  hacer=lambda tx, asu: enviar_mail(direccion, asu or "", tx))
    return pedir_confirmacion("whatsapp", nombre, mensaje,
                              hacer=lambda tx, _asu: enviar_whatsapp(nombre, datos["telefono"], tx))


def esperando_respuesta():
    """True si JARVIS acaba de preguntar algo (a quién, número, qué decirle, asunto o '¿lo mando?')."""
    global borrador
    if borrador and time.time() > borrador["hasta"]:
        borrador = None
    return borrador is not None or hay_pendiente()


def es_pedido_de_envio(t):
    t = limpiar_mail_dictado(t)
    return any(p.match(t) for p in (PATRON_COMPLETO, PATRON_PARA, PATRON_SIN_SEPARADOR, PATRON_SOLO_CANAL))


def continuar_borrador(texto, t):
    """Si JARVIS estaba preguntando algo para un mensaje, usa esta respuesta. Si no corresponde, None."""
    global borrador
    if not esperando_respuesta() or borrador is None:
        return None
    b = borrador
    limpio = t.strip(" ,.!¿?¡")

    if b["espera"] == "asunto":
        if limpio in ("sin asunto", "ninguno", "no", "nada", "vacio", "ningun asunto", "no le pongas"):
            b["asunto"] = ""
        else:
            m = re.match(r"^(?:el asunto es|asunto|ponele)\s*:?\s*", t)
            b["asunto"] = jarvis.parte_original(texto, m.end() if m else 0).strip(' ."')
        return avanzar_borrador()

    if limpio in NO or limpio in ("cancela el mensaje", "no importa", "deja nomas", "olvidate"):
        borrador = None
        return "Listo, no mando nada."
    if es_pedido_de_envio(t):  # en vez de contestar, pidió otro envío completo: empieza de nuevo
        borrador = None
        return None

    if b["espera"] == "destino":
        if len(limpio.split()) > 5:
            borrador = None  # parece otra cosa: se abandona el mensaje
            return None
        m = re.match(r"^(?:a\s+|para\s+)?", t)
        b["destino"], b["nombre"] = jarvis.parte_original(texto, m.end()).strip(" .,?¿!¡"), None
        return avanzar_borrador()

    if b["espera"] == "numero":
        digitos = re.sub(r"\D", "", t)
        if len(digitos) < 6:
            borrador = None
            return None
        contactos = cargar_contactos()
        contactos.setdefault(b["nombre"], {})["telefono"] = normalizar_numero(t)
        guardar_contactos(contactos)
        b["datos"] = contactos[b["nombre"]]
        return f"Agendé a {b['nombre']} con el número +{b['datos']['telefono']}. " + avanzar_borrador()

    if b["espera"] == "email":
        m = re.search(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", limpiar_mail_dictado(t))
        if not m:
            borrador = None
            return None
        contactos = cargar_contactos()
        contactos.setdefault(b["nombre"], {})["email"] = m.group(0)
        guardar_contactos(contactos)
        b["datos"] = contactos[b["nombre"]]
        return f"Guardé el mail de {b['nombre']}. " + avanzar_borrador()

    if b["espera"] == "mensaje":
        m = re.match(rf"^(?:(?:{VERBO_CLITICO}|deci|ponele|el mensaje es|el texto es|que diga)\s+)?(?:que\s+)?", t)
        b["pedido"] = jarvis.parte_original(texto, m.end()).strip() or texto.strip()
        if not _pedido_util(b["pedido"]):
            return "Necesito el texto exacto, no lo voy a inventar. ¿Qué le digo?"
        return avanzar_borrador()
    return None


def manejar_mandar(texto, t):
    t_mail = limpiar_mail_dictado(t)
    igual = t_mail == t  # si no cambió, se recuperan tildes y mayúsculas del original
    if PARA_MI.search(t_mail) and not PATRON_COMPLETO.match(t_mail):
        return None  # "preciso que me digas qué son las sucesiones" es una pregunta, no un mensaje

    def parte(m, g):
        return (original(texto, m, g) if igual else m.group(g).strip()) if m.group(g) else None

    canal = "gmail" if es_mail_pedido(t_mail) else "whatsapp"

    for patron in (PATRON_COMPLETO, PATRON_PARA):  # "decile a mi amor que la amo"
        m = patron.match(t_mail)
        if m:
            destino, asunto = separar_asunto(parte(m, 1))
            return nuevo_borrador("gmail" if "@" in destino else canal, destino, parte(m, 2), asunto)

    m = PATRON_SIN_SEPARADOR.match(t_mail)  # "decile a mi amor hola" / "mandale un mensaje a Juan"
    if m:
        destino, asunto = separar_asunto(parte(m, 1))
        destino, pedido = separar_contacto(destino)
        return nuevo_borrador("gmail" if "@" in destino else canal, destino, pedido, asunto)

    m = PATRON_SIN_DESTINO.match(t_mail)  # "dile que la amo", "mandale otro mensaje"
    if m:
        pedido = parte(m, 1)
        destino = ultimo["nombre"] if ultimo["nombre"] and time.time() - ultimo["cuando"] < 600 else None
        # "mandale algo lindo A MI AMOR": el destinatario quedó al final
        quien = contacto_mencionado(t_mail)
        if pedido and quien:
            fin = re.search(rf"\s+(?:a|para)\s+(?:mi\s+)?{re.escape(jarvis.normalizar(quien))}\s*$", jarvis.normalizar(pedido))
            if fin:
                pedido, destino = pedido[: fin.start()].strip(), quien
        return nuevo_borrador(canal, destino, pedido)

    if PATRON_SOLO_CANAL.match(t_mail):  # "mandá un whatsapp"
        return nuevo_borrador(canal)

    m = PRESENTATE.search(t_mail)  # "presentate a mi amor": no inventa la presentación, pregunta
    if m:
        return nuevo_borrador(canal, contacto_mencionado(t_mail) or parte(m, 1))

    # Parece un pedido de mensaje pero no se entendió: NO deja que el chat lo "actúe", pregunta
    if PARECE_ENVIO.search(t_mail) and not PREGUNTA_GENERAL.match(t_mail):
        quien = contacto_mencionado(t_mail)
        if quien:
            return nuevo_borrador(canal, quien)
        return ("No entendí bien a quién o qué mandar. Decímelo así: «decile a Juan que llego tarde», "
                "o «mandale un mensaje a Juan» y te pregunto lo que falta.")
    return None


# ======================= TikTok =======================

def manejar_tiktok(texto, t):
    t = re.sub(r"\btik\s*tok\b", "tiktok", t)
    if "tiktok" not in t:
        return None
    abrir = lambda url: webbrowser.open(url)  # noqa: E731
    if re.search(r"\b(?:mensajes|chats?|dm|dms|inbox|bandeja)\b", t):
        abrir("https://www.tiktok.com/messages")
        return "Abriendo tus mensajes de TikTok."
    if re.search(r"\b(?:subi|subir|sube|subime|publica|publicar|postea|postear|carga|cargar)\b", t):
        abrir("https://www.tiktok.com/tiktokstudio/upload")
        return "Abriendo TikTok para subir un video."
    m = re.search(r"\b(?:perfil|cuenta|usuario)\s+(?:de\s+)?@?([\w.]+)", t) or re.search(r"@([\w.]+)", t)
    if m and m.group(1) != "tiktok":
        abrir(f"https://www.tiktok.com/@{m.group(1)}")
        return f"Abriendo el perfil de {m.group(1)} en TikTok."
    m = re.match(r"^(?:busca|buscame|buscar|pone|poneme|mostrame|quiero ver|reproduci)\s+(?:en tiktok\s+)?"
                 r"(?:videos?\s+(?:de|sobre)\s+|sobre\s+)?(.+?)(?:\s+en tiktok)?$", t)
    if m and m.group(1).strip() not in ("tiktok", ""):
        consulta = m.group(1).strip()
        abrir("https://www.tiktok.com/search?q=" + urllib.parse.quote_plus(consulta))
        return f"Buscando {consulta} en TikTok."
    if re.match(r"^(?:abri|abre|abrime|abrir|entra a|entra en|pone|poneme)\s+(?:el |la )?tiktok$", t) or t == "tiktok":
        abrir("https://www.tiktok.com/foryou")
        return "Abriendo TikTok."
    return None


# ======================= Pasar cosas entre apps =======================
# "mandale por WhatsApp a Juan el último video", "mandame por mail el Word que hiciste", "mandale a Juan por mail la
# imagen", "anotá el mail 2 en mis pendientes", "guardá el último video en la carpeta Fotos".
# Mandar SIEMPRE pide confirmación (como los mensajes).
TIPO_ARCHIVO = (r"(video|videito|documento|word|excel|planilla|presentacion|powerpoint|pdf|archivo|imagen|foto|dibujo|"
                r"grabacion)")
MANDAR_ARCHIVO = re.compile(rf"^(?:(?:che|jarvis)[\s,]+)?(?:manda|mandale|mandame|envia|enviale|enviame|pasa|pasale|"
                            rf"pasame|comparti|compartile|compartime)\b(?P<resto>.*?\b(?:el|la|ese|esa|este|esta|mi|tu|"
                            rf"lo|los|las)\s+(?:ultim[oa]s?\s+)?{TIPO_ARCHIVO}s?\b.*)$")
PASAR_MAIL_A_PENDIENTE = re.compile(r"\b(?:anota|agrega|pasa|guarda|pone|manda)\w*\s+(?:el |ese |este |aquel )?(?:mail|correo)"
                                    r"(?:\s+(?:numero |nro )?(\d+|primero|segundo|tercero|cuarto|quinto|ultimo))?\s+"
                                    r"(?:a|en|como)\s+(?:un |mis |los )?pendientes?\b")
GUARDAR_EN_CARPETA = re.compile(rf"^(?:guarda|guardame|copia|copiame|move|movelo|movela|mueve|pasa|pasame)\s+(?:el |la |ese |"
                                rf"esa |este |esta |mi )?(?:ultim[oa] )?{TIPO_ARCHIVO}(?: (?:que (?:hiciste|creaste|"
                                rf"armaste)|de recien))?\s+(?:a|en|dentro de)\s+(?:la\s+)?carpeta\s+(?:de\s+(?:la\s+|el\s+)?|"
                                rf"llamada\s+|que se llama\s+)?(?P<carpeta>.+)$")
_ultimo_mail_leido = [None]


def _extensiones(tipo):
    tipo = {"videito": "video", "grabacion": "video", "foto": "imagen", "dibujo": "imagen", "planilla": "excel",
            "powerpoint": "presentacion", "word": "documento"}.get(tipo, tipo)
    return tipo, {"video": {".mp4", ".mkv", ".mov", ".avi", ".webm"}, "imagen": {".png", ".jpg", ".jpeg", ".webp"},
                  "documento": {".docx", ".doc", ".odt"}, "excel": {".xlsx", ".xls", ".csv"},
                  "presentacion": {".pptx", ".ppt"}, "pdf": {".pdf"}, "archivo": None}[tipo]


def archivo_pedido(t):
    """La ruta del archivo del que hablás: 'el último video', 'el Word que hiciste', 'la imagen', 'el video de la pila'."""
    m = re.search(rf"\b(?:el|la|ese|esa|este|esta|mi|lo|los|las)\s+(?:ultim[oa]s?\s+)?{TIPO_ARCHIVO}s?\b(?:\s+(?:de|del|sobre|"
                  rf"que se llama)\s+(?:la |el |los |las )?(?P<nombre>.+?))?(?:\s+(?:por|a|al|para|que hiciste|que creaste)\b.*)?$", t)
    if not m:
        return None, None
    tipo, extensiones = _extensiones(m.group(1))
    nombre = (m.group("nombre") or "").strip()
    palabras = [w for w in re.findall(r"[a-z0-9ñ]+", nombre) if len(w) > 2][:4]
    if tipo == "video":
        lista = jarvis.videos.videos_recientes(1, palabras or None)
        return (lista[0] if lista else None), tipo
    ultimo = jarvis.ultimo_archivo.get("ruta")
    if not palabras and ultimo and os.path.exists(ultimo) and (extensiones is None or os.path.splitext(ultimo)[1].lower()
                                                                in extensiones):
        return ultimo, tipo
    carpetas = [jarvis.CARPETA_IMAGENES] if tipo == "imagen" else [jarvis.CARPETA_DOCS] + jarvis.carpetas_busqueda()
    hallados = []
    for carpeta in carpetas:
        for raiz, subs, archivos in os.walk(carpeta):
            if raiz.count(os.sep) - carpeta.count(os.sep) >= 2:
                subs[:] = []
            for a in archivos:
                base, ext = os.path.splitext(a)
                if (extensiones is None or ext.lower() in extensiones) and all(p in jarvis.normalizar(base) for p in palabras):
                    ruta = os.path.join(raiz, a)
                    try:
                        hallados.append((os.path.getmtime(ruta), ruta))
                    except OSError:
                        pass
        if hallados and carpeta in (jarvis.CARPETA_IMAGENES, jarvis.CARPETA_DOCS):
            break  # primero lo que hizo JARVIS
    return (max(hallados)[1] if hallados else None), tipo


def copiar_archivo_al_portapapeles(ruta):
    """Pone el archivo en el portapapeles (como Ctrl+C en el Explorador), para pegarlo en WhatsApp."""
    import struct

    import win32clipboard

    datos = struct.pack("IiiII", 20, 0, 0, 0, 1) + (os.path.abspath(ruta) + "\0").encode("utf-16-le") + b"\0\0"
    win32clipboard.OpenClipboard()
    try:
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32clipboard.CF_HDROP, datos)
    finally:
        win32clipboard.CloseClipboard()


def enviar_archivo_whatsapp(nombre, numero, ruta):
    """Abre el chat en WhatsApp Desktop, pega el archivo y aprieta Enter (WhatsApp muestra la vista previa)."""
    estaba_abierto = whatsapp_abierto()
    os.startfile("whatsapp://send?" + urllib.parse.urlencode({"phone": numero}))
    limite = time.time() + (8 if estaba_abierto else 25)
    while "whatsapp" not in ventana_activa().lower():
        if time.time() > limite:
            raise RuntimeError("WhatsApp no se abrió a tiempo, no mandé nada")
        time.sleep(0.25)
    time.sleep(1.5 if estaba_abierto else 5)
    copiar_archivo_al_portapapeles(ruta)
    if "whatsapp" not in ventana_activa().lower():
        raise RuntimeError("otra ventana tapó a WhatsApp, así que no pegué el archivo")
    ctypes.windll.user32.keybd_event(0x11, 0, 0, 0)  # Ctrl+V
    ctypes.windll.user32.keybd_event(0x56, 0, 0, 0)
    ctypes.windll.user32.keybd_event(0x56, 0, 2, 0)
    ctypes.windll.user32.keybd_event(0x11, 0, 2, 0)
    time.sleep(3)  # WhatsApp arma la vista previa
    if "whatsapp" not in ventana_activa().lower():
        raise RuntimeError("otra ventana tapó a WhatsApp: el archivo quedó pegado, pero no apreté enviar")
    jarvis.tecla(VK_ENTER)
    return f"Listo, le mandé «{os.path.basename(ruta)}» a {nombre} por WhatsApp."


def manejar_mandar_archivo(texto, t):
    t = _limpio(t)
    m = MANDAR_ARCHIVO.match(t)
    if not m:
        return None
    archivo = re.search(rf"\b(?:el|la|ese|esa|este|esta|mi|tu|lo|los|las)\s+(?:ultim[oa]s?\s+)?{TIPO_ARCHIVO}", t)
    if archivo and re.search(r"\b(?:que|diciendo|decile)\b", t[:archivo.start()]):
        return None  # "mandale a Juan que mire el video": es un mensaje, no el archivo
    if re.search(r"\ba (?:vertical|horizontal|mp4|mp3|pdf|word|texto|blanco y negro|camara lenta)\b|"
                 r"\bpara (?:tik ?tok|reels?|shorts?|historias)\b|\ba (?:la|una) carpeta\b", t):
        return None  # "pasá el video a vertical", "pasá el Word a PDF": es una edición, no mandarlo
    ruta, tipo = archivo_pedido(t)
    if not ruta:
        return f"No encontré {'ese ' + tipo if tipo else 'el archivo'}. Decime cómo se llama o pedímelo de nuevo cuando lo haga."
    por_whatsapp = bool(re.search(r"\b(?:whatsapp|wpp|wsp|whats)\b", t))
    por_mail = bool(re.search(rf"\b(?:{PALABRA_MAIL})\b", t))
    para_mi = bool(re.search(r"^(?:(?:che|jarvis)[\s,]+)?(?:mandame|enviame|pasame|compartime)\b", t)) or \
        bool(re.search(r"\ba mi (?:mail|correo)\b", t))
    if not por_whatsapp and not por_mail:
        por_mail = para_mi  # "mandame el video": a tu propio mail
        if not por_mail:
            return "¿Por WhatsApp o por mail? Decímelo así: «mandale por WhatsApp a Juan el último video»."
    mb = os.path.getsize(ruta) / 2 ** 20
    nombre_archivo = os.path.basename(ruta)
    if para_mi:
        destino = credenciales()[0]
        if not destino:
            return sin_gmail()
        if mb > 24:
            return f"«{nombre_archivo}» pesa {mb:.0f} MB y Gmail deja hasta 25. Está en {os.path.dirname(ruta)}."
        return pedir_confirmacion("gmail", destino, f"Te mando «{nombre_archivo}».", asunto=nombre_archivo,
                                  hacer=lambda tx, asu: enviar_mail(destino, asu or nombre_archivo, tx, [ruta]))
    a_quien = re.search(r"\ba\s+(?!mi mail|mi correo)(.+?)(?=\s+(?:el|la|ese|esa|este|esta|mi|los|las|por|que)\b|$)", m.group("resto"))
    if not a_quien:
        a_quien = re.search(r"^(?:mandale|enviale|pasale|compartile)\s+(?:por \w+\s+)?(?:a\s+)?(.+?)(?=\s+(?:el|la|ese|esa)\b)", t)
    if not a_quien:
        return "¿A quién se lo mando?"
    pedido_nombre = a_quien.group(1).strip()
    if por_mail and "@" in pedido_nombre:
        nombre, datos = pedido_nombre.replace(" arroba ", "@").replace(" ", ""), {}
        datos["email"] = nombre
    else:
        nombre, datos, opciones = buscar_contacto(pedido_nombre)
        if opciones:
            return f"¿A cuál? Tengo a {', '.join(opciones)}."
        if not nombre:
            return f"No tengo a «{pedido_nombre}» en tus contactos. Agendalo así: «agendá a {pedido_nombre} con el número ...»."
    if por_mail:
        if not datos.get("email"):
            return f"No tengo el mail de {nombre}. Decime: «agendá el mail de {nombre}: ...»."
        if not gmail_configurado():
            return sin_gmail()
        if mb > 24:
            return f"«{nombre_archivo}» pesa {mb:.0f} MB y Gmail deja hasta 25: mandalo por WhatsApp."
        direccion = datos["email"]
        return pedir_confirmacion("gmail", f"{nombre} <{direccion}>" if nombre != direccion else direccion,
                                  f"Te paso «{nombre_archivo}».", asunto=nombre_archivo,
                                  hacer=lambda tx, asu: enviar_mail(direccion, asu or nombre_archivo, tx, [ruta]))
    if not datos.get("telefono"):
        return f"No tengo el número de {nombre}."
    return pedir_confirmacion("whatsapp", nombre, f"[archivo] {nombre_archivo}",
                              pregunta=f"¿Le mando «{nombre_archivo}» ({mb:.1f} MB) a {nombre} por WhatsApp?",
                              hacer=lambda _tx, _asu: enviar_archivo_whatsapp(nombre, datos["telefono"], ruta))


def manejar_mail_a_pendiente(texto, t):
    m = PASAR_MAIL_A_PENDIENTE.search(_limpio(t))
    if not m:
        return None
    cual = m.group(1)
    if cual:
        n = int(cual) if cual.isdigit() else len(_ultima_lista) if cual == "ultimo" else ORDINALES.get(cual)
        correo = _ultima_lista[n - 1] if n and 1 <= n <= len(_ultima_lista) else None
    else:
        correo = _ultimo_mail_leido[0] or (_ultima_lista[0] if len(_ultima_lista) == 1 else None)
    if not correo:
        return "¿Cuál mail? Decime el número de la última lista: «anotá el mail 2 en mis pendientes»."
    texto_pendiente = f"Mail de {correo['de']}: {correo['asunto']}"
    jarvis.habilidades.agregar_pendiente(texto_pendiente)
    return f"Listo, lo anoté en tus pendientes: «{texto_pendiente}»."


def manejar_guardar_en_carpeta(texto, t):
    m = GUARDAR_EN_CARPETA.match(_limpio(t))
    if not m:
        return None
    ruta, tipo = archivo_pedido(re.sub(r"\s+(?:a|en|dentro de)\s+(?:la\s+)?carpeta\b.*$", "", t))
    if not ruta:
        return f"No encontré {'el ' + tipo if tipo else 'el archivo'}."
    pedida = m.group("carpeta").strip(" .")
    destino = None
    home = os.path.expanduser("~")
    raices = jarvis.carpetas_busqueda() + [os.path.join(home, "Videos"), os.path.join(home, "Pictures")]
    for raiz in [r for r in dict.fromkeys(raices) if os.path.isdir(r)]:
        for carpeta, subs, _ in os.walk(raiz):
            if carpeta.count(os.sep) - raiz.count(os.sep) >= 2:
                subs[:] = []
            for s in subs:
                if jarvis.normalizar(s) == jarvis.normalizar(pedida) or (len(pedida) > 3 and jarvis.normalizar(pedida) in
                                                                         jarvis.normalizar(s)):
                    destino = os.path.join(carpeta, s)
                    break
            if destino:
                break
        if destino:
            break
    creada = False
    if not destino:
        documentos = next((r for r in jarvis.carpetas_busqueda() if os.path.basename(r).lower() in ("documents", "documentos")),
                          home)
        destino = os.path.join(documentos, pedida[:1].upper() + pedida[1:])
        os.makedirs(destino, exist_ok=True)
        creada = True
    import shutil

    mover = bool(re.match(r"^(?:move|movelo|movela|mueve)\b", t))
    final = os.path.join(destino, os.path.basename(ruta))
    if os.path.exists(final) and os.path.abspath(final) != os.path.abspath(ruta):
        base, ext = os.path.splitext(final)
        final = f"{base} (copia){ext}"
    (shutil.move if mover else shutil.copy2)(ruta, final)
    jarvis.recordar_archivo(final)
    return (f"Listo, {'moví' if mover else 'guardé una copia de'} «{os.path.basename(ruta)}» en "
            f"{'la carpeta nueva ' if creada else ''}{destino}.")


# ======================= Entrada principal =======================

def ejecutar(texto, t):
    """La llama main.ejecutar_accion. Devuelve la respuesta si el pedido era de acá, o None."""
    import celular  # "configurar celular": JARVIS por Telegram

    for manejar in (manejar_agenda, manejar_mandar_archivo, manejar_mail_a_pendiente, manejar_busqueda_mails,
                    manejar_gmail, manejar_llamada, manejar_mandar, manejar_tiktok, celular.manejar,
                    manejar_guardar_en_carpeta):
        respuesta = manejar(texto, t)
        if respuesta is not None:
            return respuesta
    return None
