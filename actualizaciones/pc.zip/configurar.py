"""Conectar Gmail, Pollinations (imágenes) o una IA en la nube (Gemini, Groq, NVIDIA) con JARVIS (una sola vez).

Ejecutá:  python configurar.py              (Gmail; o decile a JARVIS "configurar Gmail")
          python configurar.py pollinations (imágenes; o decile "configurar Pollinations")
          python configurar.py celular      (JARVIS en Telegram; o decile "configurar celular")
Las claves se guardan en el Administrador de credenciales de Windows, no en un archivo.
"""
import getpass
import imaplib
import sys
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

import keyring

SERVICIO_CLAVE = "JARVIS-Gmail"


def pollinations():
    print("=" * 62)
    print("  J.A.R.V.I.S. · Conectar Pollinations (generar imágenes)")
    print("=" * 62)
    print("""
Con una cuenta gratis de Pollinations, JARVIS usa modelos de imagen
mucho mejores (Z-Image Turbo / Flux) cuando la PC no puede generarlas
(por ejemplo en modo juego).

 1. Te voy a abrir enter.pollinations.ai/keys
 2. Iniciá sesión (con Google o GitHub) y creá una clave SECRETA
    (empieza con sk_).
 3. Copiala y pegala acá abajo.
""")
    input("Apretá Enter para abrir la página...")
    webbrowser.open("https://enter.pollinations.ai/keys")
    while True:
        clave = getpass.getpass("\nClave de Pollinations (no se ve al pegar): ").strip()
        print("Probando la clave (genera una imagen chiquita)...")
        try:
            url = ("https://gen.pollinations.ai/image/" + urllib.parse.quote("a small red apple")
                   + "?model=zimage&width=256&height=256")
            pedido = urllib.request.Request(url, headers={"Authorization": f"Bearer {clave}",
                                                          "User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(pedido, timeout=90) as r:
                if not r.headers.get("Content-Type", "").startswith("image/"):
                    raise RuntimeError("no devolvió una imagen")
            break
        except Exception as e:
            print(f"\n  No funcionó: {e}")
            print("  Revisá que sea la clave secreta (sk_...) completa.")
        if input("¿Probar de nuevo? (s/n): ").strip().lower() != "s":
            return
    keyring.set_password("JARVIS-Pollinations", "clave", clave)
    print("\n  ¡Listo! Pollinations quedó conectado. JARVIS lo usa cuando la PC no puede generar la imagen.")


PASOS_NUBE = {
    "gemini": """ 1. Te voy a abrir Google AI Studio (aistudio.google.com).
 2. Entrá con tu cuenta de Google y tocá "Create API key" (empieza con AQ. o con AIza).
    Es gratis: tiene un límite de usos por día que alcanza de sobra.
 3. Copiala y pegala acá abajo.""",
    "groq": """ 1. Te voy a abrir console.groq.com
 2. Creá una cuenta gratis (podés entrar con Google) y tocá "Create API Key"
    (empieza con gsk_). Es gratis y responde muy rápido.
 3. Copiala y pegala acá abajo.""",
    "nvidia": """ 1. Te voy a abrir build.nvidia.com
 2. Iniciá sesión y tocá "Get API Key" (empieza con nvapi-).
 3. Copiala y pegala acá abajo.""",
}


def nube(proveedor="gemini"):
    """Conectar una IA grande en la nube (Gemini, Groq o NVIDIA) para "pensar más"."""
    import json
    import subprocess

    from cerebro_nvidia import PROVEEDORES

    d = PROVEEDORES[proveedor]
    print("=" * 62)
    print(f"  J.A.R.V.I.S. · IA en la nube: {d['nombre']} (opcional)")
    print("=" * 62)
    print(f"""
Con una clave de {d['nombre']}, cuando toques "pensar más" la pregunta la
responde un modelo mucho más grande (en la nube). Gemma sigue siendo el
cerebro de siempre y todo funciona sin internet como antes.

{PASOS_NUBE[proveedor]}

La clave se guarda como VARIABLE DE ENTORNO de tu usuario de Windows
({d['variable']}), no en ningún archivo de JARVIS.
""")
    input("Apretá Enter para abrir la página...")
    webbrowser.open(d["pagina"])
    def probar(clave, modelo):
        cuerpo = json.dumps({"model": modelo, "max_tokens": 5, "messages": [{"role": "user", "content": "hola"}]}).encode()
        pedido = urllib.request.Request(d["url"] + "/chat/completions", data=cuerpo,
                                        headers={"Authorization": f"Bearer {clave}", "Content-Type": "application/json",
                                                 "User-Agent": "JARVIS"})
        with urllib.request.urlopen(pedido, timeout=60) as r:
            json.load(r)

    def motivo(e):
        """Lo que explica la API (sin la clave): 'API key not valid', 'model not found'..."""
        try:
            cuerpo = json.loads(e.read().decode("utf-8", "replace"))
            if isinstance(cuerpo, list):
                cuerpo = cuerpo[0] if cuerpo else {}
            error = cuerpo.get("error", cuerpo)
            return str(error.get("message") if isinstance(error, dict) else error)[:200]
        except Exception:
            return ""

    while True:
        clave = getpass.getpass(f"\nClave de {d['nombre']} (no se ve al pegar): ").strip()
        print("Probando la clave...")
        modelo = d["modelo"]
        try:
            try:
                probar(clave, modelo)
            except urllib.error.HTTPError as e:
                if e.code != 404:
                    raise
                # ese modelo ya no existe (Google los retira seguido): se busca uno que tu cuenta sí tenga
                from cerebro_nvidia import listar_modelos, mejor_modelo

                modelo = mejor_modelo(proveedor, [i for i in listar_modelos(proveedor, clave) if i != d["modelo"]])
                if not modelo:
                    raise
                print(f"  El modelo {d['modelo']} ya no está; pruebo con {modelo}...")
                probar(clave, modelo)
            print(f"\n  ¡Anda! (modelo: {modelo})")
            break
        except urllib.error.HTTPError as e:
            explicacion = motivo(e)
            print(f"\n  {d['nombre']} respondió error {e.code}"
                  + (": la clave no es válida (o la cuenta todavía está en revisión)." if e.code in (400, 401, 403) else ".")
                  + (f"\n  Detalle: {explicacion}" if explicacion else ""))
        except Exception as e:
            print(f"\n  No pude probarla ({e}). ¿Hay internet?")
        if input("¿Probar de nuevo? (s/n): ").strip().lower() != "s":
            if input("¿Guardarla igual sin probar? (s/n): ").strip().lower() == "s":
                break
            return
    # setx la guarda en tus variables de usuario (JARVIS la lee desde ahí, sin reiniciar)
    r = subprocess.run(["setx", d["variable"], clave], capture_output=True, text=True)
    if r.returncode != 0:
        print(f"\n  No pude guardar la variable: {r.stderr.strip()}")
        return
    print(f"\n  ¡Listo! {d['nombre']} quedó conectado. En JARVIS tocá el cerebrito (pensar más) antes de una pregunta.")


def main():
    print("=" * 62)
    print("  J.A.R.V.I.S. · Conectar Gmail")
    print("=" * 62)
    print("""
Gmail no deja usar tu contraseña normal. Hay que crear una
"contraseña de aplicación" (16 letras) solo para JARVIS:

 1. Tu cuenta de Google tiene que tener la VERIFICACIÓN EN 2 PASOS
    activada (Seguridad > Verificación en 2 pasos).
 2. Te voy a abrir la página "Contraseñas de aplicaciones".
 3. En "Nombre de la app" escribí JARVIS y tocá Crear.
 4. Copiá las 16 letras que te muestra y pegalas acá abajo.
""")
    tiene_2pasos = input("¿Ya tenés activada la verificación en 2 pasos? (s/n): ").strip().lower()
    if tiene_2pasos != "s":
        print("""
Primero activala (si no, Google dice "La opción de configuración que
buscas no está disponible para tu cuenta"):
  - Tocá "Activar la verificación en 2 pasos" y seguí los pasos
    (te piden tu celular para mandarte un código).
""")
        input("Apretá Enter para abrir esa página...")
        webbrowser.open("https://myaccount.google.com/signinoptions/twosv")
        input("\nCuando la tengas activada, apretá Enter para seguir...")

    input("Apretá Enter para abrir la página de contraseñas de aplicación...")
    webbrowser.open("https://myaccount.google.com/apppasswords")
    print("""
Si igual te dice "no está disponible para tu cuenta", puede ser una cuenta
de trabajo/escuela o con Protección avanzada. En ese caso cerrá esta
ventana y pedile a Claude que te arme la conexión con la API de Gmail.""")

    while True:
        usuario = input("\nTu dirección de Gmail: ").strip()
        clave = getpass.getpass("Contraseña de aplicación (no se ve al escribir/pegar): ").replace(" ", "").strip()
        print("Probando la conexión...")
        try:
            with imaplib.IMAP4_SSL("imap.gmail.com", timeout=30) as m:
                m.login(usuario, clave)
            break
        except imaplib.IMAP4.error:
            print("\n  Gmail rechazó esos datos. Revisá que sea la contraseña de APLICACIÓN")
            print("  (16 letras), no tu contraseña normal.")
        except OSError as e:
            print(f"\n  No pude conectarme a Gmail ({e}). ¿Hay internet?")
        if input("¿Probar de nuevo? (s/n): ").strip().lower() != "s":
            return

    anterior = keyring.get_password(SERVICIO_CLAVE, "usuario")
    if anterior and anterior != usuario:
        try:
            keyring.delete_password(SERVICIO_CLAVE, anterior)
        except Exception:
            pass
    keyring.set_password(SERVICIO_CLAVE, "usuario", usuario)
    keyring.set_password(SERVICIO_CLAVE, usuario, clave)
    print(f"\n  ¡Listo! Gmail ({usuario}) quedó conectado a JARVIS.")
    print("  Probá decirle: \"revisá mis mails\" o \"mandale un mail a ...\"")


# ---------------------------------------------------------------------------
#  JARVIS en el celular (bot de Telegram en Google Apps Script)
# ---------------------------------------------------------------------------

def _telegram(token, metodo, **datos):
    import json

    pedido = urllib.request.Request(f"https://api.telegram.org/bot{token}/{metodo}", json.dumps(datos).encode(),
                                    {"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(pedido, timeout=30) as r:
            respuesta = json.load(r)
    except urllib.error.HTTPError as e:
        respuesta = json.loads(e.read().decode() or "{}")
    if not respuesta.get("ok"):
        raise RuntimeError(respuesta.get("description", "Telegram rechazó el pedido"))
    return respuesta.get("result")


def _copiar(texto):
    try:
        import win32clipboard
        import win32con

        win32clipboard.OpenClipboard()
        try:
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardText(texto, win32con.CF_UNICODETEXT)
        finally:
            win32clipboard.CloseClipboard()
        return True
    except Exception:
        return False


def _copiar_codigo_del_bot():
    """Copia bot_celular/Codigo.gs (o lo abre en el Bloc de notas si no se puede copiar). Devuelve el aviso."""
    import subprocess

    import celular as cel

    with open(cel.CODIGO_BOT, encoding="utf-8") as f:
        copiado = _copiar(f.read())
    if not copiado:
        subprocess.Popen(["notepad.exe", cel.CODIGO_BOT])
    return ("  (Ya copié el código del bot: está listo para pegar.)" if copiado else
            "  (Te abrí el código en el Bloc de notas: Ctrl+A y Ctrl+C para copiarlo.)")


def _actualizar_solo(estado):
    """La PC sube el código nuevo y lo publica en la misma dirección (bot_celular/actualizar_mi_bot.ps1, con clasp):
    vos solo entrás con tu cuenta de Google. True si el bot ya tiene el código nuevo."""
    import os
    import re
    import subprocess

    import celular as cel

    m = re.search(r"/macros/s/([\w-]+)/exec$", keyring.get_password(cel.SERVICIO, "url") or "")
    if not (estado.get("script") and m):
        return False
    script = os.path.join(os.path.dirname(cel.CODIGO_BOT), "actualizar_mi_bot.ps1")
    try:
        r = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script,
                            "-Script", estado["script"], "-Implementacion", m.group(1)])
    except OSError as e:
        print(f"\n  No pude abrir el actualizador: {e}")
        return False
    if r.returncode != 0:
        return False
    try:
        if cel.pedir("estado").get("version") != cel.version_local():
            return False
        cel.pedir("preparar")  # relojes y comandos de Telegram al día
    except Exception:
        pass  # (ya tiene el código nuevo: los relojes se ponen al día solos con el próximo mensaje)
    return True


def actualizar_bot(estado):
    """El bot ya anda: solo hay que ponerle el código nuevo. Sin URL, token ni claves: lo hace la PC (o te guía)."""
    import re
    import time

    import celular as cel

    nueva = cel.version_local()
    actual = estado.get("version") or "vieja"
    print(f"\n  Código del bot en tu cuenta de Google: versión {actual} · el de esta PC: versión {nueva}")
    if actual == nueva:
        print("  Ya está al día: no hay nada que actualizar.")
        return
    print("""
ACTUALIZAR EL BOT (sin tocar claves)
  Lo hago yo: vos solo entrás con tu cuenta de Google (la del bot) y tocás «Permitir».
  La dirección del bot sigue siendo la misma, así que Telegram y la app siguen conectados.""")
    if input("\n  Enter = lo hago yo · M = a mano, como antes: ").strip().lower() != "m":
        if _actualizar_solo(estado):
            print("\n  ¡Listo! El bot ya tiene el código nuevo (y no hizo falta tocar ninguna clave).")
            return
        print("\n  No pude hacerlo solo, así que vamos a mano (2 minutos):")
    proyecto = (f"https://script.google.com/home/projects/{estado['script']}/edit" if estado.get("script")
                else "https://script.google.com/home")
    print(f"""
{_copiar_codigo_del_bot()}
 1. Te abro tu proyecto de Apps Script{'' if estado.get('script') else ' (abrí el que se llama «JARVIS celular»)'}.
 2. Hacé clic en el código, Ctrl+A, Ctrl+V y Ctrl+S (guardar).
 3. Arriba a la derecha: Implementar > Gestionar implementaciones > el lápiz (editar) >
    Versión: «Nueva versión» > Implementar.
    (Ojo: NO «Nueva implementación», que cambia la dirección.)
 4. Si te pide «Autorizar acceso», tocalo: tu cuenta > «Configuración avanzada» > «Ir a ...» > «Permitir».
Yo me doy cuenta solo cuando esté listo.""")
    input("\nApretá Enter para abrir el proyecto...")
    webbrowser.open(proyecto)
    print("\nEsperando que el bot tenga el código nuevo (hasta 15 minutos)...")
    fin = time.time() + 900
    pagina_desde = None  # desde cuándo contesta una página de Google en vez del bot
    avisado = False
    while time.time() < fin:
        time.sleep(5)
        try:
            if cel.pedir("estado").get("version") == nueva:
                cel.pedir("preparar")  # relojes y comandos de Telegram al día
                print("\n  ¡Listo! El bot ya tiene el código nuevo (y no hizo falta tocar ninguna clave).")
                return
            pagina_desde = None
        except Exception as e:
            # la versión nueva quedó publicada pero pide un permiso que falta aceptar: el bot no contesta hasta eso
            if "no respondió bien" not in str(e):
                continue
            pagina_desde = pagina_desde or time.time()
            if not avisado and time.time() - pagina_desde > 20:
                avisado = True
                print("""
  Tu bot ya tiene el código nuevo pero pide un permiso nuevo de Google. En el proyecto:
  arriba, en la lista de funciones (al lado de «Ejecutar»), elegí «autorizar», tocá «Ejecutar» y aceptá
  («Revisar permisos» > tu cuenta > «Configuración avanzada» > «Ir a ...» > «Permitir»). Yo sigo esperando.""")
    print("""
  Todavía no veo el código nuevo. Fijate que hayas guardado (Ctrl+S) y elegido «Nueva versión» al editar la
  implementación. Si sin querer hiciste «Nueva implementación», pegá acá su URL (termina en /exec) y la uso;
  si no, apretá Enter y probá de nuevo más tarde.""")
    url = input("\nURL nueva (o Enter): ").strip()
    if not re.match(r"^https://script\.google\.com/(?:a/[^/\s]+/)?macros/s/[\w-]+/exec$", url):
        return
    try:
        # misma clave de siempre; el bot ya tiene el token y Gemini, y apunta Telegram a la dirección nueva
        clave = keyring.get_password(cel.SERVICIO, "clave_pc")
        r = cel.pedir("configurar", url=url, clave=clave, clave_nueva=clave, zona_min=cel.zona_minutos())
    except Exception as e:
        print(f"  No pude: {e}")
        return
    keyring.set_password(cel.SERVICIO, "url", url)
    print(f"  Listo: ahora uso la dirección nueva (código versión {r.get('version') or 'vieja'}).")


def celular():
    """Conecta el bot de Telegram: JARVIS en el celular, aunque la PC esté apagada. Si ya está conectado y anda,
    ofrece actualizarle el código (sin pedir nada de nuevo)."""
    import re
    import secrets
    import time

    import celular as cel
    from cerebro_nvidia import MODELOS
    from cerebro_nvidia import clave as clave_nube

    print("=" * 62)
    print("  J.A.R.V.I.S. · En tu celular (Telegram)")
    print("=" * 62)
    estado = None
    if cel.configurado():
        try:
            estado = cel.pedir("estado")
        except Exception:
            estado = None  # no contesta (otra dirección, o la clave no coincide): se configura de nuevo
    if estado:
        print("\n  Tu bot ya está conectado y andando.")
        eleccion = input("\n  1) Actualizarle el código   2) Configurarlo de nuevo desde cero   (Enter = 1): ").strip()
        if eleccion != "2":
            actualizar_bot(estado)
            return
    print("""
Vas a tener a JARVIS en Telegram, aunque la PC esté apagada: vive gratis
en tu cuenta de Google (Apps Script) y piensa con Gemini. Puede charlar
sabiendo tus recuerdos, entender fotos, videos, PDFs y links de YouTube,
manejar pendientes y recordatorios (te avisa al celular) y leer o mandar
mails (mandar y borrar, siempre con tu OK).
Son 3 pasos, unos 5 minutos.""")
    gemini = clave_nube("gemini")
    if not gemini:
        print("\n  Primero conectá Gemini (el bot piensa con él): cerrá y ejecutá  python configurar.py gemini")
        return

    print("""
PASO 1 de 3 · Crear el bot en Telegram
 1. En Telegram buscá  @BotFather  (tiene tilde azul) y mandale  /newbot
 2. Te pide un nombre (ej: JARVIS) y un usuario que termine en "bot"
    (ej: jarvis_de_juan_bot).
 3. Te da un TOKEN (números:letras). Copialo y pegalo acá abajo.""")
    while True:
        token = getpass.getpass("\nToken del bot (no se ve al pegar): ").strip()
        try:
            bot = _telegram(token, "getMe")
            break
        except Exception as e:
            print(f"\n  No funcionó: {e}. Revisá que sea el token completo.")
        if input("¿Probar de nuevo? (s/n): ").strip().lower() != "s":
            return
    print(f"  Bot encontrado: @{bot['username']}")

    print(f"""
PASO 2 de 3 · Poner el bot en tu cuenta de Google
{_copiar_codigo_del_bot()}
    (Si ya tenías el proyecto «JARVIS celular», usá ese: pegá el código ahí y en el paso 3 hacé
    Gestionar implementaciones > lápiz > «Nueva versión», y copiá esa URL.)
 1. Te voy a abrir Google Apps Script con un proyecto nuevo.
 2. Borrá lo que tiene, pegá el código (Ctrl+V) y guardá (Ctrl+S).
    Arriba a la izquierda cambiale el nombre a "JARVIS celular".
 3. Arriba a la derecha: Implementar > Nueva implementación.
 4. En el engranaje de "Seleccionar tipo" elegí "Aplicación web".
      Ejecutar como: Yo        Quién tiene acceso: Cualquier usuario
    y tocá Implementar.
 5. Tocá "Autorizar acceso" y elegí tu cuenta. Como el bot lo hiciste
    vos, Google avisa que no está verificado: tocá "Configuración
    avanzada" > "Ir a JARVIS celular" > Permitir. (Pide Gmail para tus mails.)
 6. Copiá la "URL" de la aplicación web (termina en /exec).""")
    input("\nApretá Enter para abrir Google Apps Script...")
    webbrowser.open("https://script.google.com/home/projects/create")
    while True:
        url = input("\nPegá la URL de la aplicación web: ").strip()
        if re.match(r"^https://script\.google\.com/(?:a/[^/\s]+/)?macros/s/[\w-]+/exec$", url):
            break
        print("  Esa no parece la URL de la aplicación web (empieza con https://script.google.com/macros/s/ y")
        print("  termina en /exec). Está en Implementar > Gestionar implementaciones.")

    print("\nConfigurando el bot...")
    clave_pc = secrets.token_urlsafe(24)
    clave_webhook = secrets.token_urlsafe(24)
    codigo = str(secrets.randbelow(900000) + 100000)
    try:
        # el bot te reconoce por la clave guardada en esta PC o por el token (no hay que borrar nada a mano)
        r = cel.pedir("configurar", url=url, clave=keyring.get_password(cel.SERVICIO, "clave_pc"),
                      token=token, gemini=gemini, clave_nueva=clave_pc, clave_webhook=clave_webhook,
                      zona_min=cel.zona_minutos(), codigo=codigo, modelo=MODELOS["gemini"])
    except Exception as e:
        print(f"\n  No pude configurarlo: {e}")
        if "clave incorrecta" in str(e):
            print("  Ese bot tiene un código viejo que no reconoce el token. Pegale el código nuevo (paso 2: Ctrl+A,")
            print("  Ctrl+V, Ctrl+S y Gestionar implementaciones > lápiz > «Nueva versión») y volvé a ejecutar esto.")
        return
    keyring.set_password(cel.SERVICIO, "url", url)
    keyring.set_password(cel.SERVICIO, "clave_pc", clave_pc)
    _telegram(token, "setWebhook", url=f"{url}?k={clave_webhook}", allowed_updates=["message", "callback_query"],
              drop_pending_updates=True, max_connections=1)  # (el menú de comandos lo pone el bot solo)
    try:
        cel.pedir("subir", aplicadas=[], datos=cel.foto(), zona_min=cel.zona_minutos())
        print("  Le pasé tus recuerdos, pendientes y recordatorios.")
    except Exception as e:
        print(f"  (No pude pasarle tus datos todavía: {e}. JARVIS lo reintenta solo.)")

    if not r.get("vinculado"):
        print(f"""
PASO 3 de 3 · Vincular tu Telegram (para que te responda solo a vos)
 En Telegram buscá  @{bot['username']}  y mandale exactamente:

      /start {codigo}
""")
        print("Esperando que lo mandes (hasta 5 minutos)...")
        fin = time.time() + 300
        vinculado = False
        while time.time() < fin and not vinculado:
            time.sleep(3)
            try:
                vinculado = bool(cel.pedir("estado").get("vinculado"))
            except Exception:
                pass
        if not vinculado:
            print("  No llegó el código. Volvé a ejecutar esto cuando quieras (te da uno nuevo).")
            return
    try:
        info = _telegram(token, "getWebhookInfo")
        if info.get("last_error_message"):
            print(f"  Ojo: Telegram dice «{info['last_error_message']}» al hablar con el bot.")
    except Exception:
        pass
    print(f"""
  ¡Listo! JARVIS ya está en tu celular: escribile o mandale notas de voz
  a @{bot['username']}. Lo que hagas ahí se pasa a la PC cuando la prendés.""")


if __name__ == "__main__":
    try:
        if len(sys.argv) > 1 and sys.argv[1] == "pollinations":
            pollinations()
        elif len(sys.argv) > 1 and sys.argv[1] == "celular":
            celular()
        elif len(sys.argv) > 1 and sys.argv[1] in ("gemini", "groq", "nvidia"):
            nube(sys.argv[1])
        else:
            main()
    finally:
        input("\nApretá Enter para cerrar esta ventana.")
