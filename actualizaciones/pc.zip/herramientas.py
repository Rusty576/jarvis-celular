"""Herramientas de JARVIS: recordatorios y alarmas, clima, noticias, respuestas con internet,
control de la PC y la música, y modo juego (para que los juegos anden lo más fluido posible).
"""
import ctypes
import datetime
import html
import json
import os
import re
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

import disco

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_RECORDATORIOS = os.path.join(BASE, "recordatorios.json")
CIUDAD = ""            # vacía = la detecta sola por internet. Ej: "Montevideo" o "Buenos Aires"
PAIS_NOTICIAS = "UY"   # noticias de este país (AR, UY, MX, ES, CO, CL...)
MODO_JUEGO_AUTO = True  # activa el modo juego solo cuando detecta un juego en pantalla completa
VERIFICAR_EN_INTERNET = True  # antes de responder datos (personajes, historia...), los busca en Wikipedia
SIN_VENTANA = 0x08000000
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/130 Safari/537.36", "Accept-Language": "es-419,es;q=0.9"}
DIAS = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"]
DIAS_LINDOS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]


_internet = {"cuando": 0.0, "hay": True}


def hay_internet():
    """¿Hay conexión? (mira un servidor DNS público; el resultado vale 30 segundos)."""
    import socket

    if time.time() - _internet["cuando"] < 30:
        return _internet["hay"]
    hay = False
    for servidor in (("1.1.1.1", 53), ("8.8.8.8", 53)):
        try:
            socket.create_connection(servidor, timeout=1.5).close()
            hay = True
            break
        except OSError:
            continue
    _internet.update(cuando=time.time(), hay=hay)
    return hay


def descargar(url, timeout=10, datos=None):
    pedido = urllib.request.Request(url, data=datos, headers=UA)
    with urllib.request.urlopen(pedido, timeout=timeout) as r:
        return r.read().decode(r.headers.get_content_charset() or "utf-8", errors="replace")


def json_de(url, timeout=10):
    return json.loads(descargar(url, timeout))


def powershell(comando, timeout=15):
    r = subprocess.run(["powershell", "-NoProfile", "-Command", comando], capture_output=True, text=True,
                       timeout=timeout, creationflags=SIN_VENTANA)
    return r.stdout.strip()


def notificar(titulo, mensaje):
    """Notificación de Windows (se ve aunque JARVIS esté minimizado)."""
    try:
        from winotify import Notification

        icono = os.path.join(BASE, "interfaz", "jarvis.png")
        Notification(app_id="J.A.R.V.I.S.", title=titulo, msg=mensaje,
                     icon=icono if os.path.exists(icono) else "").show()
    except Exception:
        pass


def sin_tildes_mismo_largo(texto):
    """True si normalizar() no cambia el largo: así las posiciones sirven para el texto original."""
    return len(jarvis.normalizar(texto)) == len(texto.strip())


# =========================================================================
#  RECORDATORIOS Y ALARMAS
# =========================================================================

NUMEROS = {"un": 1, "uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7,
           "ocho": 8, "nueve": 9, "diez": 10, "once": 11, "doce": 12, "trece": 13, "catorce": 14, "quince": 15,
           "veinte": 20, "veinticinco": 25, "treinta": 30, "cuarenta": 40, "cincuenta": 50, "sesenta": 60}
UNIDADES = {"segundo": 1, "seg": 1, "minuto": 60, "min": 60, "hora": 3600, "h": 3600}

_lock = threading.Lock()
sonando = {}  # alarmas/recordatorios que están sonando ahora: id -> datos


def a_numero(s):
    s = s.strip()
    if re.fullmatch(r"\d+(?:[.,]\d+)?", s):
        return float(s.replace(",", "."))
    return NUMEROS.get(s)


DURACION = re.compile(r"\b(?:en|dentro de|de)\s+((?:(?:\d+(?:[.,]\d+)?|[a-z]+)\s+(?:segundos?|seg|minutos?|mins?|horas?|hs)"
                      r"(?:\s+y\s+media)?(?:\s+y\s+)?)+|media hora|un rato)\b")
HORA = re.compile(r"\b(?:a las?|para las?|tipo|como a las)\s+(?!(?:manana|tarde|noche|mediodia)\b)(\d{1,2}|[a-z]+)"
                  r"(?:[:.](\d{2})|\s+y\s+(media|cuarto|\d{1,2}))?"
                  r"(?:\s*(?:horas?|hrs?|hs|h)(?![a-z]))?(?:\s+(?:de la|en la|por la)\s+(manana|tarde|noche))?\b")
# "esta noche", "en la noche", "a la tarde"... sin hora: la noche son las 21, la tarde las 17 y la mañana las 9
PARTE_DEL_DIA = re.compile(r"\b(?:(?:hoy\s+)?(?:a|en|por|de)\s+la\s+(manana|tarde|noche)|esta\s+(manana|tarde|noche)|"
                           r"de\s+(noche))\b")
HORA_DE_LA_PARTE = {"manana": (9, 0), "tarde": (17, 0), "noche": (21, 0)}
DIA = re.compile(r"\b(pasado manana|manana(?! a la manana)|hoy|esta noche|esta tarde|(?:el |este )?"
                 r"(?:lunes|martes|miercoles|jueves|viernes|sabado|domingo))\b")


def segundos_de(texto):
    if "un rato" in texto:
        return 15 * 60
    total = 1800 if re.search(r"\bmedia hora\b", texto) else 0
    texto = re.sub(r"\bmedia hora\b", "", texto)
    for cantidad, unidad in re.findall(r"(\d+(?:[.,]\d+)?|[a-z]+)\s+(segundos?|seg|minutos?|mins?|horas?|hs)\b", texto):
        n = a_numero(cantidad)
        if n is not None:
            total += n * UNIDADES[unidad.rstrip("s")]
    if re.search(r"\bhoras?\s+y\s+media\b", texto):
        total += 1800
    return int(total) or None


def momento_de(texto, ahora=None, hora_si_falta=None):
    """Devuelve (datetime, [spans usados]) para 'en 20 minutos', 'mañana a las 8', 'el lunes a las 9 de la noche'...
    hora_si_falta: (h, m) para cuando dice el día pero no la hora ("para mañana", "el viernes")."""
    ahora = ahora or datetime.datetime.now()
    m = DURACION.search(texto)
    if m:
        s = segundos_de(m.group(1))
        if s:
            return ahora + datetime.timedelta(seconds=s), [m.span()]

    spans = []
    h = mi = None
    parte = None
    m = HORA.search(texto)
    if m:
        h = a_numero(m.group(1))
        if h is None:
            return None, []
        h = int(h)
        extra = m.group(3)
        mi = int(m.group(2)) if m.group(2) else 30 if extra == "media" else 15 if extra == "cuarto" else int(extra) if extra else 0
        parte = m.group(4)
        spans.append(m.span())
    elif re.search(r"\bal mediodia\b", texto):
        h, mi = 12, 0
        spans.append(re.search(r"\bal mediodia\b", texto).span())
    elif PARTE_DEL_DIA.search(texto):   # "para hoy en la noche", "esta tarde", "a la mañana"
        m = PARTE_DEL_DIA.search(texto)
        h, mi = HORA_DE_LA_PARTE[next(g for g in m.groups() if g)]
        spans.append(m.span())
    if h is None and hora_si_falta:
        d0 = DIA.search(texto)
        if d0 and d0.group(1).replace("el ", "").replace("este ", "") != "hoy":
            h, mi = hora_si_falta
    if h is None or h > 23 or mi > 59:
        return None, []

    dias = None
    d = DIA.search(texto)
    if d:
        if not any(a < d.end() and d.start() < b for a, b in spans):   # ("esta noche" ya estaba: no se saca dos veces)
            spans.append(d.span())
        palabra = d.group(1).replace("el ", "").replace("este ", "")
        if palabra == "pasado manana":
            dias = 2
        elif palabra == "manana":
            dias = 1
        elif palabra in ("hoy", "esta noche", "esta tarde"):
            dias = 0
            parte = parte or ("noche" if "noche" in palabra else "tarde" if "tarde" in palabra else None)
        elif palabra in DIAS:
            dias = (DIAS.index(palabra) - ahora.weekday()) % 7
    if parte in ("tarde", "noche") and h < 12:
        h += 12
    if parte == "manana" and h == 12:
        h = 0

    base = ahora.replace(second=0, microsecond=0)
    if dias is not None:
        cuando = (base + datetime.timedelta(days=dias)).replace(hour=h, minute=mi)
        if cuando <= ahora:
            cuando += datetime.timedelta(days=7 if d and d.group(1).replace("el ", "") in DIAS else 1)
        return cuando, spans
    # sin día: la próxima vez que sean esas horas (si dijo "a las 7" a las 10 de la mañana, son las 19)
    opciones = [base.replace(hour=h, minute=mi)]
    if h < 12 and not parte:
        opciones.append(base.replace(hour=h + 12, minute=mi))
    opciones += [o + datetime.timedelta(days=1) for o in opciones]
    return min(o for o in opciones if o > ahora), spans


def describir_momento(cuando):
    ahora = datetime.datetime.now()
    hora = f"{cuando.hour}:{cuando.minute:02d}"
    faltan = (cuando - ahora).total_seconds()
    if faltan < 3600:
        minutos = max(1, round(faltan / 60))
        return f"en {minutos} {'minuto' if minutos == 1 else 'minutos'} ({hora})"
    if cuando.date() == ahora.date():
        return f"hoy a las {hora}"
    if cuando.date() == ahora.date() + datetime.timedelta(days=1):
        return f"mañana a las {hora}"
    return f"el {DIAS_LINDOS[cuando.weekday()]} {cuando.day} a las {hora}"


def cargar_recordatorios():
    return disco.leer(ARCHIVO_RECORDATORIOS, [])


def guardar_recordatorios(lista):
    disco.guardar(ARCHIVO_RECORDATORIOS, lista, indent=2)


def agregar_recordatorio(cuando, texto, tipo, repetir=None):
    with _lock:
        lista = cargar_recordatorios()
        nuevo = {"id": int(time.time() * 1000), "cuando": cuando.isoformat(timespec="seconds"),
                 "texto": texto, "tipo": tipo}
        if repetir:  # {"tipo": "mensual", "dias": [1..10], "hora": "10:00"}: al sonar se agenda la próxima vez
            nuevo["repetir"] = repetir
        lista.append(nuevo)
        lista.sort(key=lambda r: r["cuando"])
        guardar_recordatorios(lista)
    jarvis.emitir("recordatorios", proximos())
    # verificación cruzada: se relee del disco y se anota en la lista de control
    try:
        jarvis.control.registrar("alarma" if tipo == "alarma" else "recordatorio",
                                 f"{texto or ('Alarma' if tipo == 'alarma' else 'Recordatorio')} — {describir_momento(cuando)}",
                                 lambda: any(r["id"] == nuevo["id"] for r in cargar_recordatorios()))
    except Exception:
        pass
    return nuevo


def proximos(cantidad=5):
    return [{**r, "falta": describir_momento(datetime.datetime.fromisoformat(r["cuando"]))}
            for r in cargar_recordatorios()[:cantidad]]


def limpiar_texto_recordatorio(texto, t, spans):
    """Saca de la frase las partes de tiempo ('en 20 minutos', 'mañana a las 8') y deja lo que hay que recordar."""
    fuente = texto.strip() if sin_tildes_mismo_largo(texto) else t
    for a, b in sorted(spans, reverse=True):
        fuente = fuente[:a] + " " + fuente[b:]
    fuente = re.sub(r"\s+", " ", fuente).strip(" ,.")
    # (\b: así «crear látigo virtual» no pierde el «crear» como si fuera «creá una alarma»)
    fuente = re.sub(r"(?i)^(?:(?:che|jarvis)[\s,]+)?(?:record[áa]me|recu[ée]rdame|acord[áa]me|av[íi]same|hac[ée]me acordar|"
                    r"acord[áa]te de|record[áa](?:me)? de|no me dejes olvidar(?: de| que)?|"
                    r"pon[ée]me|pon[ée]|program[áa](?:me)?|cre[áa](?:me)?|activ[áa]|configur[áa])\b\s*", "", fuente)
    fuente = re.sub(r"(?i)^(?:que me )?despert(?:[áa]me|arme)\s*", "", fuente)
    fuente = re.sub(r"(?i)^(?:bien |re |muy )?(?:temprano|tempranito)\b\s*", "", fuente)  # relleno, no es el motivo
    fuente = re.sub(r"(?i)^(?:una |la |un )?(?:alarma|despertador|temporizador|timer|recordatorio)\s*", "", fuente)
    for _ in range(3):  # "para que de llamar..." -> "llamar..." (pueden venir varias seguidas)
        fuente = re.sub(r"(?i)^(?:que|de|para|a|al|en)\s+", "", fuente).strip(" ,.")
        fuente = re.sub(r"(?i)\s+(?:para|de|a|al|en|el|la|hoy)$", "", fuente).strip(" ,.")  # "... para" (de "para hoy")
    return fuente[:1].upper() + fuente[1:] if fuente else ""


# "quiero que me recuerdes mañana X", "haceme un recordatorio para el lunes", "¿podés recordarme...?": es lo mismo que
# "recordame ...". Antes no se reconocía: la IA de la charla contestaba "Añadí recordatorio..." y no guardaba nada.
# "recordatorio crear látigo virtual", "nuevo recordatorio: ...": también (antes iba a la IA, que decía "listo" sin guardar)
PEDIDO_INDIRECTO = re.compile(
    r"^(?:(?:che|jarvis|hola|pa|dale|bueno|porfa|ey)[\s,]+)*(?:(?:quiero|necesito|preciso|podrias|podes|me podes|"
    r"me podrias|vos podes)\s+(?:que\s+)?)?(?:me\s+)?(?:recuerdes|recordes|recordas|recordarme|"
    r"(?:hagas|haces|hace|haceme|hazme|haz|crea|creame|crees|pone|poneme|pongas|agrega|agregame|anota|anotame|"
    r"programa|programame|arma|armame)\s+un\s+recordatorio|(?:un\s+|nuevo\s+)?recordatorio)"
    r"\b\s*:?\s*(?:de\s+que\s+|para\s+que\s+|que\s+|sobre\s+)?")


def como_recordame(texto, t):
    """Pasa un pedido indirecto a 'recordame ...' (en el texto original y en el normalizado, que miden lo mismo).
    Devuelve (texto, t, si_era_indirecto)."""
    m = PEDIDO_INDIRECTO.match(t)
    if not m:
        return texto, t, False
    resto_t = t[m.end():]
    resto = texto.strip()[m.end():] if sin_tildes_mismo_largo(texto) else resto_t
    return "recordame " + resto, "recordame " + resto_t, True


RECORDAR = re.compile(r"^(?:(?:che|jarvis)[\s,]+)?(?:recordame|recuerdame|acordame|avisame|haceme acordar|"
                      r"acordate de|recorda(?:me)? de|no me dejes olvidar(?: de| que)?)\b")
ALARMA = re.compile(r"^(?:(?:che|jarvis)[\s,]+)?(?:(?:poneme|pone|ponme|programa|programame|crea|creame|activa|configura)\s+)?"
                    r"(?:una |la |un |el )?(?:alarma|despertador|temporizador|timer|cuenta regresiva)\b|"
                    r"^(?:(?:che|jarvis)[\s,]+)?(?:despertame|levantame)\b|\b(?:de |que me )?desperta(?:rme|me)\b")


# ---------- Recordatorios que se repiten ----------
# "recordame del 1 al 10 de cada mes renovar el bono", "todos los días a las 8 recordame tomar la pastilla",
# "cada lunes avisame sacar la basura", "el 5 de cada mes recordame pagar la luz". Antes no existían: la IA contestaba
# "a partir de ahora te lo voy a recordar" y no se guardaba NADA.
_N = r"(\d{1,2}|[a-z]+)"
RANGO_MES = re.compile(rf"\b(?:cada |todos los )?(?:dias? )?del? {_N} al {_N} de (?:cada|todos los) mes(?:es)?\b|"
                       rf"\b(?:cada|todos los) mes(?:es)?,? (?:los dias )?del? {_N} al {_N}\b")
DIA_MES = re.compile(rf"\b(?:el|los|cada) (?:dia )?{_N} de (?:cada|todos los) mes(?:es)?\b|"
                     rf"\b(?:todos los|cada) {_N} del mes\b|\btodos los meses el (?:dia )?{_N}\b")
DIARIO = re.compile(r"\b(?:todos los dias|cada dia|diariamente|todas las (manana|tarde|noche)s)\b")
SEMANAL = re.compile(r"\b(?:todos los|cada) (lunes|martes|miercoles|jueves|viernes|sabado|domingo)s?\b")
PIDE_RECORDAR = re.compile(r"\b(?:recordame|recuerdame|recordarme|me recuerdes|me recordes|me recordas|acordame|"
                           r"avisame|me avises|haceme acordar|no me dejes olvidar)\b")


def repeticion_de(t):
    """({"tipo": "mensual"|"semanal"|"diario", "dias": [...]}, span) o (None, None)."""
    m = RANGO_MES.search(t)
    if m:
        numeros = [a_numero(x) for x in m.groups() if x]
        if len(numeros) == 2 and all(numeros) and 1 <= numeros[0] <= numeros[1] <= 31:
            return {"tipo": "mensual", "dias": list(range(int(numeros[0]), int(numeros[1]) + 1))}, m.span()
    m = DIA_MES.search(t)
    if m:
        dia = a_numero(next(x for x in m.groups() if x))
        if dia and 1 <= dia <= 31:
            return {"tipo": "mensual", "dias": [int(dia)]}, m.span()
    m = SEMANAL.search(t)
    if m:
        return {"tipo": "semanal", "dias": [DIAS.index(m.group(1))]}, m.span()
    m = DIARIO.search(t)
    if m:
        return {"tipo": "diario", "dias": [], "parte": m.group(1)}, m.span()
    return None, None


def hora_de(t, parte=None):
    """(hora, minuto) de 'a las 8', 'a las 9 de la noche'... Si no dice, a la mañana (10:00) o según 'todas las noches'."""
    m = HORA.search(t)
    if m:
        h = a_numero(m.group(1))
        if h is not None and 0 <= h <= 23:
            extra = m.group(3)
            mi = int(m.group(2)) if m.group(2) else 30 if extra == "media" else 15 if extra == "cuarto" else \
                int(extra) if extra and extra.isdigit() else 0
            h = int(h) + (12 if (m.group(4) or parte) in ("tarde", "noche") and h < 12 else 0)
            return h, min(mi, 59)
    parte = parte or next((p for p in ("manana", "tarde", "noche") if re.search(rf"\b(?:a la|por la|de la) {p}\b", t)), None)
    return {"manana": (9, 0), "tarde": (17, 0), "noche": (21, 0)}.get(parte, (10, 0))


def proxima_vez(rep, desde=None):
    desde = desde or datetime.datetime.now()
    h, mi = map(int, rep["hora"].split(":"))
    base = desde.replace(hour=h, minute=mi, second=0, microsecond=0)
    for k in range(0, 370):
        dia = base + datetime.timedelta(days=k)
        if dia <= desde:
            continue
        if rep["tipo"] == "diario" or (rep["tipo"] == "semanal" and dia.weekday() in rep["dias"]) or \
                (rep["tipo"] == "mensual" and dia.day in rep["dias"]):
            return dia
    return None


def describir_repeticion(rep):
    dias = rep.get("dias") or []
    if rep["tipo"] == "mensual":
        cuando = (f"del {dias[0]} al {dias[-1]} de cada mes" if len(dias) > 1 else f"el {dias[0]} de cada mes")
    elif rep["tipo"] == "semanal":
        cuando = "todos los " + ", ".join(DIAS_LINDOS[d] for d in dias)
    else:
        cuando = "todos los días"
    return f"{cuando} a las {rep['hora']}"


def lo_que_hay_que_recordar(t, span_repeticion):
    """'necesito que del 1 al 10 de cada mes me recuerdes que tengo que ir a renovar el bono, es decir...'
    -> 'Ir a renovar el bono'."""
    sin_rep = t[:span_repeticion[0]] + " " + t[span_repeticion[1]:]
    m = re.search(PIDE_RECORDAR.pattern + r"\s+(?:lo\s+)?(?:de\s+|que\s+)?(.+)$", sin_rep)
    resto = m.group(1) if m else sin_rep
    resto = re.split(r"\s+(?:es decir|o sea|osea|me lo|y que me|porque|asi no|cada tanto|en esos dias)\b|[.,;]", resto)[0]
    resto = HORA.sub(" ", resto)
    resto = re.sub(r"^(?:(?:que|de)\s+)?(?:tengo que|tenes que|debo|hay que)\s+", "", resto.strip())
    resto = re.sub(r"\s+", " ", resto).strip(" ,.")
    return resto[:1].upper() + resto[1:]


def manejar_repetidos(texto, t):
    """Crea un recordatorio que se repite. None si el pedido no es de eso."""
    if not PIDE_RECORDAR.search(t):
        return None
    rep, span = repeticion_de(t)
    if not rep:
        return None
    lo_que = lo_que_hay_que_recordar(t, span)
    if not lo_que or len(lo_que) < 3:
        return "¿Qué querés que te recuerde? Decímelo así: «recordame del 1 al 10 de cada mes renovar el bono»."
    h, mi = hora_de(t, rep.pop("parte", None))
    rep["hora"] = f"{h}:{mi:02d}"
    cuando = proxima_vez(rep)
    if not cuando:
        return "No encontré cuándo te lo tendría que recordar. Probá con «el 5 de cada mes» o «todos los lunes»."
    agregar_recordatorio(cuando, lo_que, "recordatorio", repetir=rep)
    return (f"Listo, te lo voy a recordar {describir_repeticion(rep)}: {lo_que}. La primera vez es "
            f"{describir_momento(cuando)}.")


def es_recordatorio(t):
    """Para que 'recordame en 20 minutos...' o 'acordate de despertarme a las 7' no se guarden como recuerdo."""
    if PEDIDO_INDIRECTO.match(t):
        return True
    if PIDE_RECORDAR.search(t) and repeticion_de(t)[0]:
        return True
    return bool((RECORDAR.match(t) or ALARMA.search(t)) and momento_de(t)[0])


def manejar_recordatorios(texto, t):
    # --- Ver ---
    if re.search(r"\b(?:que|cuales|mis)\s+(?:recordatorios|alarmas|pendientes)\b|que tengo pendiente|"
                 r"tengo (?:alguna |algun )?(?:alarma|recordatorio)", t):
        lista = proximos(10)
        if not lista:
            return "No tenés recordatorios ni alarmas pendientes."
        lineas = [f"- {'Alarma' if r['tipo'] == 'alarma' else 'Recordatorio'} {r['falta']}"
                  + (f": {r['texto']}" if r["texto"] else "")
                  + (f" (se repite {describir_repeticion(r['repetir'])})" if r.get("repetir") else "") for r in lista]
        return f"Tenés {len(lista)} pendientes:\n" + "\n".join(lineas)

    # --- Borrar ---
    m = re.match(r"^(?:borra|borrame|cancela|cancelame|elimina|saca|quita|apaga)\s+(?:el |la |los |las |todos los |todas las )?"
                 r"(recordatorios?|alarmas?|temporizador(?:es)?)(?:\s+(?:de|del|para|que|a)\s+(.+))?$", t)
    if m:
        tipo = "alarma" if m.group(1).startswith(("alarma", "temporizador")) else "recordatorio"
        with _lock:
            lista = cargar_recordatorios()
            del_tipo = [r for r in lista if r["tipo"] == tipo]
            if "todos" in t or "todas" in t:
                borrar = del_tipo
            elif m.group(2):
                clave = m.group(2)
                borrar = [r for r in del_tipo if r["texto"] and clave in jarvis.normalizar(r["texto"])]
                if not borrar:  # "la alarma de las 7": busca por hora (7:00 o 19:00)
                    hora = re.search(r"(\d{1,2})(?:[:.](\d{2}))?", clave)
                    if hora:
                        h, mi = int(hora.group(1)), int(hora.group(2) or 0)
                        validas = {f"{h:02d}:{mi:02d}", f"{(h + 12) % 24:02d}:{mi:02d}"}
                        borrar = [r for r in del_tipo if r["cuando"][11:16] in validas]
            else:
                borrar = del_tipo[:1] if len(del_tipo) == 1 else []
                if len(del_tipo) > 1:
                    return f"Tenés {len(del_tipo)} {tipo}s. Decime cuál, por ejemplo: cancelá la {tipo} de las 7."
            if not borrar:
                return f"No encontré esa {tipo}." if tipo == "alarma" else "No encontré ese recordatorio."
            ids = {r["id"] for r in borrar}
            guardar_recordatorios([r for r in lista if r["id"] not in ids])
        jarvis.emitir("recordatorios", proximos())
        return f"Listo, borré {len(borrar)} {tipo}{'s' if len(borrar) > 1 else ''}." if len(borrar) > 1 else \
            f"Listo, borré {'la alarma' if tipo == 'alarma' else 'el recordatorio'}."

    # "quiero que me recuerdes...", "haceme un recordatorio...": se lee como "recordame ..."
    texto, t = re.sub(r"\s+", " ", texto).strip(), re.sub(r"\s+", " ", t).strip()   # "a  las 20" (dos espacios)
    texto, t, indirecto = como_recordame(texto, t)

    # --- Crear uno que se repite ("del 1 al 10 de cada mes", "todos los lunes", "todos los días a las 8") ---
    respuesta = manejar_repetidos(texto, t)
    if respuesta is not None:
        return respuesta

    # --- Crear ---
    es_alarma = bool(ALARMA.match(t) or re.search(r"\bdesperta(?:rme|me)\b", t))
    if not (es_alarma or RECORDAR.match(t)):
        return None
    # "temporizador de 5 minutos" -> "temporizador en 5 minutos" (mismo largo, así las posiciones siguen sirviendo)
    t_tiempo = re.sub(r"\b(temporizador|timer|cuenta regresiva)(\s+)de\b", r"\1\2en", t)
    cuando, spans = momento_de(t_tiempo)
    sin_hora = False
    if not cuando and not es_alarma:  # "recordame para mañana comprar pan": el día sí, la hora no -> a las 9
        cuando, spans = momento_de(t_tiempo, hora_si_falta=(9, 0))
        sin_hora = cuando is not None
    if not cuando:
        if RECORDAR.match(t) and not es_alarma and not indirecto:
            return None  # "recordame que..." sin hora: es un recuerdo común (lo maneja main.py)
        if es_alarma:
            return "¿Para qué hora? Por ejemplo: poneme una alarma a las 7, o en 10 minutos."
        # pidió un recordatorio pero falta qué o cuándo: se pregunta (nunca se inventa) y la respuesta completa la orden
        lo_que = limpiar_texto_recordatorio(texto, t, [])
        if not lo_que:
            jarvis.esperar_complemento("recordame")
            return "Dale. ¿Qué querés que te recuerde y para cuándo? Por ejemplo: «mañana a las 9 llamar al dentista»."
        jarvis.esperar_complemento(f"recordame {lo_que}")
        return f"¿Para cuándo te recuerdo «{lo_que}»? Por ejemplo: mañana a las 9, o el viernes a la tarde."
    lo_que = limpiar_texto_recordatorio(texto, t, spans)
    if es_alarma and t_tiempo != t:
        lo_que = lo_que or "Terminó el temporizador"
    tipo = "alarma" if es_alarma else "recordatorio"
    if tipo == "recordatorio" and not lo_que:
        return "¿Qué querés que te recuerde?"
    agregar_recordatorio(cuando, lo_que, tipo)
    if tipo == "alarma":
        return f"Listo, alarma {describir_momento(cuando)}" + (f": {lo_que}." if lo_que else ".")
    if sin_hora:
        return f"Listo, te lo recuerdo {describir_momento(cuando)} (no me dijiste la hora): {lo_que}."
    return f"Listo, te lo recuerdo {describir_momento(cuando)}: {lo_que}."


def disparar(r):
    """Suena / avisa un recordatorio que llegó a su hora."""
    cuando = datetime.datetime.fromisoformat(r["cuando"])
    atraso = (datetime.datetime.now() - cuando).total_seconds()
    titulo = "Alarma" if r["tipo"] == "alarma" else "Recordatorio"
    if atraso > 15 * 60:  # pasó con la compu apagada o JARVIS cerrado
        jarvis.aviso(f"Mientras no estaba encendido se pasó este {titulo.lower()} ({cuando:%d/%m %H:%M}): {r['texto'] or titulo}")
        notificar(f"{titulo} perdido", r["texto"] or f"{cuando:%d/%m %H:%M}")
        return
    sonando[r["id"]] = r
    jarvis.emitir("alarma", {"id": r["id"], "tipo": r["tipo"], "texto": r["texto"], "hora": f"{cuando:%H:%M}"})
    notificar(f"J.A.R.V.I.S. · {titulo}", r["texto"] or f"Son las {cuando:%H:%M}")
    frase = f"Te recuerdo: {r['texto']}." if r["tipo"] == "recordatorio" else \
        f"Alarma. Son las {cuando.hour}:{cuando.minute:02d}." + (f" {r['texto']}." if r["texto"] else "")
    threading.Thread(target=_hacer_sonar, args=(r, frase), daemon=True).start()


def _hacer_sonar(r, frase):
    """Las alarmas suenan hasta que digas 'listo' / 'posponé' (máximo 1 minuto). Los recordatorios, una vez."""
    jarvis.sonar("alarma")
    time.sleep(1.2)
    jarvis.hablar(frase, threading.Event())
    if r["tipo"] == "recordatorio":
        time.sleep(20)
        terminar_alarma(r["id"], "visto")
        return
    fin = time.time() + 60
    while r["id"] in sonando and time.time() < fin:
        jarvis.espera_orden_hasta = time.time() + 4  # podés decir "listo" sin decir "Jarvis"
        jarvis.sonar("alarma")
        time.sleep(2.5)
    terminar_alarma(r["id"], "sin respuesta")


def terminar_alarma(id_, estado):
    if sonando.pop(id_, None) is not None:
        jarvis.emitir("alarma_fin", {"id": id_, "estado": estado})


def parar_alarmas():
    for id_ in list(sonando):
        terminar_alarma(id_, "apagada")


def responder_alarma(t):
    """Si hay algo sonando: 'listo/apagala/ya' la apaga, 'posponé (5 minutos)' la repite más tarde."""
    if not sonando:
        return None
    t = t.strip(" ,.!¿?¡")
    m = re.search(r"\b(?:pospon\w*|snooze|despues|mas tarde|(\d+|[a-z]+) minutos? mas|en (\d+|[a-z]+) minutos?)\b", t)
    if m or t.startswith("pospon"):
        minutos = a_numero(m.group(1) or m.group(2) or "") if m and (m.group(1) or m.group(2)) else None
        n = re.search(r"(\d+|[a-z]+)\s+minutos?", t)
        minutos = minutos or (a_numero(n.group(1)) if n else None) or 10
        for id_, r in list(sonando.items()):
            agregar_recordatorio(datetime.datetime.now() + datetime.timedelta(minutes=minutos), r["texto"], r["tipo"])
            terminar_alarma(id_, "pospuesta")
        return f"Listo, te aviso de nuevo en {int(minutos)} minutos."
    if len(t.split()) <= 4 and re.search(r"\b(?:listo|ya|ok|okay|apaga\w*|para\w*|basta|silencio|chau|gracias|"
                                         r"me levante|desperte|entendido|dale|corta\w*|frena\w*)\b", t):
        parar_alarmas()
        return "Listo, alarma apagada."
    return None


def _bucle_recordatorios():
    while True:
        try:
            ahora = datetime.datetime.now()
            with _lock:
                lista = cargar_recordatorios()
                vencidos = [r for r in lista if datetime.datetime.fromisoformat(r["cuando"]) <= ahora]
                if vencidos:
                    ids = {r["id"] for r in vencidos}
                    quedan = [r for r in lista if r["id"] not in ids]
                    for r in vencidos:  # los que se repiten vuelven a la lista, para la próxima vez
                        siguiente = proxima_vez(r["repetir"], ahora) if r.get("repetir") else None
                        if siguiente:
                            quedan.append({**r, "cuando": siguiente.isoformat(timespec="seconds")})
                    quedan.sort(key=lambda r: r["cuando"])
                    guardar_recordatorios(quedan)
            for r in vencidos:
                disparar(r)
            if vencidos:
                jarvis.emitir("recordatorios", proximos())
        except Exception:
            pass
        time.sleep(1)


# =========================================================================
#  CLIMA
# =========================================================================

CLIMA_CODIGOS = {0: "despejado", 1: "mayormente despejado", 2: "parcialmente nublado", 3: "nublado", 45: "con niebla",
                 48: "con niebla", 51: "con llovizna débil", 53: "con llovizna", 55: "con llovizna intensa",
                 56: "con llovizna helada", 57: "con llovizna helada", 61: "con lluvia débil", 63: "con lluvia",
                 65: "con lluvia fuerte", 66: "con lluvia helada", 67: "con lluvia helada", 71: "con nevadas débiles",
                 73: "con nieve", 75: "con nevadas fuertes", 77: "con granizo fino", 80: "con chaparrones",
                 81: "con chaparrones fuertes", 82: "con chaparrones muy fuertes", 85: "con nevadas", 86: "con nevadas",
                 95: "con tormentas", 96: "con tormentas y granizo", 99: "con tormentas fuertes y granizo"}
_ubicacion = None


def geocodificar(nombre):
    r = json_de("https://geocoding-api.open-meteo.com/v1/search?count=1&language=es&name=" + urllib.parse.quote(nombre))
    if not r.get("results"):
        return None
    x = r["results"][0]
    return x["name"], x["latitude"], x["longitude"]


def ubicacion_actual():
    global _ubicacion
    if _ubicacion:
        return _ubicacion
    if CIUDAD:
        _ubicacion = geocodificar(CIUDAD)
    if not _ubicacion:
        try:
            d = json_de("https://ipinfo.io/json", 6)
            lat, lon = (float(x) for x in d["loc"].split(","))
            _ubicacion = (d.get("city") or "tu zona", lat, lon)
        except Exception:
            _ubicacion = ("Montevideo", -34.90, -56.19)
    return _ubicacion


PIDE_CLIMA = re.compile(r"\b(?:clima|pronostico|temperatura|cuantos grados|que tiempo (?:hace|va a hacer)|"
                        r"como (?:esta|va a estar|viene) el tiempo|(?:va a|va a) llover|llueve|llovera|lluvia|"
                        r"hace (?:calor|frio)|va a hacer (?:calor|frio)|necesito paraguas|llevo paraguas)\b")


def manejar_clima(texto, t):
    if not PIDE_CLIMA.search(t):
        return None
    if re.search(r"\b(?:programa|codigo|codificalo|script|app|aplicacion|funcion|pagina web|bot|python|javascript|"
                 r"proyecto|ejercicio|que me (?:diga|muestre))\b", t):
        return None  # "haceme un programa en Python que me diga el clima" es código (antes: "no encontré la ciudad python")
    temporales = r"(?:hoy|manana|pasado manana|ahora|esta semana|la semana|el fin de semana|el finde|esta noche|esta tarde)"
    lugar = None
    m = re.search(rf"\ben\s+(?!la semana|el fin)([a-z][a-z .]+?)(?:\s+{temporales})?\s*\??$", t)
    if m and m.group(1).strip() not in ("casa", "la calle", "la ciudad"):
        lugar = m.group(1).strip()
    try:
        if lugar:
            ubic = geocodificar(lugar)
            if not ubic:
                return f"No encontré la ciudad {lugar}."
        else:
            ubic = ubicacion_actual()
        nombre, lat, lon = ubic
        d = json_de(f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
                    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m"
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                    "&timezone=auto&forecast_days=7")
    except Exception as e:
        return f"No pude consultar el clima: {e}"

    dia = d["daily"]
    fechas = [datetime.date.fromisoformat(x) for x in dia["time"]]

    def resumen_dia(i, nombre_dia):
        lluvia = dia["precipitation_probability_max"][i] or 0
        return (f"{nombre_dia} {CLIMA_CODIGOS.get(dia['weather_code'][i], '')}, máxima de "
                f"{round(dia['temperature_2m_max'][i])} y mínima de {round(dia['temperature_2m_min'][i])} grados"
                f", con {lluvia}% de probabilidad de lluvia")

    if re.search(r"\b(?:semana|pronostico extendido|proximos dias)\b", t):
        lineas = [f"- {DIAS_LINDOS[f.weekday()].capitalize()} {f.day}: {CLIMA_CODIGOS.get(dia['weather_code'][i], '')}, "
                  f"{round(dia['temperature_2m_min'][i])}° a {round(dia['temperature_2m_max'][i])}°, "
                  f"lluvia {dia['precipitation_probability_max'][i] or 0}%" for i, f in enumerate(fechas)]
        return f"Pronóstico para {nombre}:\n" + "\n".join(lineas)

    if re.search(r"\b(?:fin de semana|finde)\b", t):
        indices = [i for i, f in enumerate(fechas) if f.weekday() >= 5][:2]
        return f"En {nombre} el fin de semana: " + "; ".join(
            resumen_dia(i, DIAS_LINDOS[fechas[i].weekday()].capitalize()) for i in indices) + "."

    i = 2 if "pasado manana" in t else 1 if re.search(r"\bmanana\b", t) else 0
    for n, nombre_dia in enumerate(DIAS):
        if re.search(rf"\b(?:el )?{nombre_dia}\b", t):
            i = next((k for k, f in enumerate(fechas) if f.weekday() == n), i)
    cuando = ["Hoy", "Mañana", "Pasado mañana"][i] if i < 3 else f"El {DIAS_LINDOS[fechas[i].weekday()]}"

    if re.search(r"\b(?:llover|llueve|llovera|lluvia|paraguas)\b", t):
        p = dia["precipitation_probability_max"][i] or 0
        veredicto = ("Sí, es muy probable que llueva" if p >= 70 else "Puede llover" if p >= 40
                     else "Es poco probable que llueva" if p >= 15 else "No, no se espera lluvia")
        consejo = " Llevá paraguas." if p >= 40 else ""
        return f"{veredicto} {cuando.lower()} en {nombre}: {p}% de probabilidad.{consejo}"

    texto_dia = resumen_dia(i, cuando)
    if i == 0:
        c = d["current"]
        return (f"Ahora en {nombre} hay {round(c['temperature_2m'])} grados, "
                f"{CLIMA_CODIGOS.get(c['weather_code'], '')}, con sensación térmica de {round(c['apparent_temperature'])}. "
                f"{texto_dia}.")
    return f"{texto_dia} en {nombre}."


# =========================================================================
#  NOTICIAS
# =========================================================================

def manejar_noticias(texto, t):
    if not re.search(r"\b(?:noticias|novedades|titulares)\b", t) or re.search(r"\b(?:busca|abri)\b.*google", t):
        return None
    m = re.search(r"\b(?:noticias|novedades|titulares)\s+(?:de|sobre|del|acerca de)\s+(.+?)\s*\??$", t)
    tema = m.group(1) if m and m.group(1) not in ("hoy", "ahora", "el dia") else None
    idioma = f"hl=es-419&gl={PAIS_NOTICIAS}&ceid={PAIS_NOTICIAS}:es-419"
    url = (f"https://news.google.com/rss/search?q={urllib.parse.quote(tema)}&{idioma}" if tema
           else f"https://news.google.com/rss?{idioma}")
    try:
        items = ET.fromstring(descargar(url)).findall("./channel/item")[:6]
    except Exception as e:
        return f"No pude traer las noticias: {e}"
    if not items:
        return "No encontré noticias sobre eso."
    lineas = []
    for i, it in enumerate(items, 1):
        titulo = html.unescape(it.findtext("title") or "")
        fuente = ""
        if " - " in titulo:
            titulo, fuente = titulo.rsplit(" - ", 1)
        lineas.append(f"{i}. {titulo}" + (f" ({fuente})" if fuente else ""))
    return (f"Últimas noticias sobre {tema}:\n" if tema else "Estas son las últimas noticias:\n") + "\n".join(lineas)


# =========================================================================
#  RESPUESTAS CON INTERNET
# =========================================================================

_buscador_bloqueado = [0.0]  # hasta cuándo DuckDuckGo nos frenó por "demasiadas búsquedas"


def buscar_web(consulta, cantidad=6):
    if time.time() < _buscador_bloqueado[0]:
        raise RuntimeError("el buscador me frenó un rato por hacer muchas búsquedas seguidas")
    pagina = descargar("https://html.duckduckgo.com/html/", 10,
                       urllib.parse.urlencode({"q": consulta, "kl": "xl-es"}).encode())
    if "anomaly" in pagina.lower() and "result__a" not in pagina:
        _buscador_bloqueado[0] = time.time() + 600  # se le pasa solo en unos minutos
        raise RuntimeError("el buscador me frenó un rato por hacer muchas búsquedas seguidas")
    resultados = []
    patron = re.compile(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</a>', re.S)
    for href, titulo, resumen in patron.findall(pagina):
        if "uddg=" in href:
            href = urllib.parse.unquote(urllib.parse.parse_qs(urllib.parse.urlparse(href).query).get("uddg", [href])[0])
        if "duckduckgo.com/y.js" in href:  # publicidad
            continue
        limpio = lambda s: html.unescape(re.sub(r"<[^>]+>", "", s)).strip()  # noqa: E731
        resultados.append({"url": href, "titulo": limpio(titulo), "resumen": limpio(resumen)})
        if len(resultados) >= cantidad:
            break
    return resultados


def texto_de_pagina(url, largo=3000):
    try:
        crudo = descargar(url, 6)
    except Exception:
        return ""
    crudo = re.sub(r"(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\1>", " ", crudo)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", crudo))).strip()[:largo]


def dominio(url):
    return urllib.parse.urlparse(url).netloc.replace("www.", "")


# ---------- Leer un documento desde un link (Google Docs, Drive, PDF, Word, una nota de un diario...) ----------

MAX_DESCARGA = 25 * 1024 * 1024
TIPOS_OFFICE = {"application/pdf": ".pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx"}


class LinkPrivado(Exception):
    pass


def _bajar(url, timeout=20):
    """(bytes, content-type, nombre de archivo, url final). Si Google pide iniciar sesión, el documento es privado."""
    pedido = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(pedido, timeout=timeout) as r:
        final = r.geturl()
        if "accounts.google.com" in final or "ServiceLogin" in final:
            raise LinkPrivado()
        datos = r.read(MAX_DESCARGA + 1)
        tipo = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        disposicion = r.headers.get("Content-Disposition") or ""
    nombre = ""
    m = re.search(r"filename\*=UTF-8''([^;]+)", disposicion) or re.search(r'filename="?([^";]+)"?', disposicion)
    if m:
        nombre = urllib.parse.unquote(m.group(1))
    return datos, tipo, nombre, final


def _texto_de_html(crudo):
    """El texto de una página, con sus párrafos y títulos (sin menús, publicidad ni scripts). (título, texto)"""
    titulo = ""
    m = (re.search(r'(?is)<meta[^>]+property="og:title"[^>]+content="([^"]+)"', crudo)
         or re.search(r"(?is)<title[^>]*>(.*?)</title>", crudo))
    if m:
        titulo = re.sub(r"\s+", " ", html.unescape(m.group(1))).strip()
    crudo = re.sub(r"(?is)<(script|style|noscript|svg|header|footer|nav|aside|form|button|iframe)[^>]*>.*?</\1>", " ", crudo)
    crudo = re.sub(r"(?is)<!--.*?-->", " ", crudo)
    # lo principal: <article> o <main>, si tiene texto suficiente
    for etiqueta in ("article", "main"):
        partes = re.findall(rf"(?is)<{etiqueta}[^>]*>(.*?)</{etiqueta}>", crudo)
        principal = max(partes, key=len) if partes else ""
        if len(re.sub(r"<[^>]+>", "", principal)) > 800:
            crudo = principal
            break
    crudo = re.sub(r"(?i)<br\s*/?>", "\n", crudo)
    crudo = re.sub(r"(?i)<li[^>]*>", "\n- ", crudo)
    crudo = re.sub(r"(?i)<h[1-6][^>]*>", "\n\n## ", crudo)
    crudo = re.sub(r"(?i)</(?:p|div|h[1-6]|li|tr|section|blockquote)>", "\n", crudo)
    texto = html.unescape(re.sub(r"<[^>]+>", " ", crudo))
    lineas = [re.sub(r"[ \t\xa0]+", " ", l).strip() for l in texto.split("\n")]
    texto = re.sub(r"\n{3,}", "\n\n", "\n".join(lineas)).strip()
    return titulo, re.sub(r"(?m)^## \s*$\n?", "", texto)


def leer_url(url):
    """Lee un documento o una página desde su link. Devuelve {"titulo", "texto"} o {"error"}.
    - Google Docs / Presentaciones / Hojas: se bajan como texto (la página del editor no tiene el texto adentro).
    - Google Drive, PDF, Word, Excel, PowerPoint: se bajan y se leen como si los arrastraras a la ventana.
    - Una página común (una nota, un artículo, Wikipedia): su texto principal, sin menús."""
    import tempfile

    google = re.search(r"docs\.google\.com/(document|presentation|spreadsheets)/d/([\w-]{20,})", url)
    drive = re.search(r"drive\.google\.com/(?:file/d/|open\?id=|uc\?(?:\S*&)?id=)([\w-]{20,})", url)
    try:
        if google:
            clase, id_ = google.groups()
            if clase == "document":
                destino = f"https://docs.google.com/document/d/{id_}/export?format=txt"
            elif clase == "presentation":
                destino = f"https://docs.google.com/presentation/d/{id_}/export/txt"
            else:
                gid = re.search(r"[#&?]gid=(\d+)", url)
                destino = f"https://docs.google.com/spreadsheets/d/{id_}/export?format=csv" + (f"&gid={gid.group(1)}" if gid else "")
            datos, tipo, nombre, _ = _bajar(destino)
            if tipo == "text/html":  # en vez del archivo devolvió una página: casi siempre es que es privado
                raise LinkPrivado()
            texto = datos.decode("utf-8-sig", errors="replace")
            return {"titulo": os.path.splitext(nombre)[0] or "Documento de Google", "texto": texto.strip()}
        if drive:
            datos, tipo, nombre, _ = _bajar(f"https://drive.usercontent.google.com/download?id={drive.group(1)}"
                                           "&export=download&confirm=t")
            if tipo == "text/html" and b"accounts.google.com" in datos[:20000]:
                raise LinkPrivado()
        else:
            datos, tipo, nombre, final = _bajar(url)
            nombre = nombre or os.path.basename(urllib.parse.urlparse(final).path)
    except LinkPrivado:
        return {"error": "el documento es privado: en Google tocá Compartir > Acceso general > «Cualquier persona con "
                         "el enlace», y pasame el link de nuevo"}
    except urllib.error.HTTPError as e:
        return {"error": "el documento es privado o pide iniciar sesión" if e.code in (401, 403)
                         else "esa página no existe" if e.code == 404 else f"la página respondió error {e.code}"}
    except Exception as e:
        return {"error": f"no pude abrir el link ({e.__class__.__name__})"}
    if len(datos) > MAX_DESCARGA:
        return {"error": "el archivo es demasiado grande (más de 25 MB)"}

    ext = TIPOS_OFFICE.get(tipo) or next((e for e in (".pdf", ".docx", ".xlsx", ".pptx") if nombre.lower().endswith(e)), "")
    if ext:  # se guarda un momento en un archivo temporal y se lee igual que un adjunto
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as f:
            f.write(datos)
        try:
            texto, aviso = jarvis.adjuntos.leer_texto(f.name)
        finally:
            os.remove(f.name)
        if not texto:
            return {"error": aviso or "el archivo no tiene texto"}
        return {"titulo": os.path.splitext(nombre)[0] or "Documento", "texto": texto, "aviso": aviso}
    if tipo.startswith("text/html") or datos[:500].lstrip().lower().startswith((b"<!doctype", b"<html")):
        titulo, texto = _texto_de_html(datos.decode("utf-8", errors="replace"))
        if len(texto) < 200:
            return {"error": "la página casi no tiene texto (puede que arme su contenido con programas o pida iniciar sesión)"}
        return {"titulo": titulo or dominio(url), "texto": texto}
    if tipo.startswith("text/") or tipo in ("application/json", "application/xml", "text/csv"):
        return {"titulo": nombre or dominio(url), "texto": datos.decode("utf-8-sig", errors="replace").strip()}
    return {"error": f"es un tipo de archivo que no sé leer ({tipo or 'desconocido'})"}


def responder_web(pregunta):
    jarvis.emitir("detalle", "Buscando en internet...")
    try:
        resultados = buscar_web(pregunta)
    except Exception as e:
        return f"No pude buscar en internet: {e}"
    if not resultados:
        return "No encontré nada en internet sobre eso."
    jarvis.emitir("detalle", f"Leyendo {dominio(resultados[0]['url'])}...")
    with ThreadPoolExecutor(2) as ex:
        paginas = list(ex.map(lambda r: texto_de_pagina(r["url"]), resultados[:2]))
    material = "\n\n".join(f"[{dominio(r['url'])}] {r['titulo']}: {r['resumen']}" for r in resultados)
    material += "".join(f"\n\nTexto de {dominio(r['url'])}: {p}" for r, p in zip(resultados, paginas) if p)
    ahora = datetime.datetime.now()
    jarvis.emitir("detalle", "Armando la respuesta...")
    r = jarvis.chat_modelo([
        {"role": "system", "content": f"Hoy es {DIAS_LINDOS[ahora.weekday()]} {ahora:%d/%m/%Y}. Respondé la pregunta en "
                                      "español rioplatense, en 2 a 4 oraciones, usando SOLO la información de internet "
                                      "que te paso. Si no alcanza o se contradice, decilo. No inventes datos ni uses emojis."},
        {"role": "user", "content": f"Pregunta: {pregunta}\n\nInformación de internet:\n{material[:9000]}"}],
        temperature=0.2, num_predict=450)
    fuentes = ", ".join(dict.fromkeys(dominio(r["url"]) for r in resultados[:3]))
    return r["message"]["content"].strip() + f"\n\nFuentes: {fuentes}"


BUSCAR = re.compile(r"^(?:(?:che|jarvis)[\s,]+)?(?:busca|buscame|buscar|investiga|investigame|averigua|averiguame|"
                    r"fijate(?: en internet)?|consulta)\s+(?:en (?:internet|la web)\s+)?(?:sobre\s+|acerca de\s+)?(.+)$")
ACTUAL = re.compile(r"\b(?:hoy|ayer|anoche|ahora mismo|actual(?:mente)?|ultim[oa]s?|reciente(?:mente)?|esta semana|"
                    r"este (?:mes|ano)|20[2-3]\d|precio|cuesta|cuanto sale|cotizacion|dolar|euro|bitcoin|resultado|"
                    r"gano|perdio|salio|estreno|elecciones|quien es el presidente|partido de|como salio|que paso con)\b")
PREGUNTA = re.compile(r"^(?:(?:che|jarvis|y|a|en|de|para|por|con)[\s,]+)?"
                      r"(?:que|quien|quienes|cuando|cuanto|cuanta|cuantos|como|donde|cual|cuales|hay|esta|sabes|"
                      r"decime|contame)\b")
NO_SABE = re.compile(r"no tengo (?:acceso|informacion (?:actualizada|en tiempo real|reciente)|forma de saber)|"
                     r"no estoy seguro|podes buscarlo|busca(?:lo|r)? en internet|consulta(?:lo|r)? en (?:internet|google)|"
                     r"no puedo (?:acceder|buscar|navegar|saber)|(?:mi|mis) (?:conocimientos?|datos) (?:llega|llegan|"
                     r"esta|estan) hasta|fecha de corte|no tengo datos actualizados|te recomiendo (?:buscar|consultar) en")


PROMPT_BUSQUEDA = (
    "Sos la parte de JARVIS que arma búsquedas en internet. Con la charla reciente, escribí UNA pregunta clara y "
    "completa, en español, de 4 a 15 palabras, con lo que el usuario quiere averiguar. Si el pedido es vago "
    "(«de las pilas», «eso», «lo de antes»), completalo con el tema del que venían hablando. Corregí errores de dictado "
    "(por ejemplo «conatos volt» es «cuántos volts»). No agregues cosas que no pidió. Respondé SOLO la pregunta.")


def consulta_para_buscar(pedido):
    """Lo que hay que buscar de verdad: sin insultos, con el tema de la charla si el pedido es vago y con los errores
    de dictado arreglados. Antes "busca de las pilas mogolico" (hablando de la pila electroquímica) buscó "Las Pilas"
    y contestó sobre un sitio arqueológico de México; "busca conatos volt..." respondió "Sí, conatos volt puede..."."""
    limpio = jarvis.sin_insultos(jarvis.normalizar(pedido)) or pedido
    if modo_juego.is_set():
        return limpio
    try:
        with jarvis.lock:
            recientes = [m for m in jarvis.historial[-6:] if m.get("role") in ("user", "assistant")]
        charla = "\n".join(("Usuario: " if m["role"] == "user" else "JARVIS: ") + re.sub(r"\s+", " ", m["content"])[:240]
                           for m in recientes)
        r = jarvis.chat_modelo([
            {"role": "system", "content": PROMPT_BUSQUEDA},
            {"role": "user", "content": (f"Charla reciente:\n{charla}\n\n" if charla else "") + f"Pedido: {limpio}"}],
            temperature=0.0, num_predict=60)
        nueva = r["message"]["content"].strip().splitlines()[0].strip(" \"'«»")
        if 2 <= len(nueva.split()) <= 22:
            return nueva
    except Exception:
        pass
    return limpio


def manejar_investigacion(texto, t):
    """«investigá a fondo X», «haceme un informe con fuentes sobre X»: varias búsquedas, lee y cita (investigacion.py)."""
    return jarvis.investigacion.manejar(texto, t)


def manejar_busqueda(texto, t):
    """'buscá X', 'averiguá X': busca en internet y responde (no abre el navegador)."""
    if re.search(r"\ben (?:google|youtube|tiktok|spotify)\b", t):
        return None  # "buscá en Google X" sigue abriendo el navegador
    m = BUSCAR.match(t)
    if not m:
        return None
    consulta = jarvis.parte_original(texto, m.start(1)) or m.group(1)
    consulta = consulta_para_buscar(consulta)
    jarvis.emitir("detalle", f"Busco: {consulta}")
    return responder_web(consulta)


# Lo tuyo (tus mails, tu agenda, tus fechas, tus pendientes) no se busca en internet: antes "¿cuáles son las fechas
# importantes que tengo este mes?" devolvía efemérides de un canal de TV de México y "mi gmail fijate" buscó en Google
PERSONAL = re.compile(r"\b(?:tengo|tenemos|tenia|mis|mi (?:agenda|calendario|correo|mail|gmail|celular|compu|pc)|"
                      r"agenda\w*|recordatorios?|pendientes?|me (?:toca|tocan|pediste|dijiste)|"
                      r"mails?|correos?|gmail|e-?mails?)\b")


def es_personal(t):
    return bool(PERSONAL.search(t))


def web_si_corresponde(texto, t):
    """Preguntas sobre cosas actuales ('¿quién ganó ayer?', '¿a cuánto está el dólar?') van a internet."""
    t = t.strip(" ¿?¡!.,")
    if PREGUNTA.match(t) and ACTUAL.search(t) and len(t.split()) >= 3 and not SOBRE_LA_CHARLA.search(t) \
            and not A_JARVIS.search(t) and not es_personal(t) and not SOBRE_JARVIS.search(t):
        return responder_web(texto.strip())
    return None


# Lo que es de JARVIS mismo, de sus apps o de lo que le mandaste (su botón, la app, el celular, el bot, su código): eso
# no está en internet. Antes «pasame el registro que te mandé al celu» buscaba en Google y contestaba con Scribd
SOBRE_JARVIS = re.compile(r"\b(?:tu (?:boton|interfaz|pantalla|ventana|codigo|voz|app|aplicacion|memoria|cerebro)|"
                          r"(?:el|ese|este) boton|la app|tu app|(?:al|del|en el|el) (?:celu|celular|telefono)|"
                          r"telegram|el bot|registro que|lo que te (?:mande|pase|envie|dije|conte))\b")


def pregunta_del_mundo(pregunta):
    """¿Es una pregunta sobre algo del mundo (que se puede buscar en internet)? Para el «no sé, lo busco»: si la IA no
    sabía algo TUYO, de JARVIS o de la charla, buscarlo en Google solo traía cualquier cosa."""
    t = jarvis.normalizar(pregunta).strip(" ¿?¡!.,")
    if len(t.split()) < 3 or SOBRE_JARVIS.search(t) or SOBRE_LA_CHARLA.search(t) or A_JARVIS.search(t) or es_personal(t):
        return False
    if getattr(jarvis, "habla_de_lo_que_paso", None) and jarvis.habla_de_lo_que_paso(t):
        return False
    if jarvis.memoria.sabe_de(pregunta):   # de eso ya sabe por tus recuerdos (tu proyecto, tu familia...)
        return False
    if SE_RESUELVE_SOLO.search(t):   # consejos, ideas, cuentas, redactar: se piensan, no se buscan
        return False
    propios = nombres_propios(pregunta)
    if any(jarvis.memoria.es_nombre_conocido(p) for p in propios):
        return False   # «¿qué le regalo a Carla?»: Carla es de tu familia, no alguien de Wikipedia
    if SOBRE_EL_USUARIO.search(t) and not propios:
        return False   # «¿qué juego me recomendás?», «¿qué le regalo a mi madre?»: es sobre vos
    return bool(PREGUNTA.match(t) or ACTUAL.search(t) or DATO_FUERTE.search(t) or propios)


# "¿cómo te sentís hoy?", "¿qué hacés hoy?", "¿vos qué opinás?": son preguntas para JARVIS, no para buscar en internet
# (antes "cómo te sientes hoy" contestaba con la traducción al inglés de la frase)
A_JARVIS = re.compile(r"^(?:y )?(?:como|que tal|que) (?:estas|andas|vas|haces|te sentis|te sientes|te va|te fue|"
                      r"te llamas|sos|eres)\b|\b(?:te|vos|contigo|tenes|sabes hacer|podes hacer)\b")
# "¿cuál es el último texto que te pasé?" es sobre esta charla, no algo que se busca en internet
SOBRE_LA_CHARLA = re.compile(r"\bque (?:te|me) (?:pase|paso|pasaste|di|diste|dije|dijiste|mande|mandaste|envie|enviaste|"
                             r"pegue|conte|contaste|pregunte|preguntaste|escribi|escribiste)\b|"
                             r"\b(?:esta|nuestra|la) (?:charla|conversacion)\b|\bque hablamos\b")


def no_sabe(respuesta):
    return bool(NO_SABE.search(jarvis.normalizar(respuesta)))


# =========================================================================
#  VERIFICAR DATOS EN INTERNET (para que no invente: Wikipedia + buscador)
# =========================================================================

VACIAS_BUSQUEDA = set("""que quien quienes cual cuales cuando donde como cuanto cuanta cuantos cuantas por porque
es son era eran fue fueron sera el la los las un una unos unas de del al a en y o u con sin para sobre se su sus lo le
les me mi mis te tu vos decime contame explicame sabes sabias conoces hay esta estan tiene tienen jarvis che
podes puedes podrias quiero saber dime dame sobre acerca algo mas muy tan pocas pocos lineas palabras breve
breves corto resumen resumido resumida detalle detalladamente rapido explicacion porfa favor""".split())


def consulta_corta(texto):
    """'¿Quién es el padre de John Marston?' -> 'padre John Marston' (mejor para buscar en Wikipedia)."""
    palabras = re.findall(r"[\wáéíóúüñÁÉÍÓÚÜÑ'-]+", texto)
    utiles = [p for p in palabras if jarvis.normalizar(p) not in VACIAS_BUSQUEDA]
    return " ".join(utiles) or texto


def _wiki_json(url):
    """Consulta a la API de Wikipedia (si responde 'demasiadas consultas', reintenta una vez)."""
    for intento in range(2):
        try:
            return json_de(url, 6)
        except urllib.error.HTTPError as e:
            if e.code != 429 or intento:
                raise
            time.sleep(1.5)


def wikipedia(consulta, cantidad=2, largo=3500, idioma="es", completos=1):
    """Los artículos de Wikipedia que mejor coinciden: [(titulo, texto, url)]. El primero completo, los demás
    solo con su introducción (son 2 consultas en total: Wikipedia frena a quien consulta demasiado)."""
    api = f"https://{idioma}.wikipedia.org/w/api.php?"
    r = _wiki_json(api + urllib.parse.urlencode({
        "action": "query", "generator": "search", "gsrsearch": consulta, "gsrlimit": cantidad + 3,
        "prop": "extracts", "exintro": 1, "explaintext": 1, "exlimit": cantidad + 3, "format": "json", "redirects": 1}))
    paginas = sorted(r.get("query", {}).get("pages", {}).values(), key=lambda p: p.get("index", 99))
    # primero los artículos cuyo título tiene las palabras de lo que preguntaste
    # ("historia Arthur Morgan" devolvía primero "Richard Morgan")
    palabras = set(re.findall(r"\w+", jarvis.normalizar(consulta)))
    paginas.sort(key=lambda p: -len(palabras & set(re.findall(r"\w+", jarvis.normalizar(re.sub(r"\(.*?\)", "", p["title"]))))))
    paginas = paginas[:cantidad]
    if not paginas:
        return []
    url = lambda t: f"https://{idioma}.wikipedia.org/wiki/" + urllib.parse.quote(t.replace(" ", "_"))  # noqa: E731
    articulos = [(p["title"], p.get("extract", "")[:largo], url(p["title"])) for p in paginas]
    for i in range(min(completos, len(paginas))):  # el principal (o los primeros), completos
        try:
            d = _wiki_json(api + urllib.parse.urlencode({"action": "query", "prop": "extracts", "explaintext": 1,
                                                         "titles": paginas[i]["title"], "format": "json", "redirects": 1}))
            texto = next(iter(d.get("query", {}).get("pages", {}).values()), {}).get("extract", "")
            texto = re.sub(r"\n{2,}", "\n", texto)
            # se saca lo que no aporta datos (referencias, enlaces externos...)
            texto = re.split(r"\n=+ (?:Referencias|Notas|Enlaces externos|Véase también|Bibliografía) =+", texto)[0]
            if texto:
                articulos[i] = (paginas[i]["title"], texto[:largo], url(paginas[i]["title"]))
        except Exception:
            pass  # queda la introducción
    return [a for a in articulos if a[1]]


_cache_material = {}  # consulta -> (cuando, texto, fuentes): la misma pregunta no se vuelve a buscar por 30 min


def material_web(consulta, largo=5000, con_paginas=False, completos=1):
    """Junta información de internet sobre algo: Wikipedia (lo principal) + resultados del buscador.
    'completos': cuántos artículos de Wikipedia traer enteros (para quizzes largos, 2).
    Devuelve (texto, fuentes) o ("", []) si no encontró nada."""
    corta = consulta_corta(consulta)
    clave = (jarvis.normalizar(corta), largo, con_paginas, completos)
    guardado = _cache_material.get(clave)
    if guardado and time.time() - guardado[0] < 1800:
        return guardado[1], guardado[2]
    texto, fuentes = _material_web(consulta, corta, largo, con_paginas, completos)
    if texto:
        _cache_material[clave] = (time.time(), texto, fuentes)
    return texto, fuentes


def _material_web(consulta, corta, largo, con_paginas, completos=1):
    # sin "with": si una búsqueda se cuelga no hay que esperarla (el "with" la espera igual, pasado el límite)
    ex = ThreadPoolExecutor(2)
    f_wiki = ex.submit(wikipedia, corta, 2, int(largo * (0.75 if completos == 1 else 0.45)), "es", completos)
    f_web = ex.submit(buscar_web, consulta, 6)
    limite = time.time() + 7
    try:
        articulos = f_wiki.result(timeout=max(0.5, limite - time.time()))
    except Exception:
        articulos = []
    try:
        resultados = f_web.result(timeout=max(0.5, limite - time.time()))
    except Exception:
        resultados = []
    ex.shutdown(wait=False)
    partes, fuentes = [], []
    if articulos:
        titulo, texto, url = articulos[0]
        partes.append(f"[Wikipedia: {titulo}]\n{texto}")
        fuentes.append("es.wikipedia.org")
    resultados = [r for r in resultados if "wikipedia.org" not in r["url"]]
    if resultados:
        partes.append("[Buscador]\n" + "\n".join(f"- {r['titulo']} ({dominio(r['url'])}): {r['resumen']}"
                                                    for r in resultados[:5]))
        fuentes += [dominio(r["url"]) for r in resultados[:2]]
    # un segundo artículo solo si el primero es cortito: si no, suele ser OTRA persona con el mismo nombre
    # (buscando "John Marston" aparecía un empresario inglés y la IA mezclaba los datos)
    if articulos and (len(articulos[0][1]) < 1500 or completos > 1):
        for titulo, texto, url in articulos[1:]:
            partes.append(f"[Wikipedia: {titulo}]\n{texto[:int(largo * (0.25 if completos == 1 else 0.45))]}")
    if con_paginas and resultados and not articulos:
        texto = texto_de_pagina(resultados[0]["url"], int(largo * 0.6))
        if texto:
            partes.append(f"[{dominio(resultados[0]['url'])}]\n{texto}")
    texto = "\n\n".join(partes)[:largo + 1500]
    return texto, list(dict.fromkeys(fuentes))


# ¿La pregunta es sobre un dato del mundo (personajes, historia, personas...) que conviene verificar? Con estas formas
# de preguntar alcanza ("¿quién inventó la imprenta?"); palabras sueltas como "madre", "juego" o "canción" ya no: solo si
# hay un nombre propio ("el padre de Arthur Morgan"). Antes "¿qué le regalo a mi madre?" o "¿qué juego me recomendás?"
# se iban a buscar a Wikipedia
DATO_FUERTE = re.compile(
    r"\b(?:quien (?:es|era|fue|invento|descubrio|gano|escribio|creo|dirigio|canta|hizo)|quienes (?:son|eran|fueron)|"
    r"en que (?:ano|siglo|fecha|pais|ciudad)|donde (?:queda|nacio|murio|vive|esta ubicad)|"
    r"cuant[oa]s (?:anos tiene|habitantes|capitulos|temporadas|episodios|goles|titulos|copas|mundiales|libros|"
    r"peliculas|discos|hijos)|como (?:murio|termina|empieza)|de que (?:murio|trata)|que paso (?:con|en)|"
    r"historia de|biografia|capital de|poblacion de|trama de|final de|lore de|cuando (?:nacio|murio|salio|se fundo|"
    r"fue|empezo|termino|se estreno|se invento)|invento|descubrio|fundo)\b")
SOBRE_EL_USUARIO = re.compile(r"\b(?:mi|mis|me|yo|conmigo|nosotros|tengo|tenemos|opinas|te parece|te gusta|"
                              r"recomenda\w*)\b")
CHARLA = re.compile(r"^(?:hola|buenas|gracias|dale|ok|jaja\w*|como (?:estas|andas|va)|que tal|todo bien)\b")


# El dictado por voz pone mayúscula a palabras comunes en el medio de la frase ("podrías decirme Cuánto es la raíz"):
# no son nombres propios (antes eso mandaba a "verificar" una raíz cuadrada en Wikipedia)
NO_SON_NOMBRES = set("""jarvis vos yo tu el ella usted ustedes nosotros que como cual cuales cuando donde quien quienes
cuanto cuanta cuantos cuantas por porque para con sin sobre de del la las los lo un una unos unas y o pero si no es son
esta estan hay me te se mi mis tus su sus este esta esto ese esa eso puedo podes podrias puedes necesito preciso quiero
quisiera decime dime contame explicame ayudame hola gracias bueno dale ok che ahora hoy manana ayer tambien ya muy mas
menos todo nada algo""".split())


def nombres_propios(texto):
    """Palabras con mayúscula que no están al principio de una oración ('John Marston', 'Red Dead')."""
    nombres = []
    for oracion in re.split(r"[.!?¿¡\n]+", texto):
        palabras = oracion.split()
        for p in palabras[1:]:
            p = p.strip(",;:()\"'«»")
            if p[:1].isupper() and jarvis.normalizar(p) not in NO_SON_NOMBRES:
                nombres.append(p)
    return nombres


# Lo que se resuelve pensando o con la calculadora (no con Wikipedia)
SE_RESUELVE_SOLO = re.compile(
    r"\b(?:cuanto (?:es|da|son)|calcula\w*|raiz|cuadrad[oa]|al cubo|porcentaje|por ciento|multiplica\w*|divid\w*|"
    r"suma\w*|resta\w*|ecuacion\w*|derivada|integral|resolve\w*|resolver|ejercicio|problema de|"
    r"traduci\w*|traduce|como se dice|corregi\w*|corrige|redacta\w*|escribime|ayudame a (?:escribir|redactar|pensar)|"
    r"que me (?:conviene|recomendas)|que opinas|ideas? (?:para|de)|consejos?)\b")


def conviene_verificar(pregunta):
    """True si la respuesta depende de datos del mundo que el modelo chico puede inventar."""
    t = jarvis.normalizar(pregunta).strip(" ¿?¡!.,")
    if not VERIFICAR_EN_INTERNET or len(t.split()) < 3 or CHARLA.match(t) or re.search(r"\d\s*[-+*/x^]\s*\d", t):
        return False
    if SE_RESUELVE_SOLO.search(t):
        return False  # cuentas, traducciones, redactar, consejos: no hay nada que buscar
    if getattr(jarvis, "habla_de_lo_que_paso", None) and jarvis.habla_de_lo_que_paso(t):
        return False  # "leé el documento que te mandé de Google": se responde con el documento
    if SOBRE_JARVIS.search(t) or A_JARVIS.search(t) or SOBRE_LA_CHARLA.search(t) or es_personal(t):
        return False  # lo de JARVIS, de la charla o tuyo no está en internet
    propios = [p for p in nombres_propios(pregunta) if not jarvis.memoria.es_nombre_conocido(p)]   # tu familia, tus mascotas: los tuyos
    if SOBRE_EL_USUARIO.search(t) and not propios:
        return False
    # órdenes para JARVIS ("llamame Hector", "de ahora en más...") no se buscan en internet
    if re.search(r"\b(?:llamame|respondeme|hablame|acordate|anota|recorda|de ahora en|a partir de ahora|"
                 r"desde ahora|me llamo|soy)\b", t) and not pregunta.strip().endswith("?"):
        return False
    if jarvis.memoria.sabe_de(pregunta):
        return False  # de eso ya sabe por tus recuerdos ("¿cuántos limones usamos?"): no se busca
    return bool(propios) or bool(DATO_FUERTE.search(t))


def consulta_con_contexto(pregunta, historial):
    """'¿Y quién es su padre?' no dice de quién: le suma los nombres propios de lo último que preguntaste."""
    if nombres_propios(pregunta):
        return pregunta
    for m in reversed(historial[-6:]):
        if m.get("role") == "user":
            propios = nombres_propios(m["content"])
            if propios:
                return pregunta + " " + " ".join(dict.fromkeys(propios))
    return pregunta


# =========================================================================
#  PRECIOS (busca en tiendas de Uruguay y compara)
# =========================================================================

PRECIO = re.compile(
    r"\b(?:cuanto (?:sale|salen|cuesta|cuestan|vale|valen|esta|estan)|a cuanto (?:esta|estan|sale|salen)|"
    r"precios? (?:de|del|de la|de los|de las)|compara(?:me|r)? (?:los )?precios|"
    r"donde (?:esta|estan|sale|salen|conviene comprar|lo compro|la compro|compro) (?:mas )?barat[oa]s?|"
    r"mas barat[oa]s? (?:de|del)|"
    r"vale la pena (?:comprar|pagar)|(?:es|esta) (?:caro|barato|bien de precio|buen precio)|"
    r"(?:esta bien|conviene|me conviene|es mucho) (?:pagar|comprar)|me (?:lo|la|los|las) (?:venden|dejan|ofrecen) (?:a|en)|"
    r"pagar \d[\d.,]* (?:dolares|pesos|usd|u\$s|verdes)|buen precio|evalua(?:me)? (?:el )?precio)\b")
NO_ES_PRODUCTO = re.compile(r"\b(?:dolar|euro|real|peso argentino|bitcoin|cripto|cotizacion|nafta|gasoil|"
                            r"ute|ose|antel|boleto|entrada)\b")
PRECIO_DICHO = re.compile(r"(?:\b(?:a|por|en|pagar|pague|piden|sale|cuesta)\s+)?(?:u\$s|us\$|usd|\$u|\$)?\s*"
                          r"(\d[\d.,]*)\s*(mil\s+)?(dolares|dolar|usd|u\$s|us\$|verdes|pesos|uyu|\$u)\b")
ARTICULOS = re.compile(r"^(?:(?:de|del|de la|de los|de las|por|para)\s+)?(?:(?:un|una|el|la|los|las|unos|unas|esa|ese|esta|este)\s+)?")
RELLENO_FINAL = re.compile(r"\s+(?:en uruguay|aca|hoy|ahora|hoy en dia|actualmente|nuev[oa]s?|usad[oa]s?|mas o menos|"
                           r"aproximadamente|en (?:dolares|pesos))$")


def extraer_producto(t):
    """'¿está bien pagar 520 dólares por una rtx 4060?' -> producto 'rtx 4060', 520 USD.
    Se hace con reglas: la IA chica a veces cambiaba el producto ('play 5' -> 'Samsung Galaxy S5')."""
    t = re.sub(r"[¿?¡!,;]", " ", t)
    precio, moneda = 0, "ninguna"
    m = PRECIO_DICHO.search(t)
    if m:
        try:
            precio = float(m.group(1).replace(".", "").replace(",", ".")) * (1000 if m.group(2) else 1)
            moneda = "USD" if re.match(r"dolar|usd|u\$s|us\$|verdes", m.group(3)) else "UYU"
        except ValueError:
            precio = 0
        t = (t[:m.start()] + " " + t[m.end():]).strip()
    t = re.sub(r"\s+", " ", t).strip()
    disparador = PRECIO.search(t)
    producto = ""
    if " por " in t and re.search(r"\b(?:pagar|pague|pago|vale la pena|conviene|esta bien|es mucho)\b", t):
        producto = t.rsplit(" por ", 1)[1]
    elif disparador:
        producto = t[disparador.end():].strip() or t[:disparador.start()].strip()
    producto = re.sub(r"^(?:che|jarvis|y|bueno)\s+", "", producto)
    for _ in range(3):  # "de una", "a la"...
        producto = ARTICULOS.sub("", producto.strip())
        producto = RELLENO_FINAL.sub("", producto)
    producto = re.sub(r"\b(?:comprar|compro|lo compro|la compro|vale|sale|cuesta)\b", "", producto)
    return {"producto": re.sub(r"\s+", " ", producto).strip(" ."), "precio_usuario": precio, "moneda": moneda}


def _precios_en(crudo):
    """Saca el precio de una página de producto (los datos estructurados que usan las tiendas)."""
    encontrados = []
    for bloque in re.findall(r'(?is)<script[^>]+application/ld\+json[^>]*>(.*?)</script>', crudo):
        try:
            datos = json.loads(bloque.strip())
        except ValueError:
            continue
        pila = [datos]
        while pila:
            d = pila.pop()
            if isinstance(d, list):
                pila += d
            elif isinstance(d, dict):
                if "price" in d or "lowPrice" in d:
                    try:
                        precio = float(str(d.get("price") or d.get("lowPrice")).replace(",", ""))
                    except ValueError:
                        precio = 0
                    if precio > 0:
                        encontrados.append((precio, str(d.get("priceCurrency") or "")))
                pila += [v for v in d.values() if isinstance(v, (dict, list))]
    if not encontrados:
        p = re.search(r'(?:product:price:amount|itemprop="price")[^>]*content="([\d.]+)"', crudo)
        c = re.search(r'(?:product:price:currency|itemprop="priceCurrency")[^>]*content="(\w+)"', crudo)
        if p and float(p.group(1)) > 0:
            encontrados.append((float(p.group(1)), c.group(1) if c else ""))
    return encontrados


def buscar_precios(producto, cantidad=8):
    """[(tienda, nombre, precio, moneda, url)] de tiendas uruguayas."""
    def buscar(consulta):
        try:
            return buscar_web(consulta, 10)
        except Exception:
            return []
    with ThreadPoolExecutor(2) as ex:
        resultados = sum(ex.map(buscar, (f"{producto} precio Uruguay", f"comprar {producto} Uruguay")), [])
    vistos, candidatos = set(), []
    for r in resultados:
        if r["url"] in vistos or re.search(r"mercadolibre|pcprice|wikipedia|youtube|reddit|facebook|instagram", r["url"]):
            continue
        vistos.add(r["url"])
        candidatos.append(r)
    claves = [w for w in re.findall(r"\w+", jarvis.normalizar(producto)) if len(w) >= 2 and w not in VACIAS_BUSQUEDA]

    def revisar(r):
        try:
            crudo = descargar(r["url"], 5)
        except Exception:
            return None
        precios = _precios_en(crudo)
        if not precios:
            return None
        nombre = html.unescape(re.sub(r"\s+", " ", (re.search(r"(?is)<title[^>]*>(.*?)</title>", crudo) or [0, r["titulo"]])[1])).strip()
        n = jarvis.normalizar(nombre + " " + r["titulo"])
        if claves and sum(1 for c in claves if c in n) < max(1, round(len(claves) * 0.6)):
            return None  # es otra cosa (un accesorio, otro modelo)
        precio, moneda = precios[0]
        moneda = {"UYU": "$U", "USD": "USD", "": "USD" if precio < 20000 else "$U"}.get(moneda.upper(), moneda.upper())
        return dominio(r["url"]), nombre[:90], precio, moneda, r["url"]
    with ThreadPoolExecutor(6) as ex:
        hallados = [x for x in ex.map(revisar, candidatos[:12]) if x]
    unicos = {}
    for h in hallados:  # una sola entrada por tienda y modelo
        unicos.setdefault((h[0], h[2]), h)
    return sorted(unicos.values(), key=lambda h: (h[3] != "USD", h[2]))[:cantidad]


def _plata(valor, moneda):
    return f"{moneda} {valor:,.0f}".replace(",", ".")


def manejar_precios(texto, t):
    """'¿Cuánto sale una RTX 4060?', '¿está bien pagar 500 dólares por un iPhone 13?', 'compará precios de...'."""
    if not PRECIO.search(t) or NO_ES_PRODUCTO.search(t):
        return None
    p = extraer_producto(t)
    producto = p["producto"]
    if len(producto) < 2:
        jarvis.esperar_complemento("cuánto sale")
        return "¿De qué producto querés que busque precios?"
    jarvis.emitir("detalle", f"Buscando precios de {producto} en tiendas de Uruguay...")
    if time.time() < _buscador_bloqueado[0]:
        return ("El buscador me frenó un rato por hacer muchas búsquedas seguidas. Probá de nuevo en unos "
                "minutos y te comparo los precios.")
    lista = buscar_precios(producto)
    if not lista and time.time() < _buscador_bloqueado[0]:
        return ("El buscador me frenó un rato por hacer muchas búsquedas seguidas. Probá de nuevo en unos "
                "minutos y te comparo los precios.")
    if not lista:
        return (f"No encontré precios confiables de {producto} en tiendas de Uruguay. Probá con el modelo exacto, "
                "o fijate en MercadoLibre (no me deja leerlo automáticamente).")
    lineas = [f"- **{tienda}**: {_plata(precio, moneda)} — {nombre}" for tienda, nombre, precio, moneda, _ in lista]
    texto_r = f"Precios de **{producto}** que encontré en tiendas de Uruguay:\n" + "\n".join(lineas)
    usd = sorted(h[2] for h in lista if h[3] == "USD")
    pesos = sorted(h[2] for h in lista if h[3] == "$U")
    for valores, moneda in ((usd, "USD"), (pesos, "$U")):
        if len(valores) >= 2:
            medio = valores[len(valores) // 2]
            texto_r += (f"\n\nEn {moneda}: va de {_plata(valores[0], moneda)} a {_plata(valores[-1], moneda)}"
                        f" (lo típico, unos {_plata(medio, moneda)}). Lo más barato: {next(h[0] for h in lista if h[2] == valores[0])}.")
    suyo, moneda_suya = p.get("precio_usuario") or 0, {"USD": "USD", "UYU": "$U"}.get(p.get("moneda"))
    if suyo > 0 and moneda_suya:
        valores = usd if moneda_suya == "USD" else pesos
        if valores:
            medio = valores[len(valores) // 2]
            dif = (suyo - medio) / medio * 100
            if suyo <= valores[0]:
                juicio = "Es un **buen precio**: está por debajo de lo más barato que encontré (fijate que sea nuevo y con garantía)."
            elif dif <= 8:
                juicio = f"Es un **precio normal** ({dif:+.0f}% respecto a lo típico)."
            else:
                juicio = f"Está **caro**: {dif:.0f}% más que lo típico. Conviene comprarlo en {next(h[0] for h in lista if h[2] == valores[0])}."
            texto_r += f"\n\nA {_plata(suyo, moneda_suya)}: {juicio}"
        else:
            texto_r += f"\n\nNo encontré precios en {moneda_suya} para comparar con lo que te ofrecen."
    return texto_r + "\n\nOjo: los precios cambian seguido; confirmalo en la tienda antes de comprar."


# =========================================================================
#  CONTROL DE LA PC Y LA MÚSICA
# =========================================================================

VK_PLAY, VK_SIGUIENTE, VK_ANTERIOR = 0xB3, 0xB0, 0xB1
ALIAS_PROGRAMAS = {
    "chrome": ["chrome.exe"], "google chrome": ["chrome.exe"], "opera": ["opera.exe"], "opera gx": ["opera.exe"],
    "edge": ["msedge.exe"], "firefox": ["firefox.exe"], "navegador": ["opera.exe", "chrome.exe", "msedge.exe"],
    "spotify": ["Spotify.exe"], "discord": ["Discord.exe"], "steam": ["steam.exe", "steamwebhelper.exe"],
    "word": ["WINWORD.EXE"], "excel": ["EXCEL.EXE"], "powerpoint": ["POWERPNT.EXE"],
    "whatsapp": ["WhatsApp.exe", "WhatsApp.Root.exe"], "onlyoffice": ["DesktopEditors.exe"],
    "bloc de notas": ["notepad.exe"], "notas": ["notepad.exe"], "calculadora": ["CalculatorApp.exe"],
    "visual studio code": ["Code.exe"], "vscode": ["Code.exe"], "epic": ["EpicGamesLauncher.exe"],
    "epic games": ["EpicGamesLauncher.exe"], "nox": ["Nox.exe", "MultiPlayerManager.exe"], "teams": ["ms-teams.exe"],
    "zoom": ["Zoom.exe"], "obs": ["obs64.exe"], "paint": ["mspaint.exe"],
}
PROTEGIDOS = {"explorer.exe", "svchost.exe", "csrss.exe", "winlogon.exe", "lsass.exe", "services.exe", "system",
              "dwm.exe", "smss.exe", "wininit.exe", "python.exe", "pythonw.exe", "ollama.exe", "msedgewebview2.exe"}


def procesos_que_coinciden(nombre):
    import psutil

    n = jarvis.normalizar(nombre).strip(" .")
    exes = {e.lower() for e in ALIAS_PROGRAMAS.get(n, [])}
    clave = n.replace(" ", "")
    encontrados = []
    for p in psutil.process_iter(["name", "pid"]):
        nombre_p = (p.info["name"] or "").lower()
        if nombre_p in PROTEGIDOS or p.info["pid"] == os.getpid():
            continue
        if nombre_p in exes or (not exes and len(clave) >= 3 and nombre_p.replace(".exe", "").startswith(clave)):
            encontrados.append(p)
    return encontrados


def cerrar_programa(nombre, forzar=False):
    procesos = procesos_que_coinciden(nombre)
    if not procesos:
        return f"No encontré {nombre} abierto."
    nombres = sorted({p.info["name"] for p in procesos})
    for exe in nombres:
        subprocess.run(["taskkill", "/IM", exe, "/T"] + (["/F"] if forzar else []), capture_output=True,
                       creationflags=SIN_VENTANA)
    time.sleep(2.5)
    if procesos_que_coinciden(nombre):
        if forzar:
            return f"No pude cerrar {nombre}."
        return (f"Le pedí a {nombre} que se cierre, pero sigue abierto (puede estar preguntando si guardás algo). "
                f"Si querés, decime 'forzá el cierre de {nombre}'.")
    return f"Listo, cerré {nombre}."


def captura_de_pantalla():
    from PIL import ImageGrab

    ruta = os.path.join(jarvis.CARPETA_IMAGENES, f"captura_{datetime.datetime.now():%Y-%m-%d_%H-%M-%S}.png")
    ImageGrab.grab(all_screens=True).save(ruta)
    jarvis.recordar_archivo(ruta)
    if not jarvis.oyentes:
        os.startfile(ruta)
    jarvis.emitir("archivo", ruta)
    return "Listo, saqué una captura de pantalla. Está en la carpeta imágenes."


def brillo(t):
    actual = powershell("(Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness).CurrentBrightness")
    if not actual.strip().isdigit():
        return "No puedo controlar el brillo de esta pantalla."
    actual = int(actual)
    n = re.search(r"\b(\d{1,3})\b", t)
    if n:
        nuevo = int(n.group(1))
    elif re.search(r"\b(?:sub|aument|mas)\w*", t):
        nuevo = actual + 20
    elif re.search(r"\b(?:baj|disminu|menos)\w*", t):
        nuevo = actual - 20
    elif re.search(r"\b(?:maximo|todo)\b", t):
        nuevo = 100
    elif re.search(r"\bminimo\b", t):
        nuevo = 0
    else:
        return f"El brillo está al {actual} por ciento."
    nuevo = max(0, min(100, nuevo))
    powershell("Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods | "
               f"Invoke-CimMethod -MethodName WmiSetBrightness -Arguments @{{Timeout=0; Brightness={nuevo}}}")
    return f"Listo, brillo al {nuevo} por ciento."


def accion_confirmada(titulo, detalle, pregunta, accion):
    return jarvis.conexiones.pedir_confirmacion("sistema", titulo, detalle, accion, pregunta=pregunta)


def manejar_pc(texto, t):
    # --- Música (teclas multimedia: funciona con Spotify, YouTube, etc.) ---
    if re.match(r"^(?:pone|poneme|dale|reanuda|segui|volve a poner)\s+(?:algo de |un poco de |la |unos temas|un tema)?\s*"
                r"(?:musica|temas?)?(?:[\s,]+la que (?:estaba sonando|estaba escuchando|sonaba))?$", t) \
            and re.search(r"\b(?:musica|temas?|sonando)\b", t):
        jarvis.tecla(VK_PLAY)  # retoma lo último que estaba sonando
        return "Listo, le di play."
    if re.match(r"^(?:(?:pone|dale|toca)\s+)?(?:pausa|play|plei)(?:\s+(?:a |de )?(?:la |el )?(?:musica|cancion|tema|video|spotify))?$", t) \
            or re.match(r"^(?:pausa|para|frena|reanuda|segui|continua|retoma)\s+(?:la |el )?(?:musica|cancion|tema|video|spotify|reproduccion)$", t):
        jarvis.tecla(VK_PLAY)
        return "Listo."
    if re.search(r"^(?:siguiente|proxima|pasa(?:la)?|salta(?:la)?|saltea(?:la)?|cambia(?:la)?)(?:\s+(?:la |el )?(?:cancion|tema|video))?$", t) \
            or re.search(r"\b(?:siguiente|proxima)\s+(?:cancion|tema|video)\b|\b(?:pasa|salta|saltea|cambia)\s+(?:de |la |el )?(?:cancion|tema)\b", t):
        jarvis.tecla(VK_SIGUIENTE)
        return "Listo, siguiente."
    if re.search(r"\b(?:cancion|tema|video)\s+anterior\b|\b(?:volve|vuelve|pone)\s+(?:a )?(?:la |el )?(?:cancion|tema) anterior\b|^anterior$", t):
        jarvis.tecla(VK_ANTERIOR)
        jarvis.tecla(VK_ANTERIOR)  # la primera vuelve al inicio del tema, la segunda al anterior
        return "Listo, anterior."
    m = re.match(r"^(?:pone|poneme|reproduci|toca|busca)\s+(.+?)\s+en spotify$", t)
    if m:
        os.startfile("spotify:search:" + urllib.parse.quote(m.group(1)))
        return f"Te busqué {m.group(1)} en Spotify."

    # --- Energía (todo esto pide confirmación) ---
    m = re.match(r"^(?:apaga|apagame|apagar)\s+(?:la |el )?(?:compu|computadora|pc|ordenador|equipo|maquina|notebook)"
                 r"(?:\s+(?:en|dentro de)\s+(.+))?$", t)
    if m:
        segundos = segundos_de(m.group(1)) if m.group(1) else 60
        if not segundos:
            return "¿En cuánto tiempo la apago?"
        cuando = describir_momento(datetime.datetime.now() + datetime.timedelta(seconds=segundos))

        def apagar():
            subprocess.run(["shutdown", "/s", "/t", str(segundos)], creationflags=SIN_VENTANA)
            return f"Listo, la compu se apaga {cuando}. Si te arrepentís, decí 'cancelá el apagado'."
        return accion_confirmada("Apagar la computadora", f"Se apaga {cuando}. Guardá lo que tengas abierto.",
                                 f"¿Apago la compu {cuando}?", apagar)
    if re.match(r"^(?:reinicia|reiniciame|reiniciar)\s+(?:la |el )?(?:compu|computadora|pc|equipo|maquina|notebook)$", t):
        def reiniciar():
            subprocess.run(["shutdown", "/r", "/t", "30"], creationflags=SIN_VENTANA)
            return "Listo, reinicio en 30 segundos. Si te arrepentís, decí 'cancelá el apagado'."
        return accion_confirmada("Reiniciar la computadora", "Se reinicia en 30 segundos.", "¿Reinicio la compu?", reiniciar)
    if re.match(r"^(?:suspende|suspendela|hiberna|pone a dormir|manda a dormir|pone en suspension)\s*(?:la |el )?"
                r"(?:compu|computadora|pc|equipo|notebook)?$", t):
        def suspender():
            threading.Timer(3, lambda: ctypes.windll.powrprof.SetSuspendState(0, 1, 0)).start()
            return "Listo, suspendo la compu."
        return accion_confirmada("Suspender la computadora", "Se suspende en 3 segundos.", "¿Suspendo la compu?", suspender)
    if re.search(r"\bcancela\w*\s+(?:el )?(?:apagado|reinicio)\b|\bno (?:la )?apagues\b", t):
        r = subprocess.run(["shutdown", "/a"], capture_output=True, creationflags=SIN_VENTANA)
        return "Listo, cancelé el apagado." if r.returncode == 0 else "No había ningún apagado programado."
    if re.match(r"^(?:bloquea|bloqueame|bloquear)\s+(?:la )?(?:pantalla|compu|pc|computadora|sesion)$", t):
        threading.Timer(1.5, ctypes.windll.user32.LockWorkStation).start()
        return "Bloqueando la pantalla."
    if re.match(r"^(?:apaga|apagame)\s+(?:la pantalla|el monitor)$", t):
        threading.Timer(1.5, lambda: ctypes.windll.user32.SendMessageW(0xFFFF, 0x0112, 0xF170, 2)).start()
        return "Apagando la pantalla. Mové el mouse para prenderla."

    # --- Otras ---
    if re.search(r"\b(?:captura|screenshot|pantallazo)\b", t) and re.search(r"\b(?:saca|sacame|hace|haceme|toma|tomame|captura)\b", t):
        return captura_de_pantalla()
    if re.search(r"\bbrillo\b", t):
        return brillo(t)
    m = re.match(r"^(?:forza(?:r)? el cierre de|cerra a la fuerza|mata(?:me)?)\s+(?:el |la )?(.+)$", t)
    if m:
        return cerrar_programa(m.group(1), forzar=True)
    m = re.match(r"^(?:cerra|cerrame|cierra|cerrar|termina)\s+(?:el |la |los |las )?(?:programa |aplicacion |app )?(.+)$", t)
    if m and m.group(1) not in ("sesion", "todo", "la sesion", "jarvis"):
        return cerrar_programa(m.group(1))
    return None


# =========================================================================
#  RENDIMIENTO Y MODO JUEGO
# =========================================================================

modo_juego = threading.Event()
_previo = {}
_prioridad_subida = set()
_juego_auto = {"desde": None, "activo_auto": False, "ultimo_visto": 0.0}
EXCLUIR_AUTO = {"explorer.exe", "chrome.exe", "msedge.exe", "opera.exe", "firefox.exe", "brave.exe", "vlc.exe",
                "powerpnt.exe", "applicationframehost.exe", "python.exe", "pythonw.exe", "whatsapp.exe",
                "whatsapp.root.exe", "code.exe", "desktopeditors.exe", "spotify.exe", "discord.exe",
                "msedgewebview2.exe", "searchhost.exe", "shellexperiencehost.exe", "lockapp.exe", "mpc-hc64.exe"}
OVERLAY_MAX_RENDIMIENTO = "ded574b5-45a0-4f42-8737-46345c09c238"  # el modo "Mejor rendimiento" de Windows 11


class _GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16),
                ("Data4", ctypes.c_ubyte * 8)]


def _guid(texto):
    import uuid

    u = uuid.UUID(texto)
    g = _GUID()
    g.Data1, g.Data2, g.Data3 = u.fields[0], u.fields[1], u.fields[2]
    for i, b in enumerate(u.bytes[8:]):
        g.Data4[i] = b
    return g


def _overlay_actual():
    try:
        g = _GUID()
        if ctypes.windll.powrprof.PowerGetEffectiveOverlayScheme(ctypes.byref(g)) == 0:
            import uuid

            return str(uuid.UUID(fields=(g.Data1, g.Data2, g.Data3, g.Data4[0], g.Data4[1],
                                         int.from_bytes(bytes(g.Data4[2:]), "big"))))
    except Exception:
        pass
    return None


def _poner_overlay(texto):
    try:
        return ctypes.windll.powrprof.PowerSetActiveOverlayScheme(ctypes.byref(_guid(texto))) == 0
    except Exception:
        return False


NOMBRES_LINDOS = {"llama-server": "mi IA (Ollama)", "ollama": "Ollama", "msedgewebview2": "WebView (ventanas de apps)",
                  "code": "VS Code", "memcompression": "compresión de memoria de Windows", "svchost": "servicios de Windows",
                  "opera": "Opera", "chrome": "Chrome", "msedge": "Edge", "discord": "Discord", "steamwebhelper": "Steam",
                  "whatsapp.root": "WhatsApp", "onedrive": "OneDrive", "pythonw": "JARVIS", "python": "Python"}


def _nombre_lindo(exe):
    base = re.sub(r"(?i)\.exe$", "", exe)
    return NOMBRES_LINDOS.get(base.lower(), base)


def consumo(top=5):
    """Los programas que más CPU y memoria usan (sumando todas sus ventanas/procesos)."""
    import psutil

    # Dos pasadas (cada una tarda ~2 s en Windows): la diferencia de tiempo de CPU entre ambas da el uso
    t0 = time.time()
    antes = {p.pid: p.info for p in psutil.process_iter(["name", "memory_info", "cpu_times"])}
    time.sleep(0.3)
    despues = {p.pid: p.info["cpu_times"] for p in psutil.process_iter(["cpu_times"])}
    segundos = max(0.5, time.time() - t0)
    nucleos = psutil.cpu_count() or 1
    grupos = {}
    for pid, info in antes.items():
        nombre = info["name"] or "?"
        if nombre in ("System Idle Process", "Idle", "System", "Registry", "Memory Compression"):
            continue
        g = grupos.setdefault(nombre, {"cpu": 0.0, "ram": 0})
        g["ram"] += info["memory_info"].rss if info["memory_info"] else 0
        c0, c1 = info["cpu_times"], despues.get(pid)
        if c0 and c1:
            g["cpu"] += max(0.0, (c1.user + c1.system) - (c0.user + c0.system)) / segundos / nucleos * 100
    por_ram = sorted(grupos.items(), key=lambda x: -x[1]["ram"])[:top]
    por_cpu = sorted(grupos.items(), key=lambda x: -x[1]["cpu"])[:top]
    return por_cpu, por_ram


def gpu():
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=5,
                           creationflags=SIN_VENTANA)
        nombre, uso, usada, total, temp = [x.strip() for x in r.stdout.strip().split(",")]
        return {"nombre": nombre, "uso": int(uso), "usada": int(usada), "total": int(total), "temp": int(temp)}
    except Exception:
        return None


def ram_modelo_ia():
    """Cuánta memoria (de video) ocupa el modelo de IA cargado en Ollama, en GB."""
    try:
        r = jarvis.ollama.ps()
        modelos = r.models if hasattr(r, "models") else r["models"]
        return sum((getattr(m, "size_vram", None) or getattr(m, "size", 0) or 0) for m in modelos) / 1e9
    except Exception:
        return 0.0


def estado_pc():
    import psutil

    mem = psutil.virtual_memory()
    with ThreadPoolExecutor(2) as ex:  # la placa de video se consulta mientras se mide la CPU
        datos_gpu = ex.submit(gpu)
        por_cpu, por_ram = consumo()
        g = datos_gpu.result()
    cpu_total = psutil.cpu_percent(interval=None)
    partes = [f"CPU al {round(cpu_total)}%, memoria al {round(mem.percent)}% "
              f"({mem.used / 1e9:.1f} de {mem.total / 1e9:.1f} GB)."]
    if g:
        partes.append(f"Placa de video {g['uso']}% de uso, {g['usada'] / 1024:.1f} de {g['total'] / 1024:.1f} GB de memoria, {g['temp']} grados.")
    partes.append("Lo que más memoria usa: " + ", ".join(
        f"{_nombre_lindo(n)} {d['ram'] / 1e9:.1f} GB" for n, d in por_ram[:4]) + ".")
    pesados_cpu = [(n, d) for n, d in por_cpu if d["cpu"] >= 3]
    if pesados_cpu:
        partes.append("Lo que más procesador usa: " + ", ".join(
            f"{_nombre_lindo(n)} {round(d['cpu'])}%" for n, d in pesados_cpu[:3]) + ".")
    ia = ram_modelo_ia()
    if ia > 0.5 and not modo_juego.is_set():
        partes.append(f"Mi modelo de IA ocupa {ia:.1f} GB de la placa de video; si vas a jugar, decime 'modo juego' y lo libero.")
    elif mem.percent > 85:
        partes.append("La memoria está muy llena: cerrar el navegador o pasar a modo juego ayudaría.")
    return " ".join(partes)


def _bajar_prioridad_jarvis(bajar=True):
    """Modo juego: JARVIS (Python) y Ollama pasan a prioridad baja. Los procesos de la ventana (WebView2) NO: ahí
    suena la música, y con un juego usando casi todo el procesador (RDR2 al 93%, en prioridad alta) el reproductor
    con prioridad baja no llegaba a preparar el audio y la música se cortaba o no se escuchaba."""
    import psutil

    clase = psutil.BELOW_NORMAL_PRIORITY_CLASS if bajar else psutil.NORMAL_PRIORITY_CLASS
    yo = psutil.Process()
    procesos = [yo] + [p for p in yo.children(recursive=True) if not _es_webview(p)]
    procesos += [p for p in psutil.process_iter(["name"]) if (p.info["name"] or "").lower().startswith("ollama")]
    for p in procesos:
        try:
            p.nice(clase)
        except Exception:
            pass
    if bajar:
        proteger_musica()
    else:
        _soltar_musica()


def _es_webview(p):
    try:
        return (p.name() or "").lower() == "msedgewebview2.exe"
    except Exception:
        return False


_musica_protegida = set()  # pids a los que se les subió la prioridad (para devolverla al salir del modo juego)


def proteger_musica():
    """Con la música de JARVIS sonando en modo juego: el servicio de audio y lo que está reproduciendo (los procesos
    de la ventana que Chromium tiene "en primer plano") pasan a prioridad sobre lo normal, para que el juego no los
    ahogue. Se repite cada 5 s (cada tema nuevo puede abrir procesos nuevos)."""
    import psutil

    if not (jarvis.musica.estado.get("modo") == "jarvis"):
        return
    try:
        hijos = [p for p in psutil.Process().children(recursive=True) if _es_webview(p)]
    except Exception:
        return
    for p in hijos:
        try:
            linea = " ".join(p.cmdline())
            prioridad = p.nice()
            if "audio.mojom.AudioService" in linea or ("--type=renderer" in linea and prioridad != psutil.IDLE_PRIORITY_CLASS):
                if prioridad != psutil.ABOVE_NORMAL_PRIORITY_CLASS:  # (los dormidos, Chromium ya los tiene en "inactiva")
                    p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
                    _musica_protegida.add(p.pid)
            elif prioridad == psutil.BELOW_NORMAL_PRIORITY_CLASS:  # lo que haya bajado una versión anterior
                p.nice(psutil.NORMAL_PRIORITY_CLASS)
        except Exception:
            pass


def _soltar_musica():
    import psutil

    for pid in list(_musica_protegida):
        try:
            psutil.Process(pid).nice(psutil.NORMAL_PRIORITY_CLASS)
        except Exception:
            pass
    _musica_protegida.clear()


def recortar_memoria():
    """Le pide a Windows que saque de la RAM lo que JARVIS no está usando (Python y la ventana dormida)."""
    import gc

    import psutil

    gc.collect()
    k32 = ctypes.windll.kernel32
    k32.OpenProcess.restype = ctypes.c_void_p
    k32.K32EmptyWorkingSet.argtypes = [ctypes.c_void_p]
    k32.CloseHandle.argtypes = [ctypes.c_void_p]
    yo = psutil.Process()
    sonando = jarvis.musica.estado.get("modo") == "jarvis"
    for p in [yo] + yo.children(recursive=True):
        if (p.name() or "").lower().startswith(("ollama", "llama")):
            continue
        if sonando and _es_webview(p):
            continue  # vaciarle la memoria al reproductor mientras suena hacía saltar el audio
        h = k32.OpenProcess(0x0100 | 0x0400 | 0x0010, False, p.pid)  # SET_QUOTA | QUERY_INFO | VM_READ
        if h:
            k32.K32EmptyWorkingSet(h)
            k32.CloseHandle(h)


def ram_jarvis_mb():
    """RAM que usa JARVIS ahora (Python + ventana, sin contar la IA)."""
    import psutil

    yo = psutil.Process()
    total = 0
    for p in [yo] + yo.children(recursive=True):
        try:
            if not (p.name() or "").lower().startswith(("ollama", "llama")):
                total += p.memory_info().rss
        except Exception:
            pass
    return total / 1e6


def activar_modo_juego(juego=None, automatico=False):
    """Deja a JARVIS en lo mínimo: sin IA, sin Ollama, con la ventana escondida y dormida.
    Sigue escuchando 'Jarvis' para comandos que no necesitan IA (hora, música, alarmas, 'terminé de jugar')."""
    import apagar

    if modo_juego.is_set():
        return "El modo juego ya está activo."
    modo_juego.set()
    hechos = []
    # 1) IA en pausa total: la saca de la placa de video y cierra Ollama (así nada la vuelve a cargar)
    ia = ram_modelo_ia()
    jarvis.KEEP_ALIVE = 0
    jarvis.generador_local.cerrar()  # si el generador de imágenes estaba abierto, suelta la placa de video
    jarvis.camara.apagar_todo()  # cámara y control por gestos
    apagar.descargar_modelos()
    apagar.cerrar_ollama()
    hechos.append(f"pausé mi IA y cerré Ollama ({ia:.1f} GB de placa de video y cerca de 1 GB de RAM libres)"
                  if ia > 0.1 else "pausé mi IA y cerré Ollama")
    # 2) JARVIS pasa a prioridad baja
    _bajar_prioridad_jarvis(True)
    # 3) Energía: modo "Mejor rendimiento" de Windows
    _previo["overlay"] = _overlay_actual()
    if _poner_overlay(OVERLAY_MAX_RENDIMIENTO):
        hechos.append("puse Windows en mejor rendimiento")
    # 4) La ventana se esconde y se duerme (deja de usar la placa de video), y se libera su memoria
    jarvis.emitir("modo_juego", True)
    hechos.append("me escondo para no gastar nada")
    threading.Timer(12, recortar_memoria).start()

    texto = ("Modo juego activado" + (f" (detecté {_nombre_lindo(juego)})" if juego else "") + ": "
             + ", ".join(hechos[:-1]) + " y " + hechos[-1] + ". Sigo escuchando: decí 'Jarvis, terminé de jugar' "
             "o abrí JARVIS para volver.")
    # 5) Sugiere cerrar lo que más consume en segundo plano
    try:
        _, por_ram = consumo(8)
        pesados = [(n, d) for n, d in por_ram if d["ram"] > 700e6 and n.lower() not in PROTEGIDOS
                   and n.lower() not in ("steam.exe", "steamwebhelper.exe") and (not juego or n.lower() != juego.lower())
                   and not n.lower().startswith(("ollama", "llama"))]
        if pesados:
            texto += " Lo que más memoria usa en segundo plano: " + ", ".join(
                f"{_nombre_lindo(n)} ({d['ram'] / 1e9:.1f} GB)" for n, d in pesados[:3]) + \
                f". Si querés, decime 'cerrá {_nombre_lindo(pesados[0][0]).lower()}'."
    except Exception:
        pass
    if automatico:
        notificar("J.A.R.V.I.S. · Modo juego", texto)
    return texto


def desactivar_modo_juego():
    if not modo_juego.is_set():
        return "El modo juego no estaba activo."
    modo_juego.clear()
    _juego_auto["activo_auto"] = False
    jarvis.KEEP_ALIVE = jarvis.KEEP_ALIVE_NORMAL
    _bajar_prioridad_jarvis(False)
    if _previo.get("overlay"):
        _poner_overlay(_previo["overlay"])
    import psutil

    for pid in list(_prioridad_subida):
        try:
            psutil.Process(pid).nice(psutil.NORMAL_PRIORITY_CLASS)
        except Exception:
            pass
    _prioridad_subida.clear()
    jarvis.emitir("modo_juego", False)
    jarvis.abrir_ollama()
    jarvis.precalentar()  # vuelve a abrir Ollama y carga la IA para responder rápido
    return "Modo juego desactivado: todo volvió a la normalidad. Estoy recargando mi IA, dame unos segundos."


def _ventana_en_pantalla_completa():
    """Devuelve (pid, exe) de la ventana del frente si ocupa toda la pantalla, o (None, None)."""
    user32 = ctypes.windll.user32
    h = user32.GetForegroundWindow()
    if not h:
        return None, None
    clase = ctypes.create_unicode_buffer(64)
    user32.GetClassNameW(h, clase, 64)
    if clase.value in ("Progman", "WorkerW", "Shell_TrayWnd"):
        return None, None

    class RECT(ctypes.Structure):
        _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long), ("r", ctypes.c_long), ("b", ctypes.c_long)]

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_ulong), ("rcMonitor", RECT), ("rcWork", RECT), ("dwFlags", ctypes.c_ulong)]

    ventana = RECT()
    user32.GetWindowRect(h, ctypes.byref(ventana))
    info = MONITORINFO()
    info.cbSize = ctypes.sizeof(MONITORINFO)
    user32.GetMonitorInfoW(user32.MonitorFromWindow(h, 2), ctypes.byref(info))
    m = info.rcMonitor
    if not (ventana.l <= m.l and ventana.t <= m.t and ventana.r >= m.r and ventana.b >= m.b):
        return None, None
    pid = ctypes.c_ulong()
    user32.GetWindowThreadProcessId(h, ctypes.byref(pid))
    try:
        import psutil

        return pid.value, psutil.Process(pid.value).name()
    except Exception:
        return None, None


def _vigilar_juegos():
    """Cada 5 segundos: le da prioridad al juego y (si MODO_JUEGO_AUTO) activa/desactiva el modo juego solo."""
    import psutil

    while True:
        time.sleep(5)
        try:
            pid, exe = _ventana_en_pantalla_completa()
            es_juego = pid and pid != os.getpid() and exe and exe.lower() not in EXCLUIR_AUTO
            ahora = time.time()
            if es_juego:
                _juego_auto["ultimo_visto"] = ahora
                if MODO_JUEGO_AUTO and not modo_juego.is_set():
                    _juego_auto["desde"] = _juego_auto["desde"] or ahora
                    if ahora - _juego_auto["desde"] >= 15:  # 15 segundos seguidos en pantalla completa
                        activar_modo_juego(exe, automatico=True)
                        _juego_auto["activo_auto"] = True
            else:
                _juego_auto["desde"] = None
            if modo_juego.is_set():
                proteger_musica()  # un tema nuevo puede haber abierto otro proceso de la ventana
                if es_juego and pid not in _prioridad_subida:
                    try:
                        psutil.Process(pid).nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
                        _prioridad_subida.add(pid)
                    except Exception:
                        pass
                if _juego_auto["activo_auto"] and ahora - _juego_auto["ultimo_visto"] > 90:
                    desactivar_modo_juego()
                    notificar("J.A.R.V.I.S. · Modo juego", "Terminaste de jugar: desactivé el modo juego.")
        except Exception:
            pass


def manejar_rendimiento(texto, t):
    # "quiero jugar al Red Dead", "vamos a jugar Among Us": abre el juego y libera la placa de video (modo juego)
    m = re.match(r"^(?:(?:me )?voy a |quiero |vamos a |me pongo a |a )?jugar(?: un rato)?\s+(?:a |al )?(?:la |el |los |las )?(.+)$", t)
    if m and not re.fullmatch(r"(?:un rato|algo|ahora|ya|tranquilo)", m.group(1)):
        respuesta = jarvis.programas.abrir_por_nombre(m.group(1))
        if respuesta and respuesta.startswith("Abriendo"):
            return respuesta + " " + activar_modo_juego()
        if respuesta:  # "¿Cuál querés abrir?"
            jarvis.esperar_complemento("quiero jugar al")
            return respuesta
        return f"No encontré «{m.group(1)}» entre tus juegos. " + activar_modo_juego()
    if re.search(r"^(?:activa(?:r)?|pone|poneme|entra en|inicia)?\s*(?:el )?modo (?:juego|gamer|gaming)(?: activado)?$|"
                 r"^(?:me )?voy a jugar|^me pongo a jugar|^quiero jugar|^vamos a jugar|^a jugar\b|^hora de jugar|"
                 r"^(?:voy a|quiero) (?:viciar|gamear)", t):
        return activar_modo_juego()
    if re.search(r"^(?:desactiva(?:r)?|saca(?:r)?|apaga(?:r)?|sali(?:r)? del?|termina(?:r)?)\s*(?:el )?modo (?:juego|gamer|gaming)$|"
                 r"^(?:ya )?termine de jugar|^deje de jugar|^modo normal$", t):
        return desactivar_modo_juego()
    if re.search(r"\b(?:que|quien)\s+(?:esta|me esta|anda)\s+(?:consumiendo|usando|gastando|chupando|comiendo)|"
                 r"por que (?:va|anda|esta) (?:tan )?(?:lenta|lento|trabada|trabado|pesada)|"
                 r"como (?:esta|anda|va) (?:la )?(?:compu|pc|computadora|maquina)|\brendimiento\b|"
                 r"uso de (?:cpu|ram|memoria|la placa)|que programas (?:consumen|usan)|estado del sistema", t):
        return estado_pc()
    if re.search(r"\b(?:libera|liberame|limpia)\s+(?:la )?(?:memoria|ram)\b", t):
        ia = ram_modelo_ia()
        antes = ram_jarvis_mb()
        jarvis.liberar_ia()
        recortar_memoria()
        ahorro = max(0.0, antes - ram_jarvis_mb())
        return ((f"Liberé {ia:.1f} GB descargando mi IA (se vuelve a cargar cuando me hables)" if ia > 0.1 else "Listo")
                + (f" y {ahorro:.0f} MB de mi propia memoria" if ahorro > 20 else "")
                + ". Para liberar más, preguntame 'qué está consumiendo' o decime 'modo juego'.")
    return None


# =========================================================================
#  ENTRADA
# =========================================================================

def ejecutar(texto, t):
    t = t.strip(" ¿?¡!.,")  # "¿va a llover?" -> "va a llover"
    for manejar in (manejar_recordatorios, manejar_rendimiento, manejar_pc, manejar_clima, manejar_noticias,
                    manejar_precios, manejar_investigacion, manejar_busqueda):
        respuesta = manejar(texto, t)
        if respuesta is not None:
            return respuesta
    return None


_iniciado = False


def iniciar():
    global _iniciado
    if _iniciado:
        return
    _iniciado = True
    threading.Thread(target=_bucle_recordatorios, daemon=True).start()
    threading.Thread(target=_vigilar_juegos, daemon=True).start()
    threading.Thread(target=ubicacion_actual, daemon=True).start()  # detecta la ciudad para el clima
