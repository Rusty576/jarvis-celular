"""La barrita de música: una ventanita flotante, siempre arriba y fuera de la pantalla principal, con lo que está
sonando, play/pausa, anterior/siguiente, volumen (rueda del mouse) y la línea de tiempo. Aparece sola cuando JARVIS
pone música y se va cuando la música se cierra. Anda en modo juego (la ventana principal duerme, esta no) y no le
saca el foco al juego al tocarla. Se puede arrastrar a donde quieras: se acuerda del lugar.

Si no suena la música de JARVIS, maneja lo que suene en otras apps (YouTube en Opera GX, Spotify, Chrome...) con el
control de medios de Windows (medios.py). En modo juego aparece sola si esa música está sonando; fuera del modo
juego, con Ctrl+Alt+M.

Atajos de teclado (andan adentro de los juegos, incluso en pantalla completa, donde la barrita no se ve):
  Ctrl+Alt+Espacio  play / pausa          Ctrl+Alt+.  siguiente      Ctrl+Alt+,  anterior
  Ctrl+Alt++        más volumen           Ctrl+Alt+-  menos volumen  Ctrl+Alt+M  mostrar / esconder la barrita
Y mientras suena la música de JARVIS, las teclas multimedia del teclado (play/pausa, siguiente, anterior) también.

Es translúcida (azulada, en degradado) y se esconde sola: a los pocos segundos se desliza hacia el borde de la
pantalla más cercano (arriba, abajo, izquierda o derecha) desvaneciéndose; no tapa ni molesta en el juego, y los
clics pasan de largo. Vuelve a donde la dejaste al pasar el mouse por ahí, al cambiar el tema, al pausar o con
los atajos.
"""
import ctypes
import ctypes.wintypes as wt
import json
import os
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

ACTIVA = True  # Configuraciones > "Barrita de música flotante"
# La barrita vieja ya no se abre: la música se ve y se maneja en la píldora (también jugando: se asoma unos segundos,
# translúcida y sin agarrar clics). Este módulo sigue con los atajos de teclado y con manejar la música; lo de la
# ventanita queda por si algún día se vuelve atrás (PILDORA = False)
PILDORA = True
AUTO_ESCONDER = True  # Configuraciones > "La barrita se esconde sola"
BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_POS = os.path.join(BASE, "barra_musica.json")  # dónde la dejaste
ANCHO, ALTO = 440, 76
ALFA_VISIBLE = 215    # qué tan opaca se ve (de 0 a 255): translúcida, se ve lo que hay atrás
ALFA_FANTASMA = 0     # escondida: desaparece del todo (vuelve al pasar el mouse por donde está)
SEGUNDOS_A_LA_VISTA = 4  # cuánto se queda a la vista después de un cambio (tema nuevo, pausa, un atajo)
WS_EX_LAYERED, WS_EX_TRANSPARENT = 0x80000, 0x20   # translúcida / que los clics la atraviesen

_ventana = [None]
_estado = {"escondida": False, "lista": False, "pendiente": False, "auto": False, "imagen": None,
           "hwnd": None, "fantasma": False, "despierta_hasta": 0.0, "ultimo": None, "vigila_mouse": False}
_lock = threading.Lock()
_lock_empuje = threading.Lock()
_hay_cambios = threading.Event()


# ---------- La ventanita ----------

class Api:
    """Lo que puede pedir la barrita (botones, rueda del mouse, línea de tiempo)."""

    def control(self, accion, valor=None):
        threading.Thread(target=_controlar, args=(accion, valor), daemon=True).start()

    def estado(self):
        return _para_la_barra()

    def esconder(self):
        esconder()


def _ui_disponible():
    return bool(jarvis and jarvis.oyentes)


def _arriba_al_centro():
    try:
        import webview

        escala = ctypes.windll.shcore.GetScaleFactorForDevice(0) / 100
        pantalla = webview.screens[0]
        return int((pantalla.width / escala - ANCHO) / 2), 14
    except Exception:
        return 460, 14


def _todas_las_pantallas():
    """(x, y, ancho, alto) de todas las pantallas juntas, en las mismas unidades que la posición guardada."""
    user32 = ctypes.windll.user32
    x, y, ancho, alto = (user32.GetSystemMetrics(i) for i in (76, 77, 78, 79))   # la pantalla "virtual"
    try:   # si el programa ve los píxeles de verdad (125 %: más grandes que las unidades de la ventana), se pasan
        user32.GetThreadDpiAwarenessContext.restype = ctypes.c_void_p
        user32.GetAwarenessFromDpiAwarenessContext.argtypes = [ctypes.c_void_p]
        reales = user32.GetAwarenessFromDpiAwarenessContext(user32.GetThreadDpiAwarenessContext()) > 0
    except Exception:
        reales = False
    escala = ctypes.windll.shcore.GetScaleFactorForDevice(0) / 100 if reales else 1
    return x / escala, y / escala, ancho / escala, alto / escala


def _posicion():
    """La última posición donde la dejaste (siempre dentro de la pantalla); si no, arriba al centro."""
    try:
        with open(ARCHIVO_POS, encoding="utf-8") as f:
            x, y = json.load(f)["xy"]
        x, y = int(x), int(y)
    except (OSError, ValueError, KeyError, TypeError):
        return _arriba_al_centro()
    try:   # arrastrada contra un borde queda unos píxeles afuera ({"xy": [0, -8]}): se la entra
        px, py, ancho, alto = _todas_las_pantallas()
        if ancho > ANCHO and alto > ALTO:
            x = int(min(max(x, px), px + ancho - ANCHO))
            y = int(min(max(y, py), py + alto - ALTO))
    except Exception:
        pass
    return x, y


def donde_esta():
    """«arriba a la izquierda», «abajo al centro»...: dónde queda (para decírtelo cuando la pedís)."""
    if PILDORA:
        return "arriba, en la píldora"
    try:
        import webview

        x, y = _posicion()
        escala = ctypes.windll.shcore.GetScaleFactorForDevice(0) / 100
        ancho, alto = webview.screens[0].width / escala, webview.screens[0].height / escala
    except Exception:
        return ""
    cx, cy = (x + ANCHO / 2) / ancho, (y + ALTO / 2) / alto
    lado = "a la izquierda" if cx < 0.34 else "a la derecha" if cx > 0.66 else "al centro"
    if cy < 0.34:
        return f"arriba {lado}"
    if cy > 0.66:
        return f"abajo {lado}"
    return "en el medio de la pantalla" if lado == "al centro" else f"{lado}, a media altura"


def _guardar_posicion(x, y):
    if _estado["fantasma"] or _estado.get("animando"):
        return   # se está escondiendo o volviendo: ese no es el lugar donde la dejaste
    _escribir_posicion(x, y)


def _escribir_posicion(x, y):
    try:
        with open(ARCHIVO_POS + ".tmp", "w", encoding="utf-8") as f:
            json.dump({"xy": [int(x), int(y)]}, f)
        os.replace(ARCHIVO_POS + ".tmp", ARCHIVO_POS)
    except OSError:
        pass


def _ajustar_ventana(v):
    """Esquinas redondeadas (Windows 11), sin botón en la barra de tareas ni en Alt+Tab, que tocarla NO le saque
    el foco al juego (WS_EX_NOACTIVATE) y translúcida (WS_EX_LAYERED: Windows la mezcla con lo que hay atrás)."""
    try:
        hwnd = int(str(v.native.Handle.ToInt64()))
        user32, dwm = ctypes.windll.user32, ctypes.windll.dwmapi
        redondo = ctypes.c_int(2)  # DWMWCP_ROUND
        dwm.DwmSetWindowAttribute(wt.HWND(hwnd), 33, ctypes.byref(redondo), ctypes.sizeof(redondo))
        GWL_EXSTYLE, WS_EX_TOOLWINDOW, WS_EX_NOACTIVATE, WS_EX_APPWINDOW = -20, 0x80, 0x08000000, 0x40000
        user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
        user32.SetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_ssize_t]
        estilo = user32.GetWindowLongPtrW(wt.HWND(hwnd), GWL_EXSTYLE)
        user32.SetWindowLongPtrW(wt.HWND(hwnd), GWL_EXSTYLE,
                                 (estilo | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_LAYERED)
                                 & ~WS_EX_APPWINDOW & ~WS_EX_TRANSPARENT)
        user32.SetLayeredWindowAttributes(wt.HWND(hwnd), 0, ALFA_VISIBLE, 2)  # LWA_ALPHA: translúcida
        if _estado["fantasma"] and _estado.get("casa"):   # estaba escondida (corrida): vuelve a su lugar
            user32.SetWindowPos(wt.HWND(hwnd), wt.HWND(-1), *_estado["casa"], 0, 0, 0x0001 | 0x0010)
        _estado.update(hwnd=hwnd, fantasma=False)
        user32.SetWindowPos(wt.HWND(hwnd), wt.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0020)  # TOPMOST,
        # sin mover, sin cambiar tamaño, sin activar, y aplicando el estilo nuevo
        if user32.IsWindowVisible(wt.HWND(hwnd)) and not _estado["escondida"]:
            user32.ShowWindow(wt.HWND(hwnd), 0)  # SW_HIDE y SW_SHOWNOACTIVATE: así sale de la barra de tareas
            user32.ShowWindow(wt.HWND(hwnd), 4)
        despertar()   # recién aparecida: a la vista unos segundos, después se esconde sola
        if not _estado["vigila_mouse"]:
            _estado["vigila_mouse"] = True
            threading.Thread(target=_esconder_sola, daemon=True).start()
    except Exception as e:
        _registrar(f"barrita: no pude ajustar la ventana ({e})")


# ---------- Se esconde sola: se desliza hacia el borde más cercano y vuelve a donde la dejaste ----------

def despertar(segundos=None):
    """Que se vea unos segundos (un tema nuevo, una pausa, un atajo...). Después vuelve a esconderse sola."""
    segundos = segundos or SEGUNDOS_A_LA_VISTA
    _estado["despierta_hasta"] = max(_estado["despierta_hasta"], time.time() + segundos)
    if PILDORA:
        _a_la_pildora(lambda p: p.asomar_musica(segundos))


def _a_la_pildora(hacer):
    try:
        hacer(jarvis.pildora)
    except Exception:
        pass


def _la_llaman():
    """¿El mouse está donde la dejaste? (se mira la posición: escondida, el mouse la atraviesa y además está corrida)"""
    user32 = ctypes.windll.user32
    caja, punto = wt.RECT(), wt.POINT()
    if not user32.GetWindowRect(wt.HWND(_estado["hwnd"]), ctypes.byref(caja)) or not user32.GetCursorPos(ctypes.byref(punto)):
        return False
    if _estado["fantasma"] and _estado.get("casa"):   # escondida: se mira su lugar, no dónde quedó
        x, y = _estado["casa"]
        caja.left, caja.right, caja.top, caja.bottom = x, x + caja.right - caja.left, y, y + caja.bottom - caja.top
    return caja.left - 6 <= punto.x <= caja.right + 6 and caja.top - 6 <= punto.y <= caja.bottom + 6


PASOS_DESVANECER = 20   # el desvanecido: 20 pasos de 18 ms (algo más de un tercio de segundo)
CERCA_DEL_BORDE = 120   # píxeles: si la dejaste así de cerca de un borde, al esconderse sale de la pantalla por ahí


class _InfoMonitor(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_ulong), ("rcMonitor", wt.RECT), ("rcWork", wt.RECT), ("dwFlags", ctypes.c_ulong)]


def _hacia_donde(caja):
    """Para qué lado se va al esconderse: hacia el borde de la pantalla que tenga más cerca (arriba, abajo, izquierda o
    derecha). Devuelve cuánto se mueve (dx, dy). Pegada a un borde, sale de la pantalla por ahí; en el medio, se
    corre lo que mide de alto (y se desvanece)."""
    user32 = ctypes.windll.user32
    info = _InfoMonitor()
    info.cbSize = ctypes.sizeof(_InfoMonitor)
    user32.MonitorFromWindow.restype = wt.HMONITOR
    user32.GetMonitorInfoW(user32.MonitorFromWindow(wt.HWND(_estado["hwnd"]), 1), ctypes.byref(info))
    pantalla = info.rcMonitor
    ancho, alto = caja.right - caja.left, caja.bottom - caja.top
    # (distancia a ese borde, hacia dónde se mueve, lo que mide en esa dirección)
    bordes = [(caja.top - pantalla.top, (0, -1), alto), (pantalla.bottom - caja.bottom, (0, 1), alto),
              (caja.left - pantalla.left, (-1, 0), ancho), (pantalla.right - caja.right, (1, 0), ancho)]
    distancia, (dx, dy), medida = min(bordes, key=lambda b: b[0])
    recorrido = max(distancia, 0) + medida if distancia <= CERCA_DEL_BORDE else alto
    return dx * recorrido, dy * recorrido


def _poner_fantasma(si):
    """Escondida (se va hacia el borde más cercano desvaneciéndose, y los clics pasan de largo) o a la vista (vuelve
    a donde la dejaste y aparece). Se mueve de a poco."""
    user32 = ctypes.windll.user32
    hwnd = wt.HWND(_estado["hwnd"])
    user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.SetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_ssize_t]
    estilo = user32.GetWindowLongPtrW(hwnd, -20) | WS_EX_LAYERED
    caja = wt.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(caja))
    if si or not _estado.get("casa"):
        _estado["casa"] = (caja.left, caja.top)   # donde la dejaste: ahí vuelve
        ancho, alto = caja.right - caja.left, caja.bottom - caja.top
        caja.left, caja.top = _estado["casa"]
        caja.right, caja.bottom = caja.left + ancho, caja.top + alto
        _estado["corrida"] = _hacia_donde(caja)
    (x_casa, y_casa), (dx, dy) = _estado["casa"], _estado.get("corrida", (0, 0))
    afuera, adentro = (x_casa + dx, y_casa + dy), (x_casa, y_casa)
    if si:
        (alfa_desde, desde), (alfa_hasta, hasta) = (ALFA_VISIBLE, adentro), (ALFA_FANTASMA, afuera)
    else:   # primero que se pueda tocar, después que vuelva y aparezca
        user32.SetWindowLongPtrW(hwnd, -20, estilo & ~WS_EX_TRANSPARENT)
        (alfa_desde, desde), (alfa_hasta, hasta) = (ALFA_FANTASMA, afuera), (ALFA_VISIBLE, adentro)
    _estado["animando"] = True
    try:
        for paso in range(1, PASOS_DESVANECER + 1):
            avance = paso / PASOS_DESVANECER
            suave = avance * avance * (3 - 2 * avance)   # empieza y termina despacio (no de golpe)
            user32.SetLayeredWindowAttributes(hwnd, 0, round(alfa_desde + (alfa_hasta - alfa_desde) * suave), 2)
            user32.SetWindowPos(hwnd, wt.HWND(-1), round(desde[0] + (hasta[0] - desde[0]) * suave),
                                round(desde[1] + (hasta[1] - desde[1]) * suave), 0, 0,
                                0x0001 | 0x0010)   # sin cambiar el tamaño ni activarla
            time.sleep(0.018)
        if si:
            user32.SetWindowLongPtrW(hwnd, -20, estilo | WS_EX_TRANSPARENT)
        _estado["fantasma"] = si
    finally:
        time.sleep(0.05)   # que lleguen los avisos de "se movió" antes de volver a guardar el lugar
        _estado["animando"] = False


def _esconder_sola():
    """Mira cada 0,15 s: con el mouse donde está o después de un cambio, a la vista; si no, escondida."""
    while True:
        time.sleep(0.15)
        try:
            if _ventana[0] is None or _estado["escondida"] or not _estado["hwnd"]:
                continue
            if _la_llaman():
                despertar(1.5)   # sacás el mouse y se queda un ratito, por si volvés
            ver = not AUTO_ESCONDER or time.time() < _estado["despierta_hasta"]
            if ver == _estado["fantasma"]:   # cambió lo que tiene que pasar
                _poner_fantasma(not ver)
        except Exception:
            time.sleep(1)


def _de_jarvis():
    return jarvis.musica.estado.get("modo") == "jarvis"


def mostrar():
    """Muestra la barrita con la música de JARVIS (si está activada en Configuraciones)."""
    if not ACTIVA or not _ui_disponible() or not _de_jarvis():
        return
    _mostrar_ventana()
    registrar_multimedia(True)


def mostrar_externo(auto=False):
    """Muestra la barrita con lo que suena en otra app (Opera, Spotify...). auto=True: la abrió el modo juego."""
    if not ACTIVA or not _ui_disponible() or _de_jarvis():
        return mostrar()
    if not jarvis.medios.actual():
        return False
    _estado["auto"] = auto
    _mostrar_ventana()
    threading.Thread(target=_vigilar_externo, daemon=True).start()
    return True


A_LA_VISTA_SI_LA_PEDIS = 15   # segundos: pedida, se queda más que con un tema nuevo (en 4 no llegabas a verla)


def mostrar_a_pedido(segundos=A_LA_VISTA_SI_LA_PEDIS):
    """'Abrí el reproductor de música': la barrita aparece SIEMPRE que la pidas (con o sin modo juego, aunque esté
    apagada en Configuraciones y aunque no suene nada: en ese caso dice "No suena nada" y espera a que pongas algo).
    Devuelve qué muestra: "jarvis", "externo", "nada" o None si la ventana de JARVIS no está abierta."""
    if not _ui_disponible():
        return None
    _estado["a_mano"] = False
    _estado["fijo"] = True  # la pediste: no se va sola aunque no suene nada
    despertar(segundos)
    if _de_jarvis():
        _mostrar_ventana()
        registrar_multimedia(True)
        return "jarvis"
    try:
        suena = bool(jarvis.medios.disponible() and jarvis.medios.actual())
    except Exception:
        suena = False
    _estado["auto"] = False
    _mostrar_ventana()
    threading.Thread(target=_vigilar_externo, daemon=True).start()
    return "externo" if suena else "nada"


def traer_a_la_vista():
    """«No la veo»: la pone arriba al centro de la pantalla principal y la deja a la vista un buen rato."""
    if PILDORA:
        _a_la_pildora(lambda p: p.asomar_musica(30))
        return "pildora"
    x, y = _arriba_al_centro()
    _escribir_posicion(x, y)   # si todavía no existe, se crea ahí
    ya_estaba = _ventana[0] is not None
    que = mostrar_a_pedido(25)
    if que is None:
        return None
    if ya_estaba:
        for _ in range(20):   # si estaba escondida, que termine de volver (escondida no se guarda el lugar)
            if not _estado["fantasma"] and not _estado.get("animando"):
                break
            time.sleep(0.1)
        try:
            _ventana[0].move(x, y)
        except Exception:
            pass
    return que


def _mostrar_ventana():
    _estado["escondida"] = False
    if PILDORA:   # (la barrita ya no: la música, en la píldora)
        _a_la_pildora(lambda p: p.asomar_musica(max(SEGUNDOS_A_LA_VISTA, _estado["despierta_hasta"] - time.time())))
        return
    with _lock:
        v = _ventana[0]
        if v is None:
            _crear()
        else:
            try:
                v.show()
                _ajustar_ventana(v)
            except Exception:
                pass
    _estado["imagen"] = None  # que vuelva a mandar la tapa
    actualizar()


def _vigilar_externo():
    """Mientras la barrita muestra la música de otra app: cada 2 s pregunta cómo va (esa app no avisa sola)."""
    if _estado.get("vigilando") or PILDORA:   # (la píldora se fija sola, en su proceso)
        return
    _estado["vigilando"] = True
    try:
        sin_nada = 0
        while _ventana[0] is not None and not _estado["escondida"] and not _de_jarvis():
            try:
                suena = jarvis.medios.actual()
            except Exception:
                suena = None
            if suena:
                sin_nada = 0
                actualizar()
            elif _estado.get("fijo"):
                actualizar()  # la pediste vos: se queda (dice "No suena nada") hasta que la escondas
            else:
                sin_nada += 1
                if sin_nada >= 3:  # cerraste la pestaña o la app: la barrita se va
                    esconder(a_mano=False)
                    break
            time.sleep(2)
    finally:
        _estado["vigilando"] = False


def _crear():
    import webview

    x, y = _posicion()
    # focus=False: pywebview la crea sin activarla (y sin que tocarla le saque el foco al juego)
    v = webview.create_window("JARVIS · Barrita de música", url=os.path.join(BASE, "interfaz", "barra_musica.html"),
                              js_api=Api(), width=ANCHO, height=ALTO, x=x, y=y, resizable=False, frameless=True,
                              easy_drag=True, on_top=True, focus=False, shadow=True, background_color="#0a2140")
    _ventana[0] = v
    _estado.update(escondida=False, lista=False)
    v.events.loaded += lambda: _al_cargar(v)
    v.events.moved += lambda x, y: _guardar_posicion(x, y)
    v.events.closed += _al_cerrar_ventana
    return v


def _al_cargar(v):
    _ajustar_ventana(v)
    _estado["lista"] = True
    actualizar()


def _al_cerrar_ventana():
    _ventana[0] = None
    _estado["lista"] = False


def esconder(a_mano=True):
    v = _ventana[0]
    _estado["fijo"] = False
    if PILDORA:
        _a_la_pildora(lambda p: p.esconder_musica())
        return
    if v is not None:
        _estado["escondida"] = True
        _estado["a_mano"] = a_mano  # escondida por vos: el modo juego no la vuelve a abrir sola
        try:
            v.hide()
        except Exception:
            pass


def alternar():
    """Ctrl+Alt+M: muestra o esconde la barrita."""
    if PILDORA:
        _a_la_pildora(lambda p: p.alternar_musica())
        return
    v = _ventana[0]
    if v is None or _estado["escondida"]:
        _estado["a_mano"] = False
        if _de_jarvis():
            mostrar()
        else:
            mostrar_externo()
    else:
        esconder()


def cerrar():
    """La música se cerró: se va la barrita (en otro hilo: esto se llama desde eventos de pywebview)."""
    registrar_multimedia(False)

    def _cerrar():
        v = _ventana[0]
        _ventana[0] = None
        if v is not None:
            try:
                v.destroy()
            except Exception:
                pass
    threading.Thread(target=_cerrar, daemon=True).start()


def _para_la_barra():
    juego = jarvis.herramientas.modo_juego.is_set()
    if _de_jarvis():
        e = jarvis.musica.estado
        d = {"titulo": e.get("titulo") or "", "canal": e.get("canal") or "", "pausado": bool(e.get("pausado")),
             "volumen": e.get("volumen", 100), "actual": e.get("actual") or 0, "duracion": e.get("duracion") or 0,
             "anuncio": bool(e.get("anuncio")), "video": bool(e.get("video_visible")), "juego": juego, "externo": False,
             "imagen": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg" if e.get("id") else ""}
    else:
        d = jarvis.medios.para_la_barra() or {"titulo": "", "canal": "", "pausado": True, "actual": 0, "duracion": 0}
        d.update(juego=juego, externo=True, imagen=d.pop("tapa", ""))
    # la tapa (de Opera viene como imagen de ~30 KB) se manda solo cuando cambia
    if d.get("imagen") == _estado["imagen"]:
        d.pop("imagen", None)
    else:
        _estado["imagen"] = d.get("imagen")
    return d


def _controlar(accion, valor=None):
    """Un botón o la rueda de la barrita: a la música de JARVIS o a la de la otra app."""
    despertar()   # con un atajo (jugando) también se ve un momento qué pasó
    if _de_jarvis():
        jarvis.musica.control(accion, valor)
    elif accion == "cerrar":  # la pestaña de Opera no se cierra desde acá: se esconde la barrita
        esconder()
        return
    elif accion == "volumen" and valor is not None:
        jarvis.medios.volumen_general(int(valor))
    elif accion in ("subir", "bajar"):
        jarvis.medios.volumen_general(cambio=10 if accion == "subir" else -10)
    else:
        jarvis.medios.control(accion, valor)
        time.sleep(0.4)  # la otra app tarda un momento en cambiar
    actualizar()


def actualizar():
    """Le pasa a la barrita cómo está la música. No bloquea nunca a quien la llama (a veces es el hilo de la
    ventana, y esperar ahí la respuesta de la barrita la trababa): lo hace un hilo aparte."""
    _hay_cambios.set()
    with _lock_empuje:
        if _estado["pendiente"]:
            return  # ya hay un hilo empujando: va a ver el cambio
        _estado["pendiente"] = True
    threading.Thread(target=_empujar, daemon=True).start()


def _empujar():
    while True:
        while _hay_cambios.is_set():
            _hay_cambios.clear()
            v = _ventana[0]
            if v is None or not _estado["lista"]:
                break
            try:
                datos = _para_la_barra()
                cambio = (datos.get("titulo"), datos.get("pausado"))
                if cambio != _estado["ultimo"]:
                    if _estado["ultimo"] is not None:
                        despertar()   # tema nuevo o pausa: se ve un momento y se vuelve a esconder
                    _estado["ultimo"] = cambio
                v.evaluate_js(f"window.actualizar && actualizar({json.dumps(datos)})")
            except Exception:
                break
        with _lock_empuje:
            if not _hay_cambios.is_set() or _ventana[0] is None or not _estado["lista"]:
                _estado["pendiente"] = False  # (si llegó un cambio justo ahora, se vuelve a empujar)
                return


# ---------- Atajos de teclado (andan adentro de los juegos) ----------

MOD_ALT, MOD_CONTROL, MOD_NOREPEAT = 0x1, 0x2, 0x4000
WM_HOTKEY, WM_APP = 0x0312, 0x8000
ATAJOS = {  # id -> (teclas, acción, cómo se muestra)
    1: (0x20, "alternar", "Ctrl+Alt+Espacio"),
    2: (0xBE, "siguiente", "Ctrl+Alt+."), 3: (0xBC, "anterior", "Ctrl+Alt+,"),
    4: (0xBB, "subir", "Ctrl+Alt++"), 5: (0x6B, "subir", None),  # + del teclado y del teclado numérico
    6: (0xBD, "bajar", "Ctrl+Alt+-"), 7: (0x6D, "bajar", None),
    8: (0x4D, "barra", "Ctrl+Alt+M"),
}
MULTIMEDIA = {20: (0xB3, "alternar"), 21: (0xB0, "siguiente"), 22: (0xB1, "anterior")}  # sin Ctrl+Alt
_hilo_atajos = {"id": None, "registrados": [], "multimedia": False}


def iniciar_atajos():
    """Arranca el hilo que escucha los atajos (una sola vez) y el que muestra la barrita al jugar."""
    if _hilo_atajos["id"] is not None:
        return
    listo = threading.Event()
    threading.Thread(target=_bucle_atajos, args=(listo,), daemon=True).start()
    threading.Thread(target=_vigilar_juego, daemon=True).start()
    listo.wait(3)


def _vigilar_juego():
    """En modo juego: si suena música en otra app (YouTube en Opera...), la barrita aparece sola para manejarla.
    Si la escondiste, no vuelve hasta Ctrl+Alt+M. Al terminar de jugar, la que abrió sola se va."""
    if PILDORA:
        return   # (la píldora se asoma sola con cada tema nuevo, sin quedarse encima del juego)
    while True:
        time.sleep(3)
        try:
            jugando = jarvis.herramientas.modo_juego.is_set()
            visible = _ventana[0] is not None and not _estado["escondida"]
            if jugando and ACTIVA and not visible and not _estado.get("a_mano") and not _de_jarvis():
                s = jarvis.medios.actual()
                if s and s["estado"] == "reproduciendo":
                    mostrar_externo(auto=True)
            elif not jugando and visible and _estado["auto"] and not _de_jarvis():
                _estado["auto"] = False
                esconder(a_mano=False)
            if not jugando:
                _estado["a_mano"] = False
        except Exception:
            pass


def _bucle_atajos(listo):
    user32 = ctypes.windll.user32
    _hilo_atajos["id"] = ctypes.windll.kernel32.GetCurrentThreadId()
    msg = wt.MSG()
    user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 0)  # crea la cola de mensajes del hilo
    for id_, (vk, _, nombre) in ATAJOS.items():
        if user32.RegisterHotKey(None, id_, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, vk):
            _hilo_atajos["registrados"].append(nombre or "")
        elif nombre:
            _registrar(f"barrita: el atajo {nombre} ya lo usa otro programa")
    listo.set()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        if msg.message == WM_HOTKEY:
            accion = (ATAJOS.get(msg.wParam) or MULTIMEDIA.get(msg.wParam) or (None, None))[1]
            if accion:
                threading.Thread(target=_atajo, args=(accion,), daemon=True).start()
        elif msg.message == WM_APP + 1:  # registrar / soltar las teclas multimedia
            if msg.wParam and not _hilo_atajos["multimedia"]:
                for id_, (vk, _) in MULTIMEDIA.items():
                    user32.RegisterHotKey(None, id_, MOD_NOREPEAT, vk)
                _hilo_atajos["multimedia"] = True
            elif not msg.wParam and _hilo_atajos["multimedia"]:
                for id_ in MULTIMEDIA:
                    user32.UnregisterHotKey(None, id_)
                _hilo_atajos["multimedia"] = False


def registrar_multimedia(si):
    """Las teclas multimedia manejan la música de JARVIS solo mientras suena (si no, son de Spotify, Opera...)."""
    if _hilo_atajos["id"] is not None:
        ctypes.windll.user32.PostThreadMessageW(_hilo_atajos["id"], WM_APP + 1, 1 if si else 0, 0)


def _atajo(accion):
    if accion == "barra":
        alternar()
        return
    if not _de_jarvis() and not jarvis.medios.actual():
        return  # no suena nada en ningún lado
    _controlar(accion)


def _registrar(texto):
    try:
        with open(os.path.join(BASE, "errores_interfaz.log"), "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {texto}\n")
    except OSError:
        pass
