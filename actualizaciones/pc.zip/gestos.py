"""Control del mouse con la mano (webcam + MediaPipe). JARVIS lo abre en un proceso aparte con "activá los gestos".

Gestos (con la palma mirando a la cámara):
  ☝  mano/índice ................ mueve el cursor (sigue el nudillo del índice: no salta al hacer clic)
  🤏 pulgar + índice juntos ...... clic; si los mantenés juntos, ARRASTRA (mover ventanas, archivos)
     pulgar + mayor juntos ....... clic derecho
  ✌  índice + mayor levantados ... scroll tipo joystick: subí o bajá la mano desde donde empezaste
                                   (se activa con la mano QUIETA un instante: moviéndola, siempre apunta)
  ✊ puño ........................ congela el cursor (para acomodarte sin mover nada)
  🖐 mano abierta y QUIETA 2,5 s . pausa / reanuda el control (moviéndola abierta no se pausa)

Para que no sea "nervioso":
  - Filtro One Euro: si la mano se mueve despacio filtra mucho (sin temblor); si se mueve rápido, responde ya.
  - Clic con histéresis: los dedos tienen que estar BIEN juntos varios cuadros para hacer clic, y separarse
    bastante para soltar. Al hacer clic el cursor se queda quieto un instante para no correrse.
  - Para cambiar de gesto (scroll, puño...) hay que mantenerlo unos cuadros: un gesto de un instante no cuenta.
Ajustes en gestos_config.json (o por voz: "gestos menos sensibles", "gestos más rápidos").

Habla con JARVIS por líneas JSON (salida): {"listo"}, {"vivo": imagen}, {"gesto": "..."}, {"foto": jpg}, {"error"}
Entrada: "foto" (foto grande para que la IA la mire), "config" (recargar ajustes) o "salir".
"""
import base64
import ctypes
import json
import math
import os
import sys
import threading
import time

BASE = os.path.dirname(os.path.abspath(__file__))
MODELO = os.path.join(BASE, "modelos", "hand_landmarker.task")
ARCHIVO_AJUSTES = os.path.join(BASE, "gestos_config.json")
CAMARA = 0
VIVO_FPS = 8  # cuadros por segundo que se mandan a la ventana de JARVIS

SIN_MOUSE = os.environ.get("JARVIS_GESTOS_SIN_MOUSE") == "1"  # para pruebas: detecta pero no mueve nada


# ======================= Ajustes =======================

def cargar_ajustes():
    """sensibilidad: 1 (muy tranquilo) a 5 (muy sensible). velocidad: 1 (hay que mover mucho la mano) a 5 (poco).
    modo: "relativo" (como un touchpad: se mueve según cuánto y qué tan rápido movés la mano) o
          "absoluto" (cada punto de la cámara es un punto fijo de la pantalla)."""
    ajustes = {"sensibilidad": 2, "velocidad": 2, "modo": "relativo"}
    try:
        with open(ARCHIVO_AJUSTES, encoding="utf-8") as f:
            for k, v in json.load(f).items():
                if k in ("sensibilidad", "velocidad"):
                    ajustes[k] = max(1, min(5, int(v)))
                elif k == "modo" and v in ("relativo", "absoluto"):
                    ajustes[k] = v
    except (OSError, ValueError):
        pass
    s, v = ajustes["sensibilidad"], ajustes["velocidad"]
    margen = {1: 0.06, 2: 0.12, 3: 0.17, 4: 0.21, 5: 0.25}[v]
    return {
        **ajustes,
        # modo relativo: ganancia según la velocidad de la mano (despacio = preciso, rápido = cruza la pantalla)
        # (antes 0.35-2.6: para cruzar la pantalla había que mover medio brazo)
        "ganancia_min": 0.5, "ganancia_max": 4.2,
        "vel_lenta": 70, "vel_rapida": 800,          # en "píxeles virtuales" por segundo (imagen a 1920 de ancho)
        "factor": {1: 0.75, 2: 1.0, 3: 1.25, 4: 1.55, 5: 1.9}[v],
        "vel_quieta": {1: 30, 2: 22, 3: 15, 4: 10, 5: 6}[s],  # más lento que esto es temblor, no movimiento
        "min_cutoff": {1: 0.2, 2: 0.3, 3: 0.5, 4: 0.8, 5: 1.2}[s],   # más bajo = más suave (menos temblor)
        "beta": 0.003,                                                # cuánto se "suelta" el filtro al ir rápido
        "zona": (margen, margen, 1 - margen, 1 - margen),             # parte de la imagen = toda la pantalla
        "pellizco_on": {1: 0.20, 2: 0.23, 3: 0.26, 4: 0.29, 5: 0.32}[s],  # qué tan juntos para hacer clic
        "pellizco_off": {1: 0.36, 2: 0.38, 3: 0.40, 4: 0.42, 5: 0.44}[s],  # qué tan separados para soltar
        "cuadros_clic": {1: 4, 2: 3, 3: 3, 4: 2, 5: 2}[s],            # cuadros seguidos para confirmar un clic
        "cuadros_gesto": {1: 5, 2: 4, 3: 3, 4: 3, 5: 2}[s],           # cuadros seguidos para cambiar de gesto
        "zona_muerta_px": {1: 6, 2: 5, 3: 3, 4: 2, 5: 1}[s],          # movimientos más chicos se ignoran
        "quieto_al_clic": 0.25,                                       # segundos sin mover el cursor al hacer clic
        # la pausa y el scroll solo se activan con la mano casi quieta (en "anchos de imagen" por segundo): si la
        # estás moviendo, estás apuntando (antes moviendo la mano abierta se pausaba sola)
        "mano_quieta": 0.12,
        "segundos_pausa": 2.5,
    }


# ======================= Filtro One Euro =======================

class OneEuro:
    """Filtro adaptativo (Casiez et al.): suaviza mucho a baja velocidad y poco a alta velocidad."""

    def __init__(self, min_cutoff, beta, d_cutoff=1.0):
        self.min_cutoff, self.beta, self.d_cutoff = min_cutoff, beta, d_cutoff
        self.x = self.dx = self.t = None

    @staticmethod
    def _alfa(cutoff, dt):
        tau = 1 / (2 * math.pi * cutoff)
        return 1 / (1 + tau / dt)

    def __call__(self, x, t):
        if self.x is None:
            self.x, self.dx, self.t = x, 0.0, t
            return x
        dt = max(1e-3, t - self.t)
        dx = (x - self.x) / dt
        self.dx += self._alfa(self.d_cutoff, dt) * (dx - self.dx)
        cutoff = self.min_cutoff + self.beta * abs(self.dx)
        self.x += self._alfa(cutoff, dt) * (x - self.x)
        self.t = t
        return self.x

    def reiniciar(self):
        self.x = self.dx = self.t = None


# ======================= Lógica de gestos (sin cámara ni mouse: se puede probar sola) =======================

def distancia(a, b):
    return ((a.x - b.x) ** 2 + (a.y - b.y) ** 2) ** 0.5


def dedos_levantados(p):
    """[pulgar, índice, mayor, anular, meñique]: levantado si la punta está claramente más lejos de la muñeca."""
    muneca = p[0]
    levantados = [distancia(p[4], p[17]) > distancia(p[3], p[17]) * 1.05]
    for punta, articulacion in ((8, 6), (12, 10), (16, 14), (20, 18)):
        levantados.append(distancia(p[punta], muneca) > distancia(p[articulacion], muneca) * 1.12)
    return levantados


class ControlGestos:
    """Recibe los puntos de la mano en cada cuadro y devuelve qué hacer con el mouse."""

    def __init__(self, ancho_pantalla, alto_pantalla, posicion_inicial):
        self.ancho, self.alto = ancho_pantalla, alto_pantalla
        self.cx, self.cy = posicion_inicial
        self.recargar()
        self.modo = "mover"
        self.candidato, self.repeticiones = "mover", 0
        self.apretado = False
        self.cuadros_pellizco = self.cuadros_derecho = 0
        self.quieto_hasta = 0.0
        self.ultimo_derecho = 0.0
        self.pausado = False
        self.abierta_desde = None
        self.scroll_origen = None
        self.scroll_acumulado = 0.0
        self.ultimo_t = None
        self.previo = None          # modo relativo: dónde estaba la mano en el cuadro anterior
        self.resto = [0.0, 0.0]     # fracciones de píxel que se van acumulando (movimientos finos)
        self.centro = None          # centro de la mano en el cuadro anterior (para saber si está quieta)
        self.vel_mano = 0.0         # qué tan rápido se mueve la mano (promedio suave)

    def recargar(self):
        self.a = cargar_ajustes()
        self.fx = OneEuro(self.a["min_cutoff"], self.a["beta"])
        self.fy = OneEuro(self.a["min_cutoff"], self.a["beta"])
        self.previo = None

    def _ganancia(self, velocidad):
        """Curva de aceleración: despacio mueve poco (preciso), rápido mueve mucho."""
        a = self.a
        s = min(1.0, max(0.0, (velocidad - a["vel_lenta"]) / (a["vel_rapida"] - a["vel_lenta"]))) ** 1.5
        return (a["ganancia_min"] + (a["ganancia_max"] - a["ganancia_min"]) * s) * a["factor"]

    def _mover_relativo(self, nx, ny, t, dt):
        """Como un touchpad: mueve según cuánto y qué tan rápido se movió la mano desde el cuadro anterior."""
        vx, vy = self.fx(nx * 1920, t), self.fy(ny * 1920, t)  # filtrado, en píxeles virtuales
        if self.previo is None or t < self.quieto_hasta:
            self.previo = (vx, vy)  # (al hacer clic, el movimiento de ese instante se descarta)
            return None
        dx, dy = vx - self.previo[0], vy - self.previo[1]
        self.previo = (vx, vy)
        velocidad = math.hypot(dx, dy) / max(dt, 1e-3)
        if velocidad < self.a["vel_quieta"]:
            return None  # es el temblor de la mano / del detector
        g = self._ganancia(velocidad)
        self.resto[0] += dx * g
        self.resto[1] += dy * g
        mx, my = int(self.resto[0]), int(self.resto[1])
        if not mx and not my:
            return None
        self.resto[0] -= mx
        self.resto[1] -= my
        self.cx = min(self.ancho - 1, max(0, self.cx + mx))
        self.cy = min(self.alto - 1, max(0, self.cy + my))
        return ("mover", int(self.cx), int(self.cy))

    def _a_pantalla(self, x, y):
        x1, y1, x2, y2 = self.a["zona"]
        fx = min(1, max(0, (x - x1) / (x2 - x1)))
        fy = min(1, max(0, (y - y1) / (y2 - y1)))
        return fx * (self.ancho - 1), fy * (self.alto - 1)

    def sin_mano(self):
        acciones = []
        if self.apretado:  # si la mano desaparece mientras arrastraba, suelta
            acciones.append(("arriba",))
            self.apretado = False
        self.cuadros_pellizco = self.cuadros_derecho = 0
        self.scroll_origen = self.abierta_desde = None
        self.candidato, self.repeticiones, self.modo = "mover", 0, "mover"
        self.fx.reiniciar()
        self.fy.reiniciar()
        self.previo = self.centro = None
        self.vel_mano = 0.0
        return acciones, "en pausa" if self.pausado else "sin mano"

    def procesar(self, p, t):
        acciones = []
        dt = t - self.ultimo_t if self.ultimo_t else 1 / 15
        self.ultimo_t = t
        pulgar, indice, mayor, anular, menique = dedos_levantados(p)
        tamano = distancia(p[0], p[9]) or 1
        r_indice = distancia(p[4], p[8]) / tamano
        r_mayor = distancia(p[4], p[12]) / tamano

        # ¿la mano se está moviendo? (centro de los nudillos, en anchos de imagen por segundo, promedio suave)
        centro = (sum(p[i].x for i in (5, 9, 13, 17)) / 4, sum(p[i].y for i in (5, 9, 13, 17)) / 4)
        if self.centro is not None and dt > 0:
            velocidad = math.dist(centro, self.centro) / dt
            self.vel_mano += 0.35 * (velocidad - self.vel_mano)
        self.centro = centro
        quieta = self.vel_mano < self.a["mano_quieta"]

        # 🖐 mano abierta y QUIETA 2,5 segundos: pausa / reanuda (si se mueve, el tiempo vuelve a empezar)
        if all((pulgar, indice, mayor, anular, menique)) and r_indice > self.a["pellizco_off"] and quieta:
            self.abierta_desde = self.abierta_desde or t
            if t - self.abierta_desde > self.a["segundos_pausa"]:
                self.pausado = not self.pausado
                self.abierta_desde = None
                acciones.append(("aviso", "pausado" if self.pausado else "activo"))
        else:
            self.abierta_desde = None
        if self.pausado:
            if self.apretado:
                acciones.append(("arriba",))
                self.apretado = False
            return acciones, "en pausa (mano abierta 2 s para seguir)"

        # ¿qué gesto parece? (mientras arrastra no cambia de modo)
        if self.apretado:
            candidato = "mover"
        elif not any((indice, mayor, anular, menique)) and r_indice > self.a["pellizco_on"]:
            candidato = "puño"
        elif (indice and mayor and not anular and not menique and r_indice > self.a["pellizco_off"]
              and (quieta or self.modo == "scroll")):
            candidato = "scroll"  # se activa con la mano quieta; una vez en scroll, subir/bajar no lo corta
        else:
            candidato = "mover"
        # solo cambia de modo si el gesto se mantiene varios cuadros seguidos
        if candidato == self.candidato:
            self.repeticiones += 1
        else:
            self.candidato, self.repeticiones, self.candidato_desde = candidato, 1, t
        # además de varios cuadros, un tiempo mínimo: para el scroll o el puño hay que mantener la postura un
        # instante (al frenar la mano para cambiar de dirección ya no se mete solo en scroll)
        sostenido = candidato == "mover" or t - getattr(self, "candidato_desde", t) >= 0.35
        if candidato != self.modo and self.repeticiones >= self.a["cuadros_gesto"] and sostenido:
            self.modo = candidato
            self.scroll_origen = None
            self.scroll_acumulado = 0.0

        if self.modo == "puño":
            # como levantar el mouse: acomodás la mano sin mover el cursor (al abrirla sigue desde ahí)
            self.previo = None
            self.fx.reiniciar()
            self.fy.reiniciar()
            return acciones, "puño: cursor quieto (acomodá la mano)"

        if self.modo == "scroll":
            # joystick: cuánto subiste o bajaste la mano desde que empezó el scroll
            y = p[9].y
            if self.scroll_origen is None:
                self.scroll_origen = y
            desvio = self.scroll_origen - y
            if abs(desvio) > 0.04:
                velocidad = math.copysign(min(1.0, (abs(desvio) - 0.04) / 0.12), desvio)
                self.scroll_acumulado += velocidad * 1400 * dt
                if abs(self.scroll_acumulado) >= 40:
                    acciones.append(("rueda", int(self.scroll_acumulado)))
                    self.scroll_acumulado = 0.0
            return acciones, "scroll: subí o bajá la mano"

        # ☝ mover: sigue el promedio de los 4 NUDILLOS (no se mueven al juntar los dedos, y al promediar
        # cuatro puntos el temblor del detector se cancela bastante)
        nudillos = (p[5], p[9], p[13], p[17])
        nx, ny = sum(q.x for q in nudillos) / 4, sum(q.y for q in nudillos) / 4
        if self.a["modo"] == "relativo":
            movimiento = self._mover_relativo(nx, ny, t, dt)
            if movimiento:
                acciones.append(movimiento)
        else:
            tx, ty = self._a_pantalla(nx, ny)
            sx, sy = self.fx(tx, t), self.fy(ty, t)
            if t >= self.quieto_hasta and math.hypot(sx - self.cx, sy - self.cy) >= self.a["zona_muerta_px"]:
                self.cx, self.cy = sx, sy
                acciones.append(("mover", int(self.cx), int(self.cy)))

        # 🤏 clic / arrastrar con histéresis
        if not self.apretado:
            self.cuadros_pellizco = self.cuadros_pellizco + 1 if r_indice < self.a["pellizco_on"] else 0
            if self.cuadros_pellizco >= self.a["cuadros_clic"]:
                acciones.append(("abajo",))
                self.apretado = True
                self.quieto_hasta = t + self.a["quieto_al_clic"]  # que el clic caiga donde apuntabas
                acciones.append(("aviso", "clic"))
        elif r_indice > self.a["pellizco_off"]:
            acciones.append(("arriba",))
            self.apretado = False
            self.cuadros_pellizco = 0

        # clic derecho: pulgar + mayor (con pausa entre clics)
        if not self.apretado and r_mayor < self.a["pellizco_on"] and r_indice > self.a["pellizco_off"]:
            self.cuadros_derecho += 1
            if self.cuadros_derecho == self.a["cuadros_clic"] + 1 and t - self.ultimo_derecho > 0.8:
                acciones += [("derecho",), ("aviso", "clic derecho")]
                self.ultimo_derecho = t
        else:
            self.cuadros_derecho = 0

        return acciones, "arrastrando" if self.apretado else "apuntando"


# ======================= Cámara, mouse y comunicación con JARVIS =======================

_lock_salida = threading.Lock()
pedidos = []


def enviar(**datos):
    with _lock_salida:
        sys.stdout.write(json.dumps(datos) + "\n")
        sys.stdout.flush()


def leer_pedidos():
    for linea in sys.stdin:
        linea = linea.strip()
        if linea == "salir":
            os._exit(0)
        pedidos.append(linea)
    os._exit(0)  # JARVIS se cerró


CONEXIONES = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8), (5, 9), (9, 10), (10, 11), (11, 12),
              (9, 13), (13, 14), (14, 15), (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]


def main():
    import cv2
    import mediapipe as mp
    from mediapipe.tasks.python import BaseOptions, vision

    user32 = ctypes.windll.user32
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # coordenadas reales de la pantalla (con zoom de Windows)
    except Exception:
        pass
    abajo, arriba, der_abajo, der_arriba, rueda = 0x0002, 0x0004, 0x0008, 0x0010, 0x0800

    def hacer(accion):
        if SIN_MOUSE:
            return
        tipo = accion[0]
        if tipo == "mover":
            user32.SetCursorPos(accion[1], accion[2])
        elif tipo == "abajo":
            user32.mouse_event(abajo, 0, 0, 0, 0)
        elif tipo == "arriba":
            user32.mouse_event(arriba, 0, 0, 0, 0)
        elif tipo == "derecho":
            user32.mouse_event(der_abajo, 0, 0, 0, 0)
            user32.mouse_event(der_arriba, 0, 0, 0, 0)
        elif tipo == "rueda":
            user32.mouse_event(rueda, 0, 0, accion[1], 0)

    cam = cv2.VideoCapture(CAMARA, cv2.CAP_DSHOW)
    if not cam.isOpened():
        enviar(error="No pude abrir la cámara (¿otra app la está usando?)")
        return
    cam.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))  # suele dar más cuadros por segundo
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 360)
    cam.set(cv2.CAP_PROP_FPS, 30)
    cam.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # siempre el cuadro más nuevo (si se acumulan, el cursor va atrasado)
    detector = vision.HandLandmarker.create_from_options(vision.HandLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=MODELO), running_mode=vision.RunningMode.VIDEO, num_hands=1,
        min_hand_detection_confidence=0.6, min_tracking_confidence=0.6, min_hand_presence_confidence=0.6))

    class PUNTO(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
    actual = PUNTO()
    user32.GetCursorPos(ctypes.byref(actual))
    control = ControlGestos(user32.GetSystemMetrics(0), user32.GetSystemMetrics(1), (float(actual.x), float(actual.y)))

    # (la entrada se empieza a leer recién ahora: leerla mientras carga MediaPipe puede trabar todo en Windows)
    threading.Thread(target=leer_pedidos, daemon=True).start()
    enviar(listo=True)

    inicio = time.time()
    ultimo_vivo = 0.0
    while True:
        ok, cuadro = cam.read()
        if not ok:
            time.sleep(0.02)
            continue
        cuadro = cv2.flip(cuadro, 1)  # espejo: movés la mano a la derecha y el cursor va a la derecha
        while pedidos:
            pedido = pedidos.pop(0)
            if pedido == "foto":
                jpg = cv2.imencode(".jpg", cuadro, [cv2.IMWRITE_JPEG_QUALITY, 88])[1].tobytes()
                enviar(foto=base64.b64encode(jpg).decode())
            elif pedido == "config":
                control.recargar()
                enviar(gesto=f"ajustes: sensibilidad {control.a['sensibilidad']}, velocidad {control.a['velocidad']}")

        t = time.time() - inicio
        imagen = mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(cuadro, cv2.COLOR_BGR2RGB))
        resultado = detector.detect_for_video(imagen, int(t * 1000))
        if resultado.hand_landmarks:
            mano = resultado.hand_landmarks[0]
            acciones, estado = control.procesar(mano, t)
        else:
            mano = None
            acciones, estado = control.sin_mano()
        for accion in acciones:
            if accion[0] == "aviso":
                enviar(gesto=accion[1])
            else:
                hacer(accion)

        # Imagen en vivo para la ventana de JARVIS (chica, con la mano dibujada y la zona activa)
        if time.time() - ultimo_vivo > 1 / VIVO_FPS:
            ultimo_vivo = time.time()
            vista = cv2.resize(cuadro, (384, 216))
            if control.a["modo"] == "absoluto":  # la zona de la imagen que equivale a toda la pantalla
                x1, y1, x2, y2 = control.a["zona"]
                cv2.rectangle(vista, (int(x1 * 384), int(y1 * 216)), (int(x2 * 384), int(y2 * 216)), (255, 217, 41), 1)
            else:  # relativo: una cruz en el centro, para saber dónde conviene tener la mano
                cv2.drawMarker(vista, (192, 108), (255, 217, 41), cv2.MARKER_CROSS, 18, 1)
            if mano:
                puntos = [(int(q.x * 384), int(q.y * 216)) for q in mano]
                color = (80, 255, 120) if control.apretado else (255, 217, 41)
                for a, b in CONEXIONES:
                    cv2.line(vista, puntos[a], puntos[b], color, 2)
                centro = (sum(puntos[i][0] for i in (5, 9, 13, 17)) // 4, sum(puntos[i][1] for i in (5, 9, 13, 17)) // 4)
                cv2.circle(vista, centro, 6, (255, 255, 255), -1)  # el punto que mueve el cursor
            jpg = cv2.imencode(".jpg", vista, [cv2.IMWRITE_JPEG_QUALITY, 70])[1].tobytes()
            enviar(vivo="data:image/jpeg;base64," + base64.b64encode(jpg).decode(), estado=estado)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        enviar(error=str(e)[:300])
