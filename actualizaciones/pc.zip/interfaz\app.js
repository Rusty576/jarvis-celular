"use strict";

// ================= Conexión con Python =================
function api(nombre, ...args) {
  if (!window.pywebview || !window.pywebview.api || !window.pywebview.api[nombre]) {
    return Promise.resolve(null);
  }
  return window.pywebview.api[nombre](...args).catch((e) => {
    lineaSistema("Error de la interfaz: " + e);
    return null;
  });
}

// los errores de la página quedan anotados en errores_interfaz.log
const erroresVistos = new Set();
function reportarError(texto) {
  if (erroresVistos.has(texto)) return;
  erroresVistos.add(texto);
  if (window.pywebview && window.pywebview.api) window.pywebview.api.error_js(texto);
}
window.addEventListener("error", (e) => reportarError(`${e.message} (${e.filename}:${e.lineno})`));
window.addEventListener("unhandledrejection", (e) => reportarError("Promesa: " + e.reason));

const $ = (id) => document.getElementById(id);
const chat = $("chat");
const entrada = $("entrada");

let estado = "libre";
let nivelMic = 0;          // volumen del micrófono (0 a 1), lo manda Python
let burbujaParcial = null; // respuesta que se está escribiendo
let temporizadorEscucha = null;
let archivosConocidos = new Set();
const inicioSesion = Date.now();

// ================= Arranque =================
const LINEAS_ARRANQUE = [
  "> inicializando núcleo de procesamiento...",
  "> conectando con modelo de lenguaje local...",
  "> calibrando reconocimiento de voz...",
  "> cargando protocolos de documentos...",
  "> enlace con interfaz holográfica establecido",
  "> todos los sistemas en línea.",
];

function animarArranque() {
  const log = $("arranque-log");
  LINEAS_ARRANQUE.forEach((l, i) => setTimeout(() => { log.textContent += l + "\n"; }, 150 + i * 200));
  setTimeout(() => $("arranque").classList.add("fuera"), 1700);
  // y después se saca del todo (antes a veces quedaba a medio desvanecer, con el texto cortado encima del reactor)
  setTimeout(() => $("arranque").remove(), 2600);
}

async function iniciar() {
  const datos = await api("iniciar");
  if (!datos) return;
  aplicarTema(datos.tema);  // modo oscuro (tema.js)

  $("modelo").textContent = datos.modelo;
  marcar("sw-escucha", datos.manos_libres);
  marcar("sw-voz", datos.voz);

  if (datos.historial.length) {
    datos.historial.forEach((m) => agregarMensaje(m.role === "user" ? "usuario" : "jarvis", m.content, { animar: false }));
    separador("Sesión actual");
  }
  pintarArchivos(datos.archivos, false);
  if (datos.musica) eventoMusica(datos.musica);
  if (datos.conexiones) eventoConexiones(datos.conexiones);
  refrescarHoy();
  ponerEstado(estado);
  setTimeout(() => api("saludar"), 1700);
  entrada.focus();
}

window.addEventListener("pywebviewready", iniciar);
animarArranque();

// ================= Eventos que llegan de JARVIS =================
window.jarvisEventos = function (lote) {
  for (const { evento, datos } of lote) {
    switch (evento) {
      case "estado": ponerEstado(datos); break;
      case "nivel":
        nivelMic = datos;
        $("vu-nivel").style.width = Math.min(100, datos * 100) + "%";
        break;
      case "umbral": $("vu-umbral").style.left = Math.min(98, datos * 100) + "%"; break;
      case "mic": micEstado = datos; pintarMic(); break;
      case "ventana": ventanaHasta = Date.now() + datos * 1000; pintarMic(); break;
      case "oido": mostrarOido(datos, false); break;
      case "parcial": mostrarParcial(datos); break;
      case "jarvis": respuestaFinal(datos); break;
      case "voz": {
        const div = agregarMensaje("usuario", datos, { voz: true });
        const adj = tomarAdjuntos(datos); // si habías pasado un archivo, va con esta orden hablada
        if (adj.html) div.querySelector(".txt").insertAdjacentHTML("afterend", adj.html);
        mostrarOido(datos, true);
        break;
      }
      case "aviso": lineaSistema(datos); break;
      case "detalle": $("reactor-detalle").textContent = datos; break;
      case "progreso": agregarMensaje("jarvis", datos, { progreso: true }); break;
      case "archivo": archivoNuevo(datos); break;
      case "tarea": actualizarTarea(datos); break;
      case "confirmar": tarjetaConfirmar(datos); break;
      case "confirmacion": cerrarConfirmacion(datos); break;
      case "alarma": tarjetaAlarma(datos); break;
      case "alarma_fin": cerrarAlarma(datos); break;
      case "modo_juego": ponerModoJuego(datos); break;
      case "camara_estado": ponerCamara(datos); break;
      case "camara_foto": fotoCamara(datos); break;
      case "camara_vivo": cuadroEnVivo(datos); break;
      case "pantalla_estado": ponerPantalla(datos); break;
      case "llamada": ponerLlamada(datos); break;
      case "fiesta": ponerFiesta(datos); break;
      case "pantalla_vivo": cuadroPantalla(datos); break;
      case "examen": eventoExamen(datos); break;
      case "abrir_memoria": abrirMemoriaEn(datos === "control" ? "control" : "red"); break;
      case "memoria_cambio": if (!$("modal-memoria").hidden) abrirMemoria(); break;  // la red se actualiza sola
      case "control": eventoControl(datos); break;
      case "gestos_estado": ponerGestos(datos); break;
      case "musica": eventoMusica(datos); break;
      case "previsualizar": mostrarCodigo(datos); break;
      case "abrir_ajustes": abrirAjustes(); break;
      case "tema": aplicarTema(datos); break;
      case "quizzes_cambio": if (seccionArchivos === "quiz") pintarQuizzes(); break;
      case "conexiones": eventoConexiones(datos); break;
      case "cerebro_usado": cerebroUsado = datos; break;
      case "pendientes": eventoPendientes(datos); break;
      case "finanzas": eventoFinanzas(datos); break;
      case "estudio": eventoEstudio(datos); break;
      case "adjunto_listo": adjuntoListo(datos); break;
      case "chat_nuevo": eventoChatNuevo(datos); break;
      case "chat_cargado": eventoChatCargado(datos); break;
      case "abrir_chats": abrirChats(); break;
    }
  }
};

// ================= Alarmas y recordatorios =================
const alarmas = new Map();

function tarjetaAlarma(d) {
  const div = document.createElement("div");
  div.className = "alarma";
  const esAlarma = d.tipo === "alarma";
  div.innerHTML = `
    <div class="alarma-cabeza">
      <span class="alarma-icono">${esAlarma ? "⏰" : "🔔"}</span>
      <div><b>${esAlarma ? "ALARMA" : "RECORDATORIO"} · ${escapar(d.hora)}</b>
      <span class="alarma-texto">${escapar(d.texto || (esAlarma ? "Es la hora" : ""))}</span></div>
    </div>
    <div class="alarma-botones">
      <button class="listo">${esAlarma ? "APAGAR" : "LISTO"}</button>
      <button class="posponer">POSPONER 10 MIN</button>
    </div>
    <div class="alarma-estado"></div>`;
  div.querySelector(".listo").onclick = () => api("alarma", "listo");
  div.querySelector(".posponer").onclick = () => api("alarma", "posponer");
  alarmas.set(d.id, div);
  chat.appendChild(div);
  alFondo();
}

function cerrarAlarma(d) {
  const div = alarmas.get(d.id);
  if (!div) return;
  div.classList.add("cerrada");
  div.querySelector(".alarma-botones")?.remove();
  const textos = { apagada: "APAGADA", pospuesta: "POSPUESTA", visto: "VISTO", "sin respuesta": "SIN RESPUESTA" };
  div.querySelector(".alarma-estado").textContent = textos[d.estado] || d.estado;
  alarmas.delete(d.id);
}

// ================= Cámara =================
let camaraActiva = false;

let gestosActivos = false;

function ponerCamara(activa) {
  camaraActiva = !!activa;
  $("cam-indicador").hidden = !camaraActiva;
  $("boton-camara").classList.toggle("activo", camaraActiva);
  if (!camaraActiva) {
    $("vivo").hidden = true;
    $("vivo-img").removeAttribute("src"); // suelta la imagen (memoria)
  }
}

function ponerGestos(activos) {
  gestosActivos = !!activos;
  $("boton-gestos").classList.toggle("activo", gestosActivos);
  document.body.classList.toggle("con-gestos", gestosActivos);
}

// ================= Modo "menea tu chapa" (fiesta) =================
let fiestaActiva = false;

const COLORES_FIESTA = ["#ff4fd8", "#29d9ff", "#ffd34d", "#4dff9a", "#b86bff"];
let relojFiesta = null;

function ponerFiesta(activa) {
  fiestaActiva = !!activa;
  // los colores cambian una vez por compás (cambiar un color repinta una vez; un filtro animado, en cada cuadro)
  clearInterval(relojFiesta);
  document.documentElement.style.removeProperty("--cian");
  if (fiestaActiva) {
    let i = 0;
    relojFiesta = setInterval(() => {
      document.documentElement.style.setProperty("--cian", COLORES_FIESTA[i++ % COLORES_FIESTA.length]);
    }, 1260);
  }
  document.body.classList.toggle("fiesta", fiestaActiva);
  const b = $("boton-fiesta");
  if (b) b.classList.toggle("activo", fiestaActiva);
  $("reactor-estado").textContent = fiestaActiva ? "MENEA TU CHAPA" : "EN ESPERA";
}

// ================= Modo llamada / videollamada con JARVIS =================
let llamadaActiva = false, llamadaSilenciada = false, llamadaReloj = null;

function ponerLlamada(d) {
  llamadaActiva = !!d.activa;
  llamadaSilenciada = !!d.silenciada;
  document.body.classList.toggle("en-llamada", llamadaActiva);
  $("llamada-barra").hidden = !llamadaActiva;
  $("llamada-tipo").textContent = d.video ? "VIDEOLLAMADA CON JARVIS" : "LLAMADA CON JARVIS";
  $("llamada-mute").textContent = llamadaSilenciada ? "ACTIVAR MIC" : "SILENCIAR";
  $("llamada-barra").classList.toggle("silenciada", llamadaSilenciada);
  ["boton-llamada", "boton-videollamada"].forEach((id) => {
    const b = $(id);
    if (b) b.classList.toggle("activo", llamadaActiva && (id === "boton-videollamada") === !!d.video);
  });
  clearInterval(llamadaReloj);
  if (llamadaActiva) {
    const tic = () => {
      const s = Math.max(0, Math.floor(Date.now() / 1000 - d.desde));
      $("llamada-tiempo").textContent = `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
    };
    tic();
    llamadaReloj = setInterval(tic, 1000);
  }
}

function alternarMuteLlamada() {
  enviarTexto(llamadaSilenciada ? "Volvé a escuchar" : "Silenciá");
}

// Pantalla compartida: usa el mismo panel EN VIVO (y tiene prioridad sobre la cámara)
let pantallaCompartida = false;

function ponerPantalla(activa) {
  pantallaCompartida = !!activa;
  document.body.classList.toggle("con-pantalla", pantallaCompartida);
  const b = $("boton-pantalla");
  if (b) b.classList.toggle("activo", pantallaCompartida);
  if (!pantallaCompartida) {
    $("vivo-titulo").textContent = "EN VIVO";
    if (!camaraActiva && !gestosActivos) { $("vivo").hidden = true; $("vivo-img").removeAttribute("src"); }
  }
}

function cuadroPantalla(d) {
  if (!pantallaCompartida) return;
  $("vivo").hidden = false;
  $("vivo-img").src = d.imagen;
  $("vivo-titulo").textContent = "PANTALLA COMPARTIDA";
  $("vivo-estado").textContent = "";
}

function cerrarVivo() {
  enviarTexto(pantallaCompartida ? "Dejá de compartir la pantalla" : gestosActivos ? "Desactivá los gestos" : "Apagá la cámara");
}

function cuadroEnVivo(d) {
  if ((!camaraActiva && !gestosActivos) || pantallaCompartida) return;
  $("vivo").hidden = false;
  $("vivo-img").src = d.imagen;
  $("vivo-estado").textContent = d.estado ? "· " + d.estado.toUpperCase() : "";
}

function fotoCamara(d) {
  const div = document.createElement("div");
  div.className = "foto-camara";
  div.innerHTML = `<div class="foto-cabeza"><span class="punto-rojo"></span>${d.origen || "CÁMARA"}${d.pregunta ? " · " + escapar(d.pregunta) : ""}</div>
    <img src="${d.imagen}" alt="Foto de la cámara">`;
  div.querySelector("img").onload = alFondo;
  chat.appendChild(div);
  alFondo();
}

// ================= Modo juego =================
let modoJuego = false;

function ponerModoJuego(activo) {
  modoJuego = !!activo;
  document.body.classList.toggle("modo-juego", modoJuego);
  $("boton-juego").classList.toggle("activo", modoJuego);
  const e = $("juego-estado");
  e.textContent = modoJuego ? "ACTIVO" : "Inactivo";
  e.className = modoJuego ? "" : "tenue";
}

// ================= Confirmar antes de mandar (WhatsApp / mail / acciones de la PC) =================
const confirmaciones = new Map(); // id -> tarjeta
const CANALES = {
  whatsapp: { badge: "whatsapp", icono: "✆", titulo: "WHATSAPP PARA" },
  gmail: { badge: "gmail", icono: "@", titulo: "MAIL PARA" },
  sistema: { badge: "sistema", icono: "!", titulo: "CONFIRMAR ACCIÓN" },
};

function tarjetaConfirmar(d) {
  const esMail = d.canal === "gmail";
  const c = CANALES[d.canal] || CANALES.sistema;
  const div = document.createElement("div");
  div.className = "confirmar " + d.canal;
  div.innerHTML = `
    <div class="confirmar-cabeza">
      <span class="badge ${c.badge}">${c.icono}</span>
      <div><b>${c.titulo}</b><span class="para">${escapar(d.para)}</span></div>
    </div>
    ${esMail ? `<div class="confirmar-asunto">Asunto: <span class="asunto-editable" contenteditable="true">${escapar(d.asunto || "")}</span></div>` : ""}
    <div class="confirmar-texto" ${d.canal !== "sistema" ? 'contenteditable="true" spellcheck="false"' : ""}>${escapar(d.texto).replace(/\n/g, "<br>")}</div>
    ${d.canal !== "sistema" ? '<div class="confirmar-ayuda">Se manda tal cual. Podés tocar el texto para corregirlo.</div>' : ""}
    <div class="confirmar-botones">
      <button class="enviar">${d.canal === "sistema" ? "CONFIRMAR" : "ENVIAR"}</button>
      <button class="cancelar">CANCELAR</button>
    </div>
    <div class="confirmar-estado"></div>`;
  div.querySelector(".enviar").onclick = () => {
    const texto = d.canal !== "sistema" ? div.querySelector(".confirmar-texto").innerText.trim() : null;
    const asunto = esMail ? div.querySelector(".asunto-editable").innerText.trim() : null;
    div.querySelectorAll("[contenteditable]").forEach((e) => e.removeAttribute("contenteditable"));
    bloquear(div, "Enviando...");
    agregarMensaje("usuario", "Sí, mandalo");
    api("confirmar", true, texto, asunto);
  };
  div.querySelector(".cancelar").onclick = () => { bloquear(div, "Cancelando..."); agregarMensaje("usuario", "No, cancelá"); api("confirmar", false); };
  confirmaciones.set(d.id, div);
  chat.appendChild(div);
  alFondo();
}

function bloquear(div, texto) {
  div.querySelectorAll("button").forEach((b) => (b.disabled = true));
  div.querySelector(".confirmar-estado").textContent = texto;
}

function cerrarConfirmacion(d) {
  const div = confirmaciones.get(d.id);
  if (!div) return;
  const textos = { enviado: "✓ ENVIADO", cancelado: "CANCELADO", vencido: "VENCIDO (no se mandó)",
                   reemplazado: "CORREGIDO (mirá la versión nueva abajo)", error: "✕ NO SE PUDO MANDAR" };
  div.classList.add("cerrada", d.estado);
  div.querySelectorAll("[contenteditable]").forEach((e) => e.removeAttribute("contenteditable"));
  div.querySelector(".confirmar-botones").remove();
  div.querySelector(".confirmar-estado").textContent = textos[d.estado] || d.estado;
  confirmaciones.delete(d.id);
}

// ================= Micrófono: si te está oyendo y qué entendió =================
let micEstado = "apagado";
let ventanaHasta = 0; // hasta cuándo escucha una orden sin tener que decir "Jarvis"

function pintarMic() {
  const barra = $("mic-barra");
  const chip = $("mic-chip");
  let clase = micEstado, texto;
  const quedan = Math.ceil((ventanaHasta - Date.now()) / 1000);
  if (typeof grabandoEspacio !== "undefined" && grabandoEspacio) { clase = "grabando"; texto = "● GRABANDO · SOLTÁ ESPACIO PARA MANDAR"; }
  else if (estado === "hablando") { clase = "pausa"; texto = "EN PAUSA · ESTOY HABLANDO"; }
  else if (micEstado === "oyendo") texto = "TE ESTOY OYENDO";
  else if (micEstado === "reconociendo") texto = "ENTENDIENDO...";
  else if (micEstado === "pausa") texto = "EN PAUSA · ESTOY HABLANDO";
  else if (estado === "escuchando" && quedan > 0) { clase = "ventana"; texto = `DECÍ TU ORDEN · ${quedan}s`; }
  else if (estado === "escuchando" && micEstado === "espera") { clase = "ventana"; texto = "HABLÁ AHORA"; }
  else if (micEstado === "espera") texto = $("sw-escucha").classList.contains("activo") ? 'DECÍ "JARVIS"' : "LISTO";
  else texto = "MICRÓFONO APAGADO";
  barra.dataset.mic = clase;
  chip.textContent = texto;
  $("boton-mic").classList.toggle("activo", clase === "ventana" || clase === "grabando" || micEstado === "oyendo");
}
setInterval(pintarMic, 250);

let temporizadorOido = null;
function mostrarOido(texto, paraJarvis) {
  const caja = $("mic-oido");
  caja.innerHTML = paraJarvis
    ? `✓ Entendí: «${escapar(texto)}»`
    : `Escuché: «${escapar(texto)}» <small>· decí "Jarvis" primero para que sea una orden</small>`;
  caja.style.opacity = 1;
  clearTimeout(temporizadorOido);
  temporizadorOido = setTimeout(() => { caja.style.opacity = 0; }, paraJarvis ? 5000 : 7000);
}

// ================= Tareas largas (archivos e imágenes) =================
const tareas = new Map(); // id -> { datos, tarjeta, inicio }
const NOMBRE_TIPO = { word: "DOCUMENTO", excel: "PLANILLA", powerpoint: "PRESENTACIÓN", imagen: "IMAGEN", examen: "QUIZ", codigo: "CÓDIGO", txt: "TEXTO" };
let destelloHasta = 0; // momento hasta el que el reactor muestra "completado"
let progresoAnillo = 0; // progreso suavizado que dibuja el reactor (0 a 1)

function tareaPrincipal() {
  let ultima = null;
  for (const t of tareas.values()) if (t.datos.estado === "activa") ultima = t;
  return ultima;
}

function tiempoDesde(inicio) {
  const s = Math.floor((Date.now() - inicio) / 1000);
  return `${Math.floor(s / 60)}:${dosDigitos(s % 60)}`;
}

function crearTarjetaTarea(d) {
  const div = document.createElement("div");
  div.className = "tarea";
  div.innerHTML = `
    <div class="tarea-icono">${badge(d.tipo)}<span class="rueda"></span><span class="tilde">✓</span></div>
    <div class="tarea-cuerpo">
      <div class="tarea-titulo"><b>${NOMBRE_TIPO[d.tipo] || "ARCHIVO"}</b>${escapar(d.titulo.charAt(0).toUpperCase() + d.titulo.slice(1))}</div>
      <div class="tarea-etapa"><span class="etapa"></span><span class="reloj-tarea"></span></div>
      <div class="tarea-barra"><span></span></div>
    </div>
    <div class="tarea-pct"></div>`;
  chat.appendChild(div);
  alFondo();
  return div;
}

function actualizarTarea(d) {
  let t = tareas.get(d.id);
  if (!t) {
    t = { datos: d, tarjeta: crearTarjetaTarea(d), inicio: Date.now() };
    tareas.set(d.id, t);
  }
  t.datos = d;
  const card = t.tarjeta;
  const pct = d.progreso;
  card.querySelector(".etapa").textContent = d.etapa;
  card.classList.toggle("indeterminada", pct === null && d.estado === "activa");
  card.querySelector(".tarea-barra span").style.width = (pct === null ? 100 : pct) + "%";

  if (d.estado === "activa") {
    card.querySelector(".tarea-pct").textContent = pct === null ? "" : pct + "%";
  } else if (d.estado === "lista") {
    card.classList.add("lista");
    card.querySelector(".tarea-pct").textContent = d.ruta ? "ABRIR" : "LISTO";
    card.querySelector(".reloj-tarea").textContent = " · " + tiempoDesde(t.inicio);
    if (d.ruta) {  // los exámenes no son un archivo para abrir
      card.dataset.ruta = d.ruta;
      card.title = "Abrir " + d.ruta;
      card.onclick = () => api("abrir", d.ruta);
    }
    destelloHasta = performance.now() + 1800;
    tareas.delete(d.id);
  } else {
    card.classList.add("error");
    card.querySelector(".tarea-pct").textContent = "✕";
    tareas.delete(d.id);
  }
  pintarPendientes();
  if (!tareaPrincipal()) ponerEstado(estado); // vuelve la etiqueta normal
  else etiquetaTarea();
}

function etiquetaTarea() {
  const t = tareaPrincipal();
  document.body.classList.toggle("generando", !!t);
  if (!t || estado === "hablando" || estado === "escuchando") return;
  const d = t.datos;
  const pct = d.progreso === null ? "" : ` · ${d.progreso}%`;
  $("reactor-estado").textContent = `GENERANDO ${NOMBRE_TIPO[d.tipo] || ""}${pct}`;
  $("reactor-detalle").textContent = `${d.etapa} · ${tiempoDesde(t.inicio)}`;
  $("estado-texto").textContent = `GENERANDO ${NOMBRE_TIPO[d.tipo] || "ARCHIVO"}`;
}

// relojes de las tarjetas y de la etiqueta
setInterval(() => {
  for (const t of tareas.values()) {
    t.tarjeta.querySelector(".reloj-tarea").textContent = " · " + tiempoDesde(t.inicio);
  }
  if (tareaPrincipal()) etiquetaTarea();
}, 1000);

// filas "generando..." arriba de todo en el panel de Archivos
function pintarPendientes() {
  const caja = $("archivos");
  caja.querySelectorAll(".archivo.pendiente").forEach((f) => f.remove());
  caja.querySelector(".vacio")?.remove();
  const filas = [...tareas.values()].filter((t) => t.datos.estado === "activa").reverse();
  for (const t of filas) {
    const d = t.datos;
    const fila = document.createElement("div");
    fila.className = "archivo pendiente";
    fila.innerHTML = `<span class="rueda-mini"></span><span class="nombre">${escapar(d.titulo)}</span>` +
      `<span class="cuando">${d.progreso === null ? "generando" : d.progreso + "%"}</span>`;
    caja.prepend(fila);
  }
}

const NOMBRES_ESTADO = {
  libre: ["EN ESPERA", "SISTEMA EN LÍNEA"],
  pensando: ["PROCESANDO", "PROCESANDO SOLICITUD"],
  hablando: ["RESPONDIENDO", "TRANSMITIENDO RESPUESTA"],
  escuchando: ["ESCUCHANDO", "CANAL DE VOZ ABIERTO"],
};

function ponerEstado(nuevo) {
  estado = NOMBRES_ESTADO[nuevo] ? nuevo : "libre";
  document.body.dataset.estado = estado;
  if (estado !== "escuchando") ventanaHasta = 0; // ya no espera la orden: corta la cuenta regresiva
  const etiqueta = $("reactor-estado");
  if (etiqueta.textContent !== NOMBRES_ESTADO[estado][0]) {  // transición suave al cambiar de estado
    etiqueta.classList.remove("cambia");
    void etiqueta.offsetWidth;
    etiqueta.classList.add("cambia");
  }
  etiqueta.textContent = NOMBRES_ESTADO[estado][0];
  $("estado-texto").textContent = NOMBRES_ESTADO[estado][1];
  $("boton-mic").classList.toggle("activo", estado === "escuchando");

  const detalle = $("reactor-detalle");
  if (estado === "libre") {
    detalle.textContent = $("sw-escucha").classList.contains("activo")
      ? 'Decí "Jarvis" o escribí una orden'
      : "Tocá el micrófono o escribí una orden";
  } else if (estado === "escuchando") {
    detalle.textContent = "Te escucho...";
  } else if (estado === "pensando") {
    detalle.textContent = "Analizando...";
  } else if (estado === "hablando") {
    detalle.textContent = "Esc o ■ para interrumpir";
  }

  clearTimeout(temporizadorEscucha);
  if (estado === "escuchando") {
    // si en 11 segundos no pasa nada, vuelve a reposo
    temporizadorEscucha = setTimeout(() => { if (estado === "escuchando") ponerEstado("libre"); }, 11000);
  }
  if (estado === "pensando" || estado === "libre") nivelMic = 0;
  etiquetaTarea(); // si se está creando un archivo, la etiqueta muestra el avance
}

// ================= Chat =================
function escapar(t) {
  // también las comillas: así sirve igual dentro de atributos (title="...", alt="...") sin que un texto pueda cerrarlos
  return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function formatear(texto) {
  // Bloques de código ```lenguaje ... ``` (si todavía se está escribiendo, el último queda abierto)
  const partes = String(texto).trim().split("```");
  return partes.map((parte, i) => {
    if (i % 2 === 0) return formatearTexto(parte);
    const salto = parte.indexOf("\n");
    const lenguaje = salto >= 0 ? parte.slice(0, salto).trim() : "";
    const codigo = salto >= 0 ? parte.slice(salto + 1).replace(/\n$/, "") : parte;
    const web = /^(html?|css|js|javascript)$/i.test(lenguaje);
    return `<div class="codigo"><div class="codigo-cabeza"><span>${escapar(lenguaje || "código")}</span><span class="codigo-botones">`
      + `<button type="button" onclick="previaDesdeChat(this)" class="${web ? "probar" : ""}">${web ? "▶ PROBAR" : "VER"}</button>`
      + `<button type="button" onclick="copiarCodigo(this)">COPIAR</button></span></div>`
      + `<pre><code>${resaltar(codigo, lenguaje)}</code></pre></div>`;
  }).join("");
}

// Colores simples para el código: comentarios, textos, números y palabras clave
const PALABRAS_CLAVE = new Set(("def class return if elif else for while in import from as with try except finally raise "
  + "lambda yield pass break continue and or not is None True False print self function const let var new this "
  + "async await switch case default typeof null undefined true false public private protected static void int "
  + "float double string bool boolean char long using namespace include struct echo SELECT FROM WHERE INSERT "
  + "UPDATE DELETE INTO VALUES JOIN ORDER BY GROUP CREATE TABLE export extends interface type package fn mut "
  + "match impl pub use mod go func defer chan map range end then do local elseif").split(" "));

function resaltar(codigo, lenguaje) {
  const conNumeral = !/^(css|scss|html|xml)$/i.test(lenguaje); // en CSS "#fff" no es un comentario
  const re = /(\/\*[\s\S]*?\*\/|\/\/[^\n]*|#[^\n]*|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`|\b\d+(?:\.\d+)?\b|\b[A-Za-z_]\w*\b)/g;
  let html = "", ultimo = 0, m;
  while ((m = re.exec(codigo))) {
    const tok = m[0];
    let clase = null;
    if (tok.startsWith("/*") || tok.startsWith("//") || (tok[0] === "#" && conNumeral)) clase = "c-com";
    else if (tok[0] === "#") { re.lastIndex = m.index + 1; html += escapar(codigo.slice(ultimo, m.index + 1)); ultimo = m.index + 1; continue; }
    else if (/^["'`]/.test(tok)) clase = "c-str";
    else if (/^\d/.test(tok)) clase = "c-num";
    else if (PALABRAS_CLAVE.has(tok)) clase = "c-kw";
    html += escapar(codigo.slice(ultimo, m.index)) + (clase ? `<span class="${clase}">${escapar(tok)}</span>` : escapar(tok));
    ultimo = m.index + tok.length;
  }
  return html + escapar(codigo.slice(ultimo));
}

function copiarCodigo(boton) {
  const codigo = boton.closest(".codigo").querySelector("code").innerText;
  const listo = () => { boton.textContent = "✓ COPIADO"; setTimeout(() => (boton.textContent = "COPIAR"), 1500); };
  navigator.clipboard.writeText(codigo).then(listo).catch(() => {
    const area = document.createElement("textarea");
    area.value = codigo;
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
    listo();
  });
}

function formatearTexto(texto) {
  // Markdown simple: **negrita**, `código`, listas con "-" o "*", títulos con "#"
  const lineas = escapar(texto.replace(/^\n+|\n+$/g, "")).split("\n");
  let html = "", enLista = false;
  for (let l of lineas) {
    l = l.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, '<code class="en-linea">$1</code>');
    const item = l.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
    if (item) {
      if (!enLista) { html += "<ul>"; enLista = true; }
      html += "<li>" + item[1] + "</li>";
      continue;
    }
    if (enLista) { html += "</ul>"; enLista = false; }
    const titulo = l.match(/^#{1,4}\s+(.*)$/);
    if (titulo) html += "<b>" + titulo[1] + "</b><br>";
    else if (l.trim()) html += l + "<br>";
    else html += "<br>";
  }
  if (enLista) html += "</ul>";
  return html.replace(/(<br>)+$/, "");
}

function hora() {
  return new Date().toLocaleTimeString("es", { hour: "2-digit", minute: "2-digit" });
}

const MAX_ELEMENTOS_CHAT = 150; // lo viejo se saca de la pantalla (el historial completo sigue guardado)

function alFondo() {
  while (chat.children.length > MAX_ELEMENTOS_CHAT) chat.firstElementChild.remove();
  chat.scrollTop = chat.scrollHeight;
}

function agregarMensaje(quien, texto, opciones = {}) {
  const div = document.createElement("div");
  div.className = "msg " + quien + (opciones.progreso ? " progreso" : "");
  const etiqueta = quien === "jarvis" ? "JARVIS" : opciones.voz ? "VOS · AUDIO" : "VOS";
  div.innerHTML = `<div class="meta"><span class="quien">${etiqueta}</span><span class="hora">${hora()}</span></div><div class="txt"></div>`;
  const txt = div.querySelector(".txt");
  chat.appendChild(div);

  if (opciones.progreso) {
    txt.textContent = texto; // el avance lo muestra la tarjeta de la tarea
  } else if (quien === "jarvis" && opciones.animar !== false) {
    escribirAnimado(div, texto);
  } else {
    txt.innerHTML = formatear(texto);
  }
  alFondo();
  return div;
}

function escribirAnimado(div, texto) {
  const txt = div.querySelector(".txt");
  div.classList.add("escribiendo");
  const paso = Math.max(1, Math.ceil(texto.length / 60)); // termina en ~1 segundo
  let i = 0;
  const intervalo = setInterval(() => {
    i += paso;
    txt.innerHTML = formatear(texto.slice(0, i));
    alFondo();
    if (i >= texto.length) {
      clearInterval(intervalo);
      div.classList.remove("escribiendo");
      txt.innerHTML = formatear(texto);
    }
  }, 16);
}

function terminarProgreso() {
  chat.querySelectorAll(".msg.progreso .puntos-carga").forEach((p) => p.remove());
  chat.querySelectorAll(".msg.progreso").forEach((m) => m.classList.remove("progreso"));
}

function mostrarParcial(texto) {
  if (!burbujaParcial) {
    burbujaParcial = agregarMensaje("jarvis", "", { animar: false });
    burbujaParcial.classList.add("escribiendo");
  }
  burbujaParcial.querySelector(".txt").innerHTML = formatear(texto);
  alFondo();
}

function respuestaFinal(texto) {
  terminarProgreso();
  let burbuja;
  if (burbujaParcial) {
    burbuja = burbujaParcial;
    burbujaParcial.querySelector(".txt").innerHTML = formatear(texto);
    burbujaParcial.classList.remove("escribiendo");
    burbujaParcial = null;
    alFondo();
  } else {
    burbuja = agregarMensaje("jarvis", texto);
  }
  if (cerebroUsado && burbuja) {  // la respondió la IA en la nube: se marca en la burbuja, con el color de esa IA
    const quien = Object.keys(COLORES_NUBE).find((k) => cerebroUsado.toLowerCase().startsWith(k));
    const c = COLORES_NUBE[quien] || COLORES_NUBE[conexiones.nube && conexiones.nube.proveedor] || COLORES_NUBE.nvidia;
    burbuja.querySelector(".meta").insertAdjacentHTML("beforeend", `<span class="marca-cerebro" style="--ia-claro: ${c.claro};
      --ia-rgb: ${c.rgb}">${escapar(cerebroUsado)}</span>`);
  }
  cerebroUsado = null;
  if (pensarMas) desarmarPensar();  // "pensar más" era solo para esa pregunta
  mostrarSubtitulo(texto);
}

function mostrarSubtitulo(texto) {
  const sub = $("subtitulo");
  const corto = texto.replace(/```[\s\S]*?(?:```|$)/g, " [código en el chat] ").replace(/\s+/g, " ").trim();
  sub.innerHTML = "<b>JARVIS</b>" + escapar(corto.length > 220 ? corto.slice(0, 217) + "..." : corto);
  sub.classList.add("visible");
  clearTimeout(sub._t);
  sub._t = setTimeout(() => sub.classList.remove("visible"), Math.min(14000, 4000 + corto.length * 45));
}

function lineaSistema(texto) {
  const div = document.createElement("div");
  div.className = "sistema-linea";
  div.textContent = texto;
  chat.appendChild(div);
  alFondo();
}

function separador(texto) {
  const div = document.createElement("div");
  div.className = "separador";
  div.textContent = texto;
  chat.appendChild(div);
}

// ================= Archivos =================
const LETRAS = { word: "W", excel: "X", powerpoint: "P", imagen: "◈", pdf: "PDF", otro: "?", examen: "Q", codigo: "</>" };

// Los archivos usan los mismos íconos hexagonales que los protocolos
const ICONO_DE_TIPO = {
  word: ["documento", "#4f9dff"], excel: ["planilla", "#3fe0a0"], powerpoint: ["presentacion", "#ff8a4c"],
  imagen: ["imagen", "#c58bff"], pdf: ["documento", "#ff5a6a"], codigo: ["codigo", "#f2c94c"], examen: ["quiz", "#ff7ad9"],
  video: ["video", "#ff4f7b"], txt: ["documento", "#9fc3d9"], otro: ["documento", "#29d9ff"],
};

function badge(tipo) {
  const icono = ICONO_DE_TIPO[tipo];
  if (icono && typeof hexIcono === "function") return `<span class="icono-archivo">${hexIcono(icono[0], icono[1])}</span>`;
  return `<span class="badge ${tipo}">${escapar(LETRAS[tipo] || "?")}</span>`;
}

function haceCuanto(segundos) {
  const d = Date.now() / 1000 - segundos;
  if (d < 60) return "recién";
  if (d < 3600) return `hace ${Math.floor(d / 60)} min`;
  if (d < 86400) return `hace ${Math.floor(d / 3600)} h`;
  const f = new Date(segundos * 1000);
  return f.toLocaleDateString("es", { day: "numeric", month: "short" });
}

const VACIO_SECCION = {
  todo: "Todavía no hay archivos. Pedime un documento, una planilla, una imagen o un programa.",
  imagen: "Sin imágenes todavía. Probá: «creame una imagen de...».",
  doc: "Sin documentos todavía. Probá: «creame un documento sobre...».",
  codigo: "Sin código guardado. Pedime un programa y decime «guardá el código».",
};

function pintarArchivos(lista, resaltar = true) {
  ultimaListaArchivos = lista || [];
  if (seccionArchivos === "quiz") { pintarPendientes(); return; } // la sección Quiz se pinta aparte
  const caja = $("archivos");
  caja.innerHTML = "";
  const visibles = filtrarArchivos(ultimaListaArchivos);
  if (!visibles.length) {
    caja.innerHTML = `<div class="vacio">${VACIO_SECCION[seccionArchivos] || VACIO_SECCION.todo}</div>`;
    pintarPendientes();
    return;
  }
  for (const a of visibles) {
    const fila = document.createElement("div");
    fila.className = "archivo" + (resaltar && !archivosConocidos.has(a.ruta) ? " nuevo" : "");
    fila.title = a.tipo === "codigo" ? "Tocá para verlo (y probarlo si es una página web)" : a.ruta;
    fila.innerHTML = `${badge(a.tipo)}<span class="nombre">${escapar(a.nombre)}${a.ext ? `<small>.${escapar(a.ext)}</small>` : ""}</span><span class="cuando">${haceCuanto(a.fecha)}</span>
      <button class="borrar-fila" title="Borrar (va a la Papelera de reciclaje)">✕</button>`;
    fila.onclick = () => abrirArchivo(a);
    fila.querySelector(".borrar-fila").onclick = (e) => {
      e.stopPropagation();
      confirmarBorrado(e.currentTarget, async () => {
        const r = await api("borrar_archivo", a.ruta);
        if (r) { lineaSistema(r.mensaje); pintarArchivos(r.lista, false); }
      });
    };
    caja.appendChild(fila);
  }
  archivosConocidos = new Set(ultimaListaArchivos.map((a) => a.ruta));
  pintarPendientes();
}

// Borrar pide dos toques: el primero arma el botón ("¿BORRAR?") y el segundo, dentro de 3 segundos, borra
function confirmarBorrado(boton, accion) {
  if (boton.dataset.armado === "1") { boton.disabled = true; accion(); return; }
  boton.dataset.armado = "1";
  boton.textContent = "¿BORRAR?";
  boton.classList.add("armado");
  setTimeout(() => {
    if (boton.isConnected) { boton.dataset.armado = ""; boton.textContent = "✕"; boton.classList.remove("armado"); }
  }, 3000);
}

async function refrescarArchivos() {
  pintarArchivos(await api("archivos"));
}

function archivoNuevo(a) {
  const yaTieneTarjeta = [...chat.querySelectorAll(".tarea.lista")].some((c) => c.dataset.ruta === a.ruta);
  if (a.tipo === "imagen" && a.imagen) {
    const div = document.createElement("div");
    div.className = "imagen-chat";
    div.title = "Abrir imagen";
    div.innerHTML = `<img src="${a.imagen}" alt="${escapar(a.nombre)}">`;
    div.onclick = () => api("abrir", a.ruta);
    div.querySelector("img").onload = alFondo;
    chat.appendChild(div);
  } else if (!yaTieneTarjeta) {
    const div = document.createElement("div");
    div.className = "tarjeta-archivo";
    div.innerHTML = `${badge(a.tipo)}<span class="nombre">${escapar(a.nombre)}.${a.ext}</span><span class="accion">ABRIR</span>`;
    div.onclick = () => api("abrir", a.ruta);
    chat.appendChild(div);
  }
  alFondo();
  refrescarArchivos();
}

// ================= Comandos =================
function enviarTexto(texto) {
  const adj = typeof tomarAdjuntos === "function" ? tomarAdjuntos(texto.trim()) : { texto, html: "" };
  texto = adj.texto.trim();
  if (!texto) { callar(); return; }
  const div = agregarMensaje("usuario", texto);
  if (adj.html) {
    div.querySelector(".txt").insertAdjacentHTML("afterend", adj.html);
    div.querySelectorAll(".msg-adjuntos img").forEach((img) => (img.onload = alFondo));
  }
  burbujaParcial = null;
  api(pensarMas ? "enviar_pensando" : "enviar", texto);  // con "pensar más", solo esta pregunta va a la nube
}

// Apenas empezás a escribir, la IA va cargando (si estaba descargada), así responde más rápido al apretar Enter
let ultimaPrecarga = 0;
let ultimaPrecargaImagen = 0;
const PIDE_IMAGEN = /imagen|dibuj|foto|pint|ilustraci|logo|wallpaper|fondo de pantalla|retrato/i;
entrada.addEventListener("input", () => {
  if (Date.now() - ultimaPrecarga > 30000) {
    ultimaPrecarga = Date.now();
    api("precargar");
  }
  // un pedido de imagen: el generador va cargando mientras terminás de escribir (cargar tarda entre 15 y 80 s)
  if (PIDE_IMAGEN.test(entrada.value) && Date.now() - ultimaPrecargaImagen > 60000) {
    ultimaPrecargaImagen = Date.now();
    api("precargar_imagen");
  }
});

$("comando").addEventListener("submit", (e) => {
  e.preventDefault();
  const texto = entrada.value;
  entrada.value = "";
  enviarTexto(texto);
});

// Esc, Enter vacío: lo calla. Solo el botón ■ cancela lo que se está creando (un quiz, una imagen...)
function callar(cancelarTareas = false) {
  api("callar", cancelarTareas);
  if (cancelarTareas) terminarProgreso();
  if (burbujaParcial) { burbujaParcial.classList.remove("escribiendo"); burbujaParcial = null; }
}

function microfono() {
  if (estado === "escuchando") { callar(); return; }
  api("microfono");
}

let apagarArmado = false;
function apagarTodo() {
  // primer clic: pide confirmar (para no apagarlo sin querer); segundo clic: apaga
  const b = document.querySelector(".ventana-botones .apagar");
  if (!apagarArmado) {
    apagarArmado = true;
    b.classList.add("armado");
    lineaSistema("¿Apagar JARVIS por completo? Libera la placa de video y cierra Ollama. Tocá ⏻ otra vez para confirmar.");
    setTimeout(() => { apagarArmado = false; b.classList.remove("armado"); }, 5000);
    return;
  }
  api("apagar");
}

function plantilla(texto) {
  entrada.value = texto;
  entrada.focus();
  entrada.setSelectionRange(texto.length, texto.length);
}

function marcar(id, activo) {
  $(id).classList.toggle("activo", !!activo);
}

async function alternarEscucha() {
  const activo = await api("alternar_manos_libres");
  marcar("sw-escucha", activo);
  if (estado === "libre") ponerEstado("libre");
}

async function alternarVoz() {
  marcar("sw-voz", await api("alternar_voz"));
}

// ================= Barra espaciadora: mantenela apretada para hablar =================
// (si la tocás y la soltás rápido, es como el botón del micrófono: escucha hasta que te callás)
let espacioDesde = 0, grabandoEspacio = false, temporizadorEspacio = null;

function espacioEsParaHablar() {
  const a = document.activeElement;
  if (a && a.isContentEditable) return false;
  if (a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA")) {
    return a === entrada && entrada.value.trim() === ""; // con texto escrito, el espacio es un espacio
  }
  return true;
}

function soltarEspacio() {
  clearTimeout(temporizadorEspacio);
  if (grabandoEspacio) api("grabar_fin");
  else if (espacioDesde) microfono();
  espacioDesde = 0;
  grabandoEspacio = false;
  document.body.classList.remove("grabando");
  pintarMic();
}

document.addEventListener("keydown", (e) => {
  if (e.code !== "Space" || e.ctrlKey || e.altKey || e.metaKey || !espacioEsParaHablar()) return;
  e.preventDefault();
  e.stopPropagation();
  if (e.repeat || espacioDesde) return;
  espacioDesde = Date.now();
  temporizadorEspacio = setTimeout(() => {
    grabandoEspacio = true;
    document.body.classList.add("grabando");
    pintarMic();
    api("grabar_inicio");
  }, 220);
}, true);
document.addEventListener("keyup", (e) => {
  if (e.code === "Space" && espacioDesde) { e.preventDefault(); e.stopPropagation(); soltarEspacio(); }
}, true);
window.addEventListener("blur", () => { if (espacioDesde) soltarEspacio(); });

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") { e.preventDefault(); callar(); }
  else if (e.code === "Space" && e.ctrlKey) { e.preventDefault(); microfono(); }
  else if (!e.ctrlKey && !e.altKey && e.key.length === 1 && e.key !== " " && document.activeElement !== entrada
           && !document.activeElement.isContentEditable && document.activeElement.tagName !== "INPUT"
           && $("modal-examen").hidden && $("modal-memoria").hidden && $("modal-codigo").hidden
           && $("modal-ajustes").hidden && $("modal-pendientes").hidden) entrada.focus();
});

// ================= Reloj y sistema =================
function dosDigitos(n) { return String(n).padStart(2, "0"); }

function tickReloj() {
  const a = new Date();
  $("reloj").textContent = `${dosDigitos(a.getHours())}:${dosDigitos(a.getMinutes())}:${dosDigitos(a.getSeconds())}`;
  $("fecha").textContent = a.toLocaleDateString("es", { weekday: "long", day: "numeric", month: "short", year: "numeric" });
}
setInterval(tickReloj, 1000);
tickReloj();

function crearSegmentos(id) {
  const caja = $(id);
  for (let i = 0; i < 20; i++) caja.appendChild(document.createElement("i"));
}
["cpu-bar", "ram-bar", "bat-bar"].forEach(crearSegmentos);

function pintarBarra(id, valor, invertir = false) {
  const llenos = Math.round((valor / 100) * 20);
  const peligro = invertir ? 100 - valor : valor;
  $(id).querySelectorAll("i").forEach((seg, i) => {
    seg.className = i < llenos ? "on" + (peligro > 85 ? " critico" : peligro > 65 ? " alto" : "") : "";
  });
}

async function actualizarSistema() {
  if (document.hidden) return; // escondida o minimizada: no pregunta nada
  const d = await api("sistema");
  if (!d) return;
  if (d.cpu !== null) { $("cpu-val").textContent = Math.round(d.cpu) + "%"; pintarBarra("cpu-bar", d.cpu); }
  if (d.ram !== null) { $("ram-val").textContent = Math.round(d.ram) + "%"; pintarBarra("ram-bar", d.ram); }
  if (d.bateria !== null) {
    $("bateria-bloque").hidden = false;
    $("bat-val").textContent = d.bateria + "%" + (d.enchufado ? " ⚡" : "");
    pintarBarra("bat-bar", d.bateria, true);
  }
  const n = $("nucleo-estado");
  if (d.nucleo === null) { n.textContent = "Verificando"; n.className = "tenue"; }
  else if (!d.nucleo) { n.textContent = "Sin conexión"; n.className = "mal"; }
  else if (d.modelo_instalado === false) { n.textContent = "Falta el modelo"; n.className = "mal"; }
  else { n.textContent = "En línea"; n.className = "ok"; }
  if (d.modo_juego !== undefined && d.modo_juego !== modoJuego) ponerModoJuego(d.modo_juego);
  // (Gmail e Imágenes los pinta eventoConexiones, que avisa apenas cambian)
  marcar("sw-escucha", d.manos_libres);
}
setInterval(actualizarSistema, 2000);
setTimeout(actualizarSistema, 600);

// ================= Reactor =================
const lienzo = $("reactor");
const ctx = lienzo.getContext("2d");
const BARRAS = 72;
const alturas = new Float32Array(BARRAS);
let energia = 0.2;
let ancho = 0, alto = 0, dpr = 1;

function ajustarLienzo() {
  const r = lienzo.getBoundingClientRect();
  dpr = window.devicePixelRatio || 1;
  ancho = r.width; alto = r.height;
  lienzo.width = Math.round(ancho * dpr);
  lienzo.height = Math.round(alto * dpr);
}
new ResizeObserver(ajustarLienzo).observe(lienzo);

function cian(a) { return `rgba(41,217,255,${a})`; }
function ambar(a) { return `rgba(255,181,71,${a})`; }

function arco(x, y, r, desde, hasta, color, grosor, brillo = 0) {
  ctx.beginPath();
  ctx.arc(x, y, r, desde, hasta);
  ctx.strokeStyle = color;
  ctx.lineWidth = grosor;
  ctx.shadowBlur = brillo;
  ctx.shadowColor = color;
  ctx.stroke();
  ctx.shadowBlur = 0;
}

// WebView2 a veces pausa requestAnimationFrame cuando la ventana estuvo tapada y no lo
// reanuda; por eso hay un temporizador de respaldo que dibuja si la animación se frenó.
let ultimoCuadro = 0;

// Cuadros por segundo: 30 normal (de sobra para que se vea fluido), 8 en modo juego
// (para no competir con el juego) y 0 si la ventana está minimizada.
function fpsObjetivo() {
  if (document.hidden || modoJuego) return 0; // en modo juego la ventana está escondida: no dibuja nada
  // en reposo el reactor late despacio: 12 cuadros alcanzan (cada cuadro recompone toda la ventana y le quita
  // tiempo al audio de la música); escuchando, pensando o hablando, 30 para que se vea fluido
  return estado === "libre" && !fiestaActiva ? 12 : 30;
}

function cuadroAnimado(ms) {
  requestAnimationFrame(cuadroAnimado);
  const fps = fpsObjetivo();
  if (fps && performance.now() - ultimoCuadro >= 1000 / fps - 4) dibujar(performance.now());
}

setInterval(() => {
  const fps = fpsObjetivo();
  if (fps && performance.now() - ultimoCuadro > Math.max(150, 2500 / fps)) dibujar(performance.now());
}, 50);

// Las decoraciones (logo, punto de estado, barrido del fondo, el meneo de la fiesta) se mueven acá, al ritmo del
// reactor, y no con animaciones CSS: cada animación CSS corre a 60 cuadros por segundo y en cada uno la placa
// integrada recompone TODA la ventana (medido: ~130% de CPU de más, y la música se entrecortaba).
const deco = { logo: null, punto: null, fondo: null, reactor: null, protocolos: [], moviendo: false, fiesta: false };

function animarDecoraciones(t) {
  if (!deco.logo) {
    deco.logo = document.querySelector(".logo-icono circle:nth-child(2)");
    deco.punto = document.querySelector(".estado-global .punto");
    deco.fondo = document.querySelector(".fondo-grilla");
    deco.reactor = $("reactor-caja");
  }
  const activo = estado !== "libre" || fiestaActiva;
  if (activo) {
    if (deco.logo) deco.logo.style.transform = `rotate(${(t * 45) % 360}deg)`;           // una vuelta cada 8 s
    if (deco.punto) deco.punto.style.opacity = (0.45 + 0.55 * Math.abs(Math.cos(t * 1.6))).toFixed(2);
    if (deco.fondo) deco.fondo.style.setProperty("--escaneo", ((t / 9) % 1).toFixed(3));  // barrido cada 9 s
    deco.moviendo = true;
  } else if (deco.moviendo) {  // vuelve a reposo: todo quieto (y sin repintar más)
    deco.moviendo = false;
    if (deco.punto) deco.punto.style.opacity = "";
    if (deco.fondo) deco.fondo.style.setProperty("--escaneo", "-1");
  }
  // los latidos (botón de protocolo activo, llamada, cámara, "pensar más", fiesta): directo sobre esos pocos
  // elementos (una variable en toda la página obligaba a recalcular los estilos de todo en cada cuadro)
  if (!deco.latidosHasta || t > deco.latidosHasta) {  // la lista se renueva cada segundo
    deco.latidos = [...document.querySelectorAll(".protocolo.activo .hex, .llamada-barra .punto-verde, "
      + ".cam-indicador:not([hidden]), .boton-pensar.activo svg, .boton-llamar.activo svg" + (fiestaActiva ? ", #reactor-estado" : ""))];
    (deco.latidosViejos || []).filter((e) => !deco.latidos.includes(e)).forEach((e) => { e.style.transform = ""; e.style.opacity = ""; });
    deco.latidosViejos = deco.latidos;
    deco.latidosHasta = t + 1;
  }
  if (deco.latidos.length) {
    const p = Math.abs(Math.sin(t * Math.PI / (fiestaActiva ? 0.63 : 1.4)));
    deco.latidos.forEach((e) => {
      if (e.classList.contains("hex") || e.id === "reactor-estado") e.style.transform = `scale(${(1 + 0.08 * p).toFixed(3)})`;
      else e.style.opacity = (0.45 + 0.55 * p).toFixed(2);
    });
  }
  // el ecualizador de la música (antes animaba la ALTURA a 60 cuadros por segundo: lo más caro que hay, y justo
  // mientras sonaba la música, que por eso se entrecortaba)
  if (!deco.eq) deco.eq = [...document.querySelectorAll("#musica-eq i")];
  const suena = typeof musica !== "undefined" && musica && musica.modo && !musica.pausado;
  if (suena) {
    deco.eq.forEach((b, i) => { b.style.transform = `scaleY(${(0.25 + 0.75 * Math.abs(Math.sin(t * 3.5 + i * 1.3))).toFixed(2)})`; });
    deco.sonando = true;
  } else if (deco.sonando) {
    deco.sonando = false;
    deco.eq.forEach((b) => { b.style.transform = ""; });
  }
  if (fiestaActiva) {  // menea la chapa: ida y vuelta una vez por compás (~95 pulsaciones por minuto)
    if (!deco.fiesta) deco.protocolos = [$("protocolos")];  // el panel entero (un elemento, no 18 por separado)
    deco.fiesta = true;
    const f = Math.sin(t * Math.PI / 0.63);
    if (deco.reactor) deco.reactor.style.transform = `rotate(${(f * 5).toFixed(2)}deg) scale(${(1.05 + 0.03 * f).toFixed(3)})`;
    deco.protocolos.forEach((b) => { b.style.transform = `translateY(${(-3 * f).toFixed(1)}px) rotate(${(f * 1.5).toFixed(2)}deg)`; });
  } else if (deco.fiesta) {
    deco.fiesta = false;
    if (deco.reactor) deco.reactor.style.transform = "";
    deco.protocolos.forEach((b) => { b.style.transform = ""; });
  }
}

function dibujar(ms) {
  ultimoCuadro = performance.now();
  if (!ancho || !alto) return;
  try {
    animarDecoraciones(ms / 1000);
    dibujarReactor(ms / 1000);
  } catch (e) {
    reportarError("Reactor: " + e + " | energia=" + energia + " nivel=" + nivelMic + " estado=" + estado + " " + ancho + "x" + alto);
    energia = 0.2;
    nivelMic = 0;
  }
}

// partículas que orbitan el reactor y ondas de cuando te escucha
const particulas = Array.from({ length: 16 }, (_, i) => ({
  a: Math.random() * Math.PI * 2, v: 0.15 + Math.random() * 0.45, r: 1.04 + Math.random() * 0.16,
  achate: 0.82 + Math.random() * 0.18, tam: 0.9 + Math.random() * 1.6, fase: Math.random() * 6,
}));
let ondas = [];
let ultimaOnda = 0;

function dibujarReactor(t) {

  // cuánta "energía" tiene el reactor según lo que está haciendo JARVIS
  let objetivo;
  if (estado === "escuchando") objetivo = 0.25 + nivelMic * 1.6;
  else if (estado === "hablando") objetivo = 0.45 + 0.35 * Math.abs(Math.sin(t * 7.3) * Math.sin(t * 3.1 + 1)) + Math.random() * 0.2;
  else if (estado === "pensando") objetivo = 0.55 + 0.15 * Math.sin(t * 6);
  else objetivo = 0.18 + 0.06 * Math.sin(t * 1.4) + nivelMic * 0.6;
  energia += (Math.min(objetivo, 1.3) - energia) * 0.12;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, ancho, alto);
  const cx = ancho / 2, cy = alto / 2 - 18;
  const R = Math.max(60, Math.min(ancho - 200, alto - 60) * 0.38);
  const velocidad = estado === "pensando" ? 3.2 : estado === "hablando" ? 1.6 : 1;

  // halo de fondo
  const halo = ctx.createRadialGradient(cx, cy, R * 0.1, cx, cy, R * 1.25);
  halo.addColorStop(0, cian(0.10 + energia * 0.12));
  halo.addColorStop(0.5, cian(0.03));
  halo.addColorStop(1, cian(0));
  ctx.fillStyle = halo;
  ctx.fillRect(0, 0, ancho, alto);

  // 1) anillo exterior con marcas
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(t * 0.05 * velocidad);
  for (let i = 0; i < 180; i++) {
    const a = (i / 180) * Math.PI * 2;
    const largo = i % 15 === 0 ? 14 : i % 5 === 0 ? 8 : 4;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * R, Math.sin(a) * R);
    ctx.lineTo(Math.cos(a) * (R - largo), Math.sin(a) * (R - largo));
    ctx.strokeStyle = cian(i % 15 === 0 ? 0.7 : 0.28);
    ctx.lineWidth = i % 15 === 0 ? 1.6 : 1;
    ctx.stroke();
  }
  ctx.restore();
  arco(cx, cy, R + 8, 0, Math.PI * 2, cian(0.12), 1);

  // 1b) partículas en órbita (más rápidas cuando trabaja)
  particulas.forEach((p) => {
    p.a += p.v * velocidad * (0.6 + energia) / 60;
    const r = R * p.r;
    const x = cx + Math.cos(p.a) * r, y = cy + Math.sin(p.a) * r * p.achate;
    const tam = p.tam * (0.8 + 0.4 * Math.sin(t * 3 + p.fase));
    ctx.beginPath();
    ctx.arc(x, y, tam, 0, Math.PI * 2);
    ctx.fillStyle = estado === "pensando" && p.tam > 1.6 ? ambar(0.85) : cian(0.75);
    ctx.shadowBlur = 8;
    ctx.shadowColor = ctx.fillStyle;
    ctx.fill();
    ctx.shadowBlur = 0;
  });

  // 2) segmentos gruesos que giran
  const g1 = -t * 0.22 * velocidad;
  for (let i = 0; i < 3; i++) {
    const ini = g1 + i * (Math.PI * 2 / 3);
    arco(cx, cy, R * 0.88, ini, ini + 1.25, cian(0.55), 5, 12);
    arco(cx, cy, R * 0.88, ini + 1.4, ini + 1.55, cian(0.35), 5);
  }
  // pequeñas marcas de "objetivo" en el anillo
  for (let i = 0; i < 4; i++) {
    const a = t * 0.4 * velocidad + i * Math.PI / 2;
    arco(cx, cy, R * 0.94, a, a + 0.08, cian(0.8), 2, 8);
  }

  // 3) barras de audio radiales
  const base = R * 0.62;
  for (let i = 0; i < BARRAS; i++) {
    const ruido = 0.5 + 0.5 * Math.sin(t * 5 + i * 0.7) * Math.sin(t * 2.3 + i * 1.9);
    const obj = energia * (0.25 + ruido * 0.9) * (0.6 + Math.random() * 0.5);
    alturas[i] += (obj - alturas[i]) * 0.25;
    const h = 3 + alturas[i] * R * 0.2;
    const a = (i / BARRAS) * Math.PI * 2 - Math.PI / 2;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * base, cy + Math.sin(a) * base);
    ctx.lineTo(cx + Math.cos(a) * (base + h), cy + Math.sin(a) * (base + h));
    ctx.strokeStyle = estado === "pensando" ? ambar(0.35 + alturas[i] * 0.5) : cian(0.3 + alturas[i] * 0.6);
    ctx.lineWidth = 2.4;
    ctx.stroke();
  }

  // 4) anillo punteado que gira al revés
  ctx.save();
  ctx.setLineDash([2, 6]);
  arco(cx, cy, R * 0.56, t * 0.3 * velocidad, t * 0.3 * velocidad + Math.PI * 2, cian(0.5), 1.5);
  ctx.restore();

  // 5) ruedita de carga mientras se crea un archivo, y destello verde al terminar
  const tarea = tareaPrincipal();
  const ahora = performance.now();
  const rA = R + 22;
  if (tarea) {
    const p = tarea.datos.progreso;
    if (p !== null) progresoAnillo += (p / 100 - progresoAnillo) * 0.08;
    arco(cx, cy, rA, 0, Math.PI * 2, cian(0.12), 4);                       // pista
    if (p !== null) {
      arco(cx, cy, rA, -Math.PI / 2, -Math.PI / 2 + progresoAnillo * Math.PI * 2, cian(0.95), 4, 16); // avance
    }
    const giro = t * 3.2;                                                   // la ruedita que gira
    arco(cx, cy, rA + 10, giro, giro + 0.9, ambar(0.9), 2.5, 12);
    arco(cx, cy, rA + 10, giro + Math.PI, giro + Math.PI + 0.45, ambar(0.55), 2.5, 8);
  } else if (ahora < destelloHasta) {
    const f = (destelloHasta - ahora) / 1800;                               // 1 -> 0
    progresoAnillo = 0;
    arco(cx, cy, rA, 0, Math.PI * 2, `rgba(77,255,184,${0.9 * f})`, 4 + 6 * f, 30 * f);
  } else {
    progresoAnillo = 0;
  }

  // barrido de "procesando" (cuando piensa sin crear archivos)
  if (estado === "pensando" && !tarea) {
    const a = t * 4;
    arco(cx, cy, R * 0.75, a, a + 1.1, ambar(0.85), 2.5, 14);
    arco(cx, cy, R * 0.75, a + Math.PI, a + Math.PI + 0.5, ambar(0.5), 2.5, 10);
  }

  // 5b) onda de voz circular mientras habla
  if (estado === "hablando") {
    ctx.beginPath();
    for (let i = 0; i <= 140; i++) {
      const a = (i / 140) * Math.PI * 2;
      const r = R * 0.72 + Math.sin(a * 6 + t * 9) * energia * 9 + Math.sin(a * 11 - t * 6) * energia * 5;
      const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
      if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y);
    }
    ctx.strokeStyle = cian(0.55);
    ctx.lineWidth = 1.6;
    ctx.shadowBlur = 12;
    ctx.shadowColor = cian(0.8);
    ctx.stroke();
    ctx.shadowBlur = 0;
  }

  // 5c) ondas expansivas desde el núcleo cuando te escucha y hablás
  if (estado === "escuchando" && nivelMic > 0.2 && t - ultimaOnda > 0.35) {
    ondas.push({ nace: t });
    ultimaOnda = t;
  }
  ondas = ondas.filter((o) => t - o.nace < 1.4);
  ondas.forEach((o) => {
    const f = (t - o.nace) / 1.4;
    arco(cx, cy, R * (0.3 + f * 0.65), 0, Math.PI * 2, cian(0.5 * (1 - f)), 2 * (1 - f) + 0.5);
  });

  // 6) anillo interior con muescas
  arco(cx, cy, R * 0.44, 0, Math.PI * 2, cian(0.65), 2, 14);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-t * 0.5 * velocidad);
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(0, 0, R * 0.39, a, a + 0.38);
    ctx.strokeStyle = cian(0.45);
    ctx.lineWidth = R * 0.05;
    ctx.stroke();
  }
  ctx.restore();

  // 7) núcleo brillante
  const rn = R * (0.24 + energia * 0.05);
  const nucleoG = ctx.createRadialGradient(cx, cy, 0, cx, cy, rn * 1.6);
  nucleoG.addColorStop(0, "rgba(255,255,255,0.95)");
  nucleoG.addColorStop(0.25, cian(0.85));
  nucleoG.addColorStop(0.6, cian(0.25 + energia * 0.2));
  nucleoG.addColorStop(1, cian(0));
  ctx.fillStyle = nucleoG;
  ctx.beginPath();
  ctx.arc(cx, cy, rn * 1.6, 0, Math.PI * 2);
  ctx.fill();
  arco(cx, cy, rn, 0, Math.PI * 2, "rgba(220,250,255,0.9)", 1.5, 20);

  // triángulo central (estilo reactor); mientras hay porcentaje no se dibuja
  if (!tarea && ahora >= destelloHasta) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(t * 0.15);
  ctx.beginPath();
  for (let i = 0; i < 3; i++) {
    const a = -Math.PI / 2 + (i * Math.PI * 2) / 3;
    ctx[i ? "lineTo" : "moveTo"](Math.cos(a) * rn * 0.62, Math.sin(a) * rn * 0.62);
  }
  ctx.closePath();
  ctx.strokeStyle = "rgba(2,40,60,0.55)";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();
  }

  // porcentaje (o ✓ al terminar) en el centro del núcleo
  let centro = null;
  if (tarea && tarea.datos.progreso !== null) centro = Math.round(progresoAnillo * 100) + "%";
  else if (!tarea && ahora < destelloHasta) centro = "✓";
  if (centro) {
    ctx.font = `700 ${Math.round(rn * 0.55)}px Orbitron, "Segoe UI", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "rgba(2,30,46,0.92)";
    ctx.fillText(centro, cx, cy + 1);
  }

  // 8) líneas de mira a los costados
  ctx.strokeStyle = cian(0.25);
  ctx.lineWidth = 1;
  for (const lado of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(cx + lado * (R + 44), cy);
    ctx.lineTo(cx + lado * (R + 86), cy);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx + lado * (R + 90), cy, 3, 0, Math.PI * 2);
    ctx.fillStyle = cian(0.6);
    ctx.fill();
  }
}
requestAnimationFrame(cuadroAnimado);
ponerEstado("libre");
