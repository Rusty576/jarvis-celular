"""Actualizarse solo: el JARVIS de PC de los demás (el que se llevó con el pendrive) se pone las versiones nuevas que
publica quien lo armó, sin que nadie toque nada.

- Cada 6 horas mira `pc.json` (en la página de la app). Si hay una versión más nueva, baja `pc.zip` y SOLO la acepta si
  viene firmada con la clave de quien publica (RSA PKCS#1 v1.5 + SHA-256; la privada vive solo en su PC, acá está la
  pública, la misma que tiene el bot): si alguien entrara a donde se publica, igual no podría meter código.
- La deja lista y se pone sola al próximo arranque (o de madrugada, si la PC está prendida y nadie la usa: se reinicia
  sola). Antes de copiar guarda lo que reemplaza; si la versión nueva no arranca bien, vuelve sola a la anterior.
- Solo cambia el código: los datos de la persona (charlas, recuerdos, ajustes) quedan como estaban.
- En la PC de quien publica (la que tiene `llevar_jarvis/`) no hace nada: ahí el código se cambia a mano.
"""
import base64
import ctypes
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
URL = "https://rusty576.github.io/jarvis-celular/actualizaciones/"
# la clave pública de quien publica (la misma que FIRMA_N en bot_celular/Codigo.gs)
FIRMA_N = int(
    "bd4586ea819011e9fac76f07260f61fa7ff40abc42946d2e6519366c1ed0c238a2f4f1f85dcc9ab934d036906f6976d1b283558a1488f0f0"
    "be50ed610050fcebbb029d2744e7ecca23eb4a807eae8d0c68835d10af218fb70120186f1671af0f93d56c9e3a056941a605cd8291c2675f"
    "23cb930dd6cbb8ca0873f97a102d2f3e852735ee58ebd120de40682b989da158149e6442bc9464741b75e10e7de8913c67f5d63637c1de4f"
    "041110b2098413f8a3cf1aff778014c68c9f74b2ec8410a6930b56193c6149c32cdda8c16049584c80cd45bdd5d249a7deab4322ac8499c5"
    "28f1cfc30fa9b4ed55fe73786e842658c987fbab2da8aed502436a1c21c31a1e1726e34f0a65200f1f816e915a33ffe4f47714d8446e2d5f"
    "ec1c0a559bc9ecaa9531023ba78a730d8abb187c78f4b6a43e0be531a0cb7055d21586570961416e14f37c0bdeede179fdbe546d2236d884"
    "3a61d02e70a178cfc0112222e8db2892efade27628ac4cc4a660d6964cf0efaeed5865e15c88ff93223adfa25cbbc5c1", 16)
FIRMA_E = 0x10001
SHA256_PREFIJO = bytes.fromhex("3031300d060960864801650304020105000420")   # (DigestInfo de SHA-256, PKCS#1 v1.5)
CARPETA = os.path.join(os.environ.get("LOCALAPPDATA") or BASE, "JARVIS", "actualizacion")
PUERTO_INSTANCIA = 47321   # (el de interfaz.py: si contesta, ya hay un JARVIS abierto)
CADA = 6 * 3600
TOPE_ZIP = 150 * 1024 * 1024
OBLIGATORIOS = ("main.py", "interfaz.py", "actualizador.py", "version_pc.txt")
jarvis = None


def _ruta(*partes):
    return os.path.join(CARPETA, *partes)


def es_la_pc_de_quien_publica():
    return os.path.isdir(os.path.join(BASE, "llevar_jarvis")) or bool(os.environ.get("JARVIS_NO_ACTUALIZAR"))


def version_actual():
    try:
        with open(os.path.join(BASE, "version_pc.txt"), encoding="utf-8") as f:
            return f.read().strip() or "0"
    except OSError:
        return "0"


def version_mayor(a, b):
    """¿«a» es más nueva que «b»? (2026.11.02.1530 > 2026.11.02.930)"""
    def numeros(v):
        try:
            return [int(x) for x in str(v or "0").split(".")]
        except ValueError:
            return [0]
    x, y = numeros(a), numeros(b)
    largo = max(len(x), len(y))
    return x + [0] * (largo - len(x)) > y + [0] * (largo - len(y))


def firma_valida(datos, firma_b64):
    """RSA PKCS#1 v1.5 + SHA-256 con la clave pública de quien publica (igual que firmaValida_ del bot)."""
    try:
        firma = base64.b64decode(str(firma_b64 or ""), validate=True)
    except (ValueError, TypeError):
        return False
    k = (FIRMA_N.bit_length() + 7) // 8
    if len(firma) != k:
        return False
    s = int.from_bytes(firma, "big")
    if s >= FIRMA_N:
        return False
    t = SHA256_PREFIJO + hashlib.sha256(datos).digest()
    return pow(s, FIRMA_E, FIRMA_N).to_bytes(k, "big") == b"\x00\x01" + b"\xff" * (k - 3 - len(t)) + b"\x00" + t


# ---------- Lo que recuerda (fuera de la carpeta del código) ----------

def _leer_estado():
    try:
        with open(_ruta("estado.json"), encoding="utf-8") as f:
            e = json.load(f)
        return e if isinstance(e, dict) else {}
    except (OSError, ValueError):
        return {}


def _guardar_estado(e):
    os.makedirs(CARPETA, exist_ok=True)
    temporal = _ruta("estado.json.tmp")
    with open(temporal, "w", encoding="utf-8") as f:
        json.dump(e, f, ensure_ascii=False, indent=1)
    os.replace(temporal, _ruta("estado.json"))


def _anotar_falla(e, version, motivo):
    e.setdefault("fallas", {})[version] = e.get("fallas", {}).get(version, 0) + 1
    e["ultimo_error"] = f"{version}: {motivo}"[:300]


# ---------- Bajar y revisar una versión nueva ----------

def _bajar(nombre, tope=2 * 1024 * 1024):
    pedido = urllib.request.Request(f"{URL}{nombre}?t={int(time.time())}", headers={"User-Agent": "JARVIS"})
    with urllib.request.urlopen(pedido, timeout=40) as r:
        datos = r.read(tope + 1)
    if len(datos) > tope:
        raise ValueError(f"{nombre} es demasiado grande")
    return datos


def _sacar_zip(datos, destino):
    """Abre el zip en `destino` sin dejar que nada se escape de esa carpeta (nombres con .. o con disco)."""
    import io

    if os.path.isdir(destino):
        shutil.rmtree(destino)
    os.makedirs(destino)
    raiz = os.path.realpath(destino)
    with zipfile.ZipFile(io.BytesIO(datos)) as z:
        for info in z.infolist():
            nombre = info.filename.replace("\\", "/")
            if nombre.endswith("/"):
                continue
            if nombre.startswith("/") or ":" in nombre or ".." in nombre.split("/"):
                raise ValueError(f"el paquete trae un nombre raro: {nombre}")
            final = os.path.realpath(os.path.join(destino, *nombre.split("/")))
            if os.path.commonpath([raiz, final]) != raiz:
                raise ValueError(f"el paquete quiere escribir afuera: {nombre}")
            os.makedirs(os.path.dirname(final), exist_ok=True)
            with z.open(info) as origen, open(final, "wb") as f:
                shutil.copyfileobj(origen, f)


def _revisar_paquete(carpeta, version):
    """Que sea JARVIS de verdad, de esa versión, y que todo el código compile (si no, ni se pone)."""
    for a in OBLIGATORIOS:
        if not os.path.isfile(os.path.join(carpeta, a)):
            raise ValueError(f"al paquete le falta {a}")
    with open(os.path.join(carpeta, "version_pc.txt"), encoding="utf-8") as f:
        if f.read().strip() != version:
            raise ValueError("la versión de adentro no coincide")
    for raiz, _, archivos in os.walk(carpeta):
        for a in archivos:
            if a.endswith(".py"):
                ruta = os.path.join(raiz, a)
                with open(ruta, encoding="utf-8") as f:
                    compile(f.read(), ruta, "exec")   # (SyntaxError: no se pone)


def revisar():
    """Mira si hay una versión nueva; si la hay y viene bien firmada, la deja lista para ponerla. Devuelve la versión
    que quedó lista (o None)."""
    if es_la_pc_de_quien_publica():
        return None
    info = json.loads(_bajar("pc.json").decode("utf-8"))
    version = str(info.get("version") or "")
    e = _leer_estado()
    if not version_mayor(version, version_actual()) or e.get("fallas", {}).get(version, 0) >= 2:
        return None
    if (e.get("lista") or {}).get("version") == version and os.path.isdir(_ruta("nueva")):
        return version
    datos = _bajar(str(info.get("archivo") or "pc.zip"), tope=TOPE_ZIP)
    if hashlib.sha256(datos).hexdigest() != str(info.get("sha256") or "") or not firma_valida(datos, info.get("firma")):
        _anotar_falla(e, version, "no vino bien firmada: no la puse")
        e["fallas"][version] = 2   # (una mal firmada no se vuelve a probar)
        _guardar_estado(e)
        return None
    try:
        _sacar_zip(datos, _ruta("nueva"))
        _revisar_paquete(_ruta("nueva"), version)
    except Exception as ex:
        shutil.rmtree(_ruta("nueva"), ignore_errors=True)
        _anotar_falla(e, version, str(ex))
        _guardar_estado(e)
        return None
    e["lista"] = {"version": version, "bajada": time.strftime("%Y-%m-%d %H:%M")}
    _guardar_estado(e)
    return version


# ---------- Ponerla (al arrancar) y volver atrás si no anda ----------

def _otro_jarvis_abierto():
    try:
        with socket.create_connection(("127.0.0.1", PUERTO_INSTANCIA), timeout=0.5):
            return True
    except OSError:
        return False


def _esperar_que_cierre(pid, segundos=90):
    """Al reiniciarse solo: el JARVIS de antes tarda unos segundos en cerrarse."""
    try:
        import psutil
    except ImportError:
        time.sleep(15)
        return
    fin = time.time() + segundos
    while time.time() < fin and psutil.pid_exists(pid):
        time.sleep(1)


def _archivos(carpeta):
    for raiz, _, archivos in os.walk(carpeta):
        for a in archivos:
            yield os.path.relpath(os.path.join(raiz, a), carpeta)


def _requisitos(carpeta):
    try:
        with open(os.path.join(carpeta, "requirements.txt"), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


def _poner(e):
    """Copia la versión lista encima del código, guardando antes lo que reemplaza (en `anterior/`)."""
    nueva, anterior = _ruta("nueva"), _ruta("anterior")
    version = e["lista"]["version"]
    if os.path.isdir(anterior):
        shutil.rmtree(anterior)
    os.makedirs(anterior)
    antes, nuevos = version_actual(), []
    lista = list(_archivos(nueva))
    for rel in lista:
        destino = os.path.join(BASE, rel)
        if os.path.isfile(destino):
            os.makedirs(os.path.dirname(os.path.join(anterior, rel)), exist_ok=True)
            shutil.copy2(destino, os.path.join(anterior, rel))
        else:
            nuevos.append(rel)
    cambian_librerias = _requisitos(nueva) != _requisitos(BASE)
    e["probando"] = {"version": version, "antes": antes, "nuevos": nuevos}
    e.pop("lista", None)
    _guardar_estado(e)   # (si se corta a mitad de copiar, el próximo arranque vuelve atrás)
    try:
        for rel in lista:
            destino = os.path.join(BASE, rel)
            os.makedirs(os.path.dirname(destino), exist_ok=True)
            shutil.copy2(os.path.join(nueva, rel), destino)
    except Exception as ex:
        _volver_atras(e, f"no pude copiar: {ex}")
        return
    for basura in ("__pycache__",):   # (que Python no use lo compilado de la versión anterior)
        shutil.rmtree(os.path.join(BASE, basura), ignore_errors=True)
    shutil.rmtree(nueva, ignore_errors=True)
    e["pip"] = e.get("pip") or cambian_librerias
    _guardar_estado(e)


def _volver_atras(e, motivo):
    p = e.pop("probando", None) or {}
    anterior = _ruta("anterior")
    if os.path.isdir(anterior):
        for rel in _archivos(anterior):
            destino = os.path.join(BASE, rel)
            os.makedirs(os.path.dirname(destino), exist_ok=True)
            shutil.copy2(os.path.join(anterior, rel), destino)
    for rel in p.get("nuevos", []):
        try:
            os.remove(os.path.join(BASE, rel))
        except OSError:
            pass
    shutil.rmtree(os.path.join(BASE, "__pycache__"), ignore_errors=True)
    version = p.get("version", "?")
    _anotar_falla(e, version, motivo)
    e["aviso"] = f"La versión nueva de JARVIS ({version}) no arrancó bien: volví sola a la que tenías."
    _guardar_estado(e)


def al_arrancar():
    """Lo primero que hace interfaz.py (antes de cargar el resto): si la vez anterior se puso una versión nueva y no
    llegó a arrancar bien, vuelve a la anterior; si hay una lista, la pone."""
    if es_la_pc_de_quien_publica():
        return
    esperar = os.environ.pop("JARVIS_ESPERAR", "")
    if esperar.isdigit():
        _esperar_que_cierre(int(esperar))
    if _otro_jarvis_abierto():
        return   # (ya hay un JARVIS abierto: no se le cambia el código mientras anda)
    e = _leer_estado()
    if e.get("probando"):
        _volver_atras(e, "no llegó a arrancar")
        return
    if e.get("lista") and os.path.isdir(_ruta("nueva")):
        _poner(e)


def arranque_bien():
    """JARVIS arrancó con la ventana andando: la versión nueva queda (y se avisa)."""
    e = _leer_estado()
    p = e.pop("probando", None)
    if p:
        e["aviso"] = f"Me actualicé solo a la versión {p.get('version')}."
        e["al_dia"] = time.strftime("%Y-%m-%d %H:%M")
        _guardar_estado(e)
    return p


# ---------- Mientras anda ----------

def _sin_usar_hace():
    """Segundos desde la última tecla o movimiento del mouse."""
    class Ultima(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]
    u = Ultima()
    u.cbSize = ctypes.sizeof(Ultima)
    try:
        if ctypes.windll.user32.GetLastInputInfo(ctypes.byref(u)):
            return (ctypes.windll.kernel32.GetTickCount() - u.dwTime) / 1000
    except Exception:
        pass
    return 0


def _se_puede_reiniciar():
    if not 3 <= time.localtime().tm_hour < 6 or _sin_usar_hace() < 30 * 60:
        return False
    try:
        if jarvis.herramientas.modo_juego.is_set() or jarvis.tareas_activas:
            return False
    except Exception:
        pass
    return True


def reiniciar():
    """Abre un JARVIS nuevo (que espera a que este se cierre, se pone la versión y arranca) y cierra este."""
    exe = sys.executable
    if exe.lower().endswith("python.exe") and os.path.isfile(exe[:-10] + "pythonw.exe"):
        exe = exe[:-10] + "pythonw.exe"   # (sin ventana negra)
    subprocess.Popen([exe, os.path.join(BASE, "interfaz.py")], cwd=BASE, close_fds=True,
                     env={**os.environ, "JARVIS_ESPERAR": str(os.getpid())},
                     creationflags=0x00000008 | 0x00000200)   # (DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP)
    threading.Timer(45, os._exit, (0,)).start()   # (por si la ventana no se cierra sola)
    try:
        jarvis.pildora.cerrar()
    except Exception:
        pass
    if getattr(jarvis, "oyentes", None):
        jarvis.emitir("cerrar")
    else:
        os._exit(0)


def _instalar_librerias(e):
    python = sys.executable
    if python.lower().endswith("pythonw.exe") and os.path.isfile(python[:-11] + "python.exe"):
        python = python[:-11] + "python.exe"
    r = subprocess.run([python, "-m", "pip", "install", "--disable-pip-version-check", "-q", "-r",
                        os.path.join(BASE, "requirements.txt")], capture_output=True, creationflags=0x08000000,
                       timeout=1800)
    if r.returncode == 0:
        e.pop("pip", None)
        _guardar_estado(e)


def _vigilar():
    time.sleep(20)
    arranque_bien()
    e = _leer_estado()
    if e.get("aviso"):
        try:
            jarvis.aviso(e.pop("aviso"))
        except Exception:
            pass
        _guardar_estado(e)
    if e.get("pip"):
        try:
            _instalar_librerias(e)
        except Exception:
            pass
    time.sleep(100)
    ultima, avisada = 0, None
    while True:
        if time.time() - ultima > CADA:
            ultima = time.time()
            try:
                lista = revisar()
                if lista and lista != avisada and not _se_puede_reiniciar():
                    avisada = lista
                    jarvis.aviso("Bajé una versión nueva de JARVIS: se pone sola la próxima vez que me prendas.")
            except Exception:
                pass
        if (_leer_estado().get("lista") or {}).get("version") and _se_puede_reiniciar():
            reiniciar()
            return
        time.sleep(300)


def iniciar(modulo_jarvis):
    """Lo llama interfaz.py con la ventana ya creada."""
    global jarvis
    jarvis = modulo_jarvis
    if es_la_pc_de_quien_publica():
        return
    threading.Thread(target=_vigilar, daemon=True).start()
