"use strict";
// Memoria: pestañas Red / Recuerdos (buscar, agregar, editar) / Lista de control (verificación cruzada).
// Usa $, api, escapar, lineaSistema (app.js), abrirMemoria, memoriaDatos, COLOR_CATEGORIA (extras.js)

let pestanaMemoria = "red";
let controlDatos = [];

async function abrirMemoriaEn(pestana) {
  await abrirMemoria();
  verPestanaMemoria(pestana || "red");
}

function verPestanaMemoria(vista) {
  pestanaMemoria = vista;
  document.querySelectorAll("#pestanas-memoria button").forEach((b) => b.classList.toggle("activa", b.dataset.vista === vista));
  $("vista-red").hidden = vista !== "red";
  $("vista-lista").hidden = vista !== "lista";
  $("vista-control").hidden = vista !== "control";
  $("memoria-titulo").textContent = { red: "Red de recuerdos", lista: "Mis recuerdos", control: "Lista de control" }[vista];
  pintarPestanaMemoria();
  if (vista === "lista") setTimeout(() => $("memoria-buscar").focus(), 50);
}
document.querySelectorAll("#pestanas-memoria button").forEach((b) => { b.onclick = () => verPestanaMemoria(b.dataset.vista); });

async function pintarPestanaMemoria() {
  if (pestanaMemoria === "lista") pintarListaRecuerdos();
  if (pestanaMemoria === "control") eventoControl((await api("control_datos")) || []);
}

const sinTildes = (t) => String(t).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");

function pintarListaRecuerdos() {
  const d = memoriaDatos;
  if (!d) return;
  const sel = $("memoria-nuevo-cat");
  if (sel.options.length <= 1) {
    Object.entries(d.categorias).forEach(([k, v]) => sel.insertAdjacentHTML("beforeend", `<option value="${k}">${escapar(v)}</option>`));
  }
  const q = sinTildes($("memoria-buscar").value.trim());
  const filtrados = d.recuerdos.filter((r) => !q || q.split(/\s+/).every((p) => sinTildes(r.texto + " " + (d.categorias[r.categoria] || "")).includes(p)));
  const grupos = Object.keys(d.categorias).map((cat) => [cat, filtrados.filter((r) => r.categoria === cat)]).filter(([, l]) => l.length);
  // arriba, lo que hay que revisar: lo que dijiste una vez y lo que aprendí solo sin que lo confirmes
  const cands = (d.candidatos || []).filter((k) => !q || q.split(/\s+/).every((p) => sinTildes(k.texto).includes(p)));
  const sinConfirmar = filtrados.filter((r) => r.auto);
  const revisar = cands.length || sinConfirmar.length ? `<div class="recuerdos-grupo revisar"><h4>Para revisar · ${cands.length + sinConfirmar.length}</h4>
      ${cands.map((k, i) => `<div class="recuerdo-fila candidato"><span class="recuerdo-texto">${escapar(k.texto)}</span>
        <span class="recuerdo-fecha">lo dijiste ${k.veces === 1 ? "1 vez" : k.veces + " veces"}</span>
        <button title="Guardarlo" class="principal" onclick="candidatoMemoria(${i}, true)">✓</button>
        <button title="No lo guardes" class="peligro" onclick="candidatoMemoria(${i}, false)">✕</button></div>`).join("")}
      ${sinConfirmar.map((r) => `<div class="recuerdo-fila"><span class="recuerdo-texto"><b class='aprendido'>★</b> ${escapar(r.texto)}</span>
        <span class="recuerdo-fecha">aprendido solo</span>
        <button title="Sí, es así" class="principal" onclick="confirmarRecuerdo(${r.id})">✓</button>
        <button title="Olvidar" class="peligro" onclick="olvidarRecuerdo(${r.id}, this)">✕</button></div>`).join("")}
    </div>` : "";
  candidatosVisibles = cands;
  $("memoria-lista").innerHTML = revisar + (grupos.length ? grupos.map(([cat, lista]) => `
    <div class="recuerdos-grupo"><h4 style="color:${COLOR_CATEGORIA[cat] || "#b8c4d0"}">${escapar(d.categorias[cat])} · ${lista.length}</h4>
      ${lista.map((r) => `<div class="recuerdo-fila" data-id="${r.id}">
        <span class="recuerdo-texto" title="Doble clic para editar">${r.auto ? "<b class='aprendido'>★</b> " : ""}${escapar(r.texto)}</span>
        <span class="recuerdo-fecha">${escapar(r.fecha || "")}</span>
        <button title="Editar" onclick="editarRecuerdo(${r.id})">✎</button>
        <button title="Olvidar" class="peligro" onclick="olvidarRecuerdo(${r.id}, this)">✕</button></div>`).join("")}
    </div>`).join("")
    : `<div class="vacio">${q ? "No encontré nada con eso." : "Todavía no hay recuerdos. Escribí uno arriba o decime «recordá que...»."}</div>`);
  $("memoria-lista").querySelectorAll(".recuerdo-texto").forEach((el) => {
    el.ondblclick = () => editarRecuerdo(Number(el.closest(".recuerdo-fila").dataset.id));
  });
}
$("memoria-buscar").addEventListener("input", pintarListaRecuerdos);

let candidatosVisibles = [];
async function candidatoMemoria(i, guardar) {
  const k = candidatosVisibles[i];
  if (!k) return;
  await api("memoria_candidato", k.texto, guardar);
  if (guardar) lineaSistema(`Guardé «${k.texto}».`);
  await abrirMemoria();
}
async function confirmarRecuerdo(id) {
  await api("memoria_confirmar", id);
  await abrirMemoria();
}

$("memoria-nuevo").addEventListener("submit", async (e) => {
  e.preventDefault();
  const texto = $("memoria-nuevo-texto").value.trim();
  if (!texto) return;
  $("memoria-nuevo-texto").value = "";
  const r = await api("memoria_agregar", texto, $("memoria-nuevo-cat").value || null);
  if (r) lineaSistema(`Guardé «${texto}»` + (r.verificado ? " ✓ verificado y anotado en la lista de control." : " (⚠ no pude verificarlo)."));
  await abrirMemoria();  // recarga red y lista
});

function editarRecuerdo(id) {
  const fila = document.querySelector(`.recuerdo-fila[data-id="${id}"]`);
  const r = memoriaDatos && memoriaDatos.recuerdos.find((x) => x.id === id);
  if (!fila || !r) return;
  fila.innerHTML = `<input class="recuerdo-editor" spellcheck="false">
    <button title="Guardar" class="principal">✓</button><button title="Cancelar">↶</button>`;
  const input = fila.querySelector("input");
  input.value = r.texto;
  input.focus();
  input.select();
  const guardar = async () => {
    if (input.value.trim() && input.value.trim() !== r.texto) await api("memoria_editar", id, input.value.trim());
    await abrirMemoria();
  };
  fila.querySelector(".principal").onclick = guardar;
  fila.querySelectorAll("button")[1].onclick = pintarListaRecuerdos;
  input.onkeydown = (e) => {
    if (e.key === "Enter") guardar();
    if (e.key === "Escape") { e.stopPropagation(); pintarListaRecuerdos(); }
  };
}

async function olvidarRecuerdo(id, boton) {
  if (boton.dataset.armado !== "1") {  // doble toque para no borrar sin querer
    boton.dataset.armado = "1";
    boton.textContent = "¿?";
    boton.classList.add("armado");
    setTimeout(() => {
      if (boton.isConnected) { boton.dataset.armado = ""; boton.textContent = "✕"; boton.classList.remove("armado"); }
    }, 3000);
    return;
  }
  await api("memoria_olvidar", id);
  await abrirMemoria();
}

const NOMBRES_CONTROL = { recuerdo: "Recuerdo", pendiente: "Pendiente", recordatorio: "Recordatorio", alarma: "Alarma", instruccion: "Instrucción" };
const COLOR_CONTROL = { recuerdo: "#29d9ff", pendiente: "#ffb547", recordatorio: "#7ab8ff", alarma: "#ff7aa8", instruccion: "#c58bff" };

function eventoControl(lista) {
  controlDatos = lista || [];
  const sinRevisar = controlDatos.filter((e) => !e.revisado).length;
  $("control-contador").hidden = !sinRevisar;
  $("control-contador").textContent = sinRevisar;
  if ($("modal-memoria").hidden || pestanaMemoria !== "control") return;
  const orden = [...controlDatos].reverse();
  $("control-lista").innerHTML = orden.length ? orden.map((e) => `
    <div class="control-fila ${e.revisado ? "revisado" : ""} ${e.verificado ? "" : "fallo"}">
      <button class="pendiente-check" onclick="revisarControl(${e.id}, ${!e.revisado})" title="${e.revisado ? "Marcar como no revisado" : "Ya lo revisé"}">${e.revisado ? "✓" : ""}</button>
      <span class="control-tipo" style="--c:${COLOR_CONTROL[e.tipo] || "#29d9ff"}">${NOMBRES_CONTROL[e.tipo] || e.tipo}</span>
      <span class="control-texto">${escapar(e.texto)}</span>
      <span class="control-verificado" title="${e.verificado ? "Lo releí del disco: quedó guardado" : "No pude confirmar que se guardó"}">${e.verificado ? "✓ VERIFICADO" : "⚠ SIN VERIFICAR"}</span>
      <span class="recuerdo-fecha">${e.fecha.slice(8, 10)}/${e.fecha.slice(5, 7)} ${e.fecha.slice(11, 16)}</span>
      <button class="pendiente-borrar" onclick="borrarControl(${e.id})" title="Quitar de la lista">✕</button>
    </div>`).join("")
    : '<div class="vacio">Todavía no registraste nada. Cuando me digas «recordá que...», «agregá ... a mis pendientes» o «recordame ...», lo anoto acá.</div>';
}

async function revisarControl(id, revisado) { eventoControl((await api("control_revisado", id, revisado)) || []); }
async function revisarTodoControl() { eventoControl((await api("control_revisar_todo")) || []); }
async function borrarControl(id) { eventoControl((await api("control_borrar", id)) || []); }
