"""Las mejoras que JARVIS se hizo a sí mismo.

Cuando le pedís algo nuevo ("mejorate: que cuando te pregunte X me digas Y"), automejora.py escribe acá la orden nueva:
un "if" en manejar() que la reconoce y, si hace falta, una función que la resuelve. main.py llama a manejar() antes que
a las demás órdenes. Así lo nuevo queda junto y separado del resto (y "deshacé la última mejora" lo saca).
"""
import re  # noqa: F401  (para las órdenes nuevas: re.search(...))

jarvis = None  # main.py se anota acá al arrancar (jarvis.emitir, jarvis.herramientas, etc.)


def manejar(texto, t):
    """Las órdenes nuevas que se agregó JARVIS. t es el mensaje normalizado (minúsculas, sin tildes).
    Devuelve la respuesta, o None si el mensaje no es ninguna de estas órdenes."""
    return None
