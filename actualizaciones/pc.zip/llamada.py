"""Modo llamada y modo videollamada: charlar con JARVIS de corrido, como por teléfono.

  - Llamada: le hablás sin decir "Jarvis" ni tocar nada; cuando termina de responder te sigue escuchando.
    Responde corto y natural, como en una charla (sin listas ni títulos).
  - Videollamada: lo mismo, y además te ve por la cámara: "¿qué tengo en la mano?", "¿cómo me queda?",
    "¿qué dice este cartel?" (solo mira cuando la pregunta tiene que ver con lo que se ve).
  - Se corta con "colgá", "cortá", "terminá la llamada", "chau" o el botón COLGAR. "Silenciá" deja de escucharte
    sin cortar (como el botón de mute). Se corta sola a los 5 minutos sin hablar y en modo juego.
Nada se graba ni se guarda: es igual que hablarle por el micrófono.
"""
import re
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

SIN_HABLAR_MAX = 5 * 60  # se corta sola si nadie habla en 5 minutos

_estado = {"activa": False, "video": False, "desde": 0.0, "silenciada": False, "ultimo": 0.0, "voz_antes": True}

EMPEZAR = re.compile(
    r"^(?:(?:che|jarvis|bueno|dale)[\s,]+)*(?:(?:activa|activame|pone|poneme|entra|entrar|inicia|empeza|abri|hace|"
    r"hagamos|arranca|quiero|podemos|hablemos|charlemos)\w*\s+(?:(?:en|el|la|una|a|un)\s+)?)?"
    r"(?:modo (?:llamada|videollamada|video llamada)|(?:una )?(?:video ?llamada|llamada)(?: conmigo| con vos| entre nosotros)?|"
    r"llamame|videollamame|hablemos por (?:llamada|telefono|videollamada)|charlemos)$")
COLGAR = re.compile(
    r"^(?:(?:bueno|listo|dale|ok|che)[\s,]+)*(?:colga\w*|corta\w*|termina\w*(?: la)? (?:video ?)?llamada|finaliza\w*|"
    r"(?:chau|adios|nos vemos|hasta luego)(?: jarvis)?|basta de (?:video ?)?llamada|sali\w* de la (?:video ?)?llamada|"
    r"fin de la (?:video ?)?llamada)$")
SILENCIAR = re.compile(r"^(?:silencia\w*|mute|muteate|no me escuches|pausa la llamada)$")
SEGUIR = re.compile(r"^(?:volve a escuchar\w*|reactiva\w*|desmute\w*|segui escuchando)$")
# en videollamada: palabras que piden mirar ("¿qué tengo en la mano?", "¿cómo me queda?", "mirá esto")
MIRA = re.compile(r"\b(?:ves|veo|viste|mira|mirame|mostrar|muestro|tengo en la mano|tengo aca|me queda|como estoy|"
                  r"como me veo|que es esto|esto|esta|este|aca|ahi|cartel|color|ropa|remera|pelo|cara|fondo|atras)\b")


def activa():
    return _estado["activa"]


def es_video():
    return _estado["activa"] and _estado["video"]


def silenciada():
    return _estado["silenciada"]


def escuchando():
    """¿Lo que digas va directo a JARVIS? (en llamada y sin silenciar)."""
    return _estado["activa"] and not _estado["silenciada"]


def _avisar_interfaz():
    jarvis.emitir("llamada", {"activa": _estado["activa"], "video": _estado["video"], "desde": _estado["desde"],
                              "silenciada": _estado["silenciada"]})


def empezar(video=False):
    if jarvis.herramientas.modo_juego.is_set():
        return "Ahora estás en modo juego: la llamada usa la IA y el micrófono todo el tiempo, mejor después."
    if _estado["activa"] and _estado["video"] == video:
        return "Ya estamos en " + ("videollamada" if video else "llamada") + ". Hablame tranquilo."
    if video:
        if jarvis.camara.gestos_activos():
            return "La cámara la está usando el control por gestos. Decime «desactivá los gestos» y probamos de nuevo."
        if not jarvis.camara.prender():
            return "No pude prender la cámara (¿la está usando otra app?). Si querés, hacemos una llamada sin video."
    elif _estado["activa"] and _estado["video"]:
        jarvis.camara.apagar()  # pasa de videollamada a llamada
    if not _estado["activa"]:  # en una llamada JARVIS habla sí o sí (al cortar vuelve como estaba)
        _estado["voz_antes"] = jarvis.voz_activada.is_set()
        _estado["manos_antes"] = jarvis.manos_libres.is_set()
        jarvis.voz_activada.set()
    _estado.update(activa=True, video=video, desde=_estado["desde"] if _estado["activa"] else time.time(),
                   silenciada=False, ultimo=time.time())
    jarvis.activar_manos_libres()  # el micrófono escuchando todo el tiempo
    threading.Thread(target=_vigilar, daemon=True).start()
    _avisar_interfaz()
    if video:
        return "¡Hola! Ya te veo. Hablame cuando quieras; para cortar decime «colgá»."
    return "¡Hola! Te escucho. Hablame cuando quieras, sin decir mi nombre; para cortar decime «colgá»."


def terminar(motivo=""):
    if not _estado["activa"]:
        return "No estábamos en ninguna llamada."
    duracion = time.time() - _estado["desde"]
    video = _estado["video"]
    _estado.update(activa=False, video=False, silenciada=False)
    if not _estado["voz_antes"]:
        jarvis.voz_activada.clear()
    if not _estado.get("manos_antes", True):
        jarvis.manos_libres.clear()  # el micrófono vuelve a como estaba antes de la llamada
    if video:
        jarvis.camara.apagar()
    _avisar_interfaz()
    minutos, segundos = divmod(int(duracion), 60)
    largo = f"{minutos} min {segundos} s" if minutos else f"{segundos} s"
    return f"Listo, corté la {'videollamada' if video else 'llamada'} ({largo})." + (f" {motivo}" if motivo else "")


def silenciar(si=True):
    if not _estado["activa"]:
        return None
    _estado["silenciada"] = si
    _avisar_interfaz()
    return ("Listo, no te escucho hasta que toques el micrófono de la llamada o me digas «Jarvis, volvé a escuchar»."
            if si else "Te escucho de nuevo.")


def oyo_algo():
    """Cada vez que le hablás: la llamada sigue viva."""
    _estado["ultimo"] = time.time()


def _vigilar():
    desde = _estado["desde"]
    while _estado["activa"] and _estado["desde"] == desde:
        time.sleep(5)
        if not _estado["activa"]:
            return
        if jarvis.herramientas.modo_juego.is_set():
            jarvis.mostrar(terminar("Entraste en modo juego."), jarvis.nueva_orden())
            return
        if time.time() - _estado["ultimo"] > SIN_HABLAR_MAX and not jarvis.hablando.is_set():
            jarvis.mostrar(terminar("Hacía un rato que no hablábamos."), jarvis.nueva_orden())
            return
        if _estado["video"]:
            jarvis.camara.mantener_prendida()  # que no se apague sola a los 2 minutos


def manejar(texto, t):
    """Órdenes de la llamada (empezar, cortar, silenciar). Devuelve la respuesta o None."""
    t = t.strip(" ¿?¡!.,")
    if _estado["activa"]:
        if COLGAR.match(t):
            return terminar()
        if SILENCIAR.match(t):
            return silenciar(True)
        if SEGUIR.match(t):
            return silenciar(False)
    m = EMPEZAR.match(t)
    if m:
        return empezar(video=bool(re.search(r"video", t)))
    return None


def estilo():
    """Lo que se suma al prompt mientras dura la llamada (cómo responder)."""
    if not _estado["activa"]:
        return ""
    texto = ("Estás en una LLAMADA de voz con el usuario: respondé como en una charla por teléfono, corto (1 a 3 "
             "oraciones), natural y cálido, SIN listas, títulos, emojis ni código. Si algo es largo, contá lo "
             "principal y preguntá si quiere que sigas.")
    if _estado["video"]:
        texto += (" Es una VIDEOLLAMADA: si te adjunté una imagen, es lo que ve tu cámara AHORA (el usuario y lo que "
                  "muestra). Mencioná lo que se ve solo si la pregunta tiene que ver; hablale de vos (\"tenés...\").")
    return texto


def imagen_para(pregunta_n):
    """En videollamada, si la pregunta tiene que ver con lo que se ve: el cuadro de la cámara (base64), o None."""
    if not es_video() or not MIRA.search(pregunta_n):
        return None
    import base64

    jpg, _ = jarvis.camara.foto()
    return base64.b64encode(jpg).decode() if jpg else None
