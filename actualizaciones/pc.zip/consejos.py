"""Consejos de JARVIS.

- Cuando le preguntás ("¿qué me aconsejás?", "¿qué hago ahora?", "organizame el día"): mira tu agenda (fechas que le
  contaste, recordatorios, pendientes), los mails sin leer, el clima y lo que estuviste haciendo en la compu, y te
  propone qué hacer primero.
- Por su cuenta (Configuraciones > "Consejos por su cuenta"), de vez en cuando y nunca mientras jugás:
  * cuando terminás de jugar mucho rato y se acerca algo importante;
  * el día antes (y el mismo día) de una fecha importante;
  * si llevás 2 horas seguidas en la compu, que hagas una pausa;
  * si se hace muy tarde;
  * a la tardecita, si tenés pendientes sin hacer.
  Cada aviso tiene su "enfriamiento" para no repetirse, y queda en el chat (y en una notificación de Windows).
"""
import datetime
import json
import os
import re
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "consejos.json")  # cuándo se dio cada aviso (para no repetirlo)
ACTIVOS = True  # Configuraciones > "Consejos por su cuenta"
CADA = 300      # cada 5 minutos se fija si hay algo para decir

MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
         "noviembre", "diciembre"]
PIDE = re.compile(r"\b(?:que me aconsejas|aconsejame|dame (?:un |algun |unos )?consejos?|algun consejo|"
                  r"que (?:hago|puedo hacer|deberia hacer|me conviene hacer)(?: (?:ahora|hoy|esta (?:tarde|noche)|"
                  r"primero|despues))?$|organiza(?:me)? (?:el|mi) (?:dia|tarde|semana)|que me recomendas hacer|"
                  r"ayudame a organizarme|por donde (?:arranco|empiezo)|como vengo(?: hoy)?$)")
PROMPT = """Sos JARVIS, el asistente personal del usuario (un estudiante de liceo en Uruguay). Con los datos de su día,
dale de 2 a 4 consejos concretos y ordenados por prioridad para AHORA: qué hacer primero, cuánto tiempo y qué dejar para
después. Tené en cuenta las fechas cercanas (cuántos días faltan), los pendientes, cuánto jugó o estudió hoy, la hora y el
clima. Español rioplatense, directo y cálido, sin sermones, sin relleno y sin inventar cosas que no están en los datos.
Si no hay nada urgente, decilo y proponé algo útil o un descanso. Nada de emojis."""

_estado = {"pendiente": None}  # un aviso guardado para cuando termines de jugar


# ---------- Fechas importantes (de tus recuerdos y recordatorios) ----------

def fechas_en(texto, hoy):
    """Las fechas que aparecen en un texto ('el 27 de octubre', '3/11'), como días del calendario."""
    n = jarvis.normalizar(texto)
    fechas = []
    for d, mes in re.findall(r"\b(\d{1,2})(?: de)? (" + "|".join(MESES) + r"|setiembre)\b", n):
        fechas.append((int(d), 9 if mes == "setiembre" else MESES.index(mes) + 1))
    for d, m in re.findall(r"\b(\d{1,2})/(\d{1,2})\b", n):
        fechas.append((int(d), int(m)))
    salida = []
    for d, m in fechas:
        try:
            f = datetime.date(hoy.year, m, d)
        except ValueError:
            continue
        if (hoy - f).days > 60:  # ya pasó hace rato: es del año que viene
            f = f.replace(year=hoy.year + 1)
        salida.append(f)
    return salida


def eventos_proximos(dias=14, hoy=None, con_recordatorios=True):
    """[(fecha, qué es, días que faltan)] de acá a 'dias' días: lo que le contaste con fecha y tus recordatorios.
    con_recordatorios=False: solo las fechas importantes que le contaste (para los avisos por su cuenta: un
    recordatorio ya avisa solo a su hora, y «Hoy es Crear látigo virtual. ¿Tenés todo listo?» no tenía sentido)."""
    hoy = hoy or datetime.date.today()
    eventos = []
    for r in jarvis.memoria.todos():
        if r["categoria"] == "instrucciones":
            continue
        for f in fechas_en(r["texto"], hoy):
            if 0 <= (f - hoy).days <= dias:
                eventos.append((f, r["texto"], (f - hoy).days))
    for r in (jarvis.herramientas.cargar_recordatorios() if con_recordatorios else []):
        try:
            f = datetime.datetime.fromisoformat(r["cuando"]).date()
        except Exception:
            continue
        if 0 <= (f - hoy).days <= dias and r.get("texto"):
            eventos.append((f, r["texto"], (f - hoy).days))
    vistos, salida = set(), []
    for e in sorted(eventos):
        if (e[0], e[1]) not in vistos:
            vistos.add((e[0], e[1]))
            salida.append(e)
    return salida


def cuando_es(dias):
    return "hoy" if dias == 0 else "mañana" if dias == 1 else f"en {dias} días"


def lo_importante(texto):
    """'La Expoferia de robótica es el 27 de octubre' -> 'La Expoferia de robótica' (para avisos cortos)."""
    corto = re.split(r"\s+(?:es|son|sera|va a ser|cae)\s+(?:el|los|la)\b|\s+el\s+\d|,", texto, maxsplit=1)[0]
    return corto.strip(" .") or texto


# ---------- Consejos cuando los pedís ----------

def contexto():
    j = jarvis
    ahora = datetime.datetime.now()
    partes = [f"Ahora es {j.DIAS[ahora.weekday()]} {ahora.day} de {MESES[ahora.month - 1]}, {ahora:%H:%M}."]
    eventos = eventos_proximos(21)
    partes.append("Fechas importantes cercanas: " + ("; ".join(f"{t} ({cuando_es(d)}, {f:%d/%m})" for f, t, d in eventos)
                                                       if eventos else "ninguna registrada en los próximos 21 días."))
    sin_hacer = [p["texto"] + (f" ({j.habilidades.describir_fecha(p['para'])})" if p.get("para") else "")
                 for p in j.habilidades.ordenados()]
    partes.append("Pendientes sin hacer (los que vencen antes, primero): " + ("; ".join(sin_hacer) if sin_hacer else "ninguno."))
    try:
        partes.append(j.actividad.texto_para_consejos())
    except Exception:
        pass
    try:
        if j.conexiones.gmail_configurado():
            resultado = {}
            hilo = threading.Thread(target=lambda: resultado.update(total=j.conexiones.leer_correos(1)[0]), daemon=True)
            hilo.start()
            hilo.join(6)  # si Gmail tarda, se sigue sin ese dato
            if "total" in resultado:
                partes.append(f"Mails sin leer: {resultado['total']}.")
    except Exception:
        pass
    try:
        c = j.habilidades.clima_corto()
        partes.append(f"Clima en {c['ciudad']}: {c['temp']} grados, {c['estado']}.")
    except Exception:
        pass
    return "\n".join(partes)


def aconsejar(pregunta):
    datos = contexto()
    try:
        r = jarvis.chat_modelo([{"role": "system", "content": PROMPT},
                                {"role": "user", "content": f"Datos del día:\n{datos}\n\nLo que pide: {pregunta}"}],
                               temperature=0.5, num_predict=420)
        texto = r["message"]["content"].strip()
        if texto:
            return jarvis.pulir_estilo(texto)
    except Exception:
        pass
    # sin IA (modo juego): lo básico, con reglas
    eventos = eventos_proximos(7)
    if eventos:
        f, t, d = eventos[0]
        return f"Lo más cercano: {lo_importante(t)} es {cuando_es(d)}. Dedicale un rato hoy, aunque sea media hora."
    return "No veo nada urgente en tu agenda. Si tenés energía, avanzá con algo de estudio; si no, descansá."


# ---------- Avisos por su cuenta ----------

def _cargar():
    try:
        with open(ARCHIVO, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _guardar(datos):
    tmp = ARCHIVO + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=1)
    os.replace(tmp, ARCHIVO)


def enfriado(clave, horas):
    """True si el aviso 'clave' no se dio en las últimas 'horas' (y lo marca como dado)."""
    datos = _cargar()
    if time.time() - datos.get(clave, 0) < horas * 3600:
        return False
    datos[clave] = time.time()
    _guardar(datos)
    return True


def jugando():
    try:
        return jarvis.herramientas.modo_juego.is_set() or jarvis.actividad.para_consejos()["jugando_ahora"]
    except Exception:
        return False


def avisar(texto):
    """Lo dice en el chat (queda en la charla), con una notificación de Windows y, si la voz está prendida, en voz alta."""
    j = jarvis
    with j.lock:
        j.historial.append({"role": "assistant", "content": texto})
        del j.historial[:-j.MAX_MENSAJES]
        j.guardar_historial()
    j.emitir("jarvis", texto)
    j.herramientas.notificar("J.A.R.V.I.S. · Consejo", texto[:200])
    try:
        if j.voz_activada.is_set() and not j.llamada.activa() and not j.hablando.is_set():
            j.hablar(texto, threading.Event())
    except Exception:
        pass


def revisar(ahora=None):
    """Se fija si hay algo para decir. Devuelve el aviso (o None)."""
    ahora = ahora or datetime.datetime.now()
    hoy = ahora.date()
    d = jarvis.actividad.para_consejos()
    if jugando():
        # mientras jugás no se dice nada; si fue mucho rato, se guarda para cuando termines
        juego = d.get("juego")
        if juego and juego["hasta"] - juego["desde"] >= 2 * 3600:
            _estado["pendiente"] = juego
        return None
    if _estado["pendiente"]:
        juego, _estado["pendiente"] = _estado["pendiente"], None
        horas = (juego["hasta"] - juego["desde"]) / 3600
        if enfriado(f"juego-{int(juego['desde'])}", 24):
            eventos = eventos_proximos(5, hoy, con_recordatorios=False)
            texto = f"Jugaste {horas:.1f} horas de {juego['app']}.".replace(".0 horas", " horas")
            if eventos:
                f, t, dias = eventos[0]
                texto += f" Acordate: {lo_importante(t)} es {cuando_es(dias)}. ¿Le dedicás un rato ahora?"
            else:
                texto += " Buen momento para estirarte y tomar agua."
            return texto
    activo = d.get("seguido", 0)
    hora = ahora.hour + ahora.minute / 60
    if 1 <= hora < 5 and activo > 600 and enfriado(f"tarde-{hoy}", 20):
        return f"Ya son las {ahora:%H:%M}. Mañana te va a costar arrancar: si podés, cortá por hoy."
    if 8 <= hora < 22:
        for f, t, dias in eventos_proximos(1, hoy, con_recordatorios=False):
            if enfriado(f"evento-{f}-{dias}-{jarvis.normalizar(t)[:40]}", 30):
                cuando = "Hoy" if dias == 0 else "Mañana"
                return f"{cuando} es {lo_importante(t)} ({f:%d/%m}). ¿Tenés todo listo? Si querés, te ayudo a repasar."
    if 8 <= hora < 22:  # un pendiente con fecha que vence mañana (o hoy)
        for p, dias in jarvis.habilidades.que_vence(hoy, 1):
            if dias >= 0 and enfriado(f"vence-{p['id']}-{dias}", 30):
                cuando = "hoy" if dias == 0 else "mañana"
                return f"Acordate: «{p['texto']}» es para {cuando}. ¿Le dedicás un rato ahora?"
    if activo >= 2 * 3600 and enfriado("pausa", 3):
        return f"Llevás {int(activo // 3600)} horas seguidas en la compu. Tomate 5 minutos: estirate y tomá agua."
    sin_hacer = [p["texto"] for p in jarvis.habilidades.pendientes() if not p.get("hecho")]
    if sin_hacer and 18 <= hora < 21 and activo > 300 and enfriado(f"pendientes-{hoy}", 20):
        lista = ", ".join(sin_hacer[:3]) + ("..." if len(sin_hacer) > 3 else "")
        return f"Te {'queda un pendiente' if len(sin_hacer) == 1 else f'quedan {len(sin_hacer)} pendientes'}: {lista}. ¿Arrancamos con uno?"
    return None


def _bucle():
    time.sleep(90)  # que JARVIS termine de arrancar
    while True:
        try:
            if ACTIVOS:
                texto = revisar()
                if texto:
                    avisar(texto)
        except Exception:
            pass
        time.sleep(CADA)


_iniciado = [False]


def iniciar():
    if _iniciado[0]:
        return
    _iniciado[0] = True
    threading.Thread(target=_bucle, daemon=True).start()


APAGAR = re.compile(r"\b(?:no me (?:des|tires|mandes) (?:mas )?consejos|deja de (?:darme|tirarme|mandarme) consejos|"
                    r"desactiva (?:los )?consejos|apaga (?:los )?consejos)\b")
PRENDER = re.compile(r"\b(?:activa|prende|volve a darme|dame de nuevo) (?:los )?consejos(?: por tu cuenta| solo)?\b")


def manejar(texto, t):
    global ACTIVOS
    t = t.strip(" ¿?¡!.,")
    if APAGAR.search(t):
        ACTIVOS = False
        _guardar_ajuste()
        return "Listo, no te doy más consejos por mi cuenta. Si querés uno, preguntame «¿qué me aconsejás?»."
    if PRENDER.search(t):
        ACTIVOS = True
        _guardar_ajuste()
        return "Listo, de vez en cuando te voy a dar algún consejo (nunca mientras jugás)."
    if PIDE.search(jarvis.sin_insultos(t)):
        jarvis.emitir("detalle", "Mirando tu agenda, pendientes y lo que hiciste hoy...")
        return aconsejar(texto)
    return None


def _guardar_ajuste():
    try:
        jarvis.ajustes.guardar({"consejos_solos": ACTIVOS})
    except Exception:
        pass
