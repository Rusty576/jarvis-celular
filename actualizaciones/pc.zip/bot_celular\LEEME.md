# El bot del celular

`Codigo.gs` es JARVIS en el celular: vive gratis en Google Apps Script y piensa con Gemini (o, si Gemini no tiene
cupo o anda lento, con una IA de repuesto). Lo usan el bot de Telegram y la app (`app_celular/`, publicada en
https://Rusty576.github.io/jarvis-celular/).

Para actualizar el tuyo: decile a JARVIS «actualizá el bot del celular» (o doble clic en `Actualizar bot del
celular.bat`, en MiJarvis) y apretá Enter. Se abre la página de Google en tu navegador: elegí tu cuenta (la del
bot), tocá «Seleccionar todo» si aparece la lista de permisos, y «Continuar». Si la página no aparece, el link queda
copiado: pegalo en el navegador donde tenés tu cuenta (o apretá Enter en la ventana y se abre de nuevo). La PC baja
tu proyecto, cambia solo el archivo del bot, lo sube y publica la versión nueva **en la misma dirección** (Telegram
y la app siguen conectados). Lo hace `actualizar_mi_bot.ps1` con clasp, igual que «JARVIS para otra persona», y el
permiso que le diste a la PC se borra al terminar (también si la vez anterior se cerró la ventana a mitad de camino).

La primera vez puede pedirte prender la «API de Google Apps Script» (se abre la página: es un interruptor). Después
de prenderla, Google tarda unos minutos en darse cuenta (a veces deja bajar el proyecto pero no subirlo): la PC espera
y reintenta sola, hasta 10 minutos.

**Si la versión nueva pide un permiso nuevo** (la 2026.10.26.1 agrega Google Drive, para pasarle archivos a la
PC), la PC te abre el proyecto: arriba, en la lista de funciones (al lado de «Ejecutar»), elegí `autorizar`, tocá
«Ejecutar» y aceptá. Mientras no lo aceptes, el bot no contesta.

Si algo falla, la misma ventana te guía para hacerlo a mano: pegar el código, guardar y en Implementar >
Gestionar implementaciones > lápiz > Versión: «Nueva versión» > Implementar.

## Qué trae la versión 2026.10.26.3

- **Documentos, presentaciones y pósters de verdad**, en tu Google Drive:
  - «haceme un documento sobre…»: un Google Docs con formato (títulos, negritas, listas, tablas, citas, saltos de
    página y hasta 3 imágenes hechas a medida), con 6 estilos (claro, elegante, colorido, oscuro, naturaleza, jarvis);
  - «haceme una presentación de…»: Google Slides con diseño (portada, contenido, imagen al costado, dos columnas,
    sección, cita y cierre), imágenes hechas a medida y las notas del que expone; en la app se ven las primeras;
  - «haceme un afiche / flyer / invitación…»: un póster (vertical, horizontal o cuadrado) con una imagen de fondo, el
    título grande y los datos; aparece cómo quedó.
  En la app, cada uno trae los botones «Abrir» y «Bajar en PDF». Con «a la PC» llegan en Word, PowerPoint o PDF
  («pasámelo a la PC» después también anda). Un documento ya no se manda nunca como texto a la PC (lo que pasó el
  26/10: llegó un .txt con el resumen).
  Las presentaciones y los pósters usan la API de Google Slides con el permiso de Drive (no piden otro). El
  actualizador declara las APIs de Drive y Slides en el proyecto (Google las prende sola).
- **«Reportar un problema»** (en la app: Ajustes; en Telegram: `/reporte qué pasó`; o decile «mandale esto a
  Claude»): un archivo con lo que pasó, la charla (con qué IA contestó cada cosa), los últimos errores del bot y cómo
  están las IAs llega a la PC, a `MiJarvis\reportes` (sin claves). Ahí lo lee Claude: decile «revisá el último reporte».

## Qué trajo la versión 2026.10.26.2

- **IAs de repuesto, todas gratis y sin tarjeta.** Si Gemini se queda sin cupo, falla o tarda, contesta otra:
  - **Groq** (la más rápida; si JARVIS en la PC tiene su clave, la pasa sola);
  - **Gemma**, de Google: usa **la misma clave de Gemini**, con su propio cupo, así que anda sin hacer nada. Si tu
    cuenta no le deja usar herramientas, igual contesta (con lo de tu día escrito: pendientes, recordatorios, clima),
    pero no puede hacer cosas (anotar, mandar, abrir);
  - **Mistral** (plan gratis «Experiment»: pide verificar el celular) y **OpenRouter** (sus modelos gratis, hasta 50
    preguntas por día), con su clave gratis.

  Groq, Mistral y OpenRouter hablan como la de OpenAI; Gemma como Gemini. Qué modelo usar se le pregunta a cada una
  (los cambian seguido). Usan las mismas herramientas (pendientes, recordatorios, mails, la PC...). Lo que no hacen:
  ver fotos y videos (eso, Gemini). Cerebras no está: desde 2026 pide tarjeta.
  - Si Gemini tardó más de 25 segundos o falló, por 15 minutos contestan primero las de repuesto (una hora si se quedó
    sin cupo). Una que se quedó sin cupo descansa 5 minutos.
  - Nunca más de 70 segundos por respuesta: pasado eso, la app de Android contesta con el cerebro del celular. Si no
    contesta ninguna, dice qué pasó con cada una («Gemini no tiene más cupo gratis por hoy; Gemma tampoco tiene cupo
    ahora»).
  - Las claves se ponen en la app (Ajustes › IAs de repuesto: «Conseguir una clave gratis», pegarla, «Guardar»; se
    prueba antes de guardarla). Gemma no lleva clave. Si JARVIS en la PC tiene la de Groq (`GROQ_API_KEY`), se la pasa sola al bot (se
    apaga en Configuraciones › Celular). Quedan en las Propiedades del script (`IA_GROQ`...), nunca en el código, y
    nunca vuelven a la app. Si la quitás desde la app, la PC no la vuelve a poner.
  - Ven lo mismo que Gemini: la charla, tus recuerdos y lo que traen las herramientas. Las versiones gratis de
    Mistral y OpenRouter pueden usar lo que les mandás para entrenar.
- **Pasarle archivos a la PC**: fotos, videos, documentos de cualquier tipo, hasta 2 GB. Pasan por una carpeta de tu
  Google Drive («JARVIS · para la PC»): la PC los baja a `documentos\Del celular` y los manda a la papelera de Drive.
  - Desde la app: el botón «🖥️ A la PC» del adjunto, o escribir «mandalo a la PC» con el archivo. Los de más de 4 MB
    la app los sube directo a Drive, de a pedazos (el bot solo abre la subida).
  - Desde Telegram: mandá el archivo con «a la PC» en el texto (hasta 20 MB: Telegram no deja bajar más).
  - Si se lo pedís después («pasale a la PC la foto que te mandé», «mandá la imagen que hiciste a la compu»), lo hace
    JARVIS con la herramienta.
  - La PC solo puede bajar lo que se le anotó (no cualquier archivo de tu Drive).

**Pide un permiso nuevo**: Google Drive (ver arriba: `autorizar`).

## Qué trajo la versión 2026.10.25.5

- **Los avisos van a la app.** El buen día, lo de la noche, los cuidados, los recordatorios y lo que contesta la PC
  quedan en una bandeja que lee la app (la de Android los muestra como notificación con la app cerrada). Dónde
  llegan se elige en la app, en Ajustes › Avisos: en la app (lo que queda la primera vez que la abrís), en Telegram
  o en los dos. Si la app no se abre en dos semanas, vuelven a Telegram solos, para que no se pierdan.
- **Fotos en la charla.** «Mostrame fotos de carpinchos» (fotos libres de Wikimedia Commons y Openverse);
  «hacé una imagen de…» (cuadrada, vertical u horizontal; «Otra versión» hace otra con la misma descripción); la
  captura de pantalla de la PC llega con la foto.
- **Noticias** de Google Noticias, gratis y sin cupo: «¿qué noticias hay de Uruguay?». Si la búsqueda en internet se
  queda sin cupo, contesta con los titulares en vez de «sin cupo».
- **«Pasale este link a la PC»**: el texto, el link o lo que venían charlando aparece en JARVIS de la PC y queda en
  la carpeta `documentos\Del celular`.
- **No dice que hizo algo si no lo hizo** (antes, «abrime Monoposto» contestaba «ahí te lo abro» sin abrir nada).
- La foto que mandaste ya no se repite en cada mensaje: solo cuando le preguntás por ella.
- Desde los Ajustes de la app: cómo te llama, si contesta corto o largo, la hora del buen día, lo de la noche y los
  cuidados (valen también para Telegram).

No pide permisos nuevos.

## JARVIS para otra persona

Un JARVIS propio para alguien que no tiene tu PC (por ejemplo tu mamá): **sus** mails, **sus** recuerdos,
**sus** recordatorios y sus WhatsApp. No ve nada tuyo y vos no ves nada suyo. Es este mismo `Codigo.gs`, pero
en un proyecto de **su** cuenta de Google. Solo usa la app, sin Telegram.

### La forma rápida: que lo haga la PC

Doble clic en **`JARVIS para otra persona.bat`** (en la carpeta de JARVIS), con esa persona al lado (o con su
cuenta a mano). La PC hace todo; esa persona solo tiene que:

1. **Entrar con su cuenta de Google** y tocar «Permitir» (se abre el navegador: elegí SU cuenta o «Usar otra
   cuenta», no la tuya).
2. Si aparece la página de **ajustes de Apps Script**: prender «API de Google Apps Script» (una sola vez por
   cuenta). La PC sigue sola.
3. **Aceptar los permisos de JARVIS** (calendario, Gmail, documentos), en una ventana privada. Si dice «Google no
   verificó esta app»: Configuración avanzada > Ir a JARVIS (no seguro) > Permitir.
4. **Crear la clave de Gemini** en AI Studio («Create API key») y tocar el botón de copiar. La PC la ve sola.
5. **Escanear los dos QR** que aparecen en la pantalla: el primero instala la app de Android; el segundo la conecta
   (tocar «Copiar», no abrir, y abrir la app JARVIS).

Nada de su cuenta queda en tu PC: el permiso que le da a la PC se borra al terminar. Queda anotado solo cuál es su
proyecto (en `%LOCALAPPDATA%\JARVIS\otras_personas`), para poder **actualizarlo**: el mismo .bat te ofrece
«actualizarlo a la versión nueva» (sube el `Codigo.gs` de ahora y la dirección sigue siendo la misma).

La primera vez, el .bat baja Node.js y clasp (la herramienta de Google para Apps Script) en
`%LOCALAPPDATA%\JARVIS`. No instala nada en Windows.

### A mano (si la forma rápida no anda)

Se hace una sola vez, con su cuenta de Google abierta (en la compu o en el celular, en el navegador):

1. **La clave de Gemini.** Entrá a https://aistudio.google.com/apikey con su cuenta y tocá «Create API key». Copiala.
2. **El proyecto.** Entrá a https://script.google.com y tocá «Nuevo proyecto». Borrá lo que trae, pegá todo
   `Codigo.gs` y guardá con Ctrl+S. Ponele de nombre «JARVIS».
3. **La clave en el proyecto.** Andá al engranaje (Configuración del proyecto) > Propiedades del script >
   Agregar propiedad del script. Propiedad: `GEMINI`, valor: la clave del paso 1. Guardá.
4. **Prepararlo.** Volvé al editor (`< >`). Arriba, al lado de «Ejecutar», elegí `configurarParaApp` y tocá
   «Ejecutar». Google pide permisos (calendario y Gmail):
   - Revisar permisos > su cuenta.
   - Si dice «Google no verificó esta app»: Configuración avanzada > Ir a JARVIS (no seguro) > Permitir.

   Es normal: la app es de ella misma y nadie más la usa.
5. **Publicarlo.** Implementar > Nueva implementación > engranaje > «Aplicación web».
   - Ejecutar como: **yo**
   - Quién tiene acceso: **cualquier usuario**

   Tocá Implementar y copiá la dirección que termina en `/exec`.
6. **En su celular, antes de 15 minutos.** Abrí esa dirección en Chrome. Aparece el botón «Abrir JARVIS».
   - **Con la app de Android** (mejor: llama, pone alarmas y avisa sin internet): instalala desde
     https://rusty576.github.io/jarvis-celular/android/JARVIS.apk. Después mantené apretado el botón «Abrir JARVIS»,
     tocá «Copiar dirección del enlace» y abrí la app: se conecta sola.
   - **Con la web app**: tocá «Abrir JARVIS». Después, en Chrome: ⋮ > «Instalar app».

   Si pasaron los 15 minutos, volvé a ejecutar `configurarParaApp` (paso 4) y abrí la dirección de nuevo.
   Pasado ese rato, la dirección sola no muestra nada: la llave queda guardada en la app de su celular.

Listo. Ya puede decirle «Jarvis…» o tocar HABLAR.

### Qué puede hacer

| Pedido | Qué pasa |
| --- | --- |
| «recordame mañana a las 9 llamar al médico» | Le llega como aviso de su Google Calendar a esa hora, aunque la app esté cerrada. |
| «¿tengo mails nuevos?», «leeme el de la escuela» | Lee sus mails. Mandar, responder y borrar siempre se confirman con un botón. |
| «acordate que el número de Juan es 099 123 456» | Lo guarda en sus recuerdos. |
| «mandale un WhatsApp a Juan que llego tarde» | Le abre WhatsApp con el mensaje escrito y ella lo manda. Usa el número de sus recuerdos; si no lo tiene, ella elige el contacto. |
| «poné música de Sandro», «abrí Maps», «llamá a Juan» | Lo abre en el celular. |
| «agregá comprar yerba a mis pendientes» | Lo anota en sus pendientes. |
| «haceme un documento con la receta del flan» | Le crea un Google Docs en su Drive (con títulos y listas) y le aparece el botón para abrirlo. |
| «haceme un dibujo de un gato astronauta» | Hace la imagen y se la muestra; tocándola se ve grande, con «Guardar» (a la galería, carpeta JARVIS), «Compartir» y «Otra versión». |
| «mostrame fotos de la rambla de Montevideo» | Le muestra fotos de verdad (libres de usar) en la charla. |
| «¿qué noticias hay?» | Los titulares de Google Noticias. |
| Mandar un archivo (el clip, al lado de la caja) | Fotos, PDF, audio, video o textos de hasta 15 MB: después le pregunta lo que quiera sobre eso. |

También tiene clima, noticias y búsquedas en internet, como el tuyo. Lo que no tiene es lo de la PC (órdenes
a la PC, ver la PC): esos botones no aparecen.

**Sobre las imágenes:** con la clave gratis de Gemini, Google no deja hacer imágenes (probado en octubre de 2026:
cupo 0 en todos los modelos de imágenes, también el nuevo «gemini-3.1-flash-lite-image»), así que Gemini escribe
la descripción y la imagen la hace Pollinations (gratis, sin cuenta; trae un logo chiquito en una esquina). **Editar una
foto** («sacale el fondo») necesita el modelo de imágenes de Gemini, que pide una clave con facturación: con la
gratis, JARVIS lo explica en vez de hacerlo.

### Para actualizarlo

- **La app** se actualiza sola: es la misma que la tuya (la de Android avisa cuando hay una versión nueva).
- **El bot** de su proyecto no se actualiza solo. Lo más fácil: `JARVIS para otra persona.bat` > su nombre. A
  mano: pegá `Codigo.gs` en su proyecto, guardá y hacé Implementar > Gestionar implementaciones > lápiz >
  «Nueva versión» > Implementar (si después no contesta, ejecutá `autorizar` como arriba).

### El último documento y los documentos como los de Claude (2026.10.31.1)

- El último PDF que le mandás queda 6 horas en tu Drive («JARVIS · último documento»). Si después le pedís algo de
  él («hazme un quiz del documento»), se lo vuelve a mostrar a Gemini; si contesta una IA de repuesto (que no lee
  PDFs), Drive lo pasa a texto y le llega el texto.
- En los documentos (`crear_documento`): recuadros de color (`> 💡 **Consejo:** …`, `> ⚠️ **Importante:** …`,
  `> 📌 **Nota:** …`, `> ✅ **En resumen:** …`), código en una caja con letra de código, y diagramas: un bloque
  ` ```mermaid ` (procesos, organigramas, líneas de tiempo) lo dibuja [Kroki](https://kroki.io) (gratis, sin clave) y
  queda como imagen.
