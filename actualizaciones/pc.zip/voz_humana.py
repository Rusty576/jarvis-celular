"""La voz humana de JARVIS: Piper, una voz neuronal que corre en la compu, SIN internet (el modelo se baja una sola vez,
unos 60 MB, a %LOCALAPPDATA%\\JARVIS\\voz, fuera de OneDrive). Suena mucho más natural que la de Windows.

Si algo falta o falla (el paquete piper-tts, el modelo todavía bajando, la placa de sonido), JARVIS habla con la voz de
Windows de siempre, sin trabarse. Para volver a esa a propósito: Ajustes › «Voz de JARVIS en la compu» › Windows."""
import json
import os
import threading
import time
import urllib.request

CARPETA = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "JARVIS", "voz")
BASE = "https://huggingface.co/rhasspy/piper-voices/resolve/main/"
# nombre -> (ruta en piper-voices, cómo se ve en Ajustes)
VOCES = {
    "es_MX-claude-high": ("es/es_MX/claude/high", "Claude (hombre, México neutro): la más natural"),
    "es_MX-ald-medium": ("es/es_MX/ald/medium", "Ald (hombre, México)"),
    "es_ES-davefx-medium": ("es/es_ES/davefx/medium", "Dave (hombre, España)"),
    "es_AR-daniela-high": ("es/es_AR/daniela/high", "Daniela (mujer, Argentina)"),
}
POR_DEFECTO = "es_MX-claude-high"
_bajando = set()
_lock = threading.Lock()


def ruta(nombre):
    return os.path.join(CARPETA, nombre + ".onnx")


def esta(nombre):
    return os.path.exists(ruta(nombre)) and os.path.exists(ruta(nombre) + ".json")


def bajar(nombre, al_terminar=None):
    """Baja el modelo en segundo plano (una sola vez; mientras, habla la voz de Windows)."""
    if nombre not in VOCES or esta(nombre):
        return
    with _lock:
        if nombre in _bajando:
            return
        _bajando.add(nombre)

    def trabajo():
        try:
            os.makedirs(CARPETA, exist_ok=True)
            # (el .json primero: es chico; si no se puede bajar, ni empieza el grande)
            for sufijo, destino in ((".onnx.json", ruta(nombre) + ".json"), (".onnx", ruta(nombre))):
                if os.path.exists(destino):
                    continue
                pedido = urllib.request.Request(BASE + VOCES[nombre][0] + "/" + nombre + sufijo,
                                                headers={"User-Agent": "JARVIS"})
                with urllib.request.urlopen(pedido, timeout=60) as r, open(destino + ".parte", "wb") as f:
                    while True:
                        trozo = r.read(1 << 16)
                        if not trozo:
                            break
                        f.write(trozo)
                if sufijo == ".onnx.json":
                    with open(destino + ".parte", encoding="utf-8") as f:
                        json.load(f)   # (que sea el archivo de verdad, no una página de error)
                elif os.path.getsize(destino + ".parte") < 5_000_000:
                    raise OSError("el modelo llegó incompleto")
                os.replace(destino + ".parte", destino)
            if al_terminar:
                al_terminar()
        except Exception:
            pass   # (sin internet ahora: se vuelve a probar al próximo arranque)
        finally:
            with _lock:
                _bajando.discard(nombre)

    threading.Thread(target=trabajo, daemon=True).start()


class Voz:
    """Una voz cargada (tarda unos segundos, una vez). decir() habla y se corta en el acto si se pide parar."""

    def __init__(self, nombre):
        from piper import PiperVoice   # (si no está el paquete, falla acá y queda la de Windows)
        self.nombre = nombre
        self.voz = PiperVoice.load(ruta(nombre))

    def precalentar(self):
        list(self.voz.synthesize("Hola."))   # (la primera frase tarda más: que sea esta, en silencio)

    def decir(self, texto, velocidad, parar):
        """velocidad: la de Ajustes (-5 lento ... 8 rápido). Vuelve cuando terminó o se cortó."""
        import numpy as np
        import sounddevice as sd
        from piper import SynthesisConfig

        escala = max(0.7, min(1.35, 1.0 - float(velocidad) * 0.04))   # (2, el de siempre: un poquito más rápido)
        config = SynthesisConfig(length_scale=escala)
        for trozo in self.voz.synthesize(texto, syn_config=config):   # (oración por oración: arranca con la primera)
            if parar.is_set():
                return
            sd.play(np.frombuffer(trozo.audio_int16_bytes, dtype=np.int16), trozo.sample_rate)
            while True:
                if parar.is_set():
                    sd.stop()
                    return
                if not sd.get_stream().active:
                    break
                time.sleep(0.03)


def cargar(nombre, al_bajar=None):
    """La voz lista para hablar, o None (y la baja si falta; al_bajar: lo que se hace cuando termina de bajar)."""
    nombre = nombre if nombre in VOCES else POR_DEFECTO
    if not esta(nombre):
        bajar(nombre, al_bajar)
        return None
    try:
        voz = Voz(nombre)
        voz.precalentar()
        return voz
    except Exception:
        return None
