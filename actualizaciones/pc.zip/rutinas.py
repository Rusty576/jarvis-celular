"""Rutinas: cosas que JARVIS hace solo.

- Al abrir una app o un juego: "cuando abra RDR2 poné chamamé", "cada vez que abra VS Code activá el modo estudio".
- A una hora: "todos los días a las 8 decime qué tengo hoy", "de lunes a viernes a las 7 de la tarde poné música".
Lo que hace es una orden común de JARVIS (la misma que le dirías vos), así que puede ser casi cualquier cosa.
Se ven con "mis rutinas", se borran con "borrá la rutina 2" y se pausan con "desactivá las rutinas".
(Para que te AVISE algo a una hora se usan los recordatorios: "recordame todos los lunes sacar la basura".)
"""
import datetime
import os
import re
import threading
import time

import disco

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "rutinas.json")
ACTIVAS = True  # Configuraciones > "Rutinas automáticas"
_lock = threading.Lock()

DIAS = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"]
VERBO_ACCION = (r"(?:pone(?:me)?|pon|reproduci\w*|activa\w*|desactiva\w*|abri\w*|abre|cerra\w*|deci(?:me)?|decile|"
                r"mostra\w*|baja\w*|subi\w*|silencia\w*|mutea\w*|apaga\w*|prende\w*|modo|pausa\w*|busca\w*|anota\w*|"
                r"agrega\w*|empeza\w*|inicia\w*|arranca\w*|hace\w*|lee\w*|conta\w*|revisa\w*|manda\w*|libera\w*|"
                r"saca\w*|que hora|que tengo|como esta|leeme|sacame|configura\w*)")
CUANDO_APP = re.compile(
    rf"^(?:(?:che|jarvis)[\s,]+)?(?:cuando|cada vez que|siempre que|apenas)\s+(?:yo\s+)?"
    rf"(?:abra|abro|inicie|inicio|arranque|empiece a jugar(?:\s+al?)?|juegue(?:\s+al?)?|me ponga a jugar(?:\s+al?)?|"
    rf"prenda|entre (?:a|al|en)|use|uso)\s+(?:el |la |al |a |los )?(?P<app>.+?)[\s,]+(?:vos\s+|jarvis\s+|que\s+|automaticamente\s+)?"
    rf"(?P<accion>{VERBO_ACCION}\b.*)$")
CUANDO_HORA = re.compile(
    rf"^(?:(?:che|jarvis)[\s,]+)?(?P<dias>todos los dias|cada dia|todas las (?:mananas|tardes|noches)|de lunes a viernes|"
    rf"los dias de semana|entre semana|los fines de semana|los findes|todos los (?:lunes|martes|miercoles|jueves|viernes|"
    rf"sabados?|domingos?)|cada (?:lunes|martes|miercoles|jueves|viernes|sabado|domingo))\s+(?:a las?\s+)?"
    rf"(?P<hora>\d{{1,2}}(?:[:.]\d{{2}})?)(?:\s*(?:hs|horas))?(?:\s+(?:de la|en la|por la) (?P<parte>manana|tarde|noche))?"
    rf"[\s,]+(?:vos\s+|jarvis\s+|que\s+)?(?P<accion>{VERBO_ACCION}\b.*)$")
VER = re.compile(r"\b(?:mis rutinas|que rutinas tengo|las rutinas que tengo|lista de rutinas|ver (?:las )?rutinas)\b")
BORRAR = re.compile(r"^(?:borra|borrame|elimina|saca|quita|cancela)\s+(?:la |las |todas las )?rutinas?\s*(?:numero |nro |n )?"
                    r"(?P<cual>.*)$")
PAUSAR = re.compile(r"^(?:desactiva|pausa|apaga|frena|para)\s+(?:las |todas las )?rutinas$")
REANUDAR = re.compile(r"^(?:activa|reanuda|prende|volve a activar)\s+(?:las |todas las )?rutinas$")


def cargar():
    return disco.leer(ARCHIVO, [])


def guardar(lista):
    disco.guardar(ARCHIVO, lista)


def dias_de(texto):
    if re.search(r"lunes a viernes|dias de semana|entre semana", texto):
        return [0, 1, 2, 3, 4]
    if re.search(r"fines de semana|findes", texto):
        return [5, 6]
    m = re.search(r"\b(lunes|martes|miercoles|jueves|viernes|sabado|domingo)", texto)
    return [DIAS.index(m.group(1))] if m else list(range(7))


def describir(r):
    if r["tipo"] == "app":
        cuando = f"cuando abras {r['nombre']}"
    else:
        d = r.get("dias") or list(range(7))
        dias = ("todos los días" if len(d) == 7 else "de lunes a viernes" if d == [0, 1, 2, 3, 4] else
                "los fines de semana" if d == [5, 6] else "los " + ", ".join(DIAS[i] for i in d))
        cuando = f"{dias} a las {r['hora']}"
    return f"{cuando}: «{r['accion']}»" + ("" if r.get("activa", True) else " (pausada)")


def _nombre_de_app(pedido):
    """El nombre de verdad de la app o el juego ('rdr2' -> 'Red Dead Redemption 2'), si está entre tus programas."""
    try:
        mejor, _parecidos = jarvis.programas.buscar(pedido, renovar_si_falta=False)
        if mejor and mejor.get("nombre"):
            return mejor["nombre"]
    except Exception:
        pass
    return {"vs code": "Visual Studio Code", "visual": "Visual Studio Code", "wpp": "WhatsApp", "wsp": "WhatsApp",
            "rdr2": "Red Dead Redemption 2", "rdr": "Red Dead Redemption"}.get(pedido.strip(), pedido.strip())


def coincide(rutina, app, exe, titulo):
    """¿La app que abriste es la de la rutina? (por nombre, título de la ventana, programa o sigla)."""
    n = jarvis.normalizar
    objetivo = n(rutina["nombre"])
    pedido = n(rutina.get("pedido", ""))
    textos = [n(app), n(titulo or ""), n(os.path.splitext(exe or "")[0])]
    if exe and exe.lower() == "code.exe":
        textos.append("visual studio code vs code")
    for x in (objetivo, pedido):
        if not x:
            continue
        palabras = re.findall(r"[a-z0-9]+", x)
        if any(all(p in t for p in palabras) for t in textos):
            return True
        sigla = "".join(w if w.isdigit() else w[0] for w in re.findall(r"[a-z0-9]+", n(app)))
        if x.replace(" ", "") in (sigla, n(os.path.splitext(exe or "")[0])):
            return True
    return False


def correr(rutina, motivo):
    """Hace la orden de la rutina como si la hubieras dicho vos (en otro hilo)."""
    jarvis.emitir("detalle", f"Rutina ({motivo}): {rutina['accion']}")
    threading.Thread(target=jarvis.despachar, args=(rutina["accion"], jarvis.nueva_orden()), daemon=True).start()


def al_abrir(app, exe, titulo, categoria):
    """La llama actividad.py cuando abrís una app."""
    if not ACTIVAS:
        return
    ahora = time.time()
    with _lock:
        lista = cargar()
        para_correr = [r for r in lista if r["tipo"] == "app" and r.get("activa", True)
                       and ahora - r.get("ultima", 0) > 30 * 60 and coincide(r, app, exe, titulo)]
        for r in para_correr:
            r["ultima"] = ahora
        if para_correr:
            guardar(lista)
    for r in para_correr:
        correr(r, f"abriste {app}")


def revisar_horas(ahora=None):
    """Corre las rutinas de hora que tocan ahora (como mucho una vez por día cada una). Devuelve cuáles corrió."""
    ahora = ahora or datetime.datetime.now()
    hoy = ahora.date().isoformat()
    with _lock:
        lista = cargar()
        tocan = []
        for r in lista:
            if r["tipo"] != "hora" or not r.get("activa", True) or r.get("ultima_fecha") == hoy:
                continue
            h, m = map(int, r["hora"].split(":"))
            momento = ahora.replace(hour=h, minute=m, second=0, microsecond=0)
            if ahora.weekday() in r.get("dias", range(7)) and 0 <= (ahora - momento).total_seconds() < 300:
                r["ultima_fecha"] = hoy
                tocan.append(r)
        if tocan:
            guardar(lista)
    for r in tocan:
        correr(r, f"son las {r['hora']}")
    return tocan


def _bucle_horas():
    while True:
        time.sleep(20)
        if ACTIVAS:
            try:
                revisar_horas()
            except Exception:
                pass


_iniciado = [False]


def iniciar():
    if _iniciado[0]:
        return
    _iniciado[0] = True
    jarvis.actividad.al_abrir(al_abrir)
    threading.Thread(target=_bucle_horas, daemon=True).start()


def manejar(texto, t):
    global ACTIVAS
    t = t.strip(" ¿?¡!.,")
    if VER.search(t):
        lista = cargar()
        if not lista:
            return ("No tenés rutinas. Probá: «cuando abra RDR2 poné chamamé» o «todos los días a las 8 decime qué "
                    "tengo hoy».")
        estado = "" if ACTIVAS else " (están todas en pausa: decí «activá las rutinas»)"
        return f"Tus rutinas{estado}:\n" + "\n".join(f"{i}. {describir(r)}" for i, r in enumerate(lista, 1))
    if PAUSAR.match(t):
        ACTIVAS = False
        _guardar_ajuste()
        return "Listo, pausé todas las rutinas. Decí «activá las rutinas» para volver."
    if REANUDAR.match(t):
        ACTIVAS = True
        _guardar_ajuste()
        return "Listo, las rutinas vuelven a funcionar."
    m = BORRAR.match(t)
    if m:
        return borrar(m.group("cual").strip(), "todas" in t)
    # una rutina para AVISARTE algo a una hora es un recordatorio ("todos los lunes recordame...")
    if jarvis.herramientas.PIDE_RECORDAR.search(t):
        return None
    m = CUANDO_APP.match(t)
    if m:
        pedido = m.group("app").strip()
        accion = jarvis.parte_original(texto, m.start("accion")) or m.group("accion")
        nombre = _nombre_de_app(pedido)
        return crear({"tipo": "app", "pedido": pedido, "nombre": nombre, "accion": accion.strip(" .")})
    m = CUANDO_HORA.match(t)
    if m:
        h, _, mi = m.group("hora").replace(".", ":").partition(":")
        h, mi = int(h), int(mi or 0)
        parte = m.group("parte") or ("tarde" if "tardes" in m.group("dias") else "noche" if "noches" in m.group("dias")
                                     else None)
        if parte in ("tarde", "noche") and h < 12:
            h += 12
        if h > 23 or mi > 59:
            return "Esa hora no existe. Decímela así: «todos los días a las 8 decime qué tengo hoy»."
        accion = jarvis.parte_original(texto, m.start("accion")) or m.group("accion")
        return crear({"tipo": "hora", "hora": f"{h}:{mi:02d}", "dias": dias_de(m.group("dias")),
                      "accion": accion.strip(" .")})
    return None


def crear(rutina):
    with _lock:
        lista = cargar()
        for r in lista:  # la misma rutina otra vez: se actualiza
            if r["tipo"] == rutina["tipo"] and r.get("nombre") == rutina.get("nombre") and r.get("hora") == rutina.get("hora") \
                    and jarvis.normalizar(r["accion"]) == jarvis.normalizar(rutina["accion"]):
                return f"Ya tenías esa rutina: {describir(r)}."
        rutina.update(id=int(time.time() * 1000), activa=True)
        lista.append(rutina)
        guardar(lista)
    aviso = "" if ACTIVAS else " Ojo: las rutinas están en pausa (decí «activá las rutinas»)."
    return f"Listo, nueva rutina: {describir(rutina)}. Para verlas decí «mis rutinas».{aviso}"


def borrar(cual, todas):
    with _lock:
        lista = cargar()
        if not lista:
            return "No tenés rutinas."
        if todas or cual in ("todas", "todas las rutinas"):
            guardar([])
            return f"Listo, borré las {len(lista)} rutinas."
        elegidas = []
        if re.fullmatch(r"\d+", cual):
            n = int(cual)
            elegidas = [lista[n - 1]] if 1 <= n <= len(lista) else []
        elif cual:
            palabras = [w for w in re.findall(r"[a-z0-9]+", jarvis.normalizar(re.sub(r"^(?:de|del|que|cuando)\s+", "", cual)))
                        if len(w) > 2]
            elegidas = [r for r in lista if palabras and all(p in jarvis.normalizar(describir(r) + " " + r.get("pedido", ""))
                                                             for p in palabras)]
        elif len(lista) == 1:
            elegidas = lista[:]
        if not elegidas:
            return "¿Cuál borro? Decime el número (mirá «mis rutinas») o de qué es: «borrá la rutina de RDR2»."
        guardar([r for r in lista if r not in elegidas])
    return "Listo, borré " + ("la rutina: " + describir(elegidas[0]) if len(elegidas) == 1 else
                              f"{len(elegidas)} rutinas") + "."


def _guardar_ajuste():
    try:
        jarvis.ajustes.guardar({"rutinas": ACTIVAS})
    except Exception:
        pass
