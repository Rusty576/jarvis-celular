"""Apaga JARVIS por completo (para jugar con todos los recursos libres).

Hace tres cosas:
  1. Saca la IA de la memoria de la placa de video.
  2. Cierra JARVIS (la ventana y el micrófono).
  3. Cierra Ollama.
Para volver a usarlo, abrí JARVIS como siempre: él solo vuelve a abrir Ollama.

Se puede usar desde el acceso directo "Apagar JARVIS" o diciéndole "apagate".
"""
import json
import os
import subprocess
import urllib.request

CARPETA = os.path.dirname(os.path.abspath(__file__))
OLLAMA = "http://127.0.0.1:11434"
SIN_VENTANA = 0x08000000


def descargar_modelos():
    """Le pide a Ollama que saque de la memoria todos los modelos cargados. Devuelve los GB liberados."""
    liberado = 0.0
    try:
        with urllib.request.urlopen(OLLAMA + "/api/ps", timeout=3) as r:
            modelos = json.load(r).get("models", [])
        for m in modelos:
            liberado += (m.get("size_vram") or m.get("size") or 0) / 1e9
            datos = json.dumps({"model": m["name"], "keep_alive": 0}).encode()
            pedido = urllib.request.Request(OLLAMA + "/api/generate", data=datos,
                                            headers={"Content-Type": "application/json"})
            urllib.request.urlopen(pedido, timeout=10).read()
    except Exception:
        pass  # Ollama ya estaba cerrado
    return liberado


def cerrar_ollama():
    for exe in ("ollama app.exe", "ollama.exe", "llama-server.exe"):
        subprocess.run(["taskkill", "/IM", exe, "/F", "/T"], capture_output=True, creationflags=SIN_VENTANA)


def cerrar_jarvis(excepto=None):
    """Cierra las ventanas/procesos de JARVIS (interfaz.py o main.py de esta carpeta)."""
    import psutil

    cerrados = 0
    for p in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            if p.info["pid"] in (os.getpid(), excepto) or "python" not in (p.info["name"] or "").lower():
                continue
            linea = " ".join(p.info["cmdline"] or []).lower()
            es_jarvis = any(x in linea for x in ("interfaz.py", "main.py", "pildora_qt.py"))   # (la píldora también)
            de_esta_carpeta = CARPETA.lower() in linea or os.path.normcase(p.cwd()) == os.path.normcase(CARPETA)
            if es_jarvis and de_esta_carpeta:
                p.kill()
                cerrados += 1
        except Exception:
            pass
    return cerrados


def apagar_todo(excepto=None):
    liberado = descargar_modelos()
    cerrar_ollama()
    cerrados = cerrar_jarvis(excepto)
    return liberado, cerrados


if __name__ == "__main__":
    liberado, cerrados = apagar_todo()
    try:
        from winotify import Notification

        icono = os.path.join(CARPETA, "interfaz", "jarvis.png")
        Notification(app_id="J.A.R.V.I.S.", title="JARVIS apagado",
                     msg=(f"Liberé {liberado:.1f} GB de la placa de video. " if liberado > 0.1 else "")
                     + "JARVIS y Ollama están cerrados. ¡Buen juego!",
                     icon=icono if os.path.exists(icono) else "").show()
    except Exception:
        pass
