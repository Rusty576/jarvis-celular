"""La píldora de JARVIS (lado JARVIS): abre pildora_qt.py (la carita flotante dibujada con Qt, en su propio proceso)
y se hablan por un enchufe local (127.0.0.1, un JSON por línea). Acá se decide qué mostrar y se hace lo que piden
sus botones; el dibujo, las animaciones y el mouse son cosa de pildora_qt.py.

  reposo   píldora chiquita con los ojos que siguen al mouse. Un clic: te escucha. Doble clic: el chat.
  dock     al pasar el mouse o mientras escucha: orden / dictar (en la ventana que estabas usando) / escribir
  cartel   la respuesta pasando como un cartel (si no estás mirando la ventana grande); una lista sale como tarjeta
  panel    Ctrl+Alt+J (o doble clic): chat compacto con pestañas Chat e Historial

Caras: "celeste" (la normal de JARVIS), "blanco", "halloween", "navidad" o "temporada" (la normal, y Halloween o
Navidad en esas fechas): Configuraciones o "poné la cara de halloween" / "cara normal".
Se esconde con juegos o videos en pantalla completa: ahí, con un tema nuevo o un atajo de música (Ctrl+Alt+Espacio,
Ctrl+Alt+M...) se asoma unos segundos translúcida y sin agarrar clics. La música se maneja desde acá (la barrita
vieja ya no se abre). Configuraciones > "Píldora flotante" la prende o la apaga.
"""
import ctypes
import ctypes.wintypes as wt
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

ACTIVA = True
LOOK = "celeste"  # Configuraciones > "Cara de la píldora"
LOOKS = ["celeste", "blanco", "halloween", "navidad", "temporada"]
SEGUIR = True  # Configuraciones > "Después de contestarte, seguir escuchando unos segundos"
OPACIDAD = 100  # Configuraciones > "Opacidad de la píldora" (30 a 100)
PUERTO_INSTANCIA = 47321  # el de interfaz.py: mandarle "mostrar" trae la ventana grande adelante
iniciada = False  # la interfaz la pone en True al arrancar (después se puede abrir o cerrar al vuelo)
BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_POS = os.path.join(BASE, "pildora.json")
_u32 = ctypes.windll.user32
_est = {"proceso": None, "conexion": None, "servidor": None, "oculta": False, "corriendo": False, "por_voz": 0.0,
        "hablo": False, "siguiendo": False, "tapa": None, "cerrando": False, "asomada_hasta": 0.0}
_lock = threading.Lock()


# ---------- El enchufe con la ventanita ----------

def _mandar(tipo, valor=None):
    c = _est["conexion"]
    if c is None:
        return
    try:
        with _lock:
            c.sendall((json.dumps({"t": tipo, "v": valor}, ensure_ascii=False) + "\n").encode("utf-8"))
    except OSError:
        _est["conexion"] = None


def _abrir_proceso():
    servidor = socket.socket()
    servidor.bind(("127.0.0.1", 0))
    servidor.listen(1)
    servidor.settimeout(30)
    _est["servidor"] = servidor
    pythonw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    _est["proceso"] = subprocess.Popen(   # (con el número de JARVIS: si JARVIS desaparece, la píldora se cierra sola)
        [pythonw if os.path.exists(pythonw) else sys.executable, os.path.join(BASE, "pildora_qt.py"),
         str(servidor.getsockname()[1]), str(os.getpid())], creationflags=0x08000000)
    try:
        conexion, _ = servidor.accept()
    except OSError:
        return False
    finally:
        servidor.close()
    conexion.settimeout(None)
    _est["conexion"] = conexion
    return True


def _bucle():
    """Mantiene viva la ventanita: si se cierra o se cuelga, la vuelve a abrir (hasta 5 veces seguidas)."""
    fallas = 0
    while ACTIVA and not _est["cerrando"] and fallas < 5:
        inicio = time.time()
        if _abrir_proceso():
            _escuchar_ventanita()
        _est["conexion"] = None
        p = _est["proceso"]
        if p and p.poll() is None:
            p.kill()
        if not ACTIVA or _est["cerrando"]:   # (la cerraron a propósito: no se vuelve a abrir; antes renacía al cerrar JARVIS)
            break
        fallas = fallas + 1 if time.time() - inicio < 60 else 0
        time.sleep(2)
    _est["corriendo"] = False


def _escuchar_ventanita():
    resto = b""
    c = _est["conexion"]
    while ACTIVA:
        try:
            datos = c.recv(65536)
        except OSError:
            return
        if not datos:
            return
        resto += datos
        while b"\n" in resto:
            linea, resto = resto.split(b"\n", 1)
            try:
                m = json.loads(linea.decode("utf-8"))
            except ValueError:
                continue
            threading.Thread(target=_atender, args=(m.get("t"), m.get("v")), daemon=True).start()


def _atender(tipo, valor):
    """Lo que pide la ventanita."""
    if tipo == "listo":
        _mandar("look", look_de_hoy())
        _mandar("opacidad", OPACIDAD)
        pos = _leer_pos()
        if pos:
            _mandar("pos", pos)
    elif tipo == "boton":
        _boton(valor)
    elif tipo == "enviar" and str(valor or "").strip():
        jarvis.despachar(str(valor).strip(), jarvis.nueva_orden())
    elif tipo == "pedir":
        _mandar("charlas", _charlas()) if valor == "charlas" else _mandar("charla", _charla())
    elif tipo == "abrir_charla":
        try:
            jarvis.chats.abrir(str(valor))
        except Exception:
            pass
        _mandar("charla", _charla())
    elif tipo == "panel":
        _mandar("panel", bool(valor))
    elif tipo == "media":
        _control_musica(valor)
    elif tipo == "bandeja":
        _bandeja(valor)
    elif tipo == "callar_seguimiento":
        _est["siguiendo"] = False
    elif tipo == "pos" and valor:
        try:
            with open(ARCHIVO_POS + ".tmp", "w", encoding="utf-8") as f:
                json.dump({"pos": valor}, f)
            os.replace(ARCHIVO_POS + ".tmp", ARCHIVO_POS)
        except OSError:
            pass


def _leer_pos():
    try:
        with open(ARCHIVO_POS, encoding="utf-8") as f:
            return json.load(f)["pos"]
    except (OSError, ValueError, KeyError):
        return None


def _charla():
    with jarvis.lock:
        hist = [m for m in jarvis.historial[-30:] if m["role"] in ("user", "assistant")]
    return [{"de": "vos" if m["role"] == "user" else "jarvis", "texto": str(m["content"])[:1200]} for m in hist][-14:]


def _charlas():
    try:
        return jarvis.chats.lista()[:30]
    except Exception:
        return []


def _boton(nombre):
    """Los 3 botones del dock (y el clic en la cara, que es "orden")."""
    if nombre == "orden":
        jarvis.escuchar(jarvis.nueva_orden())
        return
    texto = escuchar_texto()
    if not texto:
        _mandar("cartel", "No te escuché. Probá de nuevo.")
        jarvis.emitir("estado", "libre")
        return
    try:
        if nombre == "dictar":
            jarvis.escritorio.dictar(texto)
            _mandar("cartel", f"Escribí: {texto}")
        elif nombre == "escribir":
            _mandar("cartel", jarvis.escritorio.escribir_con_ia(texto))
    except Exception as e:
        _mandar("cartel", f"No pude: {e}")
    jarvis.emitir("estado", "libre")


def escuchar_texto():
    """Te escucha una vez y devuelve el texto (sin mandárselo a JARVIS como orden)."""
    if not jarvis.mic_lock.acquire(blocking=False):
        return ""
    try:
        jarvis.sonar("activar")
        jarvis.emitir("estado", "escuchando")
        audio = jarvis.grabar(jarvis.nueva_orden())
        if audio is None:
            return ""
        jarvis.emitir("estado", "pensando")
        opciones = jarvis.reconocer(audio)
        if not opciones:
            return ""
        jarvis.sonar("listo")
        return opciones[0]
    except Exception:
        return ""
    finally:
        jarvis.mic_lock.release()


# ---------- Arrancar, apagar, caras ----------

def crear():
    """La abre (si está activada). Se llama al arrancar la interfaz."""
    if not ACTIVA or _est["corriendo"]:
        return
    _est["corriendo"] = True
    _est["cerrando"] = False
    threading.Thread(target=_bucle, daemon=True).start()
    threading.Thread(target=_vigilar, daemon=True).start()
    threading.Thread(target=_atajo, daemon=True).start()
    import atexit
    atexit.register(cerrar)


def cerrar():
    _est["cerrando"] = True   # (primero: que el bucle no la vuelva a abrir)
    _est["corriendo"] = False
    _mandar("salir")
    p = _est["proceso"]
    if p and p.poll() is None:
        try:
            p.wait(1.5)
        except Exception:
            p.kill()


# ---------- La música en la píldora (reemplaza a la barrita vieja) ----------

def asomar_musica(segundos=8):
    """Muestra la música en la píldora unos segundos (un atajo, «abrí el panel de música»). Jugando, se asoma
    translúcida y sin agarrar clics, y se vuelve a esconder sola."""
    _est["asomada_hasta"] = time.time() + segundos
    jarvis_dice = _musica_ahora()
    if jarvis_dice:
        _mandar("musica_jarvis", jarvis_dice)   # (que la píldora ya tenga el tema de JARVIS)
    _mandar("asomar", {"segundos": segundos})


def esconder_musica():
    _est["asomada_hasta"] = 0.0
    _mandar("musica_fuera")


def alternar_musica():
    """Ctrl+Alt+M: la música en la píldora, o la esconde si ya está a la vista."""
    if time.time() < _est["asomada_hasta"]:
        esconder_musica()
    else:
        asomar_musica(15)


def aplicar_ajuste(si):
    """Configuraciones > "Píldora flotante"."""
    global ACTIVA
    ACTIVA = si
    if not iniciada:
        return
    if si:
        crear()
    else:
        cerrar()


def look_de_hoy():
    if LOOK != "temporada":
        return LOOK
    hoy = time.localtime()
    if (hoy.tm_mon == 10 and hoy.tm_mday >= 24) or (hoy.tm_mon == 11 and hoy.tm_mday <= 1):
        return "halloween"
    if hoy.tm_mon == 12 and 15 <= hoy.tm_mday <= 31:
        return "navidad"
    return "celeste"


def poner_opacidad(valor):
    global OPACIDAD
    OPACIDAD = max(30, min(100, int(valor)))
    _mandar("opacidad", OPACIDAD)


def poner_look(cual):
    global LOOK
    if cual in LOOKS:
        LOOK = cual
        _mandar("look", look_de_hoy())


# ---------- Lo que pasa en JARVIS ----------

def oyente(evento, datos):
    """Se anota en jarvis.oyentes: recibe todo lo que JARVIS muestra."""
    if evento in ("estado", "nivel", "voz", "oido"):
        _mandar(evento, datos)
    elif evento == "jarvis":
        _mandar("jarvis", {"texto": str(datos), "cartel": _cartel_corresponde()})
    # después de contestarte algo que le dijiste en voz alta, sigue escuchando un rato (para seguir la charla)
    if evento == "voz":
        _est["por_voz"] = time.time()
    elif evento == "estado" and datos == "hablando":
        _est["hablo"] = True
    elif evento == "estado" and datos == "libre" and _est["hablo"]:
        _est["hablo"] = False
        if SEGUIR and time.time() - _est["por_voz"] < 180 and not _est["siguiendo"]:
            threading.Thread(target=_seguir_escuchando, daemon=True).start()


def _seguir_escuchando():
    """Como heynixi: con la respuesta todavía a la vista, te escucha unos segundos más sin que digas «Jarvis».
    Si no decís nada, vuelve al reposo sin hacer ruido."""
    _est["siguiendo"] = True
    try:
        limite = time.time() + 90
        while (jarvis.hablando.is_set() or jarvis._actividad["pedidos"] > 0) and time.time() < limite:
            time.sleep(0.15)  # que termine de hablar (no se escucha a sí mismo)
        time.sleep(0.35)
        if jarvis.manos_libres.is_set() or jarvis.ptt_activo.is_set() or not _est["siguiendo"]:
            return  # con manos libres ya te está escuchando
        if not jarvis.mic_lock.acquire(blocking=False):
            return
        parar = threading.Event()
        _mandar("seguimiento", True)
        try:
            audio = jarvis.grabar(parar)
            if audio is None or not _est["siguiendo"]:
                jarvis.emitir("estado", "libre")
                return
            jarvis.emitir("estado", "pensando")
            opciones = jarvis.reconocer(audio)
        except Exception:
            jarvis.emitir("estado", "libre")
            return
        finally:
            jarvis.mic_lock.release()
            _mandar("seguimiento", False)
        if not opciones:
            jarvis.emitir("estado", "libre")
            return
        texto = jarvis.quitar_activacion(opciones[0])[0] or opciones[0]
        jarvis.sonar("listo")
    finally:
        _est["siguiendo"] = False
    jarvis.emitir("voz", texto)
    jarvis.despachar(texto, jarvis.nueva_orden())


def _musica_ahora():
    """La música de JARVIS (su ventana de YouTube), para la píldora. None si no suena la de JARVIS.
    La de las otras apps (Spotify, Opera...) la consulta la píldora misma, en su proceso: el control de medios de
    Windows (winrt) una vez tiró abajo a JARVIS entero; si falla ahí, solo se reinicia la píldora."""
    try:
        if not jarvis.barra_musica._de_jarvis():
            return None
        e = jarvis.musica.estado
        if not e.get("titulo"):
            return None
        d = {"titulo": e.get("titulo") or "", "artista": e.get("canal") or "YouTube", "pausado": bool(e.get("pausado")),
             "actual": e.get("actual") or 0, "duracion": e.get("duracion") or 0, "clave": e.get("id") or e["titulo"]}
        tapa = f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg" if e.get("id") else ""
    except Exception:
        return None
    if tapa and tapa != _est["tapa"]:
        _est["tapa"] = tapa
        try:
            import base64
            import requests
            d["tapa"] = "data:image/jpeg;base64," + base64.b64encode(requests.get(tapa, timeout=5).content).decode()
        except Exception:
            d["tapa"] = ""
    return d


def _control_musica(accion):
    """Los botones de la música cuando suena la de JARVIS (la de otras apps la maneja la píldora)."""
    try:
        jarvis.musica.control(accion)
    except Exception:
        pass
    time.sleep(0.4)
    _mandar("musica_jarvis", _musica_ahora())


def _bandeja(accion):
    """El menú del ícono de la bandeja."""
    if accion == "abrir":
        try:
            with socket.create_connection(("127.0.0.1", PUERTO_INSTANCIA), timeout=2) as c:
                c.sendall(b"mostrar")
        except OSError:
            pass
    elif accion == "ajustes":
        _bandeja("abrir")
        jarvis.emitir("abrir_ajustes", True)
    elif accion in ("chequeo", "exportar"):
        jarvis.despachar("chequeo del sistema" if accion == "chequeo" else "exportá mis datos", jarvis.nueva_orden())
    elif accion == "apagar":
        jarvis.apagar_jarvis(jarvis.nueva_orden())


def _cartel_corresponde():
    """Mostrar la respuesta en la píldora si no estás mirando la ventana grande de JARVIS, o si le hablaste por voz
    (así se ve la respuesta mientras te sigue escuchando)."""
    if time.time() - _est["por_voz"] < 60:
        return True
    try:
        import win32process
        _, pid = win32process.GetWindowThreadProcessId(_u32.GetForegroundWindow())
        return pid != os.getpid()
    except Exception:
        return True


def _vigilar():
    """Cada segundo y medio: escondida con juegos o videos en pantalla completa; baila si suena música."""
    musica = None
    while _est["corriendo"]:
        time.sleep(1.5)
        if _est["conexion"] is None:
            continue
        try:
            pid, _exe = jarvis.herramientas._ventana_en_pantalla_completa()
            propia = _est["proceso"] and pid == _est["proceso"].pid
            tapar = jarvis.herramientas.modo_juego.is_set() or bool(pid and pid != os.getpid() and not propia)
        except Exception:
            tapar = False
        if tapar != _est["oculta"]:
            _est["oculta"] = tapar
            _mandar("ocultar", tapar)
        ahora = _musica_ahora()
        if ahora or musica:
            _mandar("musica_jarvis", ahora)  # cada 1,5 s: la barra de tiempo al día
        musica = ahora


def _atajo():
    """Ctrl+Alt+J abre o cierra el chat (anda en cualquier ventana)."""
    if not _u32.RegisterHotKey(None, 0x4A41, 0x0001 | 0x0002 | 0x4000, 0x4A):  # MOD_ALT|MOD_CONTROL|NOREPEAT, J
        return
    msg = wt.MSG()
    while _u32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        if msg.message == 0x0312 and msg.wParam == 0x4A41:  # WM_HOTKEY
            _mandar("panel", "alternar")


# ---------- Por voz: "poné la cara de halloween", "cara normal" ----------

CARA = re.compile(r"^(?:pone(?:le|me)?|cambia(?:le)?|usa|quiero)\s+(?:la\s+)?(?:cara|look|carita)\s+(?:de\s+|del\s+|en\s+)?"
                  r"(?P<cual>normal|jarvis|celeste|blanc[ao]|halloween|calabaza|navidad|navidena|papa noel|"
                  r"(?:segun la |de )?(?:temporada|fecha))$|^(?:cara|look) (?P<cual2>normal|halloween|navidad|blanc[ao])$")
NOMBRES_CARA = {"normal": "celeste", "jarvis": "celeste", "celeste": "celeste", "blanca": "blanco", "blanco": "blanco",
                "halloween": "halloween", "calabaza": "halloween", "navidad": "navidad", "navidena": "navidad",
                "papa noel": "navidad"}


def manejar(texto, t):
    m = CARA.match(t.strip(" ¿?¡!.,"))
    if not m:
        return None
    cual = m.group("cual") or m.group("cual2")
    look = NOMBRES_CARA.get(cual, "temporada")
    jarvis.ajustes.guardar({"pildora_look": look})
    return {"celeste": "Listo, la píldora tiene la cara normal de JARVIS.", "blanco": "Listo, cara blanca.",
            "halloween": "¡Buuu! Cara de Halloween puesta.", "navidad": "¡Jo jo jo! Cara navideña puesta.",
            "temporada": "Listo: cara normal, y en Halloween y Navidad se disfraza sola."}[look]
