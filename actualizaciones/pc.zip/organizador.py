"""Rutinas con nombre, hábitos, apuntes rápidos y el modo agente.

  Rutinas con nombre: "creá una rutina llamada empezar el día: abrí Spotify y abrí Gmail", después "empezar el día"
                      (o "hacé la rutina empezar el día"), "borrá la rutina empezar el día". Se ven en "mis rutinas".
  Hábitos:            "agregá el hábito leer 20 minutos", "hice el hábito leer" / "ya hice leer", "mis hábitos"
                      (con la racha de días seguidos), "borrá el hábito leer".
  Apuntes:            "apuntá: la clave del wifi es en la heladera", "tomá nota: ...", "mis apuntes",
                      "buscá en mis apuntes wifi", "borrá el apunte 2". ("mis notas" son las de los exámenes.)
  Agente:             "encargate de esto: abrí Spotify, poné música para estudiar y avisame en 25 minutos". Arma los
                      pasos con la IA y los hace de a uno, mostrando cada uno. Solo cosas seguras: nunca manda
                      mensajes, borra, compra ni cambia su propio código.
"""
import datetime
import difflib
import os
import re
import threading

import disco

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "organizador.json")
_lock = threading.Lock()


def _n(texto):
    return jarvis.normalizar(texto)


def _cargar():
    datos = disco.leer(ARCHIVO, {})
    for clave in ("rutinas", "habitos", "apuntes"):
        datos.setdefault(clave, [])
    return datos


def _guardar(datos):
    with _lock:
        disco.guardar(ARCHIVO, datos)


def _original(texto, m, g):
    """El grupo g del match (hecho sobre el texto normalizado) pero con las tildes y mayúsculas que escribiste."""
    base = texto.strip(" ,.;:¡!¿?")
    if len(base) == len(m.string):
        return base[m.start(g):m.end(g)]
    return m.group(g)


def _el_mas_parecido(frase, nombres, minimo=0.6):
    """El índice del nombre que más se parece a la frase (o None)."""
    f = _n(frase).strip(" .")
    mejor, puntaje = None, minimo
    for i, nombre in enumerate(nombres):
        n = _n(nombre)
        p = 1.0 if n == f else max(difflib.SequenceMatcher(None, f, n).ratio(), 0.85 if f and f in n else 0)
        if p >= puntaje:
            mejor, puntaje = i, p
    return mejor


# ---------- Correr varias órdenes seguidas (rutinas y agente) ----------

PROHIBIDO = re.compile(r"\b(?:mejorate|automejora|deshace|borra\w*|elimina\w*|manda\w*|envia\w*|escribile|decile|"
                       r"avisale|llama\w*|videollama\w*|compra\w*|paga\w*|apaga(?:te| la compu| la pc)|reinicia\w*|"
                       r"formatea\w*|desinstala\w*|suspende\w*|hiberna\w*|cerra (?:todo|sesion))\b")


def correr_pasos(pasos, titulo):
    """Hace cada orden con lo mismo que usa JARVIS para lo que le pedís, y avisa cómo va."""
    import guardia

    hechos = []
    guardian = guardia.Guardia(max_iguales=1, presupuesto=None)  # (de OpenJarvis: la misma orden dos veces no suma)
    for i, paso in enumerate(pasos, 1):
        jarvis.emitir("detalle", f"{titulo} · paso {i} de {len(pasos)}: {paso}")
        veredicto = guardian.revisar("orden", _n(paso).strip(" .,!"))
        if veredicto["aviso"] or not veredicto["seguir"]:
            hechos.append(f"{i}. {paso} → no lo repetí: ya lo había hecho")
            continue
        if PROHIBIDO.search(_n(paso)):
            hechos.append(f"{i}. {paso} → no lo hice: eso lo hacés vos")
            continue
        try:
            respuesta = jarvis.ejecutar_accion(paso)
        except Exception as e:
            respuesta = f"falló ({e})"
        if respuesta is None:
            respuesta = "no es una orden que sepa hacer sola"
        hechos.append(f"{i}. {paso} → {str(respuesta).splitlines()[0][:140] if respuesta else 'listo'}")
    return hechos


def separar_pasos(texto):
    """'abrí Spotify y abrí Gmail, después poné música' -> ['abrí Spotify', 'abrí Gmail', 'poné música']."""
    verbo = jarvis.rutinas.VERBO_ACCION
    plano = _n(texto)  # mismo largo que el original: se corta ahí y se devuelven los pedazos originales
    if len(plano) != len(texto):
        texto = plano
    cortes = re.finditer(rf"\s*(?:;|\n|,\s*(?:y\s+)?(?:despues\s+|luego\s+)?|\s+y\s+(?:despues\s+|luego\s+)?(?={verbo})|"
                         rf"\s+(?:despues|luego)\s+(?={verbo}))\s*", plano)
    partes, desde = [], 0
    for c in cortes:
        partes.append(texto[desde:c.start()])
        desde = c.end()
    partes.append(texto[desde:])
    return [p.strip(" .") for p in partes if p and len(p.strip(" .")) > 1]


# ---------- Rutinas con nombre ----------

CREAR_RUTINA = re.compile(r"^(?:crea|creame|arma|armame|hace|haceme|guarda|agrega)\s+(?:una |la )?rutina\s+"
                          r"(?:que se llame|llamada|con el nombre|de nombre)?\s*(?P<nombre>[^:]+?)\s*:\s*(?P<pasos>.+)$")
CORRER_RUTINA = re.compile(r"^(?:hace|haceme|corre|ejecuta|arranca|empeza|inicia|activa)\w*\s+(?:la\s+)?rutina\s+"
                           r"(?:de\s+)?(?P<nombre>.+)$")
BORRAR_RUTINA = re.compile(r"^(?:borra|elimina|saca|quita)\w*\s+la\s+rutina\s+(?:de\s+|llamada\s+)?(?P<nombre>\D.+)$")


def manejar_rutinas(texto, t):
    datos = _cargar()
    rutinas = datos["rutinas"]
    m = CREAR_RUTINA.match(t)
    if m and not re.match(r"^(?:cuando|cada|todos|siempre|de lunes|los )", m.group("nombre")):
        nombre = _original(texto, m, "nombre").strip(" «»\"'")
        pasos = separar_pasos(_original(texto, m, "pasos"))
        if not pasos:
            return "¿Qué tiene que hacer la rutina? Por ejemplo: «creá una rutina llamada estudiar: abrí Classroom y modo estudio»."
        i = _el_mas_parecido(nombre, [r["nombre"] for r in rutinas], 0.95)
        if i is not None:
            rutinas.pop(i)
        rutinas.append({"nombre": nombre, "pasos": pasos})
        _guardar(datos)
        lista = "\n".join(f"{i}. {p}" for i, p in enumerate(pasos, 1))
        return f"Listo, guardé la rutina «{nombre}». Decí «{nombre}» y hago esto:\n{lista}"
    m = BORRAR_RUTINA.match(t)
    if m and rutinas:
        i = _el_mas_parecido(m.group("nombre"), [r["nombre"] for r in rutinas])
        if i is not None:
            borrada = rutinas.pop(i)
            _guardar(datos)
            return f"Borré la rutina «{borrada['nombre']}»."
    if not rutinas:
        return None
    m = CORRER_RUTINA.match(t)
    frase = m.group("nombre") if m else t
    i = _el_mas_parecido(frase, [r["nombre"] for r in rutinas], 0.6 if m else 0.9)
    if i is not None:
        rutina = rutinas[i]
        hechos = correr_pasos(rutina["pasos"], f"Rutina «{rutina['nombre']}»")
        return f"Hice la rutina «{rutina['nombre']}»:\n" + "\n".join(hechos)
    return None


def lista_rutinas():
    rutinas = _cargar()["rutinas"]
    if not rutinas:
        return ""
    return "Tus rutinas con nombre (decí el nombre y las hago):\n" + "\n".join(
        f"• {r['nombre']}: {', '.join(r['pasos'])}" for r in rutinas)


# ---------- Hábitos ----------

AGREGAR_HABITO = re.compile(r"^(?:agrega|suma|anota|crea|empeza)\w*\s+(?:el |un |como |a mis )?(?:nuevo )?habitos?\s*"
                            r"(?:de |nuevo:?|:)?\s*(?P<que>.+)$|^quiero (?:empezar el|crear el|agregar el) habito "
                            r"(?:de )?(?P<que2>.+)$")
HICE_HABITO = re.compile(r"^(?:(?:ya|hoy)\s+)?(?:hice|cumpli|complete|termine|marca\w*)\s+(?:el |mi )?habito\s+"
                         r"(?:de\s+)?(?P<que>.+)$|^(?:ya|hoy)\s+(?:hice|cumpli con)\s+(?P<que2>.+)$")
VER_HABITOS = re.compile(r"\b(?:mis habitos|que habitos tengo|como (?:voy|vengo) con (?:los|mis) habitos|"
                         r"(?:mis )?rachas?(?: de habitos)?)\b")
BORRAR_HABITO = re.compile(r"^(?:borra|elimina|saca|quita)\w*\s+(?:el |mi )?habito\s+(?:de\s+)?(?P<que>.+)$")


def racha(hechos, hoy=None):
    """Días seguidos cumplidos, contando hasta hoy (o hasta ayer si hoy todavía no lo hiciste)."""
    hoy = hoy or datetime.date.today()
    dias = set(hechos)
    dia = hoy if hoy.isoformat() in dias else hoy - datetime.timedelta(days=1)
    cuenta = 0
    while dia.isoformat() in dias:
        cuenta += 1
        dia -= datetime.timedelta(days=1)
    return cuenta


def texto_habitos(habitos):
    hoy = datetime.date.today().isoformat()
    lineas = []
    for h in habitos:
        r = racha(h["hechos"])
        marca = "✔" if hoy in h["hechos"] else "○"
        lineas.append(f"{marca} {h['nombre']}: racha de {r} día{'s' if r != 1 else ''}"
                      + ("" if hoy in h["hechos"] else " (hoy te falta)"))
    return "\n".join(lineas)


def manejar_habitos(texto, t):
    datos = _cargar()
    habitos = datos["habitos"]
    m = AGREGAR_HABITO.match(t)
    if m:
        g = "que" if m.group("que") else "que2"
        nombre = _original(texto, m, g).strip(" .")
        if _el_mas_parecido(nombre, [h["nombre"] for h in habitos], 0.9) is not None:
            return f"Ya tenés el hábito «{nombre}»."
        habitos.append({"nombre": nombre, "creado": datetime.date.today().isoformat(), "hechos": []})
        _guardar(datos)
        return f"Listo, nuevo hábito: «{nombre}». Cuando lo hagas decime «hice el hábito {nombre}» y te llevo la racha."
    if VER_HABITOS.search(t):
        if not habitos:
            return "Todavía no tenés hábitos. Probá: «agregá el hábito leer 20 minutos»."
        return "Tus hábitos:\n" + texto_habitos(habitos)
    m = BORRAR_HABITO.match(t)
    if m and habitos:
        i = _el_mas_parecido(m.group("que"), [h["nombre"] for h in habitos])
        if i is not None:
            borrado = habitos.pop(i)
            _guardar(datos)
            return f"Borré el hábito «{borrado['nombre']}»."
    m = HICE_HABITO.match(t)
    if m and habitos:
        frase = m.group("que") or m.group("que2")
        i = _el_mas_parecido(frase, [h["nombre"] for h in habitos], 0.55 if m.group("que") else 0.7)
        if i is None:
            return None if m.group("que2") else f"No tengo un hábito «{frase}». Decí «mis hábitos» para verlos."
        h = habitos[i]
        hoy = datetime.date.today().isoformat()
        if hoy in h["hechos"]:
            return f"«{h['nombre']}» ya lo tenías marcado hoy. Racha: {racha(h['hechos'])} días."
        h["hechos"].append(hoy)
        h["hechos"] = sorted(set(h["hechos"]))[-400:]
        _guardar(datos)
        r = racha(h["hechos"])
        festejo = " ¡Una semana entera!" if r == 7 else " ¡Un mes seguido, crack!" if r == 30 else ""
        return f"¡Bien! Marqué «{h['nombre']}». Racha: {r} día{'s' if r != 1 else ''} seguido{'s' if r != 1 else ''}.{festejo}"
    return None


# ---------- Apuntes rápidos ----------

APUNTAR = re.compile(r"^(?:apunta(?:me)?|toma(?:me)? (?:una )?nota|nota rapida|anota en (?:mis )?apuntes|"
                     r"guarda(?:me)? (?:un|este) apunte)\s*(?:de |que )?:?\s*(?P<que>.+)$")
VER_APUNTES = re.compile(r"^(?:(?:mostra|leeme|decime)\w*\s+)?(?:mis apuntes|mis notas rapidas|que (?:tengo )?apunte|"
                         r"que apuntes tengo)$")
BUSCAR_APUNTE = re.compile(r"^(?:busca\w*|encontra\w*)\s+en\s+(?:mis\s+)?(?:apuntes|notas rapidas)\s+(?:sobre |de |lo de )?"
                           r"(?P<que>.+)$")
BORRAR_APUNTE = re.compile(r"^(?:borra|elimina|saca|quita)\w*\s+(?:el\s+)?apunte\s+(?:numero |nro |n )?(?P<cual>.+)$")


def manejar_apuntes(texto, t):
    datos = _cargar()
    apuntes = datos["apuntes"]
    m = APUNTAR.match(t)
    if m:
        cosa = _original(texto, m, "que").strip()
        apuntes.append({"texto": cosa, "fecha": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")})
        _guardar(datos)
        return f"Apuntado (es el apunte {len(apuntes)})."
    if VER_APUNTES.match(t):
        if not apuntes:
            return "No tenés apuntes. Probá: «apuntá: la clave del wifi está en la heladera»."
        return "Tus apuntes:\n" + "\n".join(f"{i}. {a['texto']} ({a['fecha'][:10]})" for i, a in enumerate(apuntes, 1))
    m = BUSCAR_APUNTE.match(t)
    if m:
        palabras = [p for p in re.findall(r"\w+", _n(m.group("que"))) if len(p) > 2]
        hallados = [(i, a) for i, a in enumerate(apuntes, 1)
                    if palabras and any(p in _n(a["texto"]) for p in palabras)]
        if not hallados:
            return f"No tengo apuntes sobre «{m.group('que')}»."
        return "Encontré esto:\n" + "\n".join(f"{i}. {a['texto']}" for i, a in hallados)
    m = BORRAR_APUNTE.match(t)
    if m and apuntes:
        cual = m.group("cual").strip()
        numero = jarvis.herramientas.numero_de(cual) if hasattr(jarvis.herramientas, "numero_de") else None
        if numero is None and cual.isdigit():
            numero = int(cual)
        if numero is None:
            i = _el_mas_parecido(cual, [a["texto"] for a in apuntes], 0.5)
            numero = i + 1 if i is not None else None
        if numero is None or not 1 <= numero <= len(apuntes):
            return "¿Cuál apunte? Decime el número (decí «mis apuntes» para verlos)."
        borrado = apuntes.pop(numero - 1)
        _guardar(datos)
        return f"Borré el apunte «{borrado['texto'][:60]}»."
    return None


# ---------- Modo agente ----------

ENCARGATE = re.compile(r"^(?:encargate|ocupate|hacete cargo)\s+(?:de\s+)?(?:esto\s*)?:?\s*(?P<que>.+)$"
                       r"|^(?:modo agente|agente)\s*:?\s+(?P<que2>.+)$")
COMO_PLANEAR = (
    "Sos el planificador de JARVIS, un asistente que controla la compu con órdenes cortas en español rioplatense. "
    "Partí el objetivo del usuario en entre 1 y 6 órdenes, cada una como la diría el usuario. Usá solo órdenes de este "
    "estilo: «abrí Spotify», «abrí youtube.com», «poné música lo-fi», «pausá la música», «subí el volumen al 40», "
    "«buscá en Google recetas de pizza», «recordame en 25 minutos tomar agua», «temporizador de 10 minutos», "
    "«modo estudio de 45 minutos», «agregá comprar pan a mis pendientes», «apuntá: ...», «¿qué tengo hoy?», "
    "«¿cómo está el clima?», «creá un documento de Word sobre ...», «hacé clic en ...», «escribí acá ...». "
    "Nunca: mandar mensajes o mails, llamar, borrar, comprar, pagar, apagar la compu ni cambiar el código de JARVIS. "
    "Si el objetivo pide algo de eso, dejalo afuera. Respetá los tiempos, cantidades y nombres exactos que dice el "
    "usuario (si dice una hora, son 60 minutos). Devolvé JSON: {\"pasos\": [\"...\"]}."
)


def agente(objetivo_txt):
    try:
        plan = jarvis.pedir_json(COMO_PLANEAR, objetivo_txt, {
            "type": "object", "properties": {"pasos": {"type": "array", "items": {"type": "string"}}},
            "required": ["pasos"]}, temperatura=0.2, largo=600)
    except jarvis.IAPausada:
        return "Estoy en modo juego: la IA está pausada."
    except Exception as e:
        return f"No pude armar el plan: {e}."
    pasos = [p.strip(" .") for p in plan.get("pasos", []) if isinstance(p, str) and p.strip()][:6]
    if not pasos:
        return "No supe partir eso en pasos que pueda hacer. ¿Me lo decís de otra forma?"
    jarvis.emitir("detalle", "Plan: " + " → ".join(pasos))
    hechos = correr_pasos(pasos, "Agente")
    return "Listo, lo hice así:\n" + "\n".join(hechos)


# ---------- Entrada ----------

def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    m = ENCARGATE.match(t)
    if m:
        return agente(_original(texto, m, "que" if m.group("que") else "que2"))
    for manejador in (manejar_rutinas, manejar_habitos, manejar_apuntes):
        respuesta = manejador(texto, t)
        if respuesta is not None:
            return respuesta
    if jarvis.rutinas.VER.search(t):  # "mis rutinas": las de rutinas.py y además las con nombre
        otras = jarvis.rutinas.manejar(texto, t)
        nombradas = lista_rutinas()
        if nombradas:
            return nombradas if otras and otras.startswith("No tenés rutinas") else f"{otras}\n\n{nombradas}"
        return otras
    return None
