"""Chequeo del sistema y tus datos (como "System Check" y "Privacy & Data" de heynixi).

  "chequeo del sistema" / "¿funciona todo?": micrófono, reconocer la voz (Google y sin internet), la IA (Ollama),
                                            la placa de video, internet, la píldora y las teclas para hablar.
  "exportá mis datos":    un .zip con tus charlas, recuerdos, pendientes, recordatorios, apuntes, hábitos... en
                          Documentos\\JARVIS (para guardarlo o pasarlo a otra compu).
  "borrá todos mis datos": pregunta primero; deja una copia en %LOCALAPPDATA%\\JARVIS\\respaldos y se reinicia.
                          No toca las configuraciones, los contactos ni tu diccionario de dictado.
"""
import datetime
import os
import re
import shutil
import socket
import time
import zipfile

import disco

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
DATOS = ["historial.json", "recuerdos.json", "recuerdos.txt", "memoria_candidatos.json", "pendientes.json",
         "recordatorios.json", "organizador.json", "examenes.json", "control.json", "rutinas.json", "chats",
         "actividad"]
EXTRAS_EXPORTAR = ["contactos.json", "dictado.json", "ajustes.json"]  # se exportan pero no se borran
RESPALDOS = os.path.join(os.environ.get("LOCALAPPDATA", BASE), "JARVIS", "respaldos")
_pendiente = {"hasta": 0.0}

CHEQUEO = re.compile(r"^(?:hace(?:me|te)?\s+(?:un\s+)?)?(?:chequeo|diagnostico)(?:\s+(?:del sistema|de jarvis|general|"
                     r"completo))?$|^chequea(?:te)?\s+(?:el sistema|todo)$|^(?:funciona todo|anda todo bien|"
                     r"system check|estas funcionando bien|esta todo bien con vos)$")
EXPORTAR = re.compile(r"^(?:exporta|descarga|guarda|sacame)\w*\s+(?:todos\s+)?(?:mis|tus|los)\s+datos\b")
BORRAR = re.compile(r"^(?:borra|elimina|limpia)\w*\s+(?:todos\s+)?(?:mis|tus|los)\s+datos\b|^borra(?:te)? todo lo que sabes$")
CONFIRMA = re.compile(r"^(?:si,?\s*)?borra(?:los)?\s+todo$|^si,?\s*(?:borralos|borra todo|dale borra todo)$")


def _ok(si):
    return "✔" if si else "✖"


def chequeo():
    lineas = ["Chequeo del sistema:"]
    # micrófono
    try:
        import sounddevice as sd
        mic = sd.query_devices(jarvis.MICROFONO, "input")
        lineas.append(f"{_ok(True)} Micrófono: {mic['name']}")
    except Exception as e:
        lineas.append(f"{_ok(False)} Micrófono: no encontré ninguno ({e})")
    # internet y Google
    try:
        socket.create_connection(("www.google.com", 443), timeout=4).close()
        internet = True
    except OSError:
        internet = False
    lineas.append(f"{_ok(internet)} Internet: {'conectado' if internet else 'sin conexión (la voz se reconoce en la compu)'}")
    # voz sin internet
    try:
        import onnx_asr  # noqa: F401
        cargada = jarvis._voz_local["modelo"] is not None
        lineas.append(f"{_ok(True)} Voz sin internet (Parakeet): {'lista' if cargada else 'instalada, se carga al usarla'}"
                      f" · modo: {jarvis.VOZ_LOCAL}")
    except Exception:
        lineas.append(f"{_ok(False)} Voz sin internet: falta instalar onnx-asr (pip install \"onnx-asr[hub]\")")
    # la IA
    t = time.time()
    responde = jarvis.ollama_responde(3)
    lineas.append(f"{_ok(responde)} IA (Ollama, {jarvis.MODELO}): "
                  + (f"responde ({time.time() - t:.1f} s)" if responde else "no responde; decime «reiniciá el núcleo»"))
    if jarvis.herramientas.modo_juego.is_set():
        lineas.append("· Modo juego activo: la IA está en pausa a propósito.")
    # placa de video
    try:
        import subprocess
        salida = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.used,memory.total", "--format=csv,noheader"],
                                capture_output=True, text=True, timeout=6, creationflags=0x08000000).stdout.strip()
        lineas.append(f"{_ok(bool(salida))} Placa de video: {salida or 'no la encontré'}")
    except Exception:
        lineas.append("· Placa de video: no pude consultarla")
    # píldora y teclas
    p = jarvis.pildora
    viva = p._est["conexion"] is not None
    lineas.append(f"{_ok(viva or not p.ACTIVA)} Píldora flotante: "
                  + ("funcionando" if viva else "apagada en Configuraciones" if not p.ACTIVA else "no arrancó"))
    lineas.append(f"{_ok(True)} Teclas para hablar (Alt derecho / Ctrl derecho): "
                  + ("activas" if jarvis.escritorio.TECLAS_ACTIVAS else "desactivadas en Configuraciones"))
    # los archivos de datos (recordatorios, pendientes, recuerdos...): si alguno estaba dañado o tomado
    problemas = disco.resumen()
    lineas.append(f"{_ok(not problemas)} Tus datos: " + ("todo se lee bien" if not problemas else "; ".join(problemas)))
    return "\n".join(lineas)


def _zip(destino, nombres):
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for nombre in nombres:
            ruta = os.path.join(BASE, nombre)
            if os.path.isfile(ruta):
                z.write(ruta, nombre)
            elif os.path.isdir(ruta):
                for raiz, _dirs, archivos in os.walk(ruta):
                    for a in archivos:
                        completo = os.path.join(raiz, a)
                        z.write(completo, os.path.relpath(completo, BASE))
    return destino


def exportar():
    with jarvis.lock:
        jarvis.guardar_historial()
    carpeta = os.path.join(os.path.expanduser("~"), "Documents", "JARVIS")
    os.makedirs(carpeta, exist_ok=True)
    destino = os.path.join(carpeta, f"JARVIS mis datos {datetime.datetime.now():%Y-%m-%d %H-%M}.zip")
    _zip(destino, DATOS + EXTRAS_EXPORTAR)
    try:
        os.startfile(carpeta)
    except OSError:
        pass
    return f"Listo, exporté tus datos a «{destino}». Te abrí la carpeta."


def borrar_todo():
    os.makedirs(RESPALDOS, exist_ok=True)
    copia = _zip(os.path.join(RESPALDOS, f"antes de borrar mis datos {datetime.datetime.now():%Y-%m-%d %H-%M}.zip"),
                 DATOS)
    with jarvis.lock:
        jarvis.historial.clear()
    for nombre in DATOS:
        ruta = os.path.join(BASE, nombre)
        try:
            if os.path.isdir(ruta):
                shutil.rmtree(ruta)
            elif os.path.exists(ruta):
                os.remove(ruta)
        except OSError:
            pass
    jarvis.automejora.reiniciar()  # que no quede nada en la memoria de JARVIS (lo volvería a guardar)
    return (f"Listo, borré tus charlas, recuerdos, pendientes, recordatorios, apuntes, hábitos y actividad. Por las "
            f"dudas dejé una copia en «{copia}». Me reinicio.")


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    if _pendiente["hasta"] and time.time() < _pendiente["hasta"]:
        _pendiente["hasta"] = 0.0
        if CONFIRMA.match(t):
            return borrar_todo()
        if t in ("no", "cancela", "mejor no", "nada"):
            return "Listo, no borré nada."
    if CHEQUEO.search(t):
        return chequeo()
    if EXPORTAR.match(t):
        return exportar()
    if BORRAR.match(t):
        _pendiente["hasta"] = time.time() + 90
        return ("¿Seguro? Voy a borrar tus charlas, recuerdos, pendientes, recordatorios, apuntes, hábitos y "
                "actividad (las configuraciones y los contactos quedan). Si estás seguro decí «sí, borrá todo».")
    return None
