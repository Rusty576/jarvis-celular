"""Generador de imágenes LOCAL (usa la placa de video de la PC, sin internet).

JARVIS lo abre en un proceso aparte solo cuando hace falta, así PyTorch no ocupa memoria el resto del tiempo.
Habla con JARVIS por líneas JSON:
  entrada:  {"prompt": "...", "negativo": "...", "ancho": 1024, "alto": 1024, "semilla": 123, "ruta": "C:/.../x.png",
             "pasos": 6, "base": "C:/.../foto.jpg" (opcional: la usa de base para editarla), "fuerza": 0.6}
  salida:   {"listo": true}  ·  {"progreso": 0.5}  ·  {"ok": true, "ruta": "..."}  ·  {"ok": false, "error": "..."}
Si pasan 8 minutos sin pedidos, se cierra solo y libera la placa de video.

Probar a mano:  python generador_imagenes.py --probar "a banana taped to a white wall"
"""
import json
import os
import sys
import threading
import time

MODELO = "Lykon/dreamshaper-xl-lightning"  # SDXL Lightning: buena calidad en 6 pasos
PASOS = 6
GUIA = 2.0
ESPERA_MAXIMA = 480  # segundos sin pedidos antes de cerrarse (8 min: cargarlo de nuevo tarda de 15 a 80 s)
VAE_RAPIDO = "madebyollin/sdxl-vae-fp16-fix"  # el decodificador de SDXL corregido para fp16 (el original iba en fp32)
NEGATIVO = ("blurry, low quality, deformed, distorted, disfigured, bad anatomy, extra fingers, watermark, "
            "text, logo, signature, jpeg artifacts, ugly")


def enviar(**datos):
    sys.stdout.write(json.dumps(datos) + "\n")
    sys.stdout.flush()


def cargar():
    import torch
    from diffusers import DPMSolverMultistepScheduler, StableDiffusionXLPipeline

    if not torch.cuda.is_available():
        raise RuntimeError("PyTorch no detecta la placa de video NVIDIA")
    extra = {}
    try:  # medido: la imagen pasa de ~26 s a ~16 s (decodificar baja de 10 s a 5 s), con la misma calidad
        from diffusers import AutoencoderKL

        extra["vae"] = AutoencoderKL.from_pretrained(VAE_RAPIDO, torch_dtype=torch.float16)
    except Exception:
        pass  # sin internet la primera vez: sigue con el decodificador original
    pipe = StableDiffusionXLPipeline.from_pretrained(MODELO, torch_dtype=torch.float16, variant="fp16",
                                                     use_safetensors=True, **extra)
    pipe.scheduler = DPMSolverMultistepScheduler.from_config(
        pipe.scheduler.config, algorithm_type="sde-dpmsolver++", use_karras_sigmas=True)
    pipe.enable_model_cpu_offload()  # entra en 6 GB de placa de video
    pipe.set_progress_bar_config(disable=True)
    return pipe


_editor = {"pipe": None, "en_uso": "texto"}  # el de "editar una imagen" comparte el modelo con el normal


def _usar(pipe, cual):
    """Los dos generadores comparten la placa de video: al cambiar de uno al otro se reacomoda la memoria."""
    if _editor["en_uso"] != cual:
        (pipe if cual == "texto" else _editor["pipe"]).enable_model_cpu_offload()
        _editor["en_uso"] = cual


def generar(pipe, pedido):
    import math

    import torch

    pasos = int(pedido.get("pasos") or PASOS)
    generador = torch.Generator("cpu").manual_seed(int(pedido.get("semilla", 0)))
    negativo = NEGATIVO + (", " + pedido["negativo"] if pedido.get("negativo") else "")  # lo de siempre + el estilo
    comunes = dict(prompt=pedido["prompt"], negative_prompt=negativo,
                   guidance_scale=GUIA, generator=generador)
    if pedido.get("base"):  # editar: parte de tu imagen y la transforma
        from diffusers import AutoPipelineForImage2Image
        from PIL import Image

        if _editor["pipe"] is None:
            _editor["pipe"] = AutoPipelineForImage2Image.from_pipe(pipe)
            _editor["pipe"].set_progress_bar_config(disable=True)
            _editor["en_uso"] = "texto"
        _usar(pipe, "edicion")
        base = Image.open(pedido["base"]).convert("RGB")
        escala = 1024 / max(base.size)  # lado mayor 1024 y medidas múltiplo de 64 (lo que necesita SDXL)
        base = base.resize((max(512, round(base.width * escala / 64) * 64), max(512, round(base.height * escala / 64) * 64)))
        fuerza = float(pedido.get("fuerza", 0.6))
        total = math.ceil(pasos / fuerza)  # así los pasos que realmente pinta siguen siendo 'pasos'

        def paso(_pipe, i, _t, kwargs):
            enviar(progreso=min(1.0, (i + 1) / max(1, int(total * fuerza))))
            return kwargs
        imagen = _editor["pipe"](image=base, strength=fuerza, num_inference_steps=total,
                                 callback_on_step_end=paso, **comunes).images[0]
    else:
        _usar(pipe, "texto")

        def paso(_pipe, i, _t, kwargs):
            enviar(progreso=(i + 1) / pasos)
            return kwargs
        imagen = pipe(width=int(pedido.get("ancho", 1024)), height=int(pedido.get("alto", 1024)),
                      num_inference_steps=pasos, callback_on_step_end=paso, **comunes).images[0]
    imagen.save(pedido["ruta"])
    return pedido["ruta"]


def main():
    # Ojo (Windows): no se puede estar leyendo la entrada en otro hilo mientras se carga PyTorch, porque si
    # alguna librería consulta esa entrada al mismo tiempo, las dos operaciones se traban. Por eso: primero se
    # carga el modelo, y después se leen los pedidos en este mismo hilo.
    try:
        pipe = cargar()
    except Exception as e:
        enviar(ok=False, error=f"No pude cargar el modelo de imágenes: {e}")
        return
    enviar(listo=True)

    ultimo_uso = [time.time()]

    def vigilar():  # si pasan 8 minutos sin pedidos, se cierra y libera la placa de video
        while True:
            time.sleep(10)
            if time.time() - ultimo_uso[0] > ESPERA_MAXIMA:
                os._exit(0)
    threading.Thread(target=vigilar, daemon=True).start()

    while True:
        linea = sys.stdin.readline()
        if not linea or linea.strip() == "salir":  # JARVIS se cerró o pidió terminar
            return
        ultimo_uso[0] = float("inf")  # mientras pinta, no se cierra
        try:
            enviar(ok=True, ruta=generar(pipe, json.loads(linea)))
        except Exception as e:
            enviar(ok=False, error=str(e)[:300])
        finally:
            ultimo_uso[0] = time.time()


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--probar":
        t = time.time()
        p = cargar()
        print(f"modelo cargado en {time.time() - t:.0f}s")
        t = time.time()
        ruta = os.path.abspath("prueba_imagen_local.png")
        generar(p, {"prompt": sys.argv[2], "semilla": 42, "ruta": ruta})
        print(f"imagen en {time.time() - t:.0f}s: {ruta}")
        if len(sys.argv) > 3:  # --probar "prompt" "prompt de la edición": edita la imagen recién hecha
            t = time.time()
            editada = os.path.abspath("prueba_imagen_editada.png")
            generar(p, {"prompt": sys.argv[3], "semilla": 7, "ruta": editada, "base": ruta, "fuerza": 0.6})
            print(f"edición en {time.time() - t:.0f}s: {editada}")
            t = time.time()
            generar(p, {"prompt": sys.argv[2], "semilla": 9, "ruta": ruta})
            print(f"otra normal después de editar en {time.time() - t:.0f}s")
    else:
        main()
