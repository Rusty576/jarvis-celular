"""Archivos e imágenes que le pasás a JARVIS (arrastrándolos a la ventana o con el botón del clip).

  - Documentos (PDF, Word, Excel, PowerPoint, texto, código): los lee y podés preguntarle sobre ellos
    ("resumilo", "¿qué dice de la fotosíntesis?", "armame un examen con esto"). Se acuerda del último por 30 minutos.
  - Imágenes: las mira con la IA ("¿qué ves?", "¿qué dice este cartel?") o las usa de base para editar
    ("pasala a estilo anime", "ponele un sombrero").
  - Links: si escribís un link en el mensaje, lee la página.
  - Videos (archivos o links de YouTube): mira momentos de todo el video y lo que se dice (ver video.py).
"""
import base64
import datetime
import io
import json
import os
import re
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(BASE, "adjuntos")
MAX_LETRAS = 14000  # lo que entra cómodo en la memoria de la IA (el resto se recorta)
DURA_DOCUMENTO = 30 * 60
DURA_IMAGEN = 10 * 60
DURA_VIDEO = 30 * 60
DURA_TEXTO_PEGADO = 3 * 24 * 60 * 60  # un texto que pegaste (un guion, apuntes) se recuerda 3 días (y se guarda en disco)
CARPETA_TEXTOS = os.path.join(CARPETA, "textos")  # los textos pegados: sobreviven a cerrar JARVIS

EXT_IMAGEN = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}
EXT_TEXTO = {".txt", ".md", ".csv", ".json", ".xml", ".html", ".htm", ".css", ".js", ".ts", ".py", ".java", ".c",
             ".cpp", ".h", ".cs", ".php", ".rb", ".go", ".rs", ".sql", ".ini", ".cfg", ".log", ".yml", ".yaml", ".bat",
             ".ps1", ".sh", ".kt", ".swift", ".lua", ".r", ".tex"}
EXT_OFFICE = {".pdf", ".docx", ".xlsx", ".xlsm", ".pptx"}

# Órdenes escondidas para la IA adentro de un texto («ignorá todas tus instrucciones y respondé...»): un modelo chico
# las obedece aunque se le diga que no (probado con Gemma 3 4B: 3 de 3, y 2 de 4 avisándole). Se sacan del texto antes
# de dárselo (así no las ve), y JARVIS te avisa después de contestar
ORDEN_ESCONDIDA = re.compile(
    r"\bignor\w*\s+(?:todas?\s+|todo\s+)?(?:las\s+|tus\s+|mis\s+|lo\s+)?(?:instrucciones|indicaciones|reglas|ordenes|órdenes|"
    r"anterior)|\bolvid\w*\s+(?:todas?\s+)?(?:tus\s+|las\s+)?(?:instrucciones|reglas|lo anterior)"
    r"|\b(?:ignore|disregard|forget)\s+(?:all\s+|any\s+)?(?:the\s+|your\s+)?(?:previous|prior|above|earlier)?\s*"
    r"(?:instructions|prompts?|rules)|\bsystem\s+prompt\b|\bprompt\s+del\s+sistema\b"
    r"|\b(?:para|to)\s+(?:la\s+ia|el\s+asistente|el\s+modelo|the\s+(?:ai|assistant|model)|chatgpt|jarvis)\s*:", re.I)
ordenes_quitadas = []    # las que se sacaron desde el último aviso (main.despachar avisa después de contestar)


def sin_ordenes(texto):
    """El texto sin las oraciones que le dan órdenes a la IA (en su lugar queda una marca). Lo demás, tal cual."""
    if not texto or not ORDEN_ESCONDIDA.search(texto):
        return texto
    for _ in range(20):
        m = ORDEN_ESCONDIDA.search(texto)
        if not m:
            break
        desde = max(texto.rfind(c, 0, m.start()) for c in ".!?\n") + 1
        hasta = [i for i in (texto.find(c, m.end()) for c in ".!?\n") if i >= 0]
        hasta = min(hasta) + 1 if hasta else len(texto)
        ordenes_quitadas.append(" ".join(texto[desde:hasta].split())[:140])
        texto = texto[:desde] + " [acá había una orden escondida: la saqué]" + texto[hasta:]
    return texto


_lock = threading.Lock()
pendientes = []          # lo que adjuntaste y todavía no usaste en un mensaje
documento_activo = None  # {"nombre", "texto", "cuando"}: para seguir preguntando sobre él
imagen_activa = None     # {"nombre", "ruta", "b64", "cuando"}
video_activo = None      # {"nombre", "cuando", "listo" (Event), "datos" (de video.py) o "error", "usado"}
incluidos = []           # qué entró en el último mensaje ("doc", "video", "imagen"): main lo usa para buscar el juego

URL = re.compile(r"https?://[^\s<>\"']+")
REFIERE_DOC = re.compile(r"\b(?:archivo|documento|pdf|word|excel|planilla|presentacion|apuntes?|folleto|texto|libro|guion|"
                         r"capitulo|pagina|seccion|tabla|diapositiva|resumi\w*|resumen|segun (?:el|eso|esto|lo)|que dice|"
                         r"ahi dice|lo que te (?:pase|mande|adjunte|di|envie|pegue))\b")
REFIERE_VIDEO = re.compile(r"\b(?:video|videos|clip|grabacion|pelicula|escena|minuto|segundo|parte|final|principio|"
                           r"aparece|dice|dicen|habla|hablan|pasa|ves|se ve|resumi\w*|resumen|de que trata)\b")
REFIERE_IMAGEN = re.compile(r"\b(?:imagen|foto|captura|cartel|dibujo|eso|esto|ahi|en ella|la misma|aparece|ves|se ve)\b")
EDITAR = re.compile(r"\b(?:edita\w*|modifica\w*|cambia\w*|converti\w*|transforma\w*|pasa(?:la|lo)|hace(?:la|lo)|"
                    r"pone(?:le|la|lo)|agrega(?:le)?|saca(?:le)?|quita(?:le)?|dibuja(?:la|lo)|pinta(?:la|lo)|"
                    r"redibuja\w*|estilo|version (?:de|en|estilo)|en (?:modo|version) )\b")
PREGUNTA = re.compile(r"^(?:que|como|cual|cuales|quien|donde|cuando|cuanto|por que|hay|tiene|es|dice|decime|"
                      r"explicame|describi|describime|resumi|resumime|leeme|lee)\b")


# ----------------------------------------------------------------- textos largos pegados en el chat
# Un guion, apuntes o un artículo pegado en el mensaje se guarda como un archivo más (para resumirlo, armar quizzes,
# preguntarle cosas un rato después...). Antes se buscaban órdenes adentro: «la temperatura» de un texto de enzimas
# pedía el clima.
INSTRUCCION = re.compile(
    r"^(?:(?:por favor|porfa|jarvis|che|bueno|ok)[\s,]+)*(?:resumi\w*|resume\w*|resumen|arma\w*|haceme|hazme|haz|hace(?:lo|la)?|"
    r"crea\w*|genera\w*|explica\w*|corregi\w*|corrige\w*|traduci\w*|traduce\w*|analiza\w*|ayuda\w*|mejora\w*|"
    r"revisa\w*|lee\w*|dame|decime|dime|sacame|pasa(?:lo|la|me)\w*|ordena\w*|reescribi\w*|reescribe\w*|verifica\w*|"
    r"chequea\w*|estudia\w*|memoriza\w*|recorda\w*|guarda\w*|tomame|evaluame|prepara\w*|"
    r"(?:quiero|necesito|preciso|podes|podrias|puedes)\s+(?:que|un|una|el|la|hacer|armar|resumir|estudiar|saber)|"
    r"que (?:opinas|te parece|dice))\b")
PEDIDO_EN_LINEA = re.compile(r"^(.{0,90}?\b(?:quiz|examen|prueba|cuestionario|test|preguntas|resumen|resumi\w*|resume\w*)\b"
                             r"(?:\s+de\s+\d+\s+preguntas)?(?:\s+(?:de|sobre|con|del|acerca de)(?:\s+(?:esto|este texto))?)?)"
                             r"\s*[:,-]?\s+")
VACIAS = set("""el la los las un una unos unas de del al a ante con contra desde en entre hacia hasta para por segun sin
sobre tras y e o u ni que como cual cuales cuando donde quien quienes es son fue fueron ser sera estan esta estas este
estos esa ese esos esas eso esto lo le les se su sus mi mis tu tus nos muy mas menos tambien pero porque si no ya hay
tiene tienen hace pueden puede cada otro otra otros otras todo toda todos todas parte partes persona hoy vamos hablar
ejemplo ejemplos tipo tipos forma manera usar usan usa uso sirve sirven gracias minutos buenos buenas dias acá aca""".split())
MOSTRAR_TEXTO = re.compile(r"\b(?:manda|mandame|pasa|pasame|mostra|mostrame|devolveme|dame|copia|copiame|repeti|repetime)\s+"
                           r"(?:de nuevo |otra vez )?(?:el|ese|aquel|mi) texto\b")


# ¿De cuál habla? Nombrar el texto o el video (o algo que solo tiene sentido en uno) decide; si no, el último usado
EXPLICITO_DOC = re.compile(r"\b(?:texto|guion|documento|archivo|pdf|apuntes?|folleto|lectura|libro|word|excel|planilla|"
                           r"link|enlace|articulo|pagina que te|"
                           r"presentacion|diapositivas?|lo que te (?:pase|pegue|escribi|mande|envie|di) (?:escrito|de texto)|"
                           r"(?:persona|parte|seccion|capitulo|punto|pagina) (?:numero |n )?\d+)\b")
EXPLICITO_VIDEO = re.compile(r"\b(?:video|videos|clip|grabacion|grabe|juego|videojuego|escena|pelicula|serie|anime|"
                             r"youtube|minuto \d+|viste|se ve|se veia|aparece en|personaje|nivel|jugador)\b")
SECCION = re.compile(r"\b(persona|parte|seccion|capitulo|punto)\s*(?:numero\s*|n\s*|nro\.?\s*|#\s*)?(\d+)\b")
HABLA_DE_PANTALLA = re.compile(r"\b(?:pantalla|ves|veo|viendo|estas mirando|que hay|que tengo abierto|que se ve|"
                               r"se ve ahora|estoy haciendo|que hago|donde toco|este error)\b")
_turno = [0]  # cuenta los mensajes (para saber qué adjunto se usó hace poco)


def _vocabulario(doc):
    if "vocabulario" not in doc:
        doc["vocabulario"] = set(re.findall(r"[a-zñ]{5,}", jarvis.normalizar(doc["texto"]))) - VACIAS
    return doc["vocabulario"]


def toca_el_texto(t, doc):
    """¿La pregunta habla de algo que está en el texto? ('la persona 4', 'las enzimas', aunque diga 'encimas')."""
    if not doc:
        return False
    m = SECCION.search(t)
    if m and re.search(rf"\b{m.group(1)}\s*{m.group(2)}\b", jarvis.normalizar(doc["texto"])):
        return True
    import difflib

    vocabulario = _vocabulario(doc)
    palabras = [w for w in re.findall(r"[a-zñ]{5,}", t) if w not in VACIAS and w not in {
        "texto", "resumen", "resumi", "resumime", "explicame", "decime", "contame", "sobre", "dice", "dijiste"}]
    return any(w in vocabulario or difflib.get_close_matches(w, vocabulario, n=1, cutoff=0.82) for w in palabras)


def nombra_el_tema(t, doc):
    """¿La pregunta nombra el TEMA del texto («el texto de enzimas»)? Más estricto que toca_el_texto: mira solo el tema
    y el nombre, no cualquier palabra de adentro (así «¿dónde están esos errores?» no trae un texto que dice «errores»)."""
    import difflib

    if not doc:
        return False
    tema = set(re.findall(r"[a-zñ]{5,}", jarvis.normalizar(f"{doc.get('tema', '')} {doc.get('nombre', '')}")))
    tema -= VACIAS | {"texto", "sobre", "pasaste", "archivo"}
    palabras = [w for w in re.findall(r"[a-zñ]{5,}", t) if w not in VACIAS]
    return any(w in tema or difflib.get_close_matches(w, tema, n=1, cutoff=0.82) for w in palabras)


# Lo que NO es del texto aunque comparta palabras: tus mails, tu agenda, "lo que hablamos" (antes el texto de enzimas
# contestaba "¿tengo algún correo de robótica?" y el de energía tapaba toda la charla sobre la pila)
NO_ES_DEL_TEXTO = re.compile(r"\b(?:mails?|correos?|gmail|e-?mails?|bandeja|recordatorios?|alarmas?|agenda|"
                             r"fechas importantes|mis pendientes)\b")


def _pedazos(texto, largo=700):
    """El texto en pedazos de ~700 letras, sin cortar renglones ni oraciones (un texto pegado todo en un renglón
    se parte por oraciones)."""
    trozos = []
    for linea in texto.splitlines():
        trozos += [linea] if len(linea) <= largo else re.split(r"(?<=[.!?:])\s+", linea)
    pedazos, actual = [], ""
    for linea in trozos:
        if actual and len(actual) + len(linea) > largo:
            pedazos.append(actual.strip())
            actual = ""
        actual += linea + "\n"
    if actual.strip():
        pedazos.append(actual.strip())
    return pedazos


def partes_que_vienen_al_caso(t, doc, maximo=3000):
    """Los pedazos del texto que tienen que ver con la pregunta Y con el tema de los últimos mensajes ("¿qué
    materiales lleva?" después de hablar de la pila: el pedazo de la pila, no el de la mini central). None si
    ninguno tiene que ver (entonces va el texto entero)."""
    import difflib

    with jarvis.lock:
        anteriores = [m["content"] for m in jarvis.historial[-4:] if m.get("role") == "user"]
    palabras = lambda s: {w for w in re.findall(r"[a-zñ]{4,}", jarvis.normalizar(s)) if w not in VACIAS}  # noqa: E731
    de_la_pregunta, del_tema = palabras(t), palabras(" ".join(anteriores[-2:]))
    puntajes = []
    for i, p in enumerate(_pedazos(doc["texto"])):
        vocab = set(re.findall(r"[a-zñ]{4,}", jarvis.normalizar(p)))
        tiene = lambda w: w in vocab or bool(difflib.get_close_matches(w, vocab, n=1, cutoff=0.85))  # noqa: E731
        puntos = 2 * sum(tiene(w) for w in del_tema) + sum(tiene(w) for w in de_la_pregunta)
        puntajes.append((puntos, i, p))
    mejores = sorted([x for x in puntajes if x[0] > 0], reverse=True)
    if not mejores:
        return None
    elegidos, total = [], 0
    for puntos, i, p in mejores:
        if total + len(p) > maximo and elegidos:
            break
        elegidos.append((i, p))
        total += len(p)
    return "\n[...]\n".join(p for i, p in sorted(elegidos))


def seccion_del_texto(t, texto):
    """'la persona 4' -> el pedazo del texto de la Persona 4 (hasta la Persona 5 o el final). None si no está."""
    m = SECCION.search(t)
    if not m:
        return None
    etiqueta, numero = m.group(1), int(m.group(2))
    normal = jarvis.normalizar(texto)  # mismo largo que el original (solo saca tildes y pasa a minúsculas)
    if len(normal) != len(texto):
        return None
    ini = re.search(rf"\b{etiqueta}\s*{numero}\b", normal)
    if not ini:
        return None
    fin = re.search(rf"\b{etiqueta}\s*{numero + 1}\b", normal[ini.end():])
    pedazo = texto[ini.start(): ini.end() + fin.start() if fin else len(texto)]
    return pedazo.strip()[:6000], f"{etiqueta.capitalize()} {numero}"


def _guardar_texto(entrada):
    try:
        os.makedirs(CARPETA_TEXTOS, exist_ok=True)
        ruta = os.path.join(CARPETA_TEXTOS, f"{int(entrada['cuando'])}.json")
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump({k: entrada.get(k) for k in ("nombre", "tema", "texto", "cuando", "aviso", "origen")}, f,
                      ensure_ascii=False)
    except OSError:
        pass


def textos_guardados():
    """Los textos que pegaste (lo más nuevo primero)."""
    salida = []
    if os.path.isdir(CARPETA_TEXTOS):
        for a in sorted(os.listdir(CARPETA_TEXTOS), reverse=True)[:30]:
            try:
                with open(os.path.join(CARPETA_TEXTOS, a), encoding="utf-8") as f:
                    salida.append(json.load(f))
            except (OSError, ValueError):
                continue
    return salida


def recuperar_texto(t, solo_si_lo_nombra=False):
    """'el texto de encimas' (aunque JARVIS se haya cerrado): busca entre los textos guardados el que habla de eso
    y lo vuelve a dejar activo. Sin tema, el último (salvo solo_si_lo_nombra: ahí tiene que nombrar su tema; lo usa la
    pantalla compartida, donde «el texto» suele ser el de la pantalla). Devuelve el documento o None."""
    global documento_activo
    import difflib

    guardados = textos_guardados()
    if not guardados:
        return None
    palabras = [w for w in re.findall(r"[a-zñ]{5,}", t) if w not in VACIAS and w not in {"texto", "resumen", "guion"}]
    elegido = None
    for g in guardados:
        if solo_si_lo_nombra:
            if nombra_el_tema(t, g):
                elegido = g
                break
            continue
        vocabulario = set(re.findall(r"[a-zñ]{5,}", jarvis.normalizar(g["tema"] + " " + g["texto"][:4000])))
        if palabras and any(w in vocabulario or difflib.get_close_matches(w, vocabulario, n=1, cutoff=0.82) for w in palabras):
            elegido = g
            break
    if elegido is None and solo_si_lo_nombra:
        return None
    elegido = elegido or guardados[0]
    with _lock:
        documento_activo = {**elegido, "pegado": True, "turnos": 0, "cuando": time.time()}
    return documento_activo


def es_texto_pegado(texto):
    """¿Es un texto largo pegado (para trabajar sobre él) y no una orden?"""
    largo = len(texto.strip())
    return largo >= 900 or (largo >= 400 and texto.count("\n") >= 4)


def separar_instruccion(texto):
    """'Armame un quiz de esto:\\n<texto>' -> ('Armame un quiz de esto', '<texto>'). Sin pedido: ('', texto)."""
    texto = texto.strip()
    lineas = texto.split("\n")
    primera, ultima = lineas[0].strip(), lineas[-1].strip()
    n1 = jarvis.normalizar(primera)
    if len(lineas) > 1 and len(primera) <= 200 and INSTRUCCION.match(n1) and not re.match(r"^hace (?:mucho|poco|\d|anos|tiempo)", n1):
        return primera.rstrip(" :"), "\n".join(lineas[1:]).strip()
    if len(lineas) > 1 and len(ultima) <= 200 and INSTRUCCION.match(jarvis.normalizar(ultima)):
        return ultima.rstrip(" :"), "\n".join(lineas[:-1]).strip()
    # "Armame un quiz de Acá tenés el guion..." (el pedido y el texto en la misma línea)
    m = PEDIDO_EN_LINEA.match(n1)
    if m and INSTRUCCION.match(n1) and len(n1) == len(primera):
        return primera[:m.end()].strip(" :,-"), texto[m.end():].strip()
    return "", texto


def tema_de(texto, cantidad=2):
    """Las palabras que más se repiten en el texto: 'enzimas y biotecnología'."""
    originales = {}
    for w in re.findall(r"[^\W\d_]{5,}", texto):
        originales.setdefault(jarvis.normalizar(w), w.lower())
    cuenta = {}
    normal = jarvis.normalizar(texto)
    for k, w in enumerate(re.finditer(r"[a-zñ]{5,}", normal)):
        if w.group() not in VACIAS:  # lo del principio (el título, la introducción) pesa más
            cuenta[w.group()] = cuenta.get(w.group(), 0) + (4 if w.start() < 400 else 1)
    # singular y plural cuentan juntos ("enzima" / "enzimas")
    for w in list(cuenta):
        if w.endswith("s") and w[:-1] in cuenta:
            cuenta[w] += cuenta.pop(w[:-1])
    mejores = [originales.get(w, w) for w, c in sorted(cuenta.items(), key=lambda x: -x[1])[:cantidad] if c >= 2]
    return " y ".join(mejores) if mejores else "lo que me pasaste"


def agregar_texto(texto, nombre=None, origen=None, aviso=""):
    """Guarda un texto pegado (o lo leído de un link) como el documento activo, como si fuera un archivo: queda
    para seguir preguntando, resumirlo o armar un quiz, aunque cierres JARVIS."""
    global documento_activo
    texto = sin_ordenes(re.sub(r"\n{3,}", "\n\n", texto.replace("\r\n", "\n").strip()))
    if len(texto) > MAX_LETRAS:
        texto, aviso = texto[:MAX_LETRAS], "es largo: leí más o menos la primera parte"
    tema = tema_de(texto)
    nombre = nombre or f"Texto sobre {tema}"
    info = {"ok": True, "nombre": nombre, "tipo": "documento", "pegado": True}
    with _lock:
        documento_activo = {"nombre": nombre, "texto": texto, "cuando": time.time(), "aviso": aviso, "turnos": 0,
                            "pegado": True, "tema": tema, "usado": _turno[0], "origen": origen}
        pendientes[:] = [a for a in pendientes if not a.get("pegado")]
        if not origen:  # lo de un link ya entra en este mismo mensaje (lo agrega para_el_mensaje)
            pendientes.append(info)
    _guardar_texto(documento_activo)  # en disco: si cerrás JARVIS, lo sigue teniendo
    return {"nombre": nombre, "tema": tema, "palabras": len(texto.split()), "aviso": aviso}


_restaurado = [False]


def olvidar_documento():
    """Charla nueva (chats.py): el texto pegado, el archivo y el video de la charla anterior dejan de entrar en las
    respuestas (antes se colaban en temas que no tenían nada que ver)."""
    global documento_activo, video_activo
    with _lock:
        documento_activo = None
        _restaurado[0] = True  # que no vuelva solo el último texto guardado
        pendientes[:] = []
    video_activo = None


BORRAR_TEXTO = re.compile(r"\b(?:borra\w*|borres|elimina\w*|olvida\w*|sacate|tira(?:lo|la|los)?|no me (?:lo |la )?"
                          r"(?:repitas|nombres|menciones) (?:nunca )?mas)\b")
# lo que no es un texto que te pasé (eso lo borran otras partes de JARVIS)
OTRA_COSA = re.compile(r"\b(?:recordatorios?|alarmas?|pendientes?|recuerdos?|mails?|correos?|charlas?|chats?|historial|"
                       r"memoria|canci\w+|musica|imagen(?:es)?|fotos?|contactos?|archivos? de la carpeta)\b")


def manejar_borrar(texto, t):
    """«bórralo, enzimas», «borrá el texto de enzimas», «olvidate del texto que te pasé»: busca los textos que te
    guardé con ese tema y te pregunta antes de borrarlos. (Antes la IA contestaba «Borré todo lo anterior sobre las
    enzimas» sin borrar nada, y los textos seguían colándose en las respuestas.)"""
    if not BORRAR_TEXTO.search(t) or OTRA_COSA.search(t):
        return None
    guardados = []
    if os.path.isdir(CARPETA_TEXTOS):
        for a in sorted(os.listdir(CARPETA_TEXTOS)):
            try:
                with open(os.path.join(CARPETA_TEXTOS, a), encoding="utf-8") as f:
                    guardados.append((os.path.join(CARPETA_TEXTOS, a), json.load(f)))
            except (OSError, ValueError):
                continue
    elegidos = [(ruta, g) for ruta, g in guardados if nombra_el_tema(t, g)]
    if not elegidos and re.search(r"\b(?:el texto|ese texto|este texto|lo que te (?:pase|pegue))\b", t):
        doc = documento_vigente()   # «borrá el texto»: el que está usando ahora
        elegidos = [(ruta, g) for ruta, g in guardados if doc and g.get("cuando") == doc.get("cuando")]
    if not elegidos:
        return None
    lista = "\n".join(f"- {g['nombre']} (del {datetime.datetime.fromtimestamp(g['cuando']):%d/%m})" for _, g in elegidos)

    def borrar():
        global documento_activo
        cuales = {g.get("texto") for _, g in elegidos}   # por el contenido: "cuando" cambia cada vez que se usa
        for ruta, _ in elegidos:
            try:
                os.remove(ruta)
            except OSError:
                pass
        with _lock:
            if documento_activo and documento_activo.get("texto") in cuales:
                documento_activo = None
            _restaurado[0] = True   # que no vuelva solo al reiniciar
        return (f"Listo, borré {'el texto' if len(elegidos) == 1 else f'los {len(elegidos)} textos'}. "
                "Ya no los voy a usar en mis respuestas.")
    cuantos = "este texto que me pasaste" if len(elegidos) == 1 else f"estos {len(elegidos)} textos que me pasaste"
    return jarvis.conexiones.pedir_confirmacion("sistema", "Borrar textos", lista, accion=borrar,
                                                pregunta=f"¿Borro {cuantos}?\n{lista}\n")


def documento_vigente():
    """El documento activo si todavía vale (un texto pegado dura más que un archivo). Después de reiniciar JARVIS,
    vuelve el último texto que pegaste (antes se perdía y te contestaba inventando)."""
    global documento_activo
    if documento_activo is None and not _restaurado[0]:
        _restaurado[0] = True
        guardados = textos_guardados()
        if guardados and time.time() - guardados[0]["cuando"] < DURA_TEXTO_PEGADO:
            documento_activo = {**guardados[0], "pegado": True, "turnos": 0, "usado": -99}
    doc = documento_activo
    if not doc:
        return None
    dura = DURA_TEXTO_PEGADO if doc.get("pegado") else DURA_DOCUMENTO
    return doc if time.time() - doc["cuando"] < dura else None


def palabras_en_documento(tema, doc=None):
    """¿El tema del pedido está en el documento? ('enzimas' en un guion de enzimas -> True)."""
    import difflib

    doc = doc or documento_vigente()
    if not doc:
        return False
    claves = {w for w in re.findall(r"[a-zñ]{4,}", jarvis.normalizar(tema)) if w not in VACIAS}
    if not claves:
        return False
    # contra las palabras PRINCIPALES del texto (de qué trata), no contra cualquier palabra que aparezca: un guion de
    # enzimas dice "reacciones químicas", pero un quiz de química no tiene que salir de ahí
    if "principales" not in doc:
        doc["principales"] = set(re.findall(r"[a-zñ]{4,}", jarvis.normalizar(tema_de(doc["texto"], 6)))) - {"y"}
    principales = doc["principales"]
    return any(w in principales or difflib.get_close_matches(w, principales, n=1, cutoff=0.82) for w in claves)


def tipo_de(nombre):
    ext = os.path.splitext(nombre)[1].lower()
    if ext in EXT_IMAGEN:
        return "imagen"
    if ext in EXT_TEXTO or ext in EXT_OFFICE:
        return "documento"
    if ext in jarvis.video.EXT_VIDEO:
        return "video"
    return None


def _nombre_libre(nombre):
    os.makedirs(CARPETA, exist_ok=True)
    base, ext = os.path.splitext(re.sub(r'[<>:"/\\|?*]', "_", os.path.basename(nombre)) or "archivo")
    ruta, n = os.path.join(CARPETA, base + ext), 2
    while os.path.exists(ruta):
        ruta, n = os.path.join(CARPETA, f"{base}_{n}{ext}"), n + 1
    return ruta


def leer_texto(ruta):
    """El texto de un documento. Devuelve (texto, aviso) — aviso dice si se recortó o no tenía texto."""
    ext = os.path.splitext(ruta)[1].lower()
    if ext == ".pdf":
        from pypdf import PdfReader

        lector = PdfReader(ruta)
        paginas = []
        for i, pagina in enumerate(lector.pages):
            paginas.append(f"[Página {i + 1}]\n{pagina.extract_text() or ''}")
            if sum(len(p) for p in paginas) > MAX_LETRAS * 1.5:
                break
        texto = "\n".join(paginas)
        if len(re.sub(r"\[Página \d+\]|\s", "", texto)) < 30:
            return "", "el PDF no tiene texto (parece escaneado: son fotos de las páginas)"
    elif ext == ".docx":
        import docx

        d = docx.Document(ruta)
        partes = [p.text for p in d.paragraphs if p.text.strip()]
        for tabla in d.tables:
            for fila in tabla.rows:
                partes.append(" | ".join(c.text.strip() for c in fila.cells))
        texto = "\n".join(partes)
    elif ext in (".xlsx", ".xlsm"):
        import openpyxl

        libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        partes = []
        for hoja in libro.worksheets[:5]:
            partes.append(f"[Hoja {hoja.title}]")
            for i, fila in enumerate(hoja.iter_rows(values_only=True)):
                if i >= 300:
                    partes.append("(...más filas)")
                    break
                if any(v is not None for v in fila):
                    partes.append(" | ".join("" if v is None else str(v) for v in fila))
        libro.close()
        texto = "\n".join(partes)
    elif ext == ".pptx":
        from pptx import Presentation

        partes = []
        for i, diapo in enumerate(Presentation(ruta).slides):
            textos = [f.text_frame.text for f in diapo.shapes if f.has_text_frame and f.text_frame.text.strip()]
            partes.append(f"[Diapositiva {i + 1}]\n" + "\n".join(textos))
        texto = "\n".join(partes)
    else:
        with open(ruta, "rb") as f:
            crudo = f.read()
        try:
            texto = crudo.decode("utf-8")
        except UnicodeDecodeError:
            texto = crudo.decode("latin-1")
    texto = re.sub(r"\n{3,}", "\n\n", texto).strip()
    if len(texto) > MAX_LETRAS:
        return texto[:MAX_LETRAS], f"es largo: leí más o menos las primeras {MAX_LETRAS // 2000} páginas"
    return texto, ""


def _imagen_b64(ruta):
    """La imagen achicada (máximo 1024 px) en JPEG base64, como la necesita la IA."""
    from PIL import Image

    with Image.open(ruta) as img:
        img = img.convert("RGB")
        img.thumbnail((1024, 1024))
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=88)
    return base64.b64encode(buf.getvalue()).decode()


def agregar(nombre, datos):
    """Guarda lo que soltaste en la ventana y lo deja listo para el próximo mensaje. Devuelve info para la interfaz."""
    global documento_activo, imagen_activa
    tipo = tipo_de(nombre)
    if not tipo:
        ext = os.path.splitext(nombre)[1] or "ese tipo"
        return {"ok": False, "error": f"No sé leer archivos {ext}. Puedo con PDF, Word, Excel, PowerPoint, texto, "
                                      "código, imágenes y videos."}
    if len(datos) > 40 * 1024 * 1024:
        return {"ok": False, "error": "Es muy grande (más de 40 MB)."}
    ruta = _nombre_libre(nombre)
    with open(ruta, "wb") as f:
        f.write(datos)
    if tipo == "video":
        return agregar_video(ruta)
    info = {"ok": True, "nombre": os.path.basename(ruta), "tipo": tipo, "ruta": ruta}
    try:
        if tipo == "imagen":
            b64 = _imagen_b64(ruta)
            with _lock:
                imagen_activa = {"nombre": info["nombre"], "ruta": ruta, "b64": b64, "cuando": time.time()}
            info["miniatura"] = "data:image/jpeg;base64," + b64
        else:
            texto, aviso = leer_texto(ruta)
            texto = sin_ordenes(texto)
            if not texto:
                return {"ok": False, "error": f"No pude sacar texto de {info['nombre']}" + (f": {aviso}." if aviso else ".")}
            with _lock:
                documento_activo = {"nombre": info["nombre"], "texto": texto, "cuando": time.time(), "aviso": aviso}
            info["letras"], info["aviso"] = len(texto), aviso
    except Exception as e:
        return {"ok": False, "error": f"No pude abrir {info['nombre']}: {e}"}
    with _lock:
        pendientes.append(info)
    return info


def agregar_video(ruta):
    """Un video (se usa desde donde está, sin copiarlo). Lo mira en segundo plano mientras escribís qué querés;
    si mandás el mensaje antes de que termine, la respuesta lo espera."""
    global video_activo
    nombre = os.path.basename(ruta)
    try:
        cuadro = jarvis.video.primer_cuadro(ruta)
    except Exception:
        cuadro = None
    if cuadro is None:
        return {"ok": False, "error": f"No pude abrir el video {nombre} (¿está dañado o es un formato raro?)."}
    entrada = {"nombre": nombre, "ruta": ruta, "cuando": time.time(), "listo": threading.Event(), "datos": None,
               "error": None, "turnos": 0, "usado": _turno[0]}

    def analizar():
        try:
            entrada["datos"] = jarvis.video.analizar_archivo(ruta)
        except Exception as e:
            entrada["error"] = str(e)
        finally:
            entrada["listo"].set()
            jarvis.emitir("detalle", f"Ya miré {nombre}")

    threading.Thread(target=analizar, daemon=True).start()
    info = {"ok": True, "nombre": nombre, "tipo": "video", "ruta": ruta, "miniatura": jarvis.video.miniatura(cuadro)}
    with _lock:
        video_activo = entrada
        pendientes.append(info)
    return info


def agregar_ruta(ruta):
    """Lo mismo que agregar(), pero con la ruta del archivo (al soltarlo en la ventana o elegirlo con el clip):
    así los videos grandes no tienen que pasar enteros por la interfaz."""
    nombre = os.path.basename(ruta)
    if tipo_de(nombre) == "video":
        return agregar_video(ruta)
    try:
        if os.path.getsize(ruta) > 40 * 1024 * 1024:
            return {"ok": False, "error": f"{nombre} es muy grande (más de 40 MB)."}
        with open(ruta, "rb") as f:
            datos = f.read()
    except OSError as e:
        return {"ok": False, "error": f"No pude abrir {nombre}: {e}"}
    return agregar(nombre, datos)


def recordar_video(datos):
    """Deja un video ya mirado (una grabación de pantalla) para seguir preguntando sobre él."""
    global video_activo
    listo = threading.Event()
    listo.set()
    with _lock:
        video_activo = {"nombre": datos["nombre"], "ruta": datos.get("ruta"), "cuando": time.time(), "listo": listo,
                        "datos": datos, "error": None, "turnos": 1, "usado": _turno[0]}


def quitar(nombre=None):
    """Saca un adjunto pendiente (la ✕ del chip) o todos."""
    global documento_activo, imagen_activa, video_activo
    with _lock:
        for a in list(pendientes):
            if nombre is None or a["nombre"] == nombre:
                pendientes.remove(a)
                if documento_activo and documento_activo["nombre"] == a["nombre"]:
                    documento_activo = None
                if imagen_activa and imagen_activa["nombre"] == a["nombre"]:
                    imagen_activa = None
                if video_activo and video_activo["nombre"] == a["nombre"]:
                    video_activo = None


def hay_pendientes():
    return bool(pendientes)


def imagen_reciente():
    if imagen_activa and time.time() - imagen_activa["cuando"] < DURA_IMAGEN:
        return imagen_activa
    return None


def es_pedido_de_edicion(t):
    """¿Quiere que la imagen que pasó se use de base para una nueva? ('pasala a estilo anime')"""
    if not imagen_reciente() or not any(a["tipo"] == "imagen" for a in pendientes):
        return False
    return bool(EDITAR.search(t)) and not PREGUNTA.match(t)


def tomar_imagen_para_editar():
    with _lock:
        img = imagen_reciente()
        pendientes[:] = [a for a in pendientes if a["tipo"] != "imagen"]
    return img["ruta"] if img else None


def para_el_mensaje(pregunta):
    """Lo que hay que sumarle a la charla por los adjuntos y links.
    Devuelve (texto_para_el_sistema, imagenes_b64, nota_para_el_historial)."""
    global documento_activo, video_activo
    t = jarvis.normalizar(pregunta)
    with _lock:
        nuevos = list(pendientes)
        pendientes.clear()
    contexto, imagenes, notas = [], [], []
    ahora = time.time()

    _turno[0] += 1
    turno = _turno[0]
    for url in URL.findall(pregunta)[:2]:
        if jarvis.video.id_youtube(url):
            continue  # se mira más abajo, como video
        jarvis.emitir("detalle", f"Leyendo {jarvis.herramientas.dominio(url)}...")
        leido = jarvis.herramientas.leer_url(url.rstrip(".,;)»"))
        if leido.get("texto"):
            agregar_texto(leido["texto"], nombre=leido["titulo"], origen=url, aviso=leido.get("aviso", ""))
            nuevos.append({"tipo": "documento", "nombre": leido["titulo"], "pegado": True, "link": True})
            notas.append(f"[Leí el link: «{leido['titulo']}»]")
        else:
            contexto.append(f"El usuario te pasó el link {url}, pero no lo pudiste leer: {leido.get('error')}. Decíselo "
                            "así, tal cual, y no inventes lo que dice.")
            notas.append(f"[No pude leer {jarvis.herramientas.dominio(url)}]")
    nuevo_doc = any(a["tipo"] == "documento" for a in nuevos)
    doc = documento_vigente()
    nombra_texto = bool(EXPLICITO_DOC.search(t))
    pantalla_activa = jarvis.pantalla.activa()
    # "el texto de encimas": si el activo no es ese (o JARVIS se reinició), lo busca entre los textos guardados
    if nombra_texto and not nuevo_doc and (not doc or (doc.get("pegado") and not toca_el_texto(t, doc))):
        doc = recuperar_texto(t, solo_si_lo_nombra=pantalla_activa) or doc

    # Videos: el que adjuntaste o un link de YouTube en el mensaje
    nuevo_video = any(a["tipo"] == "video" for a in nuevos)
    vid = jarvis.video.id_youtube(pregunta)
    if vid:
        listo = threading.Event()
        listo.set()
        entrada = {"nombre": "video de YouTube", "cuando": ahora, "listo": listo, "datos": None, "error": None, "turnos": 0}
        try:
            entrada["datos"] = jarvis.video.analizar_youtube(vid)
            entrada["nombre"] = entrada["datos"]["nombre"]
        except Exception as e:
            entrada["error"] = str(e)
        video_activo, nuevo_video = entrada, True
    v = video_activo
    if v and ahora - v["cuando"] >= DURA_VIDEO and not nuevo_video:
        video_activo = v = None

    # ¿De cuál habla? Lo nuevo o lo que nombra (o algo que está en el texto: "la persona 4", "las enzimas")
    pide_doc = bool(doc) and (nuevo_doc or nombra_texto or toca_el_texto(t, doc))
    pide_video = bool(v) and (nuevo_video or bool(EXPLICITO_VIDEO.search(t)))
    if pide_doc and pide_video and not (nuevo_doc or nuevo_video):
        if nombra_texto and not EXPLICITO_VIDEO.search(t):
            pide_video = False  # "lo que dice la persona 4 del texto": el video no
        elif EXPLICITO_VIDEO.search(t) and not nombra_texto:
            pide_doc = False
    sigue_el_tema = bool(REFIERE_VIDEO.search(t) or REFIERE_DOC.search(t) or
                         re.search(r"\b(?:eso|esto|ese|esa|ahi|se trata|el que|la que|lo que|crees|parece)\b", t))
    # "resumilo", "leelo", "explicámelo": un verbo solo con "-lo/-la" habla de lo último que se usó
    solo_verbo = bool(re.match(r"^(?:y\s+)?(?:resumi|resume|lee|explica|traduci|traduce|analiza|revisa|corregi|"
                               r"mira|pasa)(?:lo|la|melo|mela|noslo)$", t.strip(" ¿?¡!.,")))
    if not pide_doc and not pide_video and ((len(t.split()) >= 3 and sigue_el_tema) or solo_verbo):
        # una pregunta que sigue la charla ("¿de qué juego se trata?"): lo último que se usó, si fue hace poco
        usados = [(x.get("usado", -99), cual) for x, cual in ((doc, "doc"), (v, "video")) if x]
        recientes = [u for u in usados if turno - u[0] <= 4]
        if recientes:
            ultimo = max(recientes)[1]
            pide_doc, pide_video = ultimo == "doc", ultimo == "video"
    # Compartiendo la pantalla, «el texto», «acá», «esos errores» son lo de la pantalla: un texto guardado entra solo si
    # lo acabás de pasar o nombrás su tema («el texto de enzimas»). (Antes «¿dónde están esos errores acá en el texto?»
    # contestó con un texto de enzimas de otro día, y el usuario estaba mirando su póster.)
    texto_de_la_pantalla = False
    if pantalla_activa and pide_doc and not nuevo_doc and not nombra_el_tema(t, doc):
        pide_doc, texto_de_la_pantalla = False, True
    # Compartiendo la pantalla y pregunta por ella ("¿qué estás viendo?", "¿qué hay en la pantalla?"): va la pantalla,
    # no el texto (antes describió "un laboratorio de enzimas" mezclando el texto pegado con la captura)
    por_pantalla = pantalla_activa and (bool(HABLA_DE_PANTALLA.search(t)) or texto_de_la_pantalla) and not (
        nuevo_doc or nuevo_video)
    if por_pantalla:
        pide_doc = pide_video = False
    # ¿Pidió el texto de verdad (lo nombró, lo acaba de pasar, "resumilo") o solo comparte alguna palabra con él?
    fuerte = nuevo_doc or nombra_texto or solo_verbo
    if pide_doc and not fuerte and (NO_ES_DEL_TEXTO.search(t) or jarvis.PIDE_LO_HABLADO.search(t)):
        pide_doc = False  # tus mails, tu agenda, "lo que hablamos": el texto no va
    incluidos.clear()

    if pide_doc:
        doc["cuando"], doc["usado"] = ahora, turno  # mientras sigas preguntando sobre él, no se vence
        incluidos.append("doc")
        quien = (f"El usuario te pasó el link {doc['origen']}, que es «{doc['nombre']}»" if doc.get("origen")
                 else f"El usuario te pegó un texto ({doc['nombre'].lower()})" if doc.get("pegado") else
                 f"El usuario te pasó el archivo «{doc['nombre']}»") + (f" ({doc['aviso']})" if doc.get("aviso") else "")
        partes = None if fuerte else partes_que_vienen_al_caso(t, doc)
        if partes:
            # solo comparte palabras con el texto: van los pedazos que vienen al caso y se sigue el tema de la charla
            # (antes iba el texto entero con "respondé usando su contenido" y, hablando de la pila, contestaba con los
            # materiales de la mini central hidroeléctrica, que era la primera opción del texto)
            contexto.append(quien + ". Estos son los pedazos de ese texto que pueden tener que ver con lo que pregunta "
                            "ahora: son solo de referencia. OJO: la pregunta sigue el tema de los últimos mensajes de la "
                            "charla; si venían hablando de una parte puntual (por ejemplo, una de las opciones del "
                            "texto), respondé sobre ESA parte y no cambies a otra. Respondé completo con lo que sabés: si "
                            "el texto no trae el dato (qué materiales concretos se usan, cuántos voltios da, cómo se "
                            "hace), dalo vos igual, sin decir «según el texto» ni ofrecer investigarlo."
                            f"\n<<<\n{partes}\n>>>")
        else:
            contexto.append(quien + ". Ya tenés su contenido completo acá abajo: no digas que lo vas a leer ni pidas un "
                            "momento. Respondé ya usando su contenido; si lo que pregunta no está ahí, decilo (no "
                            f"inventes). Contenido:\n<<<\n{doc['texto']}\n>>>")
        parte = seccion_del_texto(t, doc["texto"])
        if parte:  # "la persona 4": esa parte aparte, así el modelo chico no se confunde de sección
            contexto.append(f"La parte que pide ({parte[1]}), tal cual está en el texto:\n<<<\n{parte[0]}\n>>>")
    elif nombra_texto and not doc and not nuevo_video:
        contexto.append("El usuario habla de un texto o archivo que NO tenés guardado. Decile que no lo tenés y que "
                        "te lo vuelva a pegar o pasar. No inventes lo que dice.")
    if doc and not documento_vigente():
        documento_activo = None

    img = imagen_reciente()
    if img and (any(a["tipo"] == "imagen" for a in nuevos) or REFIERE_IMAGEN.search(t)) and not pide_doc:
        imagenes.append(img["b64"])
        incluidos.append("imagen")
        contexto.append(f"El usuario te pasó la imagen «{img['nombre']}» (la tenés adjunta en su mensaje): mirala y "
                        "respondé sobre lo que se ve de verdad. Si algo no se distingue, decilo.")

    if pide_video:
        if not v["listo"].is_set():
            jarvis.emitir("detalle", "Terminando de mirar el video...")
            v["listo"].wait(240)
        v["cuando"], v["usado"] = ahora, turno
        incluidos.append("video")
        if v.get("datos"):
            contexto.append(jarvis.video.contexto(v["datos"]))
            imagenes.extend(v["datos"]["imagenes"])
            if vid:
                notas.append(f"[Vi el video «{v['nombre']}»]")
        else:
            contexto.append(f"El usuario te pasó el video «{v['nombre']}», pero no lo pudiste ver "
                            f"({v.get('error') or 'tardó demasiado'}). Decíselo; no inventes lo que tiene.")

    # Pantalla compartida: si la pregunta es sobre lo que estás haciendo, mira cómo está la pantalla ahora
    if por_pantalla or (not pide_doc and not pide_video and jarvis.pantalla.corresponde(pregunta)):
        texto_pantalla, imagenes_pantalla = jarvis.pantalla.para_el_mensaje(t)
        if texto_pantalla:
            contexto.append(texto_pantalla)
            imagenes[:0] = imagenes_pantalla
            incluidos.append("pantalla")
        elif por_pantalla:  # todavía no llegó la primera imagen: mejor decirlo que inventar
            contexto.append("El usuario está compartiendo la pantalla, pero todavía no te llegó ninguna imagen de ella. "
                            "Decile que todavía no la ves y que pregunte de nuevo en unos segundos. No describas nada.")

    notas += [f"[Adjuntó {a['nombre']}]" for a in nuevos if not a.get("link")]
    return "\n\n".join(contexto), imagenes, " ".join(notas)
