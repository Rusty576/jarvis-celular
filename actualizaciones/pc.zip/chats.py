"""Las charlas de JARVIS, separadas (como en ChatGPT): así lo que hablaste de química no se mezcla con los mails.

- La charla actual está en historial.json (como siempre); las anteriores, en la carpeta chats/ (un archivo cada una).
- Si pasan más de 2 horas sin hablar, el próximo mensaje empieza una charla nueva solo (la anterior queda guardada, y
  el texto que le habías pegado deja de colarse en las respuestas).
- "nueva charla", "/nuevo", "/clear", "empecemos de cero" o el botón Chats -> NUEVA CHARLA: empezar una nueva.
- En el botón Chats ves las anteriores: tocás una y volvés a esa charla (con su contexto); también se pueden borrar.
- Los recuerdos, pendientes y recordatorios son los mismos en todas las charlas.
"""
import datetime
import os
import re
import threading
import time
import uuid

import disco

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(BASE, "chats")
ACTIVA = os.path.join(CARPETA, "activa.json")  # {id, titulo, creado, actualizado} de la charla actual
INDICE = os.path.join(CARPETA, "indice.json")  # las charlas guardadas (sin los mensajes, para listarlas rápido)
PAUSA_PARA_NUEVA = 2 * 3600  # sin hablar más que esto: el próximo mensaje empieza una charla nueva
_lock = threading.RLock()

NUEVA = re.compile(
    r"^/(?:nuevo|nueva|clear|limpiar|reset)$|"
    r"^(?:(?:che|jarvis|bueno|dale)[\s,]+)*(?:(?:empeza\w*|arranca\w*|abri|abre|crea|creame|hace|haceme|hagamos|"
    r"inicia\w*)\s+)?(?:una\s+|otra\s+)?(?:nueva\s+)?(?:charla|conversacion|chat)(?:\s+nuevo|\s+nueva)?"
    r"(?:\s+(?:de cero|desde cero|limpia))?$|"
    r"^(?:(?:che|jarvis)[\s,]+)?(?:empecemos|arranquemos|empezamos) (?:de nuevo|de cero|desde cero|otra vez)$|"
    r"^(?:(?:che|jarvis)[\s,]+)?(?:borra|limpia|resetea)\w*\s+(?:la |el |esta |este )?(?:charla|chat|conversacion)$")
VER = re.compile(r"\b(?:mis (?:charlas|chats|conversaciones)|(?:charlas|chats|conversaciones) (?:anteriores|viejas|guardadas)|"
                 r"que (?:charlas|chats) tengo)\b")


def _leer(ruta, defecto):
    return disco.leer(ruta, defecto)


def _escribir(ruta, datos):
    os.makedirs(CARPETA, exist_ok=True)
    disco.guardar(ruta, datos)


def _nueva_meta():
    ahora = time.time()
    return {"id": uuid.uuid4().hex[:10], "titulo": "", "creado": ahora, "actualizado": ahora}


def meta():
    """Los datos de la charla actual (la crea si no hay)."""
    with _lock:
        m = _leer(ACTIVA, None)
        if not m:
            m = _nueva_meta()
            _escribir(ACTIVA, m)
        return m


def titulo_de(mensajes):
    """El título: el primer pedido de la charla, corto ("Armame un quiz de enzimas")."""
    for m in mensajes:
        if m.get("role") == "user":
            t = re.sub(r"^(?:(?:che|jarvis|hola|bueno|dale|pa)[\s,!.]+)+", "", m["content"].strip(), flags=re.I)
            t = re.sub(r"\s+", " ", t).strip(" ¿?¡!.,")
            if len(t) >= 4 and not t.startswith("["):
                return (t[:1].upper() + t[1:])[:60] + ("…" if len(t) > 60 else "")
    return "Charla sin título"


def _cuando(segundos):
    d = datetime.datetime.fromtimestamp(segundos)
    hoy = datetime.date.today()
    if d.date() == hoy:
        return f"hoy {d:%H:%M}"
    if d.date() == hoy - datetime.timedelta(days=1):
        return f"ayer {d:%H:%M}"
    return f"{d:%d/%m %H:%M}"


def lista():
    """Las charlas: la actual primero y después las guardadas, de la más nueva a la más vieja."""
    with _lock:
        m = meta()
        actual = {"id": m["id"], "titulo": m["titulo"] or titulo_de(jarvis.historial) if jarvis else m["titulo"],
                  "actualizado": m["actualizado"], "mensajes": len(jarvis.historial) if jarvis else 0, "actual": True}
        guardadas = sorted(_leer(INDICE, []), key=lambda c: -c["actualizado"])
    salida = [actual] + [{**c, "actual": False} for c in guardadas]
    for c in salida:
        c["cuando"] = _cuando(c["actualizado"])
    return salida


def archivar():
    """Guarda la charla actual en chats/ (si tiene algo). La llama nueva() y abrir()."""
    if not jarvis.historial:
        return
    m = meta()
    titulo = m["titulo"] or titulo_de(jarvis.historial)
    _escribir(os.path.join(CARPETA, m["id"] + ".json"), {**m, "titulo": titulo, "mensajes": list(jarvis.historial)})
    indice = [c for c in _leer(INDICE, []) if c["id"] != m["id"]]
    indice.append({"id": m["id"], "titulo": titulo, "creado": m["creado"], "actualizado": m["actualizado"],
                   "mensajes": len(jarvis.historial)})
    _escribir(INDICE, indice)


def nueva(motivo="pedido"):
    """Empieza una charla nueva: la actual queda guardada, el contexto (y el texto pegado) se limpia."""
    with jarvis.lock, _lock:  # mismo orden que el resto de JARVIS (si no, se pueden trabar)
        archivar()
        jarvis.historial.clear()
        jarvis.guardar_historial_sin_tocar()
        _escribir(ACTIVA, _nueva_meta())
    try:
        jarvis.adjuntos.olvidar_documento()  # el texto o video de la charla anterior ya no entra en las respuestas
    except Exception:
        pass
    jarvis.emitir("chat_nuevo", {"motivo": motivo})


def tocar():
    """Después de cada mensaje: la charla actual se actualizó (y si no tenía título, se le pone)."""
    with _lock:
        m = meta()
        m["actualizado"] = time.time()
        if not m["titulo"] and jarvis and jarvis.historial:
            m["titulo"] = titulo_de(jarvis.historial)
        _escribir(ACTIVA, m)


def al_hablar():
    """Al llegar un mensaje: si pasaron más de 2 horas desde el último, empieza una charla nueva. True si lo hizo."""
    if jarvis.historial and time.time() - meta()["actualizado"] > PAUSA_PARA_NUEVA:
        nueva("pausa")
        return True
    return False


def abrir(id_):
    """Vuelve a una charla guardada: la actual se guarda y la elegida pasa a ser la actual (con su contexto)."""
    with jarvis.lock, _lock:  # mismo orden que el resto de JARVIS (si no, se pueden trabar)
        guardada = _leer(os.path.join(CARPETA, f"{id_}.json"), None) if re.fullmatch(r"[0-9a-f]{10}", str(id_)) else None
        if not guardada:
            return None
        archivar()
        jarvis.historial[:] = guardada["mensajes"]
        jarvis.guardar_historial_sin_tocar()
        _escribir(ACTIVA, {k: guardada[k] for k in ("id", "titulo", "creado", "actualizado")})
        os.remove(os.path.join(CARPETA, f"{id_}.json"))  # ahora es la actual (se vuelve a guardar al cambiar)
        _escribir(INDICE, [c for c in _leer(INDICE, []) if c["id"] != id_])
    try:
        jarvis.adjuntos.olvidar_documento()
    except Exception:
        pass
    datos = {"titulo": guardada["titulo"], "mensajes": guardada["mensajes"][-80:]}
    jarvis.emitir("chat_cargado", datos)
    return datos


def borrar(id_):
    """Borra una charla guardada (la actual no: para eso, empezá una nueva y borrá la anterior)."""
    if not re.fullmatch(r"[0-9a-f]{10}", str(id_)):
        return False
    with _lock:
        ruta = os.path.join(CARPETA, f"{id_}.json")
        if os.path.exists(ruta):
            os.remove(ruta)
        _escribir(INDICE, [c for c in _leer(INDICE, []) if c["id"] != id_])
    return True


def migrar():
    """La primera vez: lo que había en historial.json (todo junto y mezclado) queda guardado como una charla
    "hasta hoy", y se empieza una limpia."""
    if os.path.exists(ACTIVA):
        return
    if jarvis.historial:
        m = _nueva_meta()
        m["titulo"] = f"Charlas hasta el {datetime.date.today():%d/%m}"
        _escribir(ACTIVA, m)
        nueva("migracion")
    else:
        meta()


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    if NUEVA.match(t):
        if not jarvis.historial:
            return "Ya estamos en una charla nueva."
        nueva("pedido")
        return "Listo, empezamos una charla nueva. La anterior quedó guardada en Chats (el botón de arriba)."
    if VER.search(t):
        charlas = lista()[1:9]
        if not charlas:
            return "Todavía no tenés charlas guardadas: esta es la primera."
        jarvis.emitir("abrir_chats", True)
        return "Tus charlas anteriores:\n" + "\n".join(f"- {c['titulo']} ({c['cuando']})" for c in charlas) + \
               "\nTe abrí la lista: tocá una para volver a esa charla."
    return None
