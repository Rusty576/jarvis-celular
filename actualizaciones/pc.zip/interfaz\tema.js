// Modo oscuro: el negro de la píldora en toda la ventana. No es una copia aparte del CSS (se quedaría vieja cuando
// cambie estilo.css): toma estilo.css tal como está y pasa los azules oscuros a negros neutros. El celeste de los
// acentos (íconos, títulos, el reactor) queda, como los ojos de la píldora.

function colorOscuro(r, g, b, a) {
  // el celeste de JARVIS: fuerte se queda; suave (bordes, rellenos, la grilla) pasa a gris
  if (r === 41 && g === 217 && b === 255) return a <= 0.3 ? `rgba(255, 255, 255, ${(a * 0.45).toFixed(3)})` : null;
  // fondos azul oscuro -> negro / gris carbón
  if (b >= r && Math.max(r, g, b) < 80) {
    const l = Math.round(((r + g + b) / 3) * 0.6);
    return `rgba(${l}, ${l}, ${l + 1}, ${a})`;
  }
  // resplandores azulados del fondo -> un gris apenas visible
  if (r < 60 && b > 150 && g > 80 && g < 200) return `rgba(255, 255, 255, ${(a * 0.2).toFixed(3)})`;
  return null;
}

function pasarAOscuro(css) {
  css = css.replace(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+))?\s*\)/g, (todo, r, g, b, a) => {
    const nuevo = colorOscuro(+r, +g, +b, a === undefined ? 1 : +a);
    return nuevo || todo;
  });
  css = css.replace(/#([0-9a-f]{6})\b/gi, (todo, h) => {
    const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
    const nuevo = colorOscuro(r, g, b, 1);
    if (!nuevo) return todo;
    const [rr, gg, bb] = nuevo.match(/\d+/g).map(Number);
    return "#" + [rr, gg, bb].map((v) => v.toString(16).padStart(2, "0")).join("");
  });
  // los textos celestes pasan a blanco/gris (como en la píldora) y el fondo, a negro puro
  return css + `
:root {
  --fondo: #000000; --panel: rgba(14, 15, 17, 0.72); --panel-borde: rgba(255, 255, 255, 0.09);
  --texto: #eef3f6; --texto-2: #9aa4ab; --texto-3: #6b747b;
  --cian-tenue: rgba(255, 255, 255, 0.07); --cian-sutil: rgba(255, 255, 255, 0.035);
}
.scanlines { display: none; }
`;
}

let cssOscuro = null;

async function aplicarTema(tema) {
  let estilo = document.getElementById("tema-oscuro");
  if (tema !== "oscuro") {
    if (estilo) estilo.remove();
    document.body.classList.remove("oscuro");
    return;
  }
  if (!cssOscuro) {
    try {
      const r = await fetch("estilo.css", { cache: "no-store" });
      cssOscuro = pasarAOscuro(await r.text());
    } catch (e) {
      return;
    }
  }
  if (!estilo) {
    estilo = document.createElement("style");
    estilo.id = "tema-oscuro";
    document.head.appendChild(estilo);
  }
  estilo.textContent = cssOscuro;
  document.body.classList.add("oscuro");
}
