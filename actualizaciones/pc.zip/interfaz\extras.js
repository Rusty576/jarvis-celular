"use strict";
// Examen interactivo y red neuronal de la memoria (usa $, api, escapar y formatear de app.js)

// ======================= EXAMEN =======================
const LETRAS_OPCION = "ABCD";
const examen = { total: 0, bien: 0, respondida: false, ultima: false, indice: 0 };

function eventoExamen(d) {
  if (d.accion === "iniciar") abrirExamen(d);
  else if (d.accion === "pregunta") mostrarPreguntaExamen(d);
  else if (d.accion === "feedback") feedbackExamen(d);
  else if (d.accion === "pista") pistaExamen(d);
  else if (d.accion === "resultado") resultadoExamen(d);
  else if (d.accion === "reintentar") habilitarOpciones();
  else if (d.accion === "cerrar") cerrarExamen();
}

// Python no entendió la respuesta: se puede volver a elegir
function habilitarOpciones() {
  examen.respondida = false;
  document.querySelectorAll("#examen-opciones .opcion").forEach((b) => { b.disabled = false; b.classList.remove("elegida"); });
  $("examen-input").disabled = false;
}

function pintarMarcador() {
  $("examen-bien").innerHTML = `${examen.bien}<small>/${examen.total}</small>`;
}

function abrirExamen(d) {
  Object.assign(examen, { total: d.total, bien: 0, respondida: false, ultima: false, indice: 0 });
  $("examen-modo").textContent = (d.modo === "tarea" ? "TAREA INTERACTIVA" : "QUIZ")
    + (d.fuente ? " · DATOS DE " + d.fuente.toUpperCase() : "");
  $("examen-titulo").textContent = d.titulo;
  pintarMarcador();
  verPantallaExamen("pregunta");
}

// "pregunta" (con PISTA / SIGUIENTE) o "resultado" (con REPASAR / CERRAR)
function verPantallaExamen(cual) {
  const resultado = cual === "resultado";
  $("modal-examen").hidden = false;
  $("examen-cuerpo").hidden = resultado;
  $("botones-pregunta").hidden = resultado;
  $("examen-resultado").hidden = !resultado;
  $("botones-resultado").hidden = !resultado;
}

function mostrarPreguntaExamen(p) {
  verPantallaExamen("pregunta");
  Object.assign(examen, { respondida: false, ultima: false, indice: p.indice, tipo: p.tipo });
  $("examen-numero").textContent = `PREGUNTA ${p.indice + 1} DE ${p.total}`;
  $("examen-barra").style.width = (100 * p.indice / p.total) + "%";
  const enunciado = $("examen-enunciado");
  enunciado.innerHTML = formatear(p.enunciado);
  const caja = $("examen-opciones");
  caja.innerHTML = "";
  // como mucho A-D (si llegara algo de más, no se muestra un botón roto)
  p.opciones.slice(0, LETRAS_OPCION.length).forEach((texto, i) => {
    if (!String(texto || "").trim()) return;
    const letra = LETRAS_OPCION[i];
    const b = document.createElement("button");
    b.className = "opcion";
    b.style.animationDelay = (i * 60) + "ms";
    b.innerHTML = `<span class="letra">${letra}</span><span class="opcion-texto">${escapar(String(texto))}</span>`;
    b.onclick = () => elegirOpcion(b, letra.toLowerCase());
    caja.appendChild(b);
  });
  $("examen-scroll").scrollTop = 0;
  $("examen-corta").hidden = p.tipo !== "corta";
  if (p.tipo === "corta") {
    $("examen-input").value = "";
    $("examen-input").disabled = false;
    setTimeout(() => $("examen-input").focus(), 50);
  }
  $("examen-pista").hidden = true;
  $("examen-feedback").hidden = true;
  $("examen-boton-pista").disabled = false;
  const sig = $("examen-boton-siguiente");
  sig.disabled = true;
  sig.textContent = "SIGUIENTE →";
  // animación de entrada de la pregunta
  const cuerpo = $("examen-cuerpo");
  cuerpo.classList.remove("entra");
  void cuerpo.offsetWidth;
  cuerpo.classList.add("entra");
}

function elegirOpcion(boton, letra) {
  if (examen.respondida) return;
  examen.respondida = true;
  boton.classList.add("elegida");
  document.querySelectorAll("#examen-opciones .opcion").forEach((b) => (b.disabled = true));
  api("examen_responder", letra);
}

$("examen-corta").addEventListener("submit", (e) => {
  e.preventDefault();
  const valor = $("examen-input").value.trim();
  if (!valor || examen.respondida) return;
  examen.respondida = true;
  $("examen-input").disabled = true;
  api("examen_responder", valor);
});

function feedbackExamen(f) {
  examen.respondida = true;
  examen.ultima = f.ultima;
  if (f.correcta) {
    examen.bien++;
    pintarMarcador();
    $("examen-bien").classList.remove("salta");
    void $("examen-bien").offsetWidth;
    $("examen-bien").classList.add("salta");
  }
  document.querySelectorAll("#examen-opciones .opcion").forEach((b) => {
    b.disabled = true;
    const texto = b.lastElementChild.textContent;
    if (texto === f.respuesta_correcta) b.classList.add("correcta");
    else if (texto === f.respuesta && !f.correcta) b.classList.add("incorrecta");
  });
  $("examen-input").disabled = true;
  const caja = $("examen-feedback");
  caja.className = "examen-feedback " + (f.correcta ? "bien" : "mal");
  caja.innerHTML = (f.correcta ? "<b>✓ ¡Correcto!</b> " : `<b>✗ La respuesta era: ${escapar(f.respuesta_correcta)}</b><br>`)
    + (f.comentario ? escapar(f.comentario) + "<br>" : "") + formatear(f.explicacion || "");
  caja.hidden = false;
  if (f.correcta) chispas(caja);
  $("examen-boton-pista").disabled = true;
  const sig = $("examen-boton-siguiente");
  sig.disabled = false;
  sig.textContent = f.ultima ? "VER MI NOTA ★" : "SIGUIENTE →";
  sig.focus({ preventScroll: true });
  caja.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function pistaExamen(d) {
  const caja = $("examen-pista");
  caja.innerHTML = "💡 " + escapar(String(d.pista || "Pensalo con calma: releé la pregunta."));
  caja.hidden = false;
  caja.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function accionExamen(accion) {
  if (accion === "siguiente" && examen.ultima) accion = "terminar";
  if (accion === "terminar" && !$("examen-resultado").hidden) return cerrarExamen();
  api("examen_accion", accion);
}

function resultadoExamen(r) {
  verPantallaExamen("resultado");
  $("examen-scroll").scrollTop = 0;
  Object.assign(examen, { bien: r.bien, total: r.total });
  pintarMarcador();
  $("examen-barra").style.width = "100%";
  const arco = $("resultado-arco");
  const largo = 2 * Math.PI * 52;
  arco.style.strokeDasharray = largo;
  arco.style.strokeDashoffset = largo;
  arco.classList.toggle("baja", r.porcentaje < 50);
  requestAnimationFrame(() => { arco.style.strokeDashoffset = largo * (1 - r.porcentaje / 100); });
  // la nota sube de a poco
  let n = 0;
  const nota = $("resultado-nota");
  const intervalo = setInterval(() => {
    nota.textContent = ++n;
    if (n >= r.nota) clearInterval(intervalo);
  }, 900 / Math.max(r.nota, 1));
  $("resultado-texto").innerHTML = `<b>${r.bien} de ${r.total}</b> correctas · ${r.porcentaje}% · ${r.minutos} min`;
  $("resultado-errores").innerHTML = r.errores.length
    ? "<div class='errores-titulo'>PARA REPASAR</div>" + r.errores.map((e) =>
      `<div class="error-item"><div class="error-pregunta">${escapar(e.enunciado)}</div>
       <div>Tu respuesta: <span class="rojo">${escapar(e.tu_respuesta)}</span> · Correcta: <span class="verde">${escapar(e.correcta)}</span></div>
       <div class="error-explicacion">${escapar(e.explicacion)}</div></div>`).join("")
    : "<div class='perfecto'>¡Sin errores! 🎉</div>";
  $("boton-repasar").hidden = !r.errores.length;
  if (r.porcentaje >= 70) chispas($("examen-resultado"), 40);
}

function cerrarExamen() {
  $("modal-examen").hidden = true;
}

// chispas de festejo (animación liviana con CSS)
function chispas(elemento, cantidad = 16) {
  const r = elemento.getBoundingClientRect();
  for (let i = 0; i < cantidad; i++) {
    const c = document.createElement("i");
    c.className = "chispa";
    c.style.left = (r.left + r.width / 2) + "px";
    c.style.top = (r.top + 20) + "px";
    const angulo = Math.random() * Math.PI * 2, distancia = 60 + Math.random() * 120;
    c.style.setProperty("--dx", Math.cos(angulo) * distancia + "px");
    c.style.setProperty("--dy", Math.sin(angulo) * distancia - 40 + "px");
    c.style.background = ["#4dffb8", "#29d9ff", "#ffd34d", "#ff7aa8"][i % 4];
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 1100);
  }
}

document.addEventListener("keydown", (e) => {
  if ($("modal-examen").hidden || document.activeElement === $("examen-input")) return;
  const tecla = e.key.toLowerCase();
  const i = "abcd1234".indexOf(tecla) % 4;
  if ("abcd1234".includes(tecla) && tecla.length === 1) {
    const b = document.querySelectorAll("#examen-opciones .opcion")[i];
    if (b && !b.disabled) { e.preventDefault(); e.stopPropagation(); b.click(); }
  } else if (e.key === "Enter" && !$("examen-boton-siguiente").disabled) {
    e.preventDefault(); accionExamen("siguiente");
  }
}, true);

// ======================= MEMORIA: RED NEURONAL =======================
const COLOR_CATEGORIA = {
  datos: "#29d9ff", personas: "#ff7aa8", estudio: "#7ab8ff", gustos: "#4dffb8", salud: "#ff8a6a", otros: "#b8c4d0",
  instrucciones: "#c58bff",
};
let red = null;

async function abrirMemoria() {
  const d = await api("memoria_datos");
  if (!d) return;
  $("modal-memoria").hidden = false;
  const aprendidos = d.recuerdos.filter((r) => r.auto).length;
  $("memoria-resumen").innerHTML = `<b>${d.recuerdos.length}</b> recuerdos · <b>${aprendidos}</b> aprendidos solos · `
    + `<b>${d.en_observacion}</b> para revisar`;
  red = construirRed(d);
  mostrarDetalle(null);
  requestAnimationFrame(dibujarRed);
  memoriaDatos = d;
  if (typeof pintarPestanaMemoria === "function") pintarPestanaMemoria();
}
let memoriaDatos = null;

function cerrarMemoria() {
  $("modal-memoria").hidden = true;
  red = null;
}

function construirRed(d) {
  const nodos = [{ id: "centro", tipo: "centro", texto: "VOS", color: "#ffffff", ax: 0, ay: 0, r: 22, fase: 0 }];
  const aristas = [];
  const categorias = Object.keys(d.categorias).filter((c) => d.recuerdos.some((r) => r.categoria === c));
  const lista = categorias.length ? categorias : Object.keys(d.categorias);
  lista.forEach((cat, i) => {
    const ang = -Math.PI / 2 + (i / lista.length) * Math.PI * 2;
    const nodoCat = { id: "cat-" + cat, tipo: "categoria", cat, texto: d.categorias[cat], color: COLOR_CATEGORIA[cat],
                      ax: Math.cos(ang) * 0.33, ay: Math.sin(ang) * 0.33, r: 13, fase: Math.random() * 6 };
    nodos.push(nodoCat);
    const propios = d.recuerdos.filter((r) => r.categoria === cat);
    propios.forEach((rec, j) => {  // los recuerdos, en abanico alrededor de su categoría
      const abanico = Math.min(1.5, 0.35 * propios.length);
      const a2 = ang + (propios.length > 1 ? (j / (propios.length - 1) - 0.5) * abanico : 0);
      const dist = 0.62 + (j % 2) * 0.12;
      nodos.push({ id: rec.id, tipo: "recuerdo", rec, texto: rec.texto, color: rec.auto ? "#ffb547" : COLOR_CATEGORIA[cat],
                   ax: Math.cos(a2) * dist, ay: Math.sin(a2) * dist, r: 7, fase: Math.random() * 6 });
    });
  });
  // lo que está en observación (lo dijiste una vez): puntos punteados en el borde, sin conexión hasta que lo guardes
  const cands = d.candidatos || [];
  cands.forEach((cand, k) => {
    const a3 = -Math.PI / 2 + ((k + 0.5) / cands.length) * Math.PI * 2;
    nodos.push({ id: "cand-" + k, tipo: "candidato", cand, texto: cand.texto, color: "#8fa3b3",
                 ax: Math.cos(a3) * 0.93, ay: Math.sin(a3) * 0.93, r: 5, fase: Math.random() * 6 });
  });
  // conexiones: VOS -> categorías -> recuerdos
  nodos.forEach((n, i) => {
    if (n.tipo === "categoria") aristas.push([0, i]);
    if (n.tipo === "recuerdo") aristas.push([nodos.findIndex((m) => m.tipo === "categoria" && m.cat === n.rec.categoria), i]);
  });
  // conexiones "neuronales" entre recuerdos que comparten palabras (adorno con sentido)
  const palabras = (t) => new Set(t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
    .split(/[^a-z0-9]+/).filter((p) => p.length > 4).map((p) => p.slice(0, 5)));
  const recs = nodos.map((n, i) => [n, i]).filter(([n]) => n.tipo === "recuerdo");
  recs.forEach(([a, i], k) => recs.slice(k + 1).forEach(([b, j]) => {
    const pa = palabras(a.texto);
    if ([...palabras(b.texto)].some((p) => pa.has(p))) aristas.push([i, j, true]);
  }));
  return { nodos, aristas, pulsos: [], sobre: null, elegido: null };
}

function posicionNodo(n, w, h, t) {
  const escala = Math.min(w, h) * 0.5 * 0.9;
  const flota = n.tipo === "centro" ? 0 : 4;
  return [w / 2 + n.ax * escala + Math.sin(t * 0.8 + n.fase) * flota,
          h / 2 + n.ay * escala + Math.cos(t * 0.6 + n.fase) * flota];
}

function dibujarRed(ms) {
  if (!red || $("modal-memoria").hidden) return;
  requestAnimationFrame(dibujarRed);
  const lienzoRed = $("red-memoria");
  const caja = lienzoRed.getBoundingClientRect();
  const dprR = window.devicePixelRatio || 1;
  if (lienzoRed.width !== Math.round(caja.width * dprR)) {
    lienzoRed.width = Math.round(caja.width * dprR);
    lienzoRed.height = Math.round(caja.height * dprR);
  }
  const c = lienzoRed.getContext("2d");
  const w = caja.width, h = caja.height, t = ms / 1000;
  c.setTransform(dprR, 0, 0, dprR, 0, 0);
  c.clearRect(0, 0, w, h);
  const pos = red.nodos.map((n) => posicionNodo(n, w, h, t));

  // aristas
  red.aristas.forEach(([a, b, cruzada]) => {
    const [x1, y1] = pos[a], [x2, y2] = pos[b];
    const activa = red.elegido !== null && (a === red.elegido || b === red.elegido);
    c.beginPath();
    if (cruzada) {  // curvas finas entre recuerdos relacionados
      c.moveTo(x1, y1);
      c.quadraticCurveTo(w / 2, h / 2, x2, y2);
      c.strokeStyle = activa ? "rgba(255,181,71,0.6)" : "rgba(255,181,71,0.13)";
      c.lineWidth = 1;
    } else {
      c.moveTo(x1, y1);
      c.lineTo(x2, y2);
      c.strokeStyle = activa ? "rgba(122,233,255,0.85)" : "rgba(41,217,255,0.22)";
      c.lineWidth = activa ? 2 : 1.2;
    }
    c.stroke();
  });

  // impulsos que viajan por las conexiones (como sinapsis)
  if (Math.random() < 0.12 && red.aristas.length) {
    red.pulsos.push({ arista: red.aristas[Math.floor(Math.random() * red.aristas.length)], p: 0, v: 0.6 + Math.random() * 0.8 });
  }
  red.pulsos = red.pulsos.filter((pu) => (pu.p += pu.v / 60) < 1);
  red.pulsos.forEach((pu) => {
    const [a, b, cruzada] = pu.arista;
    const [x1, y1] = pos[a], [x2, y2] = pos[b];
    let x, y;
    if (cruzada) {
      const q = pu.p, cx = w / 2, cy = h / 2;
      x = (1 - q) * (1 - q) * x1 + 2 * (1 - q) * q * cx + q * q * x2;
      y = (1 - q) * (1 - q) * y1 + 2 * (1 - q) * q * cy + q * q * y2;
    } else {
      x = x1 + (x2 - x1) * pu.p;
      y = y1 + (y2 - y1) * pu.p;
    }
    c.beginPath();
    c.arc(x, y, 2.4, 0, Math.PI * 2);
    c.fillStyle = cruzada ? "rgba(255,200,110,0.95)" : "rgba(170,240,255,0.95)";
    c.shadowBlur = 10;
    c.shadowColor = c.fillStyle;
    c.fill();
    c.shadowBlur = 0;
  });

  // nodos
  red.nodos.forEach((n, i) => {
    const [x, y] = pos[i];
    const resaltado = i === red.sobre || i === red.elegido;
    const latido = n.tipo === "centro" ? 1 + 0.06 * Math.sin(t * 2.2) : 1;
    const radio = n.r * latido * (resaltado ? 1.35 : 1);
    const brillo = c.createRadialGradient(x, y, 0, x, y, radio * 2.6);
    brillo.addColorStop(0, n.color + "aa");
    brillo.addColorStop(1, n.color + "00");
    c.fillStyle = brillo;
    c.beginPath();
    c.arc(x, y, radio * 2.6, 0, Math.PI * 2);
    c.fill();
    c.beginPath();
    c.arc(x, y, radio, 0, Math.PI * 2);
    c.fillStyle = n.tipo === "recuerdo" || n.tipo === "candidato" ? "#06121c" : n.color;
    c.fill();
    c.lineWidth = resaltado ? 2.5 : 1.6;
    c.strokeStyle = n.color;
    if (n.tipo === "candidato") c.setLineDash([2, 3]);
    c.stroke();
    c.setLineDash([]);
    if (n.tipo === "candidato") {
      if (resaltado) {
        c.font = "600 13px Rajdhani, sans-serif";
        c.textAlign = "center";
        c.fillStyle = "#b8c4d0";
        const corto = n.texto.length > 38 ? n.texto.slice(0, 36) + "…" : n.texto;
        c.fillText(corto + " (¿lo guardo?)", x, y - radio - 9);
      }
    } else if (n.tipo === "centro") {
      c.font = "700 12px Orbitron, sans-serif";
      c.textAlign = "center";
      c.fillStyle = "#02121c";
      c.fillText("VOS", x, y + 4);
    } else if (n.tipo !== "recuerdo") {
      // al costado de la línea (los recuerdos salen hacia afuera, en abanico: así el nombre no queda debajo de ellos)
      const horizontal = Math.abs(n.ax) > Math.abs(n.ay);
      c.font = "600 11px Orbitron, sans-serif";
      c.textAlign = horizontal ? "center" : "left";
      c.fillStyle = "#d4f3ff";
      c.fillText(n.texto.toUpperCase(), horizontal ? x : x + radio + 8, horizontal ? y + radio + 16 : y + 4);
    } else if (resaltado) {
      c.font = "600 13px Rajdhani, sans-serif";
      c.textAlign = "center";
      c.fillStyle = "#d4f3ff";
      const corto = n.texto.length > 38 ? n.texto.slice(0, 36) + "…" : n.texto;
      c.fillText(corto, x, y - radio - 9);
    }
  });
  red.pos = pos;
}

function nodoEn(evento) {
  if (!red || !red.pos) return null;
  const caja = $("red-memoria").getBoundingClientRect();
  const x = evento.clientX - caja.left, y = evento.clientY - caja.top;
  let mejor = null, distMejor = 1e9;
  red.pos.forEach(([nx, ny], i) => {
    const d = Math.hypot(nx - x, ny - y);
    if (d < red.nodos[i].r + 10 && d < distMejor) { mejor = i; distMejor = d; }
  });
  return mejor;
}

$("red-memoria").addEventListener("mousemove", (e) => {
  if (!red) return;
  red.sobre = nodoEn(e);
  $("red-memoria").style.cursor = red.sobre !== null ? "pointer" : "default";
});

$("red-memoria").addEventListener("click", (e) => {
  if (!red) return;
  red.elegido = nodoEn(e);
  mostrarDetalle(red.elegido !== null ? red.nodos[red.elegido] : null);
});

let olvidoArmado = null;
function mostrarDetalle(n) {
  const caja = $("memoria-detalle");
  olvidoArmado = null;
  if (!n || n.tipo === "centro") {
    caja.innerHTML = `<div class="memoria-ayuda">Tocá un nodo para ver el recuerdo.<br><br>
      <span class="leyenda-punto"></span> Lo que me pediste recordar<br>
      <span class="leyenda-punto auto"></span> Lo que aprendí solo (lo dijiste en varias charlas)<br>
      <span class="leyenda-punto candidato"></span> Lo que dijiste una vez: ¿lo guardo?<br><br>
      Para que recuerde algo: «recordá que...». Para olvidar: tocá el recuerdo y «Olvidar».</div>`;
    return;
  }
  if (n.tipo === "candidato") {
    const k = n.cand;
    caja.innerHTML = `<div class="detalle-cat" style="color:#b8c4d0">PARA REVISAR</div>
      <div class="detalle-texto">${escapar(k.texto)}</div>
      <div class="detalle-meta">Lo dijiste ${k.veces === 1 ? "una vez" : k.veces + " veces"}${k.fecha ? " · desde " + escapar(k.fecha) : ""}. Todavía no lo uso en las charlas.</div>
      <div class="detalle-botones"><button class="boton-confirmar" id="cand-si">GUARDAR</button>
      <button class="boton-olvidar" id="cand-no">NO LO GUARDES</button></div>`;
    $("cand-si").onclick = async () => { await api("memoria_candidato", k.texto, true); abrirMemoria(); };
    $("cand-no").onclick = async () => { await api("memoria_candidato", k.texto, false); abrirMemoria(); };
    return;
  }
  if (n.tipo === "categoria") {
    const hijos = red.nodos.filter((m) => m.tipo === "recuerdo" && m.rec.categoria === n.cat);
    caja.innerHTML = `<div class="detalle-cat" style="color:${n.color}">${escapar(n.texto.toUpperCase())}</div>`
      + hijos.map((m) => `<div class="detalle-item">${m.rec.auto ? "★ " : ""}${escapar(m.texto)}</div>`).join("");
    return;
  }
  const r = n.rec;
  caja.innerHTML = `<div class="detalle-cat" style="color:${COLOR_CATEGORIA[r.categoria]}">${escapar((red.nodos.find((m) => m.cat === r.categoria) || {}).texto || r.categoria).toUpperCase()}</div>
    <div class="detalle-texto">${escapar(r.texto)}</div>
    <div class="detalle-meta">${r.auto ? "<span class='aprendido'>★ Lo aprendí solo</span> · " : r.confianza === "confirmado" ? "✓ Confirmado por vos · " : ""}Desde ${escapar(r.fecha || "")}</div>
    ${r.auto ? '<button class="boton-confirmar" id="boton-confirmar">SÍ, ES ASÍ</button>' : ""}
    <button class="boton-olvidar" id="boton-olvidar">OLVIDAR ESTE RECUERDO</button>`;
  if (r.auto) $("boton-confirmar").onclick = async () => { await api("memoria_confirmar", r.id); abrirMemoria(); };
  $("boton-olvidar").onclick = async () => {
    if (olvidoArmado !== r.id) {
      olvidoArmado = r.id;
      $("boton-olvidar").textContent = "TOCÁ OTRA VEZ PARA CONFIRMAR";
      $("boton-olvidar").classList.add("armado");
      return;
    }
    await api("memoria_olvidar", r.id);
    abrirMemoria();
  };
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !$("modal-memoria").hidden) { e.stopPropagation(); cerrarMemoria(); }
}, true);

// ======================= ARCHIVOS E IMÁGENES PARA JARVIS =======================
// Se arrastran a la ventana, se pegan con Ctrl+V o se suben con el clip. Quedan como "chips" arriba del campo de
// texto y van con el próximo mensaje ("resumilo", "¿qué ves?", "armame un quiz con esto", "pasala a estilo anime").
const MAX_MB_ADJUNTO = 25;
const adjuntosPendientes = []; // {nombre, tipo, miniatura, subiendo}

function pintarAdjuntos() {
  const caja = $("adjuntos");
  caja.hidden = !adjuntosPendientes.length;
  caja.innerHTML = adjuntosPendientes.map((a, i) => `
    <div class="adjunto ${a.subiendo ? "subiendo" : ""}">
      ${a.miniatura ? `<img src="${a.miniatura}" alt="">` : `<span class="adjunto-icono">${a.tipo === "imagen" ? "◈" : a.tipo === "video" ? "🎬" : "📄"}</span>`}
      <span class="adjunto-nombre">${escapar(a.nombre)}</span>
      ${a.subiendo ? '<span class="adjunto-estado">leyendo...</span>' : `<button type="button" title="Quitar" onclick="quitarAdjunto(${i})">✕</button>`}
    </div>`).join("");
  const hayImagen = adjuntosPendientes.some((a) => a.tipo === "imagen");
  const hayVideo = adjuntosPendientes.some((a) => a.tipo === "video");
  entrada.placeholder = !adjuntosPendientes.length ? "Escribí una orden..."
    : hayVideo ? "¿Qué querés saber del video? (Enter = resumilo)"
    : hayImagen ? "¿Qué hago con la imagen? (Enter = qué ves)"
    : "¿Qué hago con el archivo? (Enter = resumilo)";
}

function quitarAdjunto(i) {
  const [a] = adjuntosPendientes.splice(i, 1);
  if (a) api("quitar_adjunto", a.nombre);
  pintarAdjuntos();
}

const esVideo = (archivo) => archivo.type.startsWith("video/") || /\.(mp4|mkv|avi|mov|webm|wmv|m4v|flv|mpe?g|3gp)$/i.test(archivo.name);

// Python avisa cuando un video (o lo elegido con el clip) ya quedó adjunto
function adjuntoListo(info) {
  const p = info.original ? adjuntosPendientes.find((a) => a.subiendo && a.original === info.original) : null;
  if (!info.ok) {
    if (p) adjuntosPendientes.splice(adjuntosPendientes.indexOf(p), 1);
    lineaSistema(info.error || "No pude abrir ese archivo.");
  } else if (p) {
    Object.assign(p, { nombre: info.nombre, tipo: info.tipo, miniatura: info.miniatura, subiendo: false, original: null });
  } else {
    adjuntosPendientes.push({ nombre: info.nombre, tipo: info.tipo, miniatura: info.miniatura });
  }
  if (info.ok && info.aviso) lineaSistema(`${info.nombre}: ${info.aviso}.`);
  pintarAdjuntos();
  entrada.focus();
}

// El clip: el selector de Windows (los videos grandes no pasan enteros por acá); si no se puede, el de la página
async function elegirArchivos() {
  const lista = await api("elegir_archivos");
  if (!Array.isArray(lista)) { $("archivo-input").click(); return; }
  lista.forEach(adjuntoListo);
}

function subirArchivos(lista, desdeSoltar = false) {
  for (const archivo of lista) {
    if (desdeSoltar && esVideo(archivo)) {
      // al soltarlo, Python recibe la ruta real del video (adjuntoListo); si en unos segundos no llegó, lo sube acá
      const espera = { nombre: archivo.name, original: archivo.name, tipo: "video", subiendo: true };
      adjuntosPendientes.push(espera);
      pintarAdjuntos();
      setTimeout(() => {
        if (!espera.subiendo || !adjuntosPendientes.includes(espera)) return;
        adjuntosPendientes.splice(adjuntosPendientes.indexOf(espera), 1);
        pintarAdjuntos();
        subirArchivos([archivo]);
      }, 6000);
      continue;
    }
    if (archivo.size > MAX_MB_ADJUNTO * 1024 * 1024) {
      lineaSistema(`${archivo.name} es muy grande (más de ${MAX_MB_ADJUNTO} MB).`);
      continue;
    }
    const pendiente = { nombre: archivo.name, tipo: archivo.type.startsWith("image/") ? "imagen" : esVideo(archivo) ? "video" : "documento", subiendo: true };
    adjuntosPendientes.push(pendiente);
    pintarAdjuntos();
    const lector = new FileReader();
    lector.onload = async () => {
      const info = await api("adjuntar", archivo.name, lector.result);
      const i = adjuntosPendientes.indexOf(pendiente);
      if (!info || !info.ok) {
        if (i >= 0) adjuntosPendientes.splice(i, 1);
        lineaSistema(info ? info.error : "No pude pasarle el archivo a JARVIS.");
      } else if (i >= 0) {
        Object.assign(pendiente, { nombre: info.nombre, tipo: info.tipo, miniatura: info.miniatura, subiendo: false });
        if (info.aviso) lineaSistema(`${info.nombre}: ${info.aviso}.`);
      }
      pintarAdjuntos();
      entrada.focus();
    };
    lector.onerror = () => { adjuntosPendientes.splice(adjuntosPendientes.indexOf(pendiente), 1); pintarAdjuntos(); };
    lector.readAsDataURL(archivo);
  }
}

// Al mandar: si no escribiste nada se usa un pedido por defecto, y los chips pasan al mensaje del chat
function tomarAdjuntos(texto) {
  const listos = adjuntosPendientes.filter((a) => !a.subiendo);
  if (!listos.length) return { texto, html: "" };
  if (!texto.trim()) {
    texto = listos.some((a) => a.tipo === "video") ? "Resumime este video."
      : listos.some((a) => a.tipo === "imagen") ? "¿Qué ves en esta imagen?" : "Resumime este archivo.";
  }
  const html = `<div class="msg-adjuntos">${listos.map((a) => a.miniatura
    ? `<img src="${a.miniatura}" alt="${escapar(a.nombre)}">`
    : `<span>📄 ${escapar(a.nombre)}</span>`).join("")}</div>`;
  adjuntosPendientes.splice(0, adjuntosPendientes.length, ...adjuntosPendientes.filter((a) => a.subiendo));
  pintarAdjuntos();
  return { texto, html };
}

$("archivo-input").addEventListener("change", (e) => { subirArchivos([...e.target.files]); e.target.value = ""; });

// Arrastrar y soltar en cualquier parte de la ventana
let arrastres = 0;
const conArchivos = (e) => e.dataTransfer && [...e.dataTransfer.types].includes("Files");
window.addEventListener("dragenter", (e) => { if (!conArchivos(e)) return; e.preventDefault(); arrastres++; $("soltar").hidden = false; });
window.addEventListener("dragover", (e) => { if (!conArchivos(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = "copy"; });
window.addEventListener("dragleave", (e) => { if (!conArchivos(e)) return; if (--arrastres <= 0) { arrastres = 0; $("soltar").hidden = true; } });
window.addEventListener("drop", (e) => {
  if (!conArchivos(e)) return;
  e.preventDefault();
  arrastres = 0;
  $("soltar").hidden = true;
  subirArchivos([...e.dataTransfer.files], true);
});
// Pegar una imagen con Ctrl+V (por ejemplo una captura de pantalla)
document.addEventListener("paste", (e) => {
  const archivos = [...((e.clipboardData && e.clipboardData.files) || [])];
  if (archivos.length) { e.preventDefault(); subirArchivos(archivos); }
});
