"""Leer y guardar los archivos de datos de JARVIS (recordatorios, pendientes, contactos, rutinas, recuerdos, charlas...)
sin perderlos nunca.

Antes, si un archivo no se podía leer, cada módulo seguía como si estuviera vacío, y lo próximo que se guardaba lo
pisaba: se perdía todo, sin aviso. Pasa de verdad:
  - un corte de luz a mitad de guardar deja el JSON cortado (dañado);
  - la carpeta está en OneDrive: mientras sincroniza, un archivo puede quedar tomado un momento (no se puede leer).
Ahora:
  - dañado: se aparta tal cual («recordatorios.json.roto-2026-10-31_1530»: nunca se borra ni se pisa) y se sigue
    con la lista vacía. El chequeo del sistema lo cuenta;
  - no se pudo leer (tomado, sin permiso): se reintenta un momento; si sigue igual, se devuelve vacío PERO ese archivo
    queda marcado y guardar() no lo pisa (lanza ArchivoOcupado) hasta que se pueda leer de nuevo;
  - guardar() escribe entero o nada (un archivo aparte que reemplaza al original).
"""
import json
import os
import threading
import time

_lock = threading.Lock()
_sin_leer = set()      # los que no se pudieron leer (no se pisan)
apartados = []         # [(original, apartado)]: los dañados que se guardaron aparte (para el chequeo del sistema)


class ArchivoOcupado(OSError):
    """No se pudo leer el archivo: guardar encima borraría lo que tiene."""


def _apartar(ruta):
    destino = base = f"{ruta}.roto-{time.strftime('%Y-%m-%d_%H%M%S')}"
    n = 1
    while os.path.exists(destino):   # (otro apartado en el mismo segundo: no se pisa)
        n += 1
        destino = f"{base}-{n}"
    try:
        os.replace(ruta, destino)
    except OSError:
        return None
    apartados.append((ruta, destino))
    return destino


def leer(ruta, vacio):
    """Lo que tiene el archivo JSON. Si no existe, vacio. Dañado: se aparta y vacio. Ocupado: vacio, y no se pisa."""
    for intento in range(3):
        try:
            with open(ruta, encoding="utf-8") as f:
                datos = json.load(f)
            with _lock:
                _sin_leer.discard(ruta)
            if vacio is not None and type(datos) is not type(vacio):   # (otra cosa: una lista donde va un diccionario)
                raise ValueError("no es lo que se esperaba")
            return datos
        except FileNotFoundError:
            with _lock:
                _sin_leer.discard(ruta)
            return _copia(vacio)
        except ValueError:   # (JSON cortado o con basura, o letras que no son UTF-8)
            with _lock:
                _sin_leer.discard(ruta)
                _apartar(ruta)
            return _copia(vacio)
        except OSError:      # tomado (OneDrive, el antivirus) o sin permiso: se espera un poco
            if intento < 2:
                time.sleep(0.3 * (intento + 1))
    with _lock:
        _sin_leer.add(ruta)
    return _copia(vacio)


def guardar(ruta, datos, indent=1):
    """Lo escribe entero o nada. Si la última vez no se pudo leer, primero se fija si ahora sí: si no, ArchivoOcupado."""
    with _lock:
        bloqueado = ruta in _sin_leer
    if bloqueado:
        try:
            with open(ruta, encoding="utf-8") as f:
                json.load(f)
        except FileNotFoundError:
            pass
        except (OSError, ValueError):
            raise ArchivoOcupado(f"no pude leer «{os.path.basename(ruta)}» y no lo quiero pisar")
        # se puede leer de nuevo, pero lo que se iba a guardar se armó sin él: tampoco se pisa (que se vuelva a pedir)
        with _lock:
            _sin_leer.discard(ruta)
        raise ArchivoOcupado(f"«{os.path.basename(ruta)}» recién se pudo leer: probá de nuevo")
    carpeta = os.path.dirname(ruta)
    if carpeta:
        os.makedirs(carpeta, exist_ok=True)
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=indent)
        f.flush()
        os.fsync(f.fileno())
    for intento in range(3):
        try:
            os.replace(tmp, ruta)
            return
        except PermissionError:   # (tomado justo en ese momento)
            if intento == 2:
                raise
            time.sleep(0.3 * (intento + 1))


def _copia(vacio):
    return json.loads(json.dumps(vacio)) if vacio is not None else None


def resumen():
    """Para el chequeo del sistema: lo que se apartó por dañado, y lo que no se pudo leer."""
    lineas = []
    for original, apartado in apartados[-5:]:
        lineas.append(f"«{os.path.basename(original)}» estaba dañado: lo guardé aparte como «{os.path.basename(apartado)}»")
    with _lock:
        for ruta in sorted(_sin_leer):
            lineas.append(f"«{os.path.basename(ruta)}» no se pudo leer (¿OneDrive lo tiene tomado?): no lo toco hasta poder")
    return lineas
