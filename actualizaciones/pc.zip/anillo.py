"""Marca un lugar de la pantalla con un anillo celeste que titila unos segundos ("¿dónde está el botón X?").

Uso: pythonw anillo.py izquierda arriba derecha abajo   (en píxeles reales de la pantalla)
"""
import ctypes
import sys
import tkinter as tk

ctypes.windll.shcore.SetProcessDpiAwareness(2)  # las coordenadas vienen en píxeles reales

izq, arr, der, aba = (int(v) for v in sys.argv[1:5])
MARGEN, GROSOR, TRANSPARENTE = 10, 5, "#010203"

ventana = tk.Tk()
ventana.overrideredirect(True)
ventana.attributes("-topmost", True)
ventana.attributes("-transparentcolor", TRANSPARENTE)
ancho, alto = der - izq + 2 * MARGEN, aba - arr + 2 * MARGEN
ventana.geometry(f"{ancho}x{alto}+{izq - MARGEN}+{arr - MARGEN}")
lienzo = tk.Canvas(ventana, width=ancho, height=alto, bg=TRANSPARENTE, highlightthickness=0)
lienzo.pack()
anillo = lienzo.create_oval(GROSOR, GROSOR, ancho - GROSOR, alto - GROSOR, outline="#29d9ff", width=GROSOR)

# que el anillo no ataje los clics (pasan a la ventana de abajo)
ventana.update_idletasks()
hwnd = ctypes.windll.user32.GetParent(ventana.winfo_id())
estilo = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
ctypes.windll.user32.SetWindowLongW(hwnd, -20, estilo | 0x80000 | 0x20)  # WS_EX_LAYERED | WS_EX_TRANSPARENT


def titilar(vez=0):
    if vez >= 8:
        ventana.destroy()
        return
    lienzo.itemconfigure(anillo, outline="#29d9ff" if vez % 2 == 0 else "#ffffff")
    ventana.after(400, titilar, vez + 1)


titilar()
ventana.mainloop()
