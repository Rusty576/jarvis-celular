# Seguridad y privacidad de JARVIS

## Qué queda en tu PC (y nunca se publica)

JARVIS guarda tus datos en archivos dentro de esta carpeta. Todos están en `.gitignore`, así que no se suben si
publicás el proyecto con git:

| Qué | Dónde |
|---|---|
| Charla y recuerdos | `historial.json`, `recuerdos.json` |
| Contactos, pendientes, recordatorios, exámenes | `contactos.json`, `pendientes.json`, `recordatorios.json`, `examenes.json` |
| Ajustes y programas detectados | `ajustes.json`, `control.json`, `programas.json`, `gestos_config.json` |
| Lo que creás o le pasás (también los videos, en `documentos/videos/`) | `imagenes/`, `documentos/`, `adjuntos/`, `grabaciones/` |
| Qué apps usás y cuánto (nombre de la app y título de la ventana, cada 5 s; sin capturas ni lo que escribís; las ventanas privadas no se anotan; se borra a los 30 días) | `actividad/` (un archivo por día) |
| Rutinas y avisos ya dados | `rutinas.json`, `consejos.json` |
| Registros de errores | `*.log` |

El registro de actividad se apaga en Configuraciones o diciendo «dejá de registrar lo que hago», y se borra con
«borrá mi actividad».

## Dónde están las claves

Ninguna clave está escrita en el código.

- **Gmail** (contraseña de aplicación) y **Pollinations**: en el Administrador de credenciales de Windows (`keyring`).
  Se cargan con `python configurar.py`.
- **IA en la nube** (opcional): en variables de entorno de tu usuario de Windows: `GEMINI_API_KEY`, `GROQ_API_KEY` o
  `NVIDIA_API_KEY`. Se crean desde Configuraciones y se pueden borrar desde ahí mismo.

## Qué sale a internet

Por defecto todo lo piensa **Gemma en tu PC** (Ollama) y funciona sin internet. Sale información solo en estos casos:

- **"Pensar más"** (el botón del cerebro) o la nube elegida en Configuraciones: se manda esa pregunta junto con las
  instrucciones de JARVIS, la charla reciente y los recuerdos que vienen al caso. Las imágenes nunca se mandan: esas las
  mira siempre Gemma. Si no hay internet o la API falla, responde Gemma y te avisa.
- **Búsquedas y consultas** que pedís vos: clima (open-meteo; tu ciudad aproximada sale de ipinfo.io), web (DuckDuckGo), noticias, cotizaciones, precios,
  YouTube y música.
- **Gmail y WhatsApp**: solo cuando lo pedís, y siempre te pregunta antes de mandar, borrar o llamar.
- **Imágenes**: se hacen en tu PC. Solo si el generador local no está disponible (o estás en modo juego) se manda la
  descripción a Pollinations. Lo mismo con las imágenes de los videos que crea.
- **Videos**: el guion lo escribe Gemma en tu PC (con datos de Wikipedia si hay internet) y la voz es la de Windows. Si
  le pedís subtítulos a un video tuyo, el audio se manda a Google para pasarlo a texto (como cuando le hablás).
- **Mandar archivos**: por mail (Gmail) o WhatsApp, solo cuando lo pedís y después de que digas «sí».
- **Automejora** («mejorate: ...»): si está activada la opción de la nube en Configuraciones y tenés clave, se manda tu
  pedido y el código de las funciones de JARVIS que tienen que ver (nunca tus datos ni tus claves). Si no, lo escribe
  Gemma en tu PC. El cambio se revisa en una copia aparte y no se aplica hasta que digas «sí»; antes se guarda una
  copia de los archivos en `automejoras/` y «deshacé la última mejora» vuelve atrás. Nunca toca `automejora.py`,
  `configurar.py`, `apagar.py` ni las confirmaciones de envío, y te avisa si el cambio borra archivos, usa claves o
  manda datos a internet.
- **Automejora sola** (Configuraciones > "Que se mejore solo"): cuando no usás JARVIS, a la nube van los momentos de
  tus charlas en que algo salió mal (tu pedido, la respuesta y lo que dijiste después) para que la IA elija qué
  arreglar, y el código que tiene que cambiar. Solo se aplica sola si el arreglo pasa la revisión y una prueba de
  verdad en una copia de JARVIS (como mucho 2 por día, con copia de antes); si no, te pregunta.

## JARVIS en el celular (opcional)

Si lo conectás (`python configurar.py celular`), un bot de Telegram vive en **tu** cuenta de Google (Apps Script,
código en `bot_celular/Codigo.gs`) y anda aunque la PC esté apagada:

- **Qué queda en tu cuenta de Google:**
  - Dónde: en las "Propiedades del script" de ese proyecto.
  - Qué se guarda: tus recuerdos, pendientes y recordatorios, las últimas 8 idas y vueltas de la charla con el bot, la
    clave de Gemini y el token del bot. JARVIS los revisa cada minuto mientras está abierto (y sube cuando algo cambia).
  - Cómo está la PC, para que el bot te cuide: tu ciudad aproximada (para el clima), si estás jugando y a qué, cuánto
    tiempo usaste la compu hoy por tipo de cosa (jugando, estudiando...) y la batería. Nunca títulos de ventanas,
    nombres de archivos ni lo que escribís. Se apaga en Configuraciones ("Pasarle al bot del celular cómo usás la PC").
- **Órdenes para la PC desde el celular** ("poné música"): cada una la confirmás con un botón en Telegram, y la PC
  solo las hace si llegan en menos de 15 minutos (si la PC estaba apagada, se descartan).
- **La voz del bot:** el texto de la respuesta se manda a la voz de Google Translate para pasarlo a audio.
- **Búsquedas desde el celular:** van a Gemini con la búsqueda de Google, con tu clave.
- **Quién lo puede usar:**
  - Solo vos: te vinculás con un código de un solo uso, y a cualquier otra cuenta de Telegram no le contesta.
  - Telegram y tu PC le hablan con claves secretas distintas. La de la PC está en el Administrador de credenciales.
  - Para configurarlo de nuevo (otra PC, otra implementación), el bot te reconoce con esa clave o con el token del
    bot de @BotFather: no hay que borrar nada a mano. Por eso el token no se comparte con nadie (si se filtra, en
    @BotFather: /revoke y configurá de nuevo).
- **Mails:**
  - Mandar, responder y borrar siempre se confirma con un botón.
  - Lo que dice un mail nunca se toma como orden (probado con un mail que "pedía" reenviar todo a otra dirección).
- **Qué pasa por Telegram:** lo que le escribís al bot y lo que te contesta, incluidas las fotos, videos y PDFs que le
  mandás.
- **Fotos, videos y PDFs:** el bot se los pasa a Gemini para entenderlos.
  - Los videos y los archivos de más de 8 MB se suben a la API de archivos de Gemini, con tu clave: quedan ahí 48 horas
    y se borran solos.
  - De los links de YouTube solo se manda el link.
- **Para desconectarlo:**
  1. En Apps Script, archivá la implementación ("Gestionar implementaciones").
  2. En @BotFather mandá `/deletebot`.

JARVIS no abre puertos a la red: lo único que escucha es `127.0.0.1` (tu propia PC). No configures
`OLLAMA_HOST=0.0.0.0`, porque eso dejaría tu IA abierta a toda la red.

## Antes de publicar el proyecto

1. Corré el revisor: `python revisar_publicacion.py`. Busca claves, mails, teléfonos, rutas con tu usuario y nombres
   de tus contactos o recuerdos en los archivos que se publicarían. Tiene que decir que no encontró nada.
2. Publicá con git (así se respeta el `.gitignore`), nunca subiendo la carpeta entera a mano.
3. Si alguna vez se publicó una clave por error, no alcanza con borrarla: **revocala y creá otra** en el sitio de ese
   servicio.

## Dependencias

`requirements.txt` fija versiones exactas, así nadie te cuela una versión nueva (y posiblemente maliciosa) de un paquete
sin que te enteres. Para actualizar, cambiá la versión a mano después de revisarla.
