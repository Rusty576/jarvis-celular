"""JARVIS en el celular: el bot de Telegram (bot_celular/Codigo.gs, en Google Apps Script) y la PC se pasan los datos.

- El bot anda solo en la nube aunque la PC esté apagada (piensa con Gemini).
- Mientras JARVIS está abierto, cada minuto:
    1) baja lo que hiciste desde el celular (pendientes nuevos o hechos, recuerdos, recordatorios, órdenes para la PC
       como "poné música", lo que le pasaste a la PC: textos, links, fotos, videos, cualquier archivo) y lo aplica acá;
       lo que hizo con las órdenes se lo cuenta al bot (si la orden hizo una imagen, como una captura de pantalla, la
       imagen también: te llega al celular). Los archivos pasan por tu Google Drive y la PC los baja a Documentos ›
       Del celular (de a pedazos: si se corta, sigue donde quedó);
    2) sube tus recuerdos, pendientes y recordatorios, para que el bot los tenga, y cómo está la PC (si estás jugando,
       cuánto la usaste hoy, la batería, tu ciudad para el clima), para que te cuide. Esto último se apaga en
       Configuraciones ("Pasarle al bot del celular cómo usás la PC").
  Si no cambió nada, sube cada 5 minutos (para que el bot sepa que la PC sigue prendida).
- La dirección del bot y su clave están en el Administrador de credenciales de Windows (keyring), no en archivos.
- Si JARVIS en la PC tiene la clave de otra IA (Groq...), se la pasa al bot una vez: así, cuando Gemini no tiene cupo,
  el celular sigue contestando con esa (Configuraciones > "Pasarle al bot del celular las claves de otras IAs").
- Se configura una sola vez:  python configurar.py celular   (o decile a JARVIS "configurar celular")
"""
import base64
import datetime
import hashlib
import io
import json
import os
import re
import threading
import time
import unicodedata
import urllib.request

import finanzas

SERVICIO = "JARVIS-Celular"
CADA = 60  # segundos entre sincronizaciones (las órdenes del celular llegan en menos de un minuto)
SUBIR_CADA = 300  # si no cambió nada, igual sube cada 5 minutos ("la PC sigue prendida")
ORDEN_VIGENTE = 15 * 60  # una orden del celular más vieja que esto no se hace (la PC estaba apagada cuando la pediste)
COMPARTIR_ACTIVIDAD = True  # Configuraciones > "Pasarle al bot del celular cómo usás la PC"
COMPARTIR_IAS = True  # Configuraciones > "Pasarle al bot del celular las claves de otras IAs"
CLAVES_IAS = {"groq": "groq"}  # IA del bot -> proveedor de cerebro_nvidia (el que tiene la clave en la PC)
_ias_pasadas = {}  # ia -> huella de la clave que ya se le pasó (en esta vuelta de JARVIS: no se repite cada minuto)
ARCHIVO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "celular.json")  # lo ya aplicado (por si se corta)
CODIGO_BOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_celular", "Codigo.gs")

estado = {"ultima": None, "error": None, "aplicadas": 0, "subido": 0.0, "foto": None, "avisado_version": None}
_lock = threading.Lock()


def version_local():
    """La VERSION de bot_celular/Codigo.gs de esta PC (para saber si el bot en Google tiene el código viejo)."""
    try:
        with open(CODIGO_BOT, encoding="utf-8") as f:
            m = re.search(r'^const VERSION = "([^"]+)"', f.read(), re.M)
        return m.group(1) if m else ""
    except OSError:
        return ""


def _leer(clave):
    try:
        import keyring

        return keyring.get_password(SERVICIO, clave)
    except Exception:
        return None


def configurado():
    return bool(_leer("url") and _leer("clave_pc"))


def ajustes():
    """Los ajustes del bot (sincronizados desde el celular)."""
    try:
        with open(ARCHIVO, encoding="utf-8") as f:
            return json.load(f).get("ajustes", {})
    except (OSError, ValueError):
        return {}


def pedir(accion, url=None, **datos):
    """Habla con el bot (Apps Script responde con una redirección: urllib la sigue sola)."""
    datos.update(accion=accion)
    datos.setdefault("clave", _leer("clave_pc"))
    pedido = urllib.request.Request(url or _leer("url"), json.dumps(datos).encode("utf-8"),
                                    {"Content-Type": "application/json"})
    with urllib.request.urlopen(pedido, timeout=40) as r:
        texto = r.read().decode("utf-8")
    try:
        respuesta = json.loads(texto)
    except ValueError:
        raise RuntimeError("el bot no respondió bien (¿la implementación es 'Aplicación web' con acceso para cualquiera?)")
    if not respuesta.get("ok"):
        raise RuntimeError(respuesta.get("error", "el bot rechazó el pedido"))
    return respuesta


def zona_minutos():
    return int(datetime.datetime.now().astimezone().utcoffset().total_seconds() // 60)


# ---------- Lo que se sube: lo que el bot necesita saber ----------

def foto():
    import habilidades
    import herramientas
    import memoria

    hace_3_dias = (datetime.datetime.now() - datetime.timedelta(days=3)).isoformat(timespec="minutes")
    return {
        "recuerdos": [{"id": r["id"], "texto": r["texto"], "categoria": r.get("categoria"), "auto": bool(r.get("auto")),
                       "confianza": r.get("confianza") or "", "fecha": r.get("fecha") or ""}
                      for r in memoria._cargar()["recuerdos"]],
        # jarv2: lo que está para revisar (y lo descartado, para que el celular no lo vuelva a proponer)
        "candidatos": memoria.candidatos()[-30:],
        "descartados": memoria._cargar_descartados()[-100:],
        "pendientes": [{"id": p["id"], "texto": p["texto"], "hecho": p["hecho"], "para": p.get("para")}
                       for p in habilidades.pendientes() if not p["hecho"] or (p.get("hecho_en") or "") >= hace_3_dias],
        "recordatorios": [{"id": r["id"], "cuando": r["cuando"], "texto": r.get("texto") or "", "tipo": r.get("tipo")}
                          for r in herramientas.cargar_recordatorios()],
        "pc": estado_pc(),
    }


def estado_pc():
    """Cómo está la PC, para que el bot te cuide (si seguís jugando de madrugada) y sepa el clima de tu ciudad.
    Sin títulos de ventanas ni nombres de archivos: solo cuánto tiempo, en qué tipo de cosa y el juego."""
    import herramientas

    pc = {}
    try:
        ciudad, lat, lon = herramientas.ubicacion_actual()
        pc["lugar"] = {"ciudad": ciudad, "lat": round(lat, 2), "lon": round(lon, 2)}
    except Exception:
        pass
    if not COMPARTIR_ACTIVIDAD:
        return pc
    pc["jugando"] = herramientas.modo_juego.is_set()
    try:
        import psutil

        bateria = psutil.sensors_battery()
        if bateria:
            pc["bateria"], pc["enchufada"] = round(bateria.percent), bool(bateria.power_plugged)
    except Exception:
        pass
    try:
        import actividad

        d = actividad.para_consejos()
        partes = [f"{actividad._hms(s)} {actividad.CATEGORIAS[c]}" for c, s in sorted(d["hoy"].items(), key=lambda x: -x[1])
                  if s >= 300 and c != "otros"]
        if partes:
            pc["resumen"] = "Hoy en la compu: " + ", ".join(partes) + "."
        pc["minutos_juego_hoy"] = round(d["hoy"].get("juego", 0) / 60)
        if d["jugando_ahora"] and d["juego"]:
            pc["jugando"] = True
            pc["juego"] = d["juego"]["app"]
            pc["juego_minutos"] = round((time.time() - d["juego"]["desde"]) / 60)
    except Exception:
        pass
    return pc


# ---------- Lo que se baja: lo que hiciste en el celular ----------

def _n(s):
    s = unicodedata.normalize("NFD", str(s or "").lower())
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", "".join(c for c in s if unicodedata.category(c) != "Mn"))).strip()


def _pendiente_de(novedad):
    import habilidades

    lista = habilidades.pendientes()
    for p in lista:
        if str(p["id"]) == str(novedad.get("id")) and _n(p["texto"]) == _n(novedad.get("texto")):
            return p
    # los creados en el celular todavía no tenían número de la PC: se buscan por el texto
    return next((p for p in lista if not p["hecho"] and _n(p["texto"]) == _n(novedad.get("texto"))), None)


def imagen_para_el_celular(ruta, lado=1600):
    """Una imagen que hizo la PC (una captura de pantalla, una imagen generada), achicada para mandarla al celular:
    {mime, datos (base64)}. None si no se pudo."""
    try:
        from PIL import Image

        with Image.open(ruta) as img:
            if img.mode in ("RGBA", "LA", "P"):   # (una foto sin fondo: sobre blanco; si no, el fondo salía negro)
                img = img.convert("RGBA")
                blanco = Image.new("RGBA", img.size, (255, 255, 255, 255))
                img = Image.alpha_composite(blanco, img)
            img = img.convert("RGB")
            img.thumbnail((lado, lado))
            buf = io.BytesIO()
            img.save(buf, "JPEG", quality=78)
        return {"mime": "image/jpeg", "datos": base64.b64encode(buf.getvalue()).decode()}
    except Exception:
        return None


def ejecutar_orden(novedad, con_imagen=False):
    """Una orden que mandaste desde el celular ("poné música"): la hace JARVIS como si se la dijeras acá.
    Devuelve lo que contestó (para mandártelo al celular). con_imagen: devuelve (texto, imagen), con la imagen que hizo
    la orden si hizo una (sacá una captura, generá una imagen); si no, None."""
    import habilidades

    jarvis = habilidades.jarvis
    texto = str(novedad.get("texto") or "").strip()[:300]
    respuesta = _ejecutar(jarvis, texto, novedad.get("en"))
    if not con_imagen:
        return respuesta[0]
    return respuesta


def _ejecutar(jarvis, texto, en):
    try:
        pedida = datetime.datetime.fromisoformat(str(en))
        tarde = (datetime.datetime.now() - pedida).total_seconds()
        if tarde > ORDEN_VIGENTE:
            return (f"No lo hice: me llegó {round(tarde / 60)} minutos tarde (la PC estaba apagada o sin internet cuando "
                    f"lo pediste), y por las dudas no hago órdenes viejas. Pedímelo de nuevo."), None
    except ValueError:
        pass
    if not texto:
        return "No me llegó qué hacer.", None
    desde = time.time()
    resultado = {}

    def hacer():
        try:
            t = jarvis.normalizar(texto).strip(" ,.;:¡!¿?")
            # "sí" / "no" a algo que la PC preguntó ("¿Apago la compu?"); si no, la orden de siempre
            r = jarvis.conexiones.responder_confirmacion(t, texto)
            if r is None:
                r = jarvis.ejecutar_accion(texto)
            resultado["texto"] = r or "Eso no es algo que la PC haga sola (para charlar, hablame en el celular)."
        except Exception as e:
            resultado["texto"] = f"No pude: {e}"
    hilo = threading.Thread(target=hacer, daemon=True)
    hilo.start()
    # lo largo (un video) sigue solo; una imagen se espera más (la primera del generador tarda ~1 minuto), así llega
    # (sacar el fondo, un 3D o un video con IA tardan uno o dos minutos: se espera hasta 5)
    largo = re.search(r"\b(fondo|3 ?d|video con ia|anima)", texto.lower())
    hilo.join(300 if largo else 150 if re.search(r"\b(imagen|dibuj|ilustraci|foto de)", texto.lower()) else 45)
    respuesta = resultado.get("texto") or "La PC lo está haciendo (tarda un poco)."
    try:
        jarvis.emitir("jarvis", f"📱 Desde el celular: «{texto}»\n{respuesta}")
    except Exception:
        pass
    # si la orden hizo una imagen (una captura, una imagen generada), también va al celular
    imagen = None
    ultimo = getattr(jarvis, "ultimo_archivo", None) or {}
    ruta = ultimo.get("ruta")
    if ruta and ultimo.get("cuando", 0) >= desde and str(ruta).lower().endswith((".png", ".jpg", ".jpeg", ".webp")) \
            and os.path.exists(ruta):
        imagen = imagen_para_el_celular(ruta)
    elif ruta and ultimo.get("cuando", 0) >= desde and str(ruta).lower().endswith((".mp4", ".webm", ".mov")) \
            and os.path.exists(ruta):
        imagen = _cuadro_del_video(ruta)   # (un video con IA: al celular le llega cómo se ve; el video queda en la PC)
    return respuesta, imagen


def _cuadro_del_video(ruta):
    """El primer cuadro de un video, como imagen para el celular."""
    try:
        import av

        with av.open(ruta) as v:
            cuadro = next(v.decode(video=0)).to_image()
        temporal = os.path.join(os.environ.get("TEMP", "."), "jarvis_cuadro.png")
        cuadro.save(temporal)
        return imagen_para_el_celular(temporal)
    except Exception:
        return None


def guardar_nota_del_celular(texto):
    """Lo que le pasaste a la PC desde el celular («pasale este link a la PC»): aparece en JARVIS y queda en un archivo
    (Documentos › Del celular). Devuelve dónde quedó."""
    import habilidades

    jarvis = habilidades.jarvis
    carpeta = os.path.join(getattr(jarvis, "CARPETA_DOCS", os.path.dirname(os.path.abspath(__file__))), "Del celular")
    os.makedirs(carpeta, exist_ok=True)
    ruta = os.path.join(carpeta, f"Del celular {datetime.datetime.now():%Y-%m-%d %H-%M-%S}.txt")
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(texto)
    try:
        jarvis.recordar_archivo(ruta)  # («abrilo» lo abre)
        corto = texto if len(texto) <= 600 else texto[:600] + "…"
        jarvis.emitir("jarvis", f"📱 Me pasaste esto desde el celular:\n{corto}\n\n(Quedó en Documentos › Del celular.)")
    except Exception:
        pass
    return ruta


def _nombre_seguro(nombre):
    n = re.sub(r'[\\/:*?"<>|\x00-\x1f]', " ", str(nombre or "")).strip(" .")[:120]
    return n or f"Del celular {datetime.datetime.now():%Y-%m-%d %H-%M-%S}"


def _ruta_libre(carpeta, nombre):
    """foto.jpg, y si ya hay una: foto (2).jpg"""
    base, ext = os.path.splitext(nombre)
    ruta, n = os.path.join(carpeta, nombre), 2
    while os.path.exists(ruta):
        ruta, n = os.path.join(carpeta, f"{base} ({n}){ext}"), n + 1
    return ruta


def _tamano_lindo(n):
    return f"{max(1, round(n / 1024))} KB" if n < 1024 * 1024 else f"{n / 1024 / 1024:.1f} MB".replace(".", ",")


def bajar_archivo_del_celular(novedad, respuestas=None):
    """Un archivo que le pasaste a la PC desde el celular (una foto, un video, un documento): lo baja de a pedazos
    (pasa por tu Google Drive) a Documentos › Del celular, le avisa al bot (que lo saca de Drive), aparece en JARVIS
    y al celular le llega «listo». Si se corta, la próxima vez sigue desde donde quedó. Devuelve la ruta."""
    import habilidades

    jarvis = habilidades.jarvis
    # («Reportar un problema» en el celular: la charla y los errores, para que los revise Claude, van a MiJarvis › reportes)
    reporte = novedad.get("carpeta") == "reportes"
    if reporte:
        carpeta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reportes")
    else:
        carpeta = os.path.join(getattr(jarvis, "CARPETA_DOCS", os.path.dirname(os.path.abspath(__file__))), "Del celular")
    os.makedirs(carpeta, exist_ok=True)
    nombre = _nombre_seguro(novedad.get("nombre"))
    parcial = os.path.join(carpeta, f"(bajando) {re.sub(r'[^\w-]', '', str(novedad['id']))[:16]} {nombre}")
    desde = os.path.getsize(parcial) if os.path.exists(parcial) else 0
    total = None
    with open(parcial, "ab") as f:
        while total is None or desde < total:
            try:
                r = pedir("pc_archivo", id=novedad["id"], desde=desde)
            except RuntimeError as e:
                if "ya no está" not in str(e):
                    raise  # se reintenta la próxima vez
                f.close()
                os.remove(parcial)  # lo sacaste de Drive antes de que llegara: no hay nada que bajar
                return None
            datos = base64.b64decode(r.get("datos") or "")
            total = int(r.get("total") or 0)
            if not datos:
                break
            f.write(datos)
            desde += len(datos)
    if total and desde < total:
        raise RuntimeError("se cortó a mitad de camino")
    ruta = _ruta_libre(carpeta, nombre)
    os.replace(parcial, ruta)
    try:
        pedir("pc_archivo_listo", id=novedad["id"])
    except Exception:
        pass  # (queda en la carpeta de Drive: no molesta)
    texto = str(novedad.get("texto") or "").strip()
    if reporte:
        try:
            jarvis.emitir("jarvis", "📨 Llegó un reporte desde el celular" + (f": «{texto[:200]}»" if texto else "")
                                    + ".\nQuedó en MiJarvis › reportes: decile a Claude «revisá el último reporte».")
        except Exception:
            pass
        if respuestas is not None:
            respuestas.append({"orden": "Reportar un problema",
                               "texto": "Listo: el reporte llegó a la PC (MiJarvis › reportes)."})
        return ruta
    try:
        jarvis.recordar_archivo(ruta)  # («abrilo» lo abre)
        jarvis.emitir("jarvis", f"📱 Me pasaste «{nombre}» ({_tamano_lindo(desde)}) desde el celular."
                                + (f"\n«{texto[:300]}»" if texto else "") + "\n\n(Quedó en Documentos › Del celular. "
                                "Decime «abrilo» y lo abro.)")
    except Exception:
        pass
    if respuestas is not None:
        respuestas.append({"orden": f"Pasar a la PC «{nombre}»",
                           "texto": f"Listo: ya está en la PC ({_tamano_lindo(desde)}), en Documentos › Del celular."})
    return ruta


def _pasar_claves_de_ias(faltan):
    """El bot no tiene clave de Groq (o la que tenía no anda) y JARVIS en la PC sí: se la pasa, una vez."""
    if not COMPARTIR_IAS:
        return
    for ia in faltan or []:
        proveedor = CLAVES_IAS.get(ia)
        if not proveedor:
            continue
        try:
            import cerebro_nvidia

            clave = cerebro_nvidia.clave(proveedor)
        except Exception:
            clave = None
        if not clave:
            continue
        huella = hashlib.sha256(clave.encode("utf-8")).hexdigest()[:16]
        if _ias_pasadas.get(ia) == huella:
            continue  # (ya se la pasó: si el bot dice que no anda, no se insiste)
        _ias_pasadas[ia] = huella
        try:
            pedir("ias", ia=ia, clave_ia=clave)  # («clave» es la de esta PC, con la que el bot la reconoce)
        except Exception:
            pass


def aplicar(novedad, respuestas=None):
    """Aplica una novedad del celular. Se pueden repetir sin problema (por si se cortó a mitad de camino).
    Lo que contesta la PC a las órdenes va a respuestas (se le manda al bot)."""
    import habilidades
    import herramientas
    import memoria

    tipo = novedad.get("tipo")
    if tipo == "orden_pc":
        texto, imagen = ejecutar_orden(novedad, con_imagen=True)
        if respuestas is not None:
            respuestas.append({"orden": novedad.get("texto"), "texto": texto, **({"imagen": imagen} if imagen else {})})
    elif tipo == "nota_pc":
        guardar_nota_del_celular(str(novedad.get("texto") or "")[:20000])
    elif tipo == "archivo_pc":
        bajar_archivo_del_celular(novedad, respuestas)
    elif tipo == "pendiente_nuevo":
        habilidades.agregar_pendiente(novedad["texto"])
    elif tipo in ("pendiente_hecho", "pendiente_borrar"):
        p = _pendiente_de(novedad)
        if p and tipo == "pendiente_hecho":
            habilidades.marcar_pendiente(p["id"], True)
        elif p:
            habilidades.borrar_pendiente(p["id"])
    elif tipo == "recuerdo":
        memoria.guardar(novedad["texto"], categoria=novedad.get("categoria") if novedad.get("categoria") in memoria.CATEGORIAS else None)
        if novedad.get("confianza") == "confirmado":
            memoria.confirmar_por_texto(novedad["texto"])
        memoria.sacar_candidato(novedad["texto"])
    elif tipo == "candidato":   # lo que contaste de pasada en el celular: queda para revisar, como acá
        memoria.agregar_candidato(str(novedad.get("texto") or ""))
    elif tipo == "candidato_descartar":
        memoria.descartar_candidato(str(novedad.get("texto") or ""))
    elif tipo in ("recuerdo_confirmar", "recuerdo_olvidar"):
        r = memoria.recuerdo_de(novedad.get("id"), novedad.get("texto"))
        if r and tipo == "recuerdo_confirmar":
            memoria.confirmar(r["id"])
        elif r:
            memoria.olvidar_id(r["id"])
    elif tipo == "recordatorio_nuevo":
        with herramientas._lock:
            lista = herramientas.cargar_recordatorios()
            if not any(str(r["id"]) == str(novedad["id"]) for r in lista):
                datetime.datetime.fromisoformat(novedad["cuando"])  # que sea una fecha de verdad
                lista.append({"id": int(novedad["id"]), "cuando": novedad["cuando"], "texto": novedad.get("texto") or "",
                              "tipo": "recordatorio"})
                lista.sort(key=lambda r: r["cuando"])
                herramientas.guardar_recordatorios(lista)
    elif tipo in ("recordatorio_avisado", "recordatorio_borrar"):
        # "avisado": ya te llegó al celular, así la PC no te lo vuelve a decir
        with herramientas._lock:
            lista = herramientas.cargar_recordatorios()
            quedan = []
            for r in lista:
                if str(r["id"]) != str(novedad["id"]):
                    quedan.append(r)
                elif tipo == "recordatorio_avisado" and r.get("repetir"):  # los que se repiten: a la próxima vez
                    siguiente = herramientas.proxima_vez(r["repetir"])
                    if siguiente:
                        quedan.append({**r, "cuando": siguiente.isoformat(timespec="seconds")})
            if quedan != lista:
                quedan.sort(key=lambda r: r["cuando"])
                herramientas.guardar_recordatorios(quedan)
    else:
        return False
    return True


def _ya_aplicadas():
    try:
        with open(ARCHIVO, encoding="utf-8") as f:
            return json.load(f).get("aplicadas", [])
    except (OSError, ValueError):
        return []


def _anotar_aplicadas(nids):
    lista = (_ya_aplicadas() + nids)[-500:]
    tmp = ARCHIVO + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"aplicadas": lista}, f)
    os.replace(tmp, ARCHIVO)


def sincronizar():
    """Baja lo del celular, lo aplica y sube cómo quedó todo. Devuelve cuántas cosas aplicó."""
    with _lock:
        bajado = pedir("bajar")
        novedades = bajado["novedades"]
        _avisar_si_hay_codigo_nuevo(bajado.get("version") or "")
        _pasar_claves_de_ias(bajado.get("ias_faltan"))
        if isinstance(bajado.get("finanzas"), dict):   # jarv2: las finanzas como las tiene el bot (con lo del celular)
            finanzas.del_bot(bajado["finanzas"])
        if bajado.get("ajustes"):
            with open(ARCHIVO, "w", encoding="utf-8") as f:
                json.dump({"ajustes": bajado["ajustes"]}, f)
        ya = set(_ya_aplicadas())  # si la vez pasada se cortó antes de avisarle al bot, no se aplican dos veces
        aplicadas, nuevas, respuestas = [], [], []
        for x in novedades:
            if x.get("nid") in ya:
                aplicadas.append(x["nid"])
                continue
            try:
                if aplicar(x, respuestas):
                    aplicadas.append(x["nid"])
                    nuevas.append(x["nid"])
            except Exception:
                pass  # queda en el bot y se reintenta la próxima vez
        if nuevas:
            _anotar_aplicadas(nuevas)
        datos = foto()
        ops = finanzas.para_el_bot()   # (lo de plata que se anotó acá y el bot todavía no tiene)
        # se sube si hay algo que avisar, si cambió algo, o cada 5 minutos (para que el bot sepa que la PC sigue prendida)
        if aplicadas or respuestas or ops or datos != estado["foto"] or time.time() - estado["subido"] >= SUBIR_CADA:
            # direccion: la del bot, para que arme el link de la app del celular (/app en Telegram)
            subido = pedir("subir", aplicadas=aplicadas, datos=datos, respuestas=respuestas, zona_min=zona_minutos(),
                           direccion=_leer("url"), finanzas_ops=ops)
            if isinstance(subido, dict) and isinstance(subido.get("finanzas"), dict):
                finanzas.del_bot(subido["finanzas"])
            estado.update(subido=time.time(), foto=datos)
        if nuevas:
            _avisar_a_la_pantalla()
        estado.update(ultima=time.time(), error=None, aplicadas=estado["aplicadas"] + len(nuevas))
        return len(nuevas)


def _avisar_si_hay_codigo_nuevo(version_bot):
    """Si el bot en Google tiene un código más viejo que el de esta PC, lo avisa una vez (en la pantalla de JARVIS)."""
    local = version_local()
    if not local or version_bot >= local or estado["avisado_version"] == local:
        return
    estado["avisado_version"] = local
    try:
        import habilidades

        habilidades.jarvis.emitir("detalle", "Hay un código nuevo para el bot del celular: decime «actualizá el bot "
                                             "del celular» y lo actualizo yo (sin tocar claves).")
    except Exception:
        pass


def _avisar_a_la_pantalla():
    try:
        import habilidades
        import herramientas

        habilidades.jarvis.emitir("pendientes", habilidades.pendientes())
        habilidades.jarvis.emitir("recordatorios", herramientas.proximos())
    except Exception:
        pass


def _bucle():
    time.sleep(15)  # que JARVIS termine de arrancar
    while True:
        if configurado():
            try:
                sincronizar()
            except Exception as e:
                estado["error"] = str(e)  # sin internet: se reintenta en un rato, no molesta
        time.sleep(CADA)


def iniciar():
    threading.Thread(target=_bucle, daemon=True).start()


# ---------- "pasame lo que te mandé al celu" ----------

# Lo que le mandaste al bot de Telegram (antes JARVIS contestaba "no tengo ningún registro" e inventaba con internet)
DEL_CELULAR = re.compile(
    r"\b(?:lo|el \w+|la \w+|los \w+|las \w+) que (?:te |le )?(?:mande|pase|envie|escribi|dije|conte|deje|subi|saque)\w*"
    r"\s+(?:al|en el|por el|desde el|por|a tu|en tu|en mi|con el)\s+(?:celu|celular|telefono|movil|telegram|bot)\b"
    r"|\b(?:registro|mensajes?|charla|chat|conversacion|foto|texto|datos|notas?)\s+(?:del|en el|de mi|de tu)\s+"
    r"(?:celu|celular|telefono|movil|telegram|bot)\b"
    r"|\blo del (?:celu|celular|telefono|telegram)\b")
# solo quiere verlo ("pasame el registro que te mandé al celu"); si pide algo más, el texto queda para eso
SOLO_TRAER = re.compile(r"^(?:[\w ]{0,30}?\s)?(?:pasa|pasame|pasamelo|mostra|mostrame|trae|traeme|traelo|dame|lee|"
                        r"leeme|leelo|busca|buscame|recupera|copia|copiame|que)\b")
PIDE_ALGO_MAS = re.compile(r"\b(?:en base|basado|segun|con eso|a partir|resum|explic|arm|hac|cre|gener|escrib|corregi|"
                           r"revis|analiz|busca(?:me)? (?:mas|info))")


def charla_del_bot():
    """La charla guardada en el bot: [{"r": "user"|"model", "t": texto}] (los últimos 8 idas y vueltas)."""
    return pedir("charla").get("charla") or []


def registro_del_celular(charla):
    """Lo que mandaste (y, si era una foto o un archivo, lo que el bot leyó de ahí) como un texto para JARVIS."""
    partes = []
    for i, m in enumerate(charla):
        texto = str(m.get("t") or "").strip()
        if m.get("r") != "user" or not texto or re.match(r"^\(Toc[oó] (?:Confirmar|Cancelar)\.\)$", texto):
            continue
        partes.append(texto)
        siguiente = charla[i + 1] if i + 1 < len(charla) else None
        if texto.startswith("(Te mandó") and siguiente and siguiente.get("r") == "model":
            partes.append("Lo que el bot leyó ahí: " + str(siguiente.get("t") or "").strip())
    return "\n\n".join(partes)


def manejar_lo_del_celular(texto, t):
    if not DEL_CELULAR.search(t):
        return None
    if not configurado():
        return "Todavía no conectaste el celular, así que no veo lo que le mandás al bot. Decí «configurar celular»."
    try:
        registro = registro_del_celular(charla_del_bot())
    except RuntimeError as e:
        if "desconocida" in str(e):
            return ("El bot del celular tiene el código viejo y todavía no me deja leer lo que le mandás. Decime "
                    "«actualizá el bot del celular» (lo hago yo: vos solo entrás con tu cuenta) y después te lo traigo.")
        return f"No pude leer el celular: {e}"
    except Exception as e:
        return f"No pude conectarme con el bot del celular: {e}"
    if not registro:
        return ("En el bot del celular no hay nada guardado de lo que le mandaste (se acuerda de los últimos 8 "
                "mensajes, y /olvidar los borra). Mandámelo de nuevo o pegalo acá.")
    import adjuntos

    adjuntos.agregar_texto(registro, nombre="Lo que mandaste al celular")
    if PIDE_ALGO_MAS.search(t) or not SOLO_TRAER.search(t):
        return None  # "en base al registro del celu...": sigue la charla (o el documento) con ese texto a mano
    return ("Esto es lo que me mandaste al celular (lo dejé a mano: preguntame sobre eso o decime «armame un "
            "documento con eso»):\n\n" + registro[:6000])


# ---------- "configurar celular" ----------

def manejar(texto, t):
    respuesta = manejar_lo_del_celular(texto, t)
    if respuesta is not None:
        return respuesta
    if re.match(r"^(?:configura|configurar|conecta|conectar|vincula|vincular|activa|activar)\s+(?:el |mi |a )?"
                r"(?:celular|telefono|movil|telegram|bot(?: de telegram)?|jarvis en el celular)$", t):
        import conexiones

        conexiones.abrir_configuracion("celular")
        return "Te abrí una ventana para conectar JARVIS con tu celular (por Telegram). Seguí los pasos de ahí."
    if re.match(r"^(?:actualiza|actualizar|actualizale|cambia|cambiale|reinstala|reinstalar)\s+(?:el codigo (?:del|al) |"
                r"el |al |mi )?(?:bot(?: del celular| de telegram)?|celular|codigo del bot|jarvis del celular|telegram)$", t):
        import conexiones

        conexiones.abrir_configuracion("celular")
        return ("Te abrí una ventana: entrás con tu cuenta de Google y yo subo el código nuevo del bot y lo publico "
                "en la misma dirección. No hay que tocar claves.")
    if re.match(r"^(?:sincroniza|sincronizar)\s+(?:con )?(?:el |mi )?(?:celular|telefono|telegram)$", t):
        if not configurado():
            return "Todavía no conectaste el celular. Decí «configurar celular» y te guío."
        try:
            n = sincronizar()
        except Exception as e:
            return f"No pude sincronizar con el celular: {e}"
        return f"Listo, sincronizado con el celular{f' (traje {n} cosas que hiciste ahí)' if n else ''}."
    return None
