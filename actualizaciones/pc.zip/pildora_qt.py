"""La píldora de JARVIS, dibujada con Qt (transparencia de verdad, bordes suaves y animaciones), en su propio proceso.
JARVIS (pildora.py) la abre y se hablan por un enchufe local (127.0.0.1), con un JSON por línea.

Formas: reposo (píldora chiquita), dock (3 botones), cartel (texto que corre), tarjeta (lista) y el panel de chat.
La cara sigue al mouse, parpadea, escucha (brilla con tu voz), piensa (mira a los costados), habla (mueve la boca),
baila con la música y pone ojos de corazón si le decís gracias. Caras: celeste, blanco, halloween, navidad.

Uso: pythonw pildora_qt.py PUERTO
"""
import json
import math
import os
import random
import sys
import threading
import time

from PySide6 import QtCore, QtGui, QtNetwork, QtWidgets

Qt = QtCore.Qt
FORMAS = {"reposo": (112, 50, 25), "dock": (132, 116, 30), "cartel": (480, 64, 32), "tarjeta": (440, 200, 26),
          "musica": (400, 78, 30)}
ACCIONES = ["orden", "dictar", "escribir", "cerrar"]  # al pasar el mouse por una respuesta: seguir o cambiar de modo
MARGEN, MARGEN_ABAJO = 14, 22  # lugar para la sombra
COLORES = {"celeste": "#29d9ff", "blanco": "#ffffff", "halloween": "#ff9f1c", "navidad": "#ff4d5e"}
ACENTO = {"celeste": "#29d9ff", "blanco": "#2f7df6", "halloween": "#ff9f1c", "navidad": "#ff4d5e"}
FUENTE = "Segoe UI"


def mezclar(a, b, t):
    return a + (b - a) * t


# ---------- La música de otras apps (acá, no en JARVIS: si el control de medios de Windows falla, cae esto solo) ----------

class Musica(QtCore.QObject):
    cambio = QtCore.Signal(object)

    def __init__(self):
        super().__init__()
        self.de_jarvis = None  # lo que suena en JARVIS (lo manda JARVIS); manda sobre lo de las otras apps
        self.externa = None
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import medios
            self.medios = medios if medios.disponible() else None
        except Exception:
            self.medios = None
        self._tapa = None
        threading.Thread(target=self._bucle, daemon=True).start()

    def _bucle(self):
        while True:
            time.sleep(1.5)
            if self.medios is None:
                continue
            try:
                s = self.medios.actual(con_tapa=True)
            except Exception:
                s = None
            if s and s.get("titulo"):
                d = {"titulo": s["titulo"], "artista": " · ".join(x for x in (s["artista"], s["app"]) if x),
                     "pausado": s["estado"] != "reproduciendo", "actual": s["actual"], "duracion": s["duracion"],
                     "clave": s["app"] + s["titulo"], "fuente": "otra"}
                tapa = s.get("tapa") or ""
                if tapa != self._tapa:
                    self._tapa = tapa
                    d["tapa"] = tapa
                self.externa = d
            else:
                self.externa = None
            if self.de_jarvis is None:
                self.cambio.emit(self.externa)

    def jarvis_dice(self, d):
        self.de_jarvis = d
        if d:
            d["fuente"] = "jarvis"
        self.cambio.emit(d or self.externa)

    def controlar(self, accion, enlace):
        if self.de_jarvis is not None:
            enlace.mandar("media", accion)
        elif self.medios is not None:
            threading.Thread(target=self.medios.control, args=(accion,), daemon=True).start()


# ---------- La conexión con JARVIS ----------

class Enlace(QtCore.QObject):
    llego = QtCore.Signal(dict)

    def __init__(self, puerto):
        super().__init__()
        self.sock = QtNetwork.QTcpSocket(self)
        self.sock.readyRead.connect(self._leer)
        # si JARVIS se cierra (aunque sea de golpe), la píldora se va con él: antes a veces quedaba sola en la pantalla
        self.sock.disconnected.connect(QtWidgets.QApplication.quit)
        self.sock.errorOccurred.connect(lambda *_: QtWidgets.QApplication.quit())
        self.sock.connectToHost("127.0.0.1", puerto)
        if not self.sock.waitForConnected(5000):
            sys.exit(1)

    def mandar(self, tipo, valor=None):
        self.sock.write((json.dumps({"t": tipo, "v": valor}, ensure_ascii=False) + "\n").encode("utf-8"))
        self.sock.flush()

    def _leer(self):
        while self.sock.canReadLine():
            try:
                self.llego.emit(json.loads(bytes(self.sock.readLine()).decode("utf-8")))
            except ValueError:
                pass


# ---------- La cara (la usan la píldora y el panel) ----------

class Cara:
    """Dibuja la cara en un QPainter, centrada en (x, y), con el estado que tenga."""

    def __init__(self):
        self.look = "celeste"
        self.estado = "libre"
        self.nivel = 0.0
        self.mirada = [0.0, 0.0]
        self.mirada_obj = [0.0, 0.0]
        self.parpadeo_hasta = 0.0
        self.proximo_parpadeo = time.time() + 2.5
        self.corazones_hasta = 0.0
        self.baila = False

    def paso(self):
        ahora = time.time()
        if ahora > self.proximo_parpadeo:
            self.parpadeo_hasta = ahora + 0.12
            self.proximo_parpadeo = ahora + random.uniform(2.6, 6.4)
        for i in (0, 1):
            self.mirada[i] += (self.mirada_obj[i] - self.mirada[i]) * 0.22

    def dibujar(self, p, cx, cy, escala=1.0):
        ahora = time.time()
        color = QtGui.QColor(COLORES.get(self.look, "#29d9ff"))
        p.save()
        p.translate(cx + self.mirada[0] * 7, cy + self.mirada[1] * 4)
        p.scale(escala, escala)
        if self.baila:
            p.rotate(6 * math.sin(ahora * math.pi * 2 / 1.0))
        dx = 5 * math.sin(ahora * math.pi * 2 / 1.6) if self.estado == "pensando" else 0
        alto = 13 * (0.08 if ahora < self.parpadeo_hasta else 1)
        grande = 1.16 if self.estado == "escuchando" else 1.0
        ojos = [(-12.5 + dx, 0), (12.5 + dx, 0)]

        # el brillo (un resplandor detrás de cada ojo)
        for ox, oy in ojos:
            g = QtGui.QRadialGradient(QtCore.QPointF(ox, oy - 1), 15)
            c1 = QtGui.QColor(color); c1.setAlphaF(0.55)
            c2 = QtGui.QColor(color); c2.setAlphaF(0.0)
            g.setColorAt(0, c1); g.setColorAt(1, c2)
            p.setPen(Qt.NoPen); p.setBrush(g)
            p.drawEllipse(QtCore.QPointF(ox, oy - 1), 15, 15)

        if ahora < self.corazones_hasta:
            p.setBrush(QtGui.QColor("#ff5a8a"))
            for ox, oy in ojos:
                corazon = QtGui.QPainterPath()
                corazon.moveTo(ox, oy + 6)
                corazon.cubicTo(ox - 9, oy - 1, ox - 5, oy - 9, ox, oy - 4)
                corazon.cubicTo(ox + 5, oy - 9, ox + 9, oy - 1, ox, oy + 6)
                p.drawPath(corazon)
        elif self.look == "halloween":
            p.setBrush(color)
            for ox, oy in ojos:
                tri = QtGui.QPolygonF([QtCore.QPointF(ox - 6.5 * grande, oy + 6),
                                       QtCore.QPointF(ox, oy + 6 - 12 * grande * (alto / 13)),
                                       QtCore.QPointF(ox + 6.5 * grande, oy + 6)])
                p.drawPolygon(tri)
        else:
            p.setBrush(color)
            for ox, oy in ojos:
                w, h = 11 * grande, alto * grande
                p.drawRoundedRect(QtCore.QRectF(ox - w / 2, oy - h / 2 - 1, w, h), min(w, h) / 2, min(w, h) / 2)

        # la boca
        abre = 1.0
        if self.estado == "hablando":
            abre = 0.6 + 1.4 * (0.5 + 0.5 * math.sin(ahora * math.pi * 2 / 0.6))
        if self.look == "halloween":
            boca = QtGui.QPainterPath()
            boca.moveTo(-8, 11)
            for i, x in enumerate(range(-5, 9, 3)):
                boca.lineTo(x, 13 if i % 2 == 0 else 11)
            boca.quadTo(0, 11 + 6 * abre, -8, 11)
            p.setBrush(color); p.setPen(Qt.NoPen); p.drawPath(boca)
        else:
            pluma = QtGui.QPen(color, 2.4); pluma.setCapStyle(Qt.RoundCap)
            p.setPen(pluma); p.setBrush(Qt.NoBrush)
            boca = QtGui.QPainterPath()
            boca.moveTo(-4.5, 12)
            boca.quadTo(0, 12 + 2.6 * abre, 4.5, 12)
            p.drawPath(boca)

        # los sombreros de temporada
        p.setPen(Qt.NoPen)
        if self.look == "halloween":
            p.setBrush(QtGui.QColor("#7a3ad8"))
            p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(-8, -10), QtCore.QPointF(1, -30), QtCore.QPointF(8, -10)]))
            p.drawRoundedRect(QtCore.QRectF(-15, -11, 30, 3), 1.5, 1.5)
        elif self.look == "navidad":
            p.setBrush(QtGui.QColor("#e53950"))
            gorro = QtGui.QPainterPath(); gorro.moveTo(-12, -10); gorro.quadTo(0, -29, 15, -19); gorro.lineTo(11, -10)
            p.drawPath(gorro)
            p.setBrush(QtGui.QColor("#ffffff"))
            p.drawEllipse(QtCore.QPointF(16, -19), 3, 3)
            p.drawRoundedRect(QtCore.QRectF(-14, -12, 28, 4), 2, 2)
        p.restore()


def dibujar_icono(p, nombre, c, color):
    pluma = QtGui.QPen(color, 1.8)
    pluma.setCapStyle(Qt.RoundCap); pluma.setJoinStyle(Qt.RoundJoin)
    p.setPen(pluma); p.setBrush(Qt.NoBrush)
    x, y = c.x(), c.y()
    if nombre == "orden":
        p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(x - 6, y - 8), QtCore.QPointF(x + 7, y - 1),
                                       QtCore.QPointF(x + 1, y + 1), QtCore.QPointF(x - 2, y + 8)]))
    elif nombre == "dictar":
        p.drawRoundedRect(QtCore.QRectF(x - 3, y - 9, 6, 11), 3, 3)
        arco = QtGui.QPainterPath(); arco.moveTo(x - 7, y - 1); arco.quadTo(x - 7, y + 6, x, y + 6)
        arco.quadTo(x + 7, y + 6, x + 7, y - 1); p.drawPath(arco)
        p.drawLine(QtCore.QPointF(x, y + 6), QtCore.QPointF(x, y + 9))
    elif nombre == "escribir":
        p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(x - 7, y + 8), QtCore.QPointF(x - 7, y + 4),
                                       QtCore.QPointF(x + 4, y - 7), QtCore.QPointF(x + 8, y - 3),
                                       QtCore.QPointF(x - 3, y + 8)]))
    elif nombre == "achicar":
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(x - 6, y + 3), QtCore.QPointF(x, y - 3), QtCore.QPointF(x + 6, y + 3)]))
    elif nombre == "cerrar":
        p.drawLine(QtCore.QPointF(x - 5, y - 5), QtCore.QPointF(x + 5, y + 5))
        p.drawLine(QtCore.QPointF(x + 5, y - 5), QtCore.QPointF(x - 5, y + 5))
    elif nombre in ("anterior", "siguiente"):
        lado = -1 if nombre == "anterior" else 1
        p.setBrush(color)
        p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(x - 4 * lado, y - 6), QtCore.QPointF(x + 4 * lado, y),
                                       QtCore.QPointF(x - 4 * lado, y + 6)]))
        p.drawLine(QtCore.QPointF(x + 6 * lado, y - 6), QtCore.QPointF(x + 6 * lado, y + 6))
    elif nombre == "play":
        p.setBrush(color)
        p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(x - 4, y - 7), QtCore.QPointF(x + 7, y), QtCore.QPointF(x - 4, y + 7)]))
    elif nombre == "pausa":
        p.setBrush(color)
        p.drawRoundedRect(QtCore.QRectF(x - 6, y - 7, 4, 14), 1, 1)
        p.drawRoundedRect(QtCore.QRectF(x + 2, y - 7, 4, 14), 1, 1)
    elif nombre == "modos":
        for dx in (-6, 0, 6):
            p.setBrush(color); p.drawEllipse(QtCore.QPointF(x + dx, y), 1.6, 1.6)
    elif nombre == "mandar":
        p.drawLine(QtCore.QPointF(x, y + 7), QtCore.QPointF(x, y - 7))
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(x - 6, y - 1), QtCore.QPointF(x, y - 7), QtCore.QPointF(x + 6, y - 1)]))


class BotonIcono(QtWidgets.QAbstractButton):
    """Un botón redondo con un ícono dibujado (como los del dock)."""

    def __init__(self, nombre, ayuda, panel, lleno=False, lado=32):
        super().__init__()
        self.nombre, self.panel, self.lleno = nombre, panel, lleno
        self.setToolTip(ayuda); self.setFixedSize(lado, lado); self.setCursor(Qt.PointingHandCursor)

    def enterEvent(self, e):
        self.update()

    def leaveEvent(self, e):
        self.update()

    def paintEvent(self, _e):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        acento = QtGui.QColor(self.panel.acento)
        centro = QtCore.QPointF(self.width() / 2, self.height() / 2)
        if self.lleno:
            p.setPen(Qt.NoPen); p.setBrush(acento); p.drawEllipse(centro, self.width() / 2, self.height() / 2)
            color = QtGui.QColor("#ffffff" if self.panel.cara.look == "blanco" else "#00151d")
        else:
            encima = self.underMouse()
            if encima:
                p.setPen(Qt.NoPen); p.setBrush(QtGui.QColor("#1d2126")); p.drawEllipse(centro, 15, 15)
            color = acento if encima else QtGui.QColor("#d7dde2")
        dibujar_icono(p, self.nombre, centro, color)
        p.end()


# ---------- La píldora ----------

class Pildora(QtWidgets.QWidget):
    def __init__(self, enlace):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.setWindowTitle("JARVIS · Píldora")
        self.enlace = enlace
        self.cara = Cara()
        self.forma = "reposo"
        self.actual = list(FORMAS["reposo"])  # ancho, alto, radio dibujados ahora (se animan hacia la forma)
        self.cx, self.y = None, 4
        self.encima = False
        self.volver_en = 0.0
        self.cartel_hasta = 0.0
        self.texto = ""
        self.texto_desde = 0.0
        self.tarjeta = ("", [])
        self.boton_encima = None
        self.apretado = None
        self.arrastrando = False
        self.oculta = False
        self.siguiendo = False  # después de contestar, te sigue escuchando con la respuesta a la vista
        self.musica = None
        self.tapa = None
        self.musica_vista = None
        # jugando (o un video a pantalla completa) la píldora se esconde; con un tema nuevo o un atajo de música se
        # asoma unos segundos, translúcida y sin agarrar clics (no te saca del juego), y se vuelve a esconder
        self.tapada = False
        self.asomada_hasta = 0.0
        self.opacidad_normal = 1.0
        self.clic_pendiente = QtCore.QTimer(self, singleShot=True, interval=260, timeout=self._clic_simple)
        self.reloj = QtCore.QTimer(self, interval=16, timeout=self._cuadro)
        self.reloj.start()

    # --- posición y tamaño ---
    def _ubicar(self, ancho, alto):
        pantalla = (self.screen() or QtWidgets.QApplication.primaryScreen()).availableGeometry()
        if self.cx is None:
            self.cx = pantalla.center().x()
        w, h = int(ancho + 2 * MARGEN), int(alto + MARGEN + MARGEN_ABAJO)
        x = int(min(max(self.cx - w / 2, pantalla.left()), pantalla.right() - w))
        self.setGeometry(x, int(self.y), w, h)

    def poner_forma(self, nombre):
        if nombre not in FORMAS or nombre == self.forma:
            return
        self.forma = nombre
        # la ventana toma el tamaño más grande (lo de antes o lo de después) mientras dura la animación
        w = max(self.actual[0], FORMAS[nombre][0])
        h = max(self.actual[1], FORMAS[nombre][1])
        self._ubicar(w, h)

    def rect_forma(self):
        w, h, r = self.actual
        return QtCore.QRectF(self.width() / 2 - w / 2, MARGEN, w, h), r

    def centro_cara(self):
        caja, _r = self.rect_forma()
        w, h, _ = self.actual
        if self.forma == "dock":
            return caja.left() + w / 2, caja.top() + min(36, h / 2)
        if self.forma in ("cartel", "tarjeta"):
            t = min(1.0, max(0.0, (w - 132) / 300))
            return caja.left() + mezclar(w / 2, 52, t), caja.top() + (32 if self.forma == "cartel" else 30)
        return caja.left() + w / 2, caja.top() + h / 2

    def listo(self):
        return all(abs(self.actual[i] - FORMAS[self.forma][i]) < 2 for i in range(3))

    def botones(self):
        caja, _r = self.rect_forma()
        cx = caja.center().x()
        if self.forma == "dock" and self.actual[1] >= 100:
            y = caja.bottom() - 27
            return [("orden", QtCore.QPointF(cx - 42, y)), ("dictar", QtCore.QPointF(cx, y)), ("escribir", QtCore.QPointF(cx + 42, y))]
        if self.forma in ("cartel", "tarjeta") and self.encima and self.listo():
            y = caja.center().y() if self.forma == "cartel" else caja.bottom() - 22
            derecha = caja.right() - 24
            return [(n, QtCore.QPointF(derecha - (3 - i) * 32, y)) for i, n in enumerate(ACCIONES)]
        if self.forma == "musica" and self.listo():
            y = caja.center().y() + 2
            derecha = caja.right() - 24
            play = "play" if (self.musica or {}).get("pausado") else "pausa"
            return [(n, QtCore.QPointF(derecha - (3 - i) * 32, y))
                    for i, n in enumerate(["anterior", play, "siguiente", "modos"])]
        return []

    # --- cada cuadro (60 por segundo) ---
    def _cuadro(self):
        ahora = time.time()
        objetivo = FORMAS[self.forma]
        cambio = False
        for i in range(3):
            if abs(self.actual[i] - objetivo[i]) > 0.3:
                self.actual[i] += (objetivo[i] - self.actual[i]) * 0.22
                cambio = True
            else:
                self.actual[i] = objetivo[i]
        if not cambio and (self.width() != objetivo[0] + 2 * MARGEN or self.height() != objetivo[1] + MARGEN + MARGEN_ABAJO):
            self._ubicar(objetivo[0], objetivo[1])  # terminó la animación: la ventana se ajusta a la forma
        # la cara mira al mouse
        pos = QtGui.QCursor.pos()
        g = self.geometry()
        cx, cy = self.centro_cara()
        dx, dy = pos.x() - (g.x() + cx), pos.y() - (g.y() + cy)
        distancia = max(math.hypot(dx, dy), 1)
        fuerza = min(distancia / 260, 1.0)
        self.cara.mirada_obj = [dx / distancia * fuerza, dy / distancia * fuerza]
        self.cara.paso()
        # ¿el mouse está encima? (se mira en cada cuadro: más seguro que esperar los avisos de Windows)
        if self.isVisible() and self.apretado is None:
            local = QtCore.QPointF(pos.x() - g.x(), pos.y() - g.y())
            sobre = self._sobre_forma(local)
            if sobre and not self.encima:
                self.encima = True
                if self.forma == "reposo":
                    self.poner_forma("musica" if self.musica else "dock")
            elif not sobre and self.encima:
                self._salio()
            self.boton_encima = self._boton_en(local) if sobre else None
        # volver al reposo cuando corresponde
        if self.volver_en and ahora > self.volver_en:
            self.volver_en = 0.0
            if self.encima or self.siguiendo or self.cara.estado == "escuchando":
                self.volver_en = ahora + 1.0  # se queda mientras la mirás o mientras te escucha
            elif ahora > self.cartel_hasta:
                self.poner_forma("reposo")
        self.update()

    def volver_al_reposo(self, segundos):
        self.volver_en = time.time() + segundos

    # --- dibujo ---
    def paintEvent(self, _e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.setRenderHint(QtGui.QPainter.TextAntialiasing)
        caja, r = self.rect_forma()
        # sombra suave (varias capas con poca opacidad)
        for i in range(8, 0, -1):
            sombra = caja.adjusted(-i * 0.6, -i * 0.3 + 3, i * 0.6, i * 1.0 + 3)
            p.setPen(Qt.NoPen)
            p.setBrush(QtGui.QColor(0, 0, 0, int(14 + (8 - i) * 3)))
            p.drawRoundedRect(sombra, r + i * 0.6, r + i * 0.6)
        # la píldora
        fondo = QtGui.QLinearGradient(caja.topLeft(), caja.bottomLeft())
        fondo.setColorAt(0, QtGui.QColor("#14171a")); fondo.setColorAt(0.45, QtGui.QColor("#060708")); fondo.setColorAt(1, QtGui.QColor("#000000"))
        p.setBrush(fondo)
        p.setPen(QtGui.QPen(QtGui.QColor("#2b2f33"), 1))
        p.drawRoundedRect(caja, r, r)
        # brillo de escucha: el borde se ilumina con tu voz
        if self.cara.estado == "escuchando":
            c = QtGui.QColor(COLORES.get(self.cara.look, "#29d9ff"))
            for i in range(4):
                c.setAlphaF(max(0.05, min(0.9, 0.2 + self.cara.nivel)) * (0.5 ** i))
                p.setPen(QtGui.QPen(c, 1.6 + i * 1.6)); p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(caja.adjusted(1 + i, 1 + i, -1 - i, -1 - i), max(1, r - i), max(1, r - i))
        p.save()
        recorte = QtGui.QPainterPath(); recorte.addRoundedRect(caja, r, r)
        p.setClipPath(recorte)
        cx, cy = self.centro_cara()
        if self.forma != "musica":  # en la música va la tapa del disco en su lugar
            self.cara.dibujar(p, cx, cy, 0.85 if self.forma == "tarjeta" else 1.0)
        listo = self.listo()
        if self.forma == "cartel" and listo:
            self._cartel(p, caja)
        elif self.forma == "tarjeta" and listo:
            self._tarjeta(p, caja)
        elif self.forma == "musica" and listo:
            self._musica(p, caja)
        elif self.forma == "reposo" and self.musica and not self.musica.get("pausado"):
            self._ecualizador(p, caja)
        botones = self.botones()
        if botones and self.forma in ("cartel", "tarjeta"):  # un fondito para que los botones se lean sobre el texto
            primero = botones[0][1]
            fondo = QtGui.QLinearGradient(primero.x() - 40, 0, primero.x() - 14, 0)
            fondo.setColorAt(0, QtGui.QColor(0, 0, 0, 0)); fondo.setColorAt(1, QtGui.QColor(0, 0, 0, 235))
            p.setPen(Qt.NoPen); p.setBrush(fondo)
            p.drawRect(QtCore.QRectF(primero.x() - 40, primero.y() - 18, caja.right() - primero.x() + 40, 36))
        for nombre, centro in botones:
            self._icono(p, nombre, centro, nombre == self.boton_encima)
        p.restore()
        p.end()

    def _icono(self, p, nombre, c, encima):
        acento = QtGui.QColor(ACENTO.get(self.cara.look, "#29d9ff"))
        if encima:
            p.setPen(Qt.NoPen); p.setBrush(QtGui.QColor("#1d2126")); p.drawEllipse(c, 15, 15)
        dibujar_icono(p, nombre, c, acento if encima else QtGui.QColor("#d7dde2"))

    def _ecualizador(self, p, caja):
        """En reposo, si suena música: tres barritas que bailan al costado de la cara."""
        color = QtGui.QColor(COLORES.get(self.cara.look, "#29d9ff")); color.setAlphaF(0.85)
        p.setPen(Qt.NoPen); p.setBrush(color)
        ahora = time.time()
        x0, base = caja.right() - 20, caja.center().y() + 6
        for i in range(3):
            alto = 4 + 8 * (0.5 + 0.5 * math.sin(ahora * (5 + i * 1.7) + i))
            p.drawRoundedRect(QtCore.QRectF(x0 + i * 4, base - alto, 2.6, alto), 1.2, 1.2)

    def _musica(self, p, caja):
        m = self.musica or {}
        tapa = QtCore.QRectF(caja.left() + 14, caja.top() + 13, 52, 52)
        camino = QtGui.QPainterPath(); camino.addRoundedRect(tapa, 10, 10)
        p.save(); p.setClipPath(camino)
        if self.tapa is not None and not self.tapa.isNull():
            p.drawPixmap(tapa, self.tapa, QtCore.QRectF(self.tapa.rect()))
        else:
            p.fillRect(tapa, QtGui.QColor("#1c1f23"))
            dibujar_icono(p, "play", tapa.center(), QtGui.QColor("#5c6670"))
        p.restore()
        izquierda = tapa.right() + 12
        ancho = caja.right() - 24 - 3 * 32 - 22 - izquierda
        f = QtGui.QFont(FUENTE, 10.5); f.setBold(True); p.setFont(f); p.setPen(QtGui.QColor("#eef6fa"))
        p.drawText(QtCore.QPointF(izquierda, caja.top() + 30),
                   QtGui.QFontMetricsF(f).elidedText(m.get("titulo", ""), Qt.ElideRight, ancho))
        f = QtGui.QFont(FUENTE, 9); p.setFont(f); p.setPen(QtGui.QColor("#8b98a3"))
        p.drawText(QtCore.QPointF(izquierda, caja.top() + 47),
                   QtGui.QFontMetricsF(f).elidedText(m.get("artista", ""), Qt.ElideRight, ancho))
        duracion = float(m.get("duracion") or 0)
        if duracion > 0:
            actual = float(m.get("actual") or 0)
            if not m.get("pausado"):
                actual = min(duracion, actual + time.time() - m.get("_recibido", time.time()))
            barra = QtCore.QRectF(izquierda, caja.top() + 56, ancho, 3)
            p.setPen(Qt.NoPen); p.setBrush(QtGui.QColor("#2a2e33")); p.drawRoundedRect(barra, 1.5, 1.5)
            lleno = QtCore.QRectF(barra.left(), barra.top(), barra.width() * actual / duracion, 3)
            p.setBrush(QtGui.QColor(ACENTO.get(self.cara.look, "#29d9ff"))); p.drawRoundedRect(lleno, 1.5, 1.5)

    def mostrar_musica(self, datos):
        if not datos:
            self.musica = None
            if self.forma == "musica":
                self.poner_forma("reposo")
            return
        datos["_recibido"] = time.time()
        if "tapa" in datos:
            self.tapa = None
            if datos["tapa"].startswith("data:"):
                imagen = QtGui.QPixmap()
                imagen.loadFromData(QtCore.QByteArray.fromBase64(datos["tapa"].split(",", 1)[1].encode()))
                self.tapa = imagen
        anterior = (self.musica or {}).get("clave")
        self.musica = datos
        nuevo = datos.get("clave") != anterior and not datos.get("pausado")
        if nuevo and self.tapada:   # jugando: tema nuevo, se asoma sin molestar
            self.asomar(5)
        elif nuevo and self.forma == "reposo" and self.isVisible():   # tema nuevo: se asoma unos segundos (como heynixi)
            self.cartel_hasta = time.time() + 5
            self.poner_forma("musica")
            self.volver_al_reposo(5.2)

    def asomar(self, segundos):
        """La música a la vista unos segundos (un tema nuevo, un atajo, «abrí el panel de música»). Si estás jugando:
        translúcida y los clics la atraviesan (no le saca el foco ni un clic al juego); después se vuelve a esconder."""
        if not self.musica:
            return
        self.asomada_hasta = max(self.asomada_hasta, time.time() + segundos)
        fantasma = self.tapada
        if bool(self.windowFlags() & Qt.WindowTransparentForInput) != fantasma:
            self.setWindowFlag(Qt.WindowTransparentForInput, fantasma)
        self.setWindowOpacity(min(self.opacidad_normal, 0.85) if fantasma else self.opacidad_normal)
        self.poner_forma("musica")
        self.volver_en = 0.0
        self.show()
        QtCore.QTimer.singleShot(int(segundos * 1000) + 100, self._fin_asomo)

    def _fin_asomo(self):
        if time.time() < self.asomada_hasta:
            return   # (otro atajo la dejó más tiempo: lo termina ese)
        self.asomada_hasta = 0.0
        if self.windowFlags() & Qt.WindowTransparentForInput:
            self.setWindowFlag(Qt.WindowTransparentForInput, False)
        self.setWindowOpacity(self.opacidad_normal)
        if self.tapada:
            self.hide()
        else:
            self.show()
            self.volver_al_reposo(0.3)

    def _cartel(self, p, caja):
        p.setPen(QtGui.QColor("#8b98a3"))
        f = QtGui.QFont(FUENTE, 7); f.setBold(True); f.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 1.2)
        p.setFont(f)
        p.drawText(QtCore.QPointF(caja.left() + 20, caja.top() + 14), "JARVIS")
        f = QtGui.QFont(FUENTE, 12)
        p.setFont(f)
        zona = QtCore.QRectF(caja.left() + 92, caja.top(), caja.width() - 114 - (128 if self.encima else 0), caja.height())
        ancho = QtGui.QFontMetricsF(f).horizontalAdvance(self.texto)
        sobra = max(0.0, ancho - zona.width())
        corrido = 0.0
        pasado = time.time() - self.texto_desde - 1.3
        if sobra > 0 and pasado > 0:
            corrido = min(sobra + 10, pasado * 45)
        p.save()
        p.setClipRect(zona)
        p.setPen(QtGui.QColor("#eef6fa"))
        p.drawText(QtCore.QRectF(zona.left() - corrido, zona.top(), ancho + 20, zona.height()),
                   Qt.AlignVCenter | Qt.AlignLeft, self.texto)
        p.restore()

    def _tarjeta(self, p, caja):
        titulo, filas = self.tarjeta
        f = QtGui.QFont(FUENTE, 11); f.setBold(True)
        p.setFont(f); p.setPen(QtGui.QColor("#eef6fa"))
        medida = QtGui.QFontMetricsF(f)
        p.drawText(QtCore.QPointF(caja.left() + 96, caja.top() + 34),
                   medida.elidedText(titulo, Qt.ElideRight, caja.width() - 118))
        f = QtGui.QFont(FUENTE, 10.5); p.setFont(f); p.setPen(QtGui.QColor("#d9e4ea"))
        medida = QtGui.QFontMetricsF(f)
        for i, fila in enumerate(filas[:6]):
            p.drawText(QtCore.QPointF(caja.left() + 22, caja.top() + 76 + i * 22),
                       medida.elidedText(fila, Qt.ElideRight, caja.width() - 44))

    # --- lo que muestra ---
    def mostrar_respuesta(self, texto):
        texto = "".join(c for c in str(texto) if c not in "*#`_").strip()
        if not texto:
            return
        lineas = [l.strip() for l in texto.splitlines() if l.strip()]
        if len(lineas) >= 3:
            self.tarjeta = (lineas[0], lineas[1:7])
            self.cartel_hasta = time.time() + 9
            self.poner_forma("tarjeta")
            self.volver_al_reposo(9.2)
            return
        self.texto = "  ·  ".join(lineas)
        self.texto_desde = time.time() + 0.3
        ancho = QtGui.QFontMetricsF(QtGui.QFont(FUENTE, 12)).horizontalAdvance(self.texto)
        dura = max(3.5, max(0.0, ancho - 366) / 45 + 3.2)
        self.cartel_hasta = time.time() + dura
        self.poner_forma("cartel")
        self.volver_al_reposo(dura + 0.2)

    # --- mouse ---
    def _sobre_forma(self, pos):
        caja, r = self.rect_forma()
        camino = QtGui.QPainterPath(); camino.addRoundedRect(caja, r, r)
        return camino.contains(QtCore.QPointF(pos))

    def _boton_en(self, pos):
        for nombre, c in self.botones():
            if math.hypot(pos.x() - c.x(), pos.y() - c.y()) < 16:
                return nombre
        return None

    def mouseMoveEvent(self, e):
        pos = e.position()
        if self.apretado is not None and e.buttons() & Qt.LeftButton:
            delta = e.globalPosition() - self.apretado
            if self.arrastrando or abs(delta.x()) + abs(delta.y()) > 5:
                self.arrastrando = True
                g = self.geometry()
                self.move(int(self.inicio_ventana.x() + delta.x()), int(self.inicio_ventana.y() + delta.y()))
                return
        sobre = self._sobre_forma(pos)
        if sobre and not self.encima:
            self.encima = True
            if self.forma == "reposo":
                self.poner_forma("musica" if self.musica else "dock")
        elif not sobre and self.encima:
            self._salio()
        self.boton_encima = self._boton_en(pos) if sobre else None
        self.setCursor(Qt.PointingHandCursor if sobre else Qt.ArrowCursor)

    def leaveEvent(self, _e):
        if self.encima:
            self._salio()
        self.boton_encima = None

    def _salio(self):
        self.encima = False
        if self.forma in ("dock", "musica"):
            self.volver_al_reposo(1.3)
        elif self.forma in ("cartel", "tarjeta"):
            self.volver_al_reposo(2.5)  # te dejo terminar de leer

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and self._sobre_forma(e.position()):
            self.apretado = e.globalPosition()
            self.inicio_ventana = self.pos()
            self.arrastrando = False

    def mouseReleaseEvent(self, e):
        if self.apretado is None:
            return
        self.apretado = None
        if self.arrastrando:
            self.arrastrando = False
            g = self.geometry()
            self.cx, self.y = g.x() + g.width() / 2, g.y()
            self.enlace.mandar("pos", [self.cx, self.y])
            return
        boton = self._boton_en(e.position())
        if boton in ("anterior", "siguiente"):
            self.musica_ctl.controlar(boton, self.enlace)
        elif boton in ("play", "pausa"):
            self.musica_ctl.controlar("alternar", self.enlace)
            if self.musica:
                self.musica["pausado"] = not self.musica.get("pausado")  # se ve enseguida (después confirma Windows)
        elif boton == "modos":
            self.poner_forma("dock")
        elif boton == "cerrar":
            self.siguiendo = False
            self.cartel_hasta = 0
            self.enlace.mandar("callar_seguimiento")
            self.poner_forma("reposo")
        elif boton:
            self.siguiendo = False
            self.enlace.mandar("boton", boton)
        else:
            self.clic_pendiente.start()  # ¿clic o doble clic?

    def mouseDoubleClickEvent(self, e):
        self.clic_pendiente.stop()
        if self._sobre_forma(e.position()) and not self._boton_en(e.position()):
            self.enlace.mandar("panel", True)

    def _clic_simple(self):
        self.enlace.mandar("boton", "orden")


# ---------- El panel de chat ----------

class Encabezado(QtWidgets.QWidget):
    def __init__(self, cara):
        super().__init__()
        self.cara = cara
        self.setFixedHeight(54)

    def paintEvent(self, _e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        self.cara.dibujar(p, self.width() / 2, 30)
        p.end()


class Panel(QtWidgets.QWidget):
    ANCHO, ALTO = 620, 560

    def __init__(self, enlace, cara):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowTitle("JARVIS · Chat")
        self.enlace, self.cara = enlace, cara
        self.pestana = "chat"
        self.vacio = None
        self.resize(self.ANCHO + 2 * MARGEN, self.ALTO + MARGEN + MARGEN_ABAJO)
        self.acento = "#29d9ff"

        caja = QtWidgets.QVBoxLayout(self)
        caja.setContentsMargins(MARGEN + 18, MARGEN + 4, MARGEN + 18, MARGEN_ABAJO + 14)
        caja.setSpacing(8)
        self.encabezado = Encabezado(cara)
        caja.addWidget(self.encabezado)

        barra = QtWidgets.QHBoxLayout()
        puntos = QtWidgets.QLabel("••••"); puntos.setStyleSheet("color:#8b98a3; letter-spacing:2px;")
        self.estado = QtWidgets.QLabel("Listo — decí «Jarvis»")
        self.estado.setStyleSheet("color:#8b98a3; font-size:15px;")
        barra.addWidget(puntos); barra.addWidget(self.estado, 1)
        for nombre, ayuda in (("orden", "Orden"), ("dictar", "Dictar en la ventana que estabas usando"),
                              ("escribir", "Escribir"), ("achicar", "Achicar (Ctrl+Alt+J)")):
            b = BotonIcono(nombre, ayuda, self)
            b.clicked.connect(lambda _=False, n=nombre: self._boton(n))
            barra.addWidget(b)
        caja.addLayout(barra)

        pestanas = QtWidgets.QHBoxLayout()
        self.tabs = {}
        fondo = QtWidgets.QFrame(); fondo.setStyleSheet("background:#15181b; border-radius:16px;")
        fila = QtWidgets.QHBoxLayout(fondo); fila.setContentsMargins(3, 3, 3, 3); fila.setSpacing(0)
        for clave, texto in (("chat", "Chat"), ("historial", "Historial")):
            b = QtWidgets.QPushButton(texto); b.setCursor(Qt.PointingHandCursor); b.setFixedHeight(28)
            b.clicked.connect(lambda _=False, c=clave: self.cambiar_pestana(c))
            fila.addWidget(b); self.tabs[clave] = b
        pestanas.addWidget(fondo); pestanas.addStretch(1)
        caja.addLayout(pestanas)

        self.scroll = QtWidgets.QScrollArea(); self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("QScrollArea{background:transparent;border:0} QScrollBar:vertical{width:6px;background:transparent}"
                                  "QScrollBar::handle:vertical{background:#2a2e33;border-radius:3px}"
                                  "QScrollBar::add-line,QScrollBar::sub-line{height:0}")
        self.lista_w = QtWidgets.QWidget(); self.lista_w.setStyleSheet("background:transparent")
        self.lista = QtWidgets.QVBoxLayout(self.lista_w); self.lista.setContentsMargins(4, 4, 8, 4); self.lista.setSpacing(4)
        self.lista.addStretch(1)
        self.scroll.setWidget(self.lista_w)
        caja.addWidget(self.scroll, 1)

        entrada = QtWidgets.QHBoxLayout()
        self.caja = QtWidgets.QLineEdit(); self.caja.setPlaceholderText("Preguntale a JARVIS…")
        self.caja.returnPressed.connect(self._mandar)
        self.caja.setFixedHeight(44)
        self.mandar_b = BotonIcono("mandar", "Mandar", self, lleno=True, lado=44)
        self.mandar_b.clicked.connect(self._mandar)
        entrada.addWidget(self.caja, 1); entrada.addWidget(self.mandar_b)
        caja.addLayout(entrada)
        self.aplicar_colores()
        QtGui.QShortcut(QtGui.QKeySequence("Esc"), self, activated=lambda: self.enlace.mandar("panel", False))
        self.reloj = QtCore.QTimer(self, interval=33, timeout=self.encabezado.update)

    def aplicar_colores(self):
        self.acento = ACENTO.get(self.cara.look, "#29d9ff")
        self.caja.setStyleSheet(f"QLineEdit{{background:#101215;border:1px solid #2b2f33;border-radius:22px;color:#eef6fa;"
                                f"font-size:16px;padding:9px 16px}} QLineEdit:focus{{border-color:{self.acento}}}")
        self.update()
        for clave, b in self.tabs.items():
            activa = clave == self.pestana
            b.setStyleSheet(f"QPushButton{{background:{'#2a2e33' if activa else 'transparent'};color:{'#fff' if activa else '#8b98a3'};"
                            "border:0;border-radius:13px;padding:0 24px;font-size:14px;font-weight:600}")

    def paintEvent(self, _e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        caja = QtCore.QRectF(MARGEN, MARGEN, self.ANCHO, self.ALTO)
        for i in range(8, 0, -1):
            p.setPen(Qt.NoPen); p.setBrush(QtGui.QColor(0, 0, 0, int(14 + (8 - i) * 3)))
            p.drawRoundedRect(caja.adjusted(-i * 0.6, -i * 0.3 + 3, i * 0.6, i + 3), 24 + i * 0.6, 24 + i * 0.6)
        p.setBrush(QtGui.QColor("#000000")); p.setPen(QtGui.QPen(QtGui.QColor("#2b2f33"), 1))
        p.drawRoundedRect(caja, 24, 24)
        p.end()

    def _boton(self, nombre):
        if nombre == "achicar":
            self.enlace.mandar("panel", False)
        else:
            self.enlace.mandar("boton", nombre)

    def _limpiar(self):
        self.vacio = None
        while self.lista.count() > 1:
            item = self.lista.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def agregar(self, de, texto, hora=True):
        if self.pestana != "chat":
            return
        if self.vacio is not None:
            self.vacio.deleteLater()
            self.vacio = None
        fila = QtWidgets.QHBoxLayout()
        globo = QtWidgets.QLabel(str(texto)); globo.setWordWrap(True)
        globo.setTextInteractionFlags(Qt.TextSelectableByMouse)
        globo.setMaximumWidth(int(self.ANCHO * 0.72))
        if de == "vos":
            texto_c = "#ffffff" if self.cara.look == "blanco" else "#00151d"
            globo.setStyleSheet(f"background:{self.acento};color:{texto_c};border-radius:14px;border-bottom-right-radius:4px;padding:7px 12px;font-size:15px")
            fila.addStretch(1); fila.addWidget(globo)
        else:
            globo.setStyleSheet("background:#1c1f23;color:#eef6fa;border-radius:14px;border-bottom-left-radius:4px;padding:7px 12px;font-size:15px")
            fila.addWidget(globo); fila.addStretch(1)
        contenedor = QtWidgets.QWidget(); contenedor.setLayout(fila); fila.setContentsMargins(0, 0, 0, 0)
        self.lista.insertWidget(self.lista.count() - 1, contenedor)
        if hora:
            h = QtWidgets.QLabel(time.strftime("%H:%M")); h.setStyleSheet("color:#8b98a3;font-size:11px")
            h.setAlignment(Qt.AlignRight if de == "vos" else Qt.AlignLeft)
            self.lista.insertWidget(self.lista.count() - 1, h)
        QtCore.QTimer.singleShot(30, lambda: self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum()))

    def mostrar_chat(self, mensajes):
        self._limpiar()
        if not mensajes:
            self.vacio = QtWidgets.QLabel("Decime algo, o escribí abajo"); self.vacio.setAlignment(Qt.AlignCenter)
            self.vacio.setStyleSheet("color:#8b98a3;font-size:14px;padding-top:150px")
            self.lista.insertWidget(0, self.vacio)
            return
        for m in mensajes:
            self.agregar(m["de"], m["texto"], hora=False)

    def mostrar_historial(self, charlas):
        self._limpiar()
        for c in charlas:
            b = QtWidgets.QPushButton(); b.setCursor(Qt.PointingHandCursor)
            fila = QtWidgets.QHBoxLayout(b); fila.setContentsMargins(10, 6, 10, 6)
            titulo = QtWidgets.QLabel(c.get("titulo") or "Charla sin título"); titulo.setStyleSheet("color:#eef6fa;font-size:15px;background:transparent")
            cuando = QtWidgets.QLabel("ahora" if c.get("actual") else c.get("cuando", "")); cuando.setStyleSheet(f"color:{self.acento};font-size:12px;background:transparent")
            fila.addWidget(titulo, 1); fila.addWidget(cuando)
            b.setFixedHeight(38)
            b.setStyleSheet("QPushButton{background:transparent;border:0;border-radius:10px;text-align:left} QPushButton:hover{background:#121518}")
            b.clicked.connect(lambda _=False, i=c.get("id"): (self.cambiar_pestana("chat", pedir=False), self.enlace.mandar("abrir_charla", i)))
            self.lista.insertWidget(self.lista.count() - 1, b)

    def cambiar_pestana(self, cual, pedir=True):
        self.pestana = cual
        self.aplicar_colores()
        if pedir:
            self.enlace.mandar("pedir", "charlas" if cual == "historial" else "charla")

    def _mandar(self):
        texto = self.caja.text().strip()
        if not texto:
            return
        self.caja.clear()
        self.agregar("vos", texto)
        if any(g in texto.lower() for g in ("gracias", "grax", "thank")):
            self.cara.corazones_hasta = time.time() + 2.6
        self.enlace.mandar("enviar", texto)

    def abrir(self, pildora):
        g = pildora.geometry()
        pantalla = (pildora.screen() or QtWidgets.QApplication.primaryScreen()).availableGeometry()
        x = int(min(max(g.x() + g.width() / 2 - self.width() / 2, pantalla.left()), pantalla.right() - self.width()))
        y = int(min(g.y(), pantalla.bottom() - self.height()))
        self.move(x, y)
        self.show(); self.raise_(); self.activateWindow()
        self.reloj.start()
        self.caja.setFocus()
        self.cambiar_pestana("chat")

    def cerrar(self):
        self.reloj.stop()
        self.hide()


# ---------- Todo junto ----------

class App:
    def __init__(self, puerto):
        self.enlace = Enlace(puerto)
        self.pildora = Pildora(self.enlace)
        self.panel = Panel(self.enlace, self.pildora.cara)
        self.musica = Musica()
        self.pildora.musica_ctl = self.musica
        self.musica.cambio.connect(self._musica)
        self.enlace.llego.connect(self.recibir)
        self.pildora._ubicar(*FORMAS["reposo"][:2])
        self.pildora.show()
        self._bandeja()
        self.enlace.mandar("listo")

    def _musica(self, v):
        self.pildora.cara.baila = bool(v and not v.get("pausado"))
        self.pildora.mostrar_musica(v)

    def _bandeja(self):
        import os
        icono = QtGui.QIcon(os.path.join(os.path.dirname(os.path.abspath(__file__)), "interfaz", "jarvis.ico"))
        self.bandeja = QtWidgets.QSystemTrayIcon(icono)
        self.bandeja.setToolTip("JARVIS")
        menu = QtWidgets.QMenu()
        menu.setStyleSheet("QMenu{background:#0b0d10;color:#eef6fa;border:1px solid #2b2f33;padding:4px}"
                           "QMenu::item{padding:6px 22px;border-radius:6px} QMenu::item:selected{background:#1d2126}"
                           "QMenu::separator{height:1px;background:#2b2f33;margin:4px 8px}")
        for texto, accion in (("Abrir JARVIS", "abrir"), ("Chat (Ctrl+Alt+J)", "chat"), (None, None),
                              ("Mostrar / esconder la píldora", "pildora"), ("Configuraciones", "ajustes"),
                              ("Chequeo del sistema", "chequeo"), ("Exportar mis datos", "exportar"), (None, None),
                              ("Apagar JARVIS", "apagar")):
            if texto is None:
                menu.addSeparator()
                continue
            menu.addAction(texto, lambda a=accion: self._menu(a))
        self.bandeja.setContextMenu(menu)
        self.bandeja.activated.connect(lambda motivo: self._menu("abrir")
                                       if motivo == QtWidgets.QSystemTrayIcon.Trigger else None)
        self.bandeja.show()
        self._menu_vivo = menu

    def _menu(self, accion):
        if accion == "chat":
            self.recibir({"t": "panel", "v": "alternar"})
        elif accion == "pildora":
            self.pildora.setVisible(not self.pildora.isVisible())
        else:
            self.enlace.mandar("bandeja", accion)

    def recibir(self, m):
        t, v = m.get("t"), m.get("v")
        cara = self.pildora.cara
        if t == "pos" and v:
            self.pildora.cx, self.pildora.y = v
            self.pildora._ubicar(*self.pildora.actual[:2])
        elif t == "look":
            cara.look = v if v in COLORES else "celeste"
            self.panel.aplicar_colores()
        elif t == "estado":
            cara.estado = v
            if v == "escuchando" and self.pildora.forma in ("reposo", "musica"):
                self.pildora.poner_forma("dock")
            if v == "libre":
                cara.nivel = 0
                self.pildora.volver_al_reposo(1.6)
            textos = {"libre": "Listo — decí «Jarvis»", "escuchando": "Te escucho…", "pensando": "Pensando…", "hablando": "Hablando…"}
            self.panel.estado.setText(textos.get(v, str(v)))
        elif t == "nivel":
            cara.nivel = float(v or 0)
        elif t in ("voz", "oido"):
            if any(g in str(v).lower() for g in ("gracias", "grax", "thank")):
                cara.corazones_hasta = time.time() + 2.6
            if t == "voz" and self.panel.isVisible():
                self.panel.agregar("vos", v)
        elif t == "jarvis":
            if self.panel.isVisible():
                self.panel.agregar("jarvis", v["texto"])
                self.panel.estado.setText(str(v["texto"]).split("\n")[0][:90])
            elif v.get("cartel"):
                self.pildora.mostrar_respuesta(v["texto"])
        elif t == "cartel":
            if not self.panel.isVisible():
                self.pildora.mostrar_respuesta(v)
        elif t == "musica_jarvis":
            self.musica.jarvis_dice(v)
        elif t == "seguimiento":
            self.pildora.siguiendo = bool(v)
            if not v:
                self.pildora.volver_al_reposo(1.2)
        elif t == "opacidad":
            self.pildora.opacidad_normal = max(0.3, min(1.0, float(v) / 100))
            self.pildora.setWindowOpacity(self.pildora.opacidad_normal)
        elif t == "ocultar":
            self.pildora.tapada = bool(v)
            if v and not self.panel.isVisible() and time.time() >= self.pildora.asomada_hasta:
                self.pildora.hide()
            elif not v:
                self.pildora.show()
        elif t == "asomar":   # un atajo de música, o «abrí el panel de música»
            self.pildora.asomar(float((v or {}).get("segundos") or 5))
        elif t == "musica_fuera":   # «escondé el panel de música»
            self.pildora.asomada_hasta = 0.0
            self.pildora._fin_asomo()
            if self.pildora.forma == "musica":
                self.pildora.poner_forma("reposo")
        elif t == "panel":
            abrir = (not self.panel.isVisible()) if v == "alternar" else bool(v)
            if abrir:
                self.pildora.hide()
                self.panel.abrir(self.pildora)
            else:
                self.panel.cerrar()
                self.pildora.poner_forma("reposo")
                self.pildora.show()
        elif t == "charla":
            if self.panel.pestana == "chat":
                self.panel.mostrar_chat(v)
        elif t == "charlas":
            if self.panel.pestana == "historial":
                self.panel.mostrar_historial(v)
        elif t == "salir":
            QtWidgets.QApplication.quit()


def main():
    app = QtWidgets.QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setFont(QtGui.QFont(FUENTE, 10))
    _todo = App(int(sys.argv[1]))
    # y por las dudas (si el enchufe no avisa): cada 2 segundos se fija que JARVIS siga vivo; si no, se cierra
    padre = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 0
    if padre:
        vigia = QtCore.QTimer(interval=2000, timeout=lambda: None if _vivo(padre) else QtWidgets.QApplication.quit())
        vigia.start()
    sys.exit(app.exec())


def _vivo(pid):
    """¿Sigue abierto el proceso de JARVIS?"""
    import ctypes
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    try:
        codigo = ctypes.c_ulong()
        return bool(k32.GetExitCodeProcess(h, ctypes.byref(codigo))) and codigo.value == 259   # STILL_ACTIVE
    finally:
        k32.CloseHandle(h)


if __name__ == "__main__":
    main()
