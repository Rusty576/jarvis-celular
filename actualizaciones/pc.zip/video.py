"""Videos: JARVIS mira videos (archivos que le pasás o links de YouTube) y graba tu pantalla.

  - Archivos (mp4, mkv, mov, avi, webm...): saca cuadros repartidos por todo el video y escucha el audio
    (lo pasa a texto con el reconocimiento de voz de Google, el mismo del micrófono; necesita internet).
  - YouTube: lee los subtítulos (con el minuto de cada parte) y mira las miniaturas de vista previa del video.
    No descarga el video.
  - Pantalla: graba unos segundos lo que hacés (escondiendo a JARVIS), lo guarda en "grabaciones" y lo mira.
La IA local ve las imágenes en "hojas" de 4 cuadros, cada uno con su minuto marcado en amarillo.
"""
import base64
import datetime
import io
import os
import re
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA_GRABACIONES = os.path.join(BASE, "grabaciones")
EXT_VIDEO = {".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv", ".m4v", ".flv", ".mpg", ".mpeg", ".3gp", ".ts"}
YOUTUBE = re.compile(r"(?:https?://)?(?:www\.|m\.|music\.)?(?:youtube\.com/(?:watch\?(?:[^\s#]*?&)?v=|shorts/|live/|embed/)"
                     r"|youtu\.be/)([\w-]{11})")
CUADROS = 8              # cuántos momentos del video mira (en 2 hojas de 4: entra cómodo en la memoria de la IA)
MAX_TRANSCRIPCION = 9000  # letras de lo que se dice en el video
MINUTOS_AUDIO = 6        # del audio de un archivo escucha como mucho los primeros 6 minutos (más tarda mucho)
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"}

PROMPT_GRABACION = """Ves cuadros de una grabación de la pantalla del usuario (su computadora), en orden. Cada imagen junta
4 momentos (arriba a la izquierda, arriba a la derecha, abajo a la izquierda, abajo a la derecha) y cada uno tiene en
amarillo el segundo de la grabación. Respondé en español rioplatense, con "vos", a lo que te pide: contá qué hizo
paso a paso y ayudalo. Si aparece un error, explicá qué significa y cómo arreglarlo. Si algo no se lee bien,
decilo: NO inventes texto ni pasos que no se ven."""


def mmss(segundos):
    s = int(segundos or 0)
    h, r = divmod(s, 3600)
    m, s = divmod(r, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def es_video(nombre):
    return os.path.splitext(nombre)[1].lower() in EXT_VIDEO


def id_youtube(texto):
    m = YOUTUBE.search(texto or "")
    return m.group(1) if m else None


def _detalle(texto):
    if jarvis:
        jarvis.emitir("detalle", texto)


# ----------------------------------------------------------------- imágenes para la IA

def hojas(cuadros, por_hoja=4, ancho=1024):
    """[(segundo, imagen PIL)] -> lista de JPEG en base64: 4 cuadros en 2x2, cada uno con su minuto marcado."""
    from PIL import Image, ImageDraw, ImageFont

    try:
        letra = ImageFont.load_default(size=20)
    except Exception:
        letra = ImageFont.load_default()
    salida = []
    for k in range(0, len(cuadros), por_hoja):
        grupo = cuadros[k:k + por_hoja]
        columnas = 1 if len(grupo) == 1 else 2
        filas = (len(grupo) + columnas - 1) // columnas
        w0, h0 = grupo[0][1].size
        celda_w = ancho // columnas
        celda_h = max(1, int(celda_w * h0 / max(1, w0)))
        hoja = Image.new("RGB", (celda_w * columnas, celda_h * filas), "black")
        dibujo = ImageDraw.Draw(hoja)
        for i, (segundo, img) in enumerate(grupo):
            x, y = (i % columnas) * celda_w, (i // columnas) * celda_h
            hoja.paste(img.convert("RGB").resize((celda_w, celda_h)), (x, y))
            etiqueta = mmss(segundo)
            dibujo.rectangle([x, y, x + 14 + 11 * len(etiqueta), y + 28], fill="black")
            dibujo.text((x + 7, y + 4), etiqueta, fill="#ffd34d", font=letra)
        buf = io.BytesIO()
        hoja.save(buf, "JPEG", quality=85)
        salida.append(base64.b64encode(buf.getvalue()).decode())
    return salida


def miniatura(img, lado=320):
    img = img.convert("RGB").copy()
    img.thumbnail((lado, lado))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=80)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


# ----------------------------------------------------------------- archivos de video

def _a_pil(cuadro):
    import cv2
    from PIL import Image

    img = Image.fromarray(cv2.cvtColor(cuadro, cv2.COLOR_BGR2RGB))
    img.thumbnail((960, 960))
    return img


def cuadros_de_archivo(ruta, cantidad=CUADROS):
    """Momentos repartidos por todo el video. Devuelve ([(segundo, imagen)], duración en segundos)."""
    import cv2

    cap = cv2.VideoCapture(ruta)
    if not cap.isOpened():
        raise RuntimeError("no pude abrir el video (¿está dañado o es un formato raro?)")
    try:
        fps = cap.get(cv2.CAP_PROP_FPS) or 0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        cuadros = []
        if total > 0 and fps > 0:
            for k in range(cantidad):
                n = int((k + 0.5) * total / cantidad)
                cap.set(cv2.CAP_PROP_POS_FRAMES, n)
                ok, f = cap.read()
                if ok:
                    cuadros.append((n / fps, _a_pil(f)))
        if len(cuadros) < cantidad // 2:  # el video no dice cuántos cuadros tiene: lo recorre entero
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            vistos, cada, i = [], max(1, int(fps or 25)), 0
            while cap.grab():
                if i % cada == 0:
                    ok, f = cap.retrieve()
                    if ok:
                        vistos.append((i / (fps or 25), _a_pil(f)))
                    if len(vistos) > 4 * cantidad:  # que no se llene la memoria con videos largos
                        vistos, cada = vistos[::2], cada * 2
                i += 1
            paso = max(1, len(vistos) // cantidad)
            cuadros = vistos[paso // 2::paso][:cantidad]
        duracion = total / fps if total > 0 and fps > 0 else (cuadros[-1][0] if cuadros else 0)
        return cuadros, duracion
    finally:
        cap.release()


def primer_cuadro(ruta):
    import cv2

    cap = cv2.VideoCapture(ruta)
    try:
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if total > 10:
            cap.set(cv2.CAP_PROP_POS_FRAMES, min(total // 10, 300))  # el primer cuadro suele ser negro
        ok, f = cap.read()
        return _a_pil(f) if ok else None
    finally:
        cap.release()


def audio_a_texto(ruta, minutos=MINUTOS_AUDIO):
    """Lo que se habla en el video, con el minuto. Devuelve (texto, aviso)."""
    try:
        import av
    except ImportError:
        return "", "no pude escuchar el audio (falta instalar la librería «av»)"
    import speech_recognition as sr

    try:
        contenedor = av.open(ruta)
    except Exception as e:
        return "", f"no pude abrir el audio ({e})"
    try:
        if not contenedor.streams.audio:
            return "", "el video no tiene sonido"
        conversor = av.AudioResampler(format="s16", layout="mono", rate=16000)
        limite = minutos * 60 * 16000 * 2
        pcm = bytearray()
        for cuadro in contenedor.decode(audio=0):
            for c in conversor.resample(cuadro):
                pcm += c.to_ndarray().tobytes()
            if len(pcm) >= limite:
                break
    except Exception as e:
        return "", f"no pude leer el audio ({e})"
    finally:
        contenedor.close()
    pcm = bytes(pcm[:limite])
    if len(pcm) < 16000:
        return "", "el video casi no tiene sonido"

    trozo = 30 * 16000 * 2  # de a 30 segundos (el reconocedor no acepta audios largos)
    partes = [(i // 32000, pcm[i:i + trozo]) for i in range(0, len(pcm), trozo)]
    sin_internet = []

    def reconocer(parte):
        segundo, datos = parte
        try:
            r = sr.Recognizer().recognize_google(sr.AudioData(datos, 16000, 2), language=jarvis.IDIOMA)
            return segundo, r
        except sr.UnknownValueError:
            return segundo, ""
        except Exception:
            sin_internet.append(1)
            return segundo, ""

    _detalle("Escuchando el audio del video...")
    with ThreadPoolExecutor(4) as ex:
        textos = list(ex.map(reconocer, partes))
    lineas = [f"[{mmss(s)}] {t}" for s, t in textos if t]
    aviso = ""
    if len(pcm) >= limite:
        aviso = f"escuché solo los primeros {minutos} minutos del audio"
    if not lineas:
        return "", ("no pude escuchar el audio: hace falta internet" if sin_internet
                    else "no se entiende que hablen (puede ser solo música)")
    return "\n".join(lineas), aviso


def analizar_archivo(ruta):
    _detalle("Mirando el video...")
    cuadros, duracion = cuadros_de_archivo(ruta)
    if not cuadros:
        raise RuntimeError("no pude sacar imágenes del video")
    texto, aviso = audio_a_texto(ruta)
    return {"nombre": os.path.basename(ruta), "origen": "archivo", "ruta": ruta, "duracion": duracion,
            "texto": texto[:MAX_TRANSCRIPCION], "aviso": aviso, "imagenes": hojas(cuadros),
            "miniatura": miniatura(cuadros[0][1])}


# ----------------------------------------------------------------- YouTube

def _bajar(url, timeout=10):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
        return r.read()


def info_youtube(vid):
    import yt_dlp

    with yt_dlp.YoutubeDL({"quiet": True, "skip_download": True, "no_warnings": True, "socket_timeout": 10}) as y:
        return y.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False, process=False)


def transcripcion_youtube(vid):
    """Los subtítulos (en español si hay; si no, los que haya) con el minuto cada ~30 segundos."""
    from youtube_transcript_api import YouTubeTranscriptApi

    lista = YouTubeTranscriptApi().list(vid)
    try:
        elegida = lista.find_transcript(["es", "es-419", "es-ES", "es-MX", "es-US", "es-AR"])
    except Exception:
        elegida = next(iter(lista))
    partes, ultimo = [], -999.0
    for p in elegida.fetch():
        if p.start - ultimo >= 30:
            partes.append(f"\n[{mmss(p.start)}] ")
            ultimo = p.start
        partes.append(p.text.replace("\n", " ") + " ")
    return re.sub(r"[ \t]+", " ", "".join(partes)).strip(), elegida.language_code


def cuadros_youtube(info, cantidad=CUADROS):
    """Las miniaturas de vista previa de YouTube (las que se ven al pasar el mouse por la barra del video)."""
    from PIL import Image

    tableros = [f for f in info.get("formats") or []
                if str(f.get("format_note", "")).startswith("storyboard") and f.get("fragments")]
    if not tableros:
        return []
    sb = max(tableros, key=lambda f: f.get("width") or 0)
    filas, columnas, w, h = sb.get("rows") or 1, sb.get("columns") or 1, sb["width"], sb["height"]
    fragmentos = sb["fragments"]
    inicios, t = [], 0.0
    for fr in fragmentos:
        inicios.append(t)
        t += fr.get("duration") or 0
    duracion = info.get("duration") or t
    if not duracion:
        return []
    pedidos = {}  # hoja -> [(segundo, celda)]
    for k in range(cantidad):
        segundo = (k + 0.5) * duracion / cantidad
        i = max(j for j, s in enumerate(inicios) if s <= segundo)
        dura = fragmentos[i].get("duration") or 1
        celda = min(filas * columnas - 1, int((segundo - inicios[i]) / dura * filas * columnas))
        pedidos.setdefault(i, []).append((segundo, celda))

    def bajar_hoja(i):
        fr = fragmentos[i]
        url = fr.get("url") or (sb.get("fragment_base_url") or "") + (fr.get("path") or "")
        try:
            return i, Image.open(io.BytesIO(_bajar(url))).convert("RGB")
        except Exception:
            return i, None

    with ThreadPoolExecutor(4) as ex:
        imagenes = dict(ex.map(bajar_hoja, list(pedidos)))
    cuadros = []
    for i, lista in pedidos.items():
        hoja = imagenes.get(i)
        if hoja is None:
            continue
        por_fila = max(1, hoja.width // w)
        for segundo, celda in lista:
            x, y = (celda % por_fila) * w, (celda // por_fila) * h
            if y + h <= hoja.height:
                cuadros.append((segundo, hoja.crop((x, y, x + w, y + h))))
    return sorted(cuadros, key=lambda c: c[0])


def analizar_youtube(texto_o_id):
    vid = id_youtube(texto_o_id) or texto_o_id
    _detalle("Mirando el video de YouTube...")
    ex = ThreadPoolExecutor(2)
    f_info = ex.submit(info_youtube, vid)
    f_subs = ex.submit(transcripcion_youtube, vid)
    try:
        info = f_info.result(timeout=25)
    except Exception:
        info = {}
    try:
        subtitulos, idioma = f_subs.result(timeout=20)
    except Exception:
        subtitulos, idioma = "", ""
    ex.shutdown(wait=False)
    if not info and not subtitulos:
        raise RuntimeError("no pude abrir el video de YouTube (¿hay internet? ¿es privado?)")
    try:
        cuadros = cuadros_youtube(info) if info else []
    except Exception:
        cuadros = []
    aviso = ""
    if not subtitulos:
        aviso = "el video no tiene subtítulos, así que no sé lo que se dice"
    elif len(subtitulos) > MAX_TRANSCRIPCION:
        aviso = f"es largo: leí más o menos hasta el minuto {mmss(_ultimo_minuto(subtitulos[:MAX_TRANSCRIPCION]))}"
    elif idioma and not idioma.startswith("es"):
        aviso = f"los subtítulos están en {idioma}"
    return {"nombre": info.get("title") or f"video de YouTube {vid}", "origen": "youtube",
            "url": f"https://www.youtube.com/watch?v={vid}", "canal": info.get("channel") or info.get("uploader") or "",
            "duracion": info.get("duration") or 0, "descripcion": (info.get("description") or "")[:1200],
            "texto": subtitulos[:MAX_TRANSCRIPCION], "aviso": aviso, "imagenes": hojas(cuadros),
            "miniatura": miniatura(cuadros[0][1]) if cuadros else ""}


def _ultimo_minuto(texto):
    marcas = re.findall(r"\[(\d+):(\d+)(?::(\d+))?\]", texto)
    if not marcas:
        return 0
    a, b, c = marcas[-1]
    return int(a) * 3600 + int(b) * 60 + int(c) if c else int(a) * 60 + int(b)


# ----------------------------------------------------------------- para la charla

def contexto(v):
    """El texto que va como sistema para que la IA responda sobre el video."""
    sobre = f"«{v['nombre']}»" + (f" del canal {v['canal']}" if v.get("canal") else "")
    partes = [f"El usuario te pasó un video: {sobre}" + (f", dura {mmss(v['duracion'])}" if v.get("duracion") else "") + "."]
    if v.get("imagenes"):
        partes.append("Tenés adjuntas imágenes del video: cada una junta 4 momentos (arriba a la izquierda, arriba a la "
                      "derecha, abajo a la izquierda, abajo a la derecha), en orden, con el minuto marcado en amarillo.")
    if v.get("texto"):
        partes.append("Lo que se dice en el video (el minuto entre corchetes)"
                      + (f" ({v['aviso']})" if v.get("aviso") else "") + f":\n<<<\n{v['texto']}\n>>>")
    else:
        partes.append("No sabés lo que se dice en el video" + (f" ({v['aviso']})" if v.get("aviso") else "")
                      + ": basate en las imágenes y aclaralo si hace falta.")
    if v.get("descripcion"):
        partes.append(f"Descripción que puso el autor:\n{v['descripcion']}")
    partes.append("Respondé sobre el video con esto. Si algo no se ve ni se dice, decí que no lo podés saber: no inventes. "
                  "Cuando ayude, decí en qué minuto pasa.")
    return "\n\n".join(partes)


# ----------------------------------------------------------------- grabar la pantalla

def grabar_pantalla(segundos=8, fps=2, ocultar=None):
    """Graba la pantalla principal (JARVIS escondido). Devuelve (ruta del mp4, [(segundo, imagen)])."""
    import cv2
    import numpy as np
    from PIL import ImageGrab

    os.makedirs(CARPETA_GRABACIONES, exist_ok=True)
    ruta = os.path.join(CARPETA_GRABACIONES, f"pantalla_{datetime.datetime.now():%Y-%m-%d_%H-%M-%S}.mp4")
    cuadros = []
    if ocultar:
        try:
            ocultar(True)
            time.sleep(0.45)
        except Exception:
            pass
    try:
        inicio = time.time()
        for k in range(max(2, int(segundos * fps))):
            espera = inicio + k / fps - time.time()
            if espera > 0:
                time.sleep(espera)
            img = ImageGrab.grab().convert("RGB")
            img.thumbnail((1280, 1280))
            cuadros.append((time.time() - inicio, img))
    finally:
        if ocultar:
            try:
                ocultar(False)
            except Exception:
                pass
    tam = cuadros[0][1].size
    escritor = cv2.VideoWriter(ruta, cv2.VideoWriter_fourcc(*"mp4v"), fps, tam)
    for _, img in cuadros:
        escritor.write(cv2.cvtColor(np.array(img.resize(tam)), cv2.COLOR_RGB2BGR))
    escritor.release()
    return ruta, cuadros


def cuadros_clave(cuadros, cantidad=CUADROS):
    """El primero, el último y los momentos donde más cambió la pantalla (en orden)."""
    if len(cuadros) <= cantidad:
        return cuadros
    import numpy as np

    chicos = [np.asarray(img.resize((64, 36)).convert("L"), dtype=np.int16) for _, img in cuadros]
    cambios = [0] + [int(np.abs(chicos[i] - chicos[i - 1]).sum()) for i in range(1, len(chicos))]
    medio = sorted(range(1, len(cuadros) - 1), key=lambda i: -cambios[i])[:cantidad - 2]
    return [cuadros[i] for i in sorted({0, len(cuadros) - 1, *medio})]


def analizar_grabacion(ruta, cuadros, pedido):
    """Le muestra a la IA los momentos clave de la grabación. Devuelve (respuesta, datos del video)."""
    elegidos = cuadros_clave(cuadros)
    imagenes = hojas(elegidos)
    duracion = cuadros[-1][0] if cuadros else 0
    datos = {"nombre": os.path.basename(ruta), "origen": "pantalla", "ruta": ruta, "duracion": duracion, "texto": "",
             "aviso": "es una grabación de tu pantalla, sin sonido", "imagenes": imagenes,
             "miniatura": miniatura(elegidos[-1][1])}
    r = jarvis.chat_modelo([{"role": "system", "content": PROMPT_GRABACION},
                            {"role": "user", "content": f"(Grabación de {round(duracion)} segundos.) {pedido}",
                             "images": imagenes}], temperature=0.2, num_predict=800)
    return r["message"]["content"].strip(), datos
