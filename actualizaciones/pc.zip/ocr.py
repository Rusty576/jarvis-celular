"""Leer el texto de una imagen (OCR) con el lector que trae Windows, sin internet.

La IA "ve" las capturas achicadas (unos 600 pedacitos por imagen): la letra chica de un póster o de un documento
no se lee y la IA la inventa. Con esto JARVIS tiene el texto de la pantalla letra por letra, y sabe dónde está cada
renglón (para encontrar una sección, como «Metodología»).
"""
import asyncio
import re

IDIOMAS = ["es-UY", "es-419", "es-MX", "es-ES", "en-US"]  # el primero que tenga Windows
AGRANDAR_HASTA = 3200  # la letra chica se lee mejor si la imagen se agranda (hasta este ancho)


def _motor():
    from winrt.windows.globalization import Language
    from winrt.windows.media.ocr import OcrEngine

    for idioma in IDIOMAS:
        if OcrEngine.is_language_supported(Language(idioma)):
            return OcrEngine.try_create_from_language(Language(idioma))
    return OcrEngine.try_create_from_user_profile_languages()


async def _leer(img):
    from PIL import Image
    from winrt.windows.graphics.imaging import BitmapPixelFormat, SoftwareBitmap
    from winrt.windows.storage.streams import DataWriter

    motor = _motor()
    rojo, verde, azul, alfa = img.convert("RGBA").split()
    bgra = Image.merge("RGBA", (azul, verde, rojo, alfa)).tobytes()   # Windows lo quiere en orden azul-verde-rojo
    escritor = DataWriter()
    escritor.write_bytes(bgra)
    mapa = SoftwareBitmap.create_copy_from_buffer(escritor.detach_buffer(), BitmapPixelFormat.BGRA8, img.width,
                                                  img.height)
    return await motor.recognize_async(mapa)


def leer(img):
    """Los renglones de texto de la imagen, en orden: [{"texto", "x", "y", "ancho", "alto"}] (en píxeles de la imagen
    original). [] si no hay texto o si Windows no tiene el lector."""
    from PIL import Image

    escala = 1.0
    if img.width < AGRANDAR_HASTA:
        escala = min(2.0, AGRANDAR_HASTA / img.width)
        img = img.resize((round(img.width * escala), round(img.height * escala)), Image.LANCZOS)
    try:
        resultado = asyncio.run(_leer(img))
    except Exception:
        return []
    renglones = []
    for linea in resultado.lines:
        cajas = [p.bounding_rect for p in linea.words]
        if not cajas:
            continue
        x = min(c.x for c in cajas)
        y = min(c.y for c in cajas)
        renglones.append({"texto": linea.text, "x": round(x / escala), "y": round(y / escala),
                          "ancho": round((max(c.x + c.width for c in cajas) - x) / escala),
                          "alto": round((max(c.y + c.height for c in cajas) - y) / escala)})
    return renglones


def texto(renglones):
    return "\n".join(r["texto"] for r in renglones)


def _normal(s):
    return s.lower().translate(str.maketrans("áéíóúüñ", "aeiouun"))


def seccion(renglones, nombre):
    """El texto de una sección: el renglón que la nombra («Metodología») y los que vienen abajo en la misma columna,
    hasta un hueco grande o el título de otra sección. None si no está."""
    nombre = _normal(nombre)
    titulos = [r for r in renglones if nombre in _normal(r["texto"]) and len(r["texto"]) <= len(nombre) + 25]
    if not titulos:
        return None
    titulo = min(titulos, key=lambda r: len(r["texto"]))   # el más cortito: el título, no una frase que lo nombra
    debajo = sorted((r for r in renglones if r["y"] > titulo["y"] and abs(r["x"] - titulo["x"]) < max(80, titulo["alto"] * 4)),
                    key=lambda r: r["y"])
    partes, ultimo = [], titulo
    for r in debajo:
        hueco = r["y"] - (ultimo["y"] + ultimo["alto"])
        if hueco > max(ultimo["alto"], r["alto"]) * 3:
            break   # un hueco grande: terminó la sección
        if partes and _es_titulo(r):
            break   # empieza otra sección
        partes.append(r["texto"])
        ultimo = r
    return titulo["texto"], " ".join(partes)


def _es_titulo(r):
    t = r["texto"].strip()
    return len(t) <= 30 and (t.isupper() or re.match(r"^\d+[.)]?\s", t) is not None or t.endswith(":"))
