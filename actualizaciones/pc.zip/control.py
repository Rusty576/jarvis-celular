"""Lista de control (verificación cruzada).

Cada vez que registrás algo (un recuerdo, un pendiente, un recordatorio, una alarma, una instrucción), además de
guardarlo donde corresponde:
  1. se VUELVE A LEER del disco para confirmar que quedó guardado de verdad (si no, reintenta y te avisa), y
  2. se anota en esta lista, para que puedas revisar todo lo que registraste y no se te olvide nada.

  "lista de control", "¿qué registré hoy?", "¿qué te pedí que recuerdes?", "ya revisé la lista"
"""
import datetime
import os
import re
import threading
import time

import disco

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "control.json")
NOMBRES = {"recuerdo": "Recuerdo", "pendiente": "Pendiente", "recordatorio": "Recordatorio", "alarma": "Alarma",
           "instruccion": "Instrucción"}
_lock = threading.Lock()


def lista():
    return disco.leer(ARCHIVO, [])


def _guardar(datos):
    disco.guardar(ARCHIVO, datos[-300:])
    if jarvis is not None:
        jarvis.emitir("control", datos[-300:])


def registrar(tipo, texto, verificar=None, reintentar=None):
    """Anota algo que registraste y comprueba que quedó guardado.
    verificar(): True si está guardado (se lee del disco). reintentar(): vuelve a guardarlo si no estaba.
    Devuelve la entrada (con 'verificado' True/False)."""
    ok = True
    if verificar:
        try:
            ok = bool(verificar())
            if not ok and reintentar:
                reintentar()
                time.sleep(0.1)
                ok = bool(verificar())
        except Exception:
            ok = False
    with _lock:
        datos = lista()
        entrada = {"id": max((e["id"] for e in datos), default=0) + 1, "tipo": tipo, "texto": str(texto).strip(),
                   "fecha": datetime.datetime.now().isoformat(timespec="minutes"), "verificado": ok, "revisado": False}
        datos.append(entrada)
        _guardar(datos)
    if not ok and jarvis is not None:
        jarvis.aviso(f"⚠ No pude confirmar que se guardó: «{texto}». Revisalo en la Lista de control.")
    return entrada


def marca(entrada):
    """El textito que se agrega a la respuesta: '✓ Verificado y anotado en tu lista de control.'"""
    return (" ✓ Verificado y anotado en tu lista de control." if entrada["verificado"]
            else " ⚠ No pude verificar que se haya guardado: fijate en la Lista de control.")


def marcar_revisado(id_, revisado=True):
    with _lock:
        datos = lista()
        for e in datos:
            if e["id"] == id_:
                e["revisado"] = revisado
        _guardar(datos)
    return datos


def revisar_todo():
    with _lock:
        datos = lista()
        for e in datos:
            e["revisado"] = True
        _guardar(datos)
    return datos


def borrar(id_):
    with _lock:
        datos = [e for e in lista() if e["id"] != id_]
        _guardar(datos)
    return datos


def texto_lista(solo_hoy=False, tipo=None):
    datos = lista()
    if solo_hoy:
        hoy = datetime.date.today().isoformat()
        datos = [e for e in datos if e["fecha"].startswith(hoy)]
    if tipo:
        datos = [e for e in datos if e["tipo"] == tipo]
    if not datos:
        return ("Hoy no registraste nada todavía." if solo_hoy else
                "La lista de control está vacía: acá se anota todo lo que me pedís guardar o recordar.")
    sin_revisar = [e for e in datos if not e["revisado"]]
    mostrar = (sin_revisar or datos)[-12:]
    lineas = [f"- {'✓' if e['verificado'] else '⚠'} {NOMBRES.get(e['tipo'], e['tipo'])}: {e['texto']} "
              f"({e['fecha'][8:10]}/{e['fecha'][5:7]} {e['fecha'][11:16]})" for e in mostrar]
    encabezado = (f"Tenés {len(sin_revisar)} registro{'s' if len(sin_revisar) != 1 else ''} sin revisar"
                  if sin_revisar else "Todo revisado. Lo último que registraste")
    return f"{encabezado}:\n" + "\n".join(lineas) + "\n\nCuando los veas, decime «ya revisé la lista»."


VER = re.compile(r"\b(?:lista de control|que registre|que (?:te )?(?:pedi|dije) que (?:recuerdes|guardes|anotes)|"
                 r"que (?:cosas )?(?:te )?(?:guarde|anote|registre)|mis registros|que tengo registrado)\b")
REVISADO = re.compile(r"\b(?:ya )?revise (?:la |toda la )?(?:lista(?: de control)?|todo)\b|^lista revisada$")


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    if REVISADO.search(t):
        revisar_todo()
        return "¡Bien! Marqué toda la lista de control como revisada."
    if VER.search(t):
        if jarvis is not None and jarvis.oyentes:
            jarvis.emitir("abrir_memoria", "control")
        return texto_lista(solo_hoy=bool(re.search(r"\bhoy\b", t)))
    return None
