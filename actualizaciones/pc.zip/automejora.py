"""Automejora: JARVIS cambia su propio código cuando se lo pedís, siempre con tu permiso.

- "mejorate: cuando te pida el dólar, decime también el euro", "modificá tu código para que...", "programate para..."
- "¿qué mejoras te hiciste?", "deshacé la última mejora", "reiniciate" (los cambios valen al reiniciar).

Cómo lo hace:
1. Busca las funciones de JARVIS que tienen que ver con el pedido (un índice de cada función de cada .py).
2. La IA elige cuáles cambiar y escribe esas funciones completas, cambiadas (la nube si está configurada y
   activada en Configuraciones: escribe mejor código; si no, Gemma).
3. Se revisa en una copia aparte: que compile, que no use nombres que no existen (pyflakes) y que el módulo se pueda
   importar. Si falla, la IA tiene una oportunidad de corregirlo. También avisa si el cambio borra archivos, usa
   claves o manda datos a internet.
4. Te muestra el cambio (diff) y pregunta. Recién con tu "sí" guarda una copia de los archivos (carpeta
   automejoras) y los cambia. Nunca toca este archivo, configurar.py, apagar.py ni las confirmaciones de envío.

Y se mejora SOLO (Configuraciones > "Que se mejore solo", o «automejorate» a secas): cuando no lo usás, revisa las
charlas, encuentra lo que salió mal, arma el arreglo y lo PRUEBA en copias de sí mismo con tu frase que falló. Si
anda, no rompe nada y lo escribió la nube, se lo aplica (máximo 2 por día) y te avisa; si no, te lo deja preparado.
"""
import ast
import datetime
import difflib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(BASE, "automejoras")  # copias de los archivos antes de cada cambio y el registro
REGISTRO = os.path.join(CARPETA, "registro.json")
USAR_NUBE = True  # Configuraciones > "Automejora con la IA de la nube" (si hay clave; si no, Gemma)

PROTEGIDOS = {"automejora.py", "configurar.py", "apagar.py", "revisar_publicacion.py"}
FUNCIONES_PROTEGIDAS = {("conexiones.py", n) for n in ("pedir_confirmacion", "responder_confirmacion",
                                                        "descartar_pendiente", "hay_pendiente")}
MAX_PARTES = 4  # cuántas funciones cambia como mucho por pedido
LETRAS_CODIGO = {"nube": 40000, "local": 14000}  # cuánto código le paso (Gemma tiene menos memoria)
LETRAS_POR_PARTE = 7000  # las partes más largas no se ofrecen: reescribirlas enteras sale mal
SEGUNDOS_PROPUESTA = 30 * 60  # cuánto queda guardada una propuesta para decir "aplicala" después

PEDIR = re.compile(
    r"^(?:(?:che|jarvis|dale|bueno)[\s,]+)*(?:auto ?mejora(?:te)?|mejorate|reprogramate|programate|agregate|"
    r"modificate|actualizate|(?:mejora|modifica|cambia|edita|toca|reprograma)\s+(?:tu|tu propio|el)\s+codigo|"
    r"quiero que te (?:mejores|modifiques|reprogrames|programes|agregues))\b[\s,:]*(?:a (?:vos|ti) mismo\s*)?"
    r"(?:para que\s+|para\s+|que\s+|con\s+)?(?P<pedido>.{6,})$")
DESHACER = re.compile(r"\b(?:deshace|deshaz|revert\w*|anula|volve atras)\w*\s+(?:la |el |tu )?(?:ultim[ao] )?"
                      r"(?:auto ?mejora|mejora|cambio (?:de|en|a) tu codigo|cambio que te hiciste)")
VER = re.compile(r"\b(?:que (?:mejoras|cambios) te (?:hiciste|aplicaste)|tus (?:auto ?)?mejoras|"
                 r"(?:historial|lista) de (?:auto ?)?mejoras)\b")
APLICAR = re.compile(r"^(?:aplica(?:la|lo)?|aplica (?:la|el) (?:auto ?mejora|mejora|cambio)|dale aplica(?:la|lo)?)$")
# Pedidos de mejora dichos como se dicen: «¿podés mejorar el botón de pensar más?», «quiero que cambies tu voz».
# Antes solo se entendía «mejorate: ...», y esto iba a la charla, que contestaba con código HTML de ejemplo
PEDIR_SUAVE = re.compile(
    r"^(?:(?:che|jarvis|dale|bueno|oye|ok)[\s,]+)*(?:(?:me |vos )?(?:podes|puedes|podrias|podras|sabes)\s+|"
    r"(?:quiero|necesito|me gustaria|estaria bueno) que\s+)(?P<pedido>(?:mejorar|cambiar|modificar|arreglar|agregar|"
    r"sumar|ponerle|hacer que|mejores|cambies|modifiques|arregles|agregues|sumes|le pongas|hagas que)\b.{4,})$")
# (que sea de JARVIS: «¿podés cambiar el color del fondo de pantalla?» es de Windows, no de él)
DE_JARVIS = re.compile(r"\b(?:tu|tus|de jarvis|pensar mas|el reactor|los protocolos|el protocolo|la barrita|"
                       r"el boton de (?:pensar|llamar|hablar|enviar|la camara|adjuntar|detener|videollamada))\b")
DE_LA_PANTALLA = re.compile(r"\b(?:boton\w*|interfaz|pantalla|panel|reactor|barra|barrita|color\w*|icono\w*|ventana|"
                            r"menu|estilo|diseno|fondo|letra|fuente|animacion|protocolo\w*)\b")
PEDIDOS = os.path.join(CARPETA, "pedidos.json")   # lo que no se puede cambiar solo: queda anotado para programarlo
REINICIAR = re.compile(r"^(?:(?:che|jarvis)[\s,]+)?(?:reiniciate|reinicia(?:te|r)? (?:jarvis|vos)|"
                       r"reinicia(?:te)? para (?:aplicar|que tome|probar).*)$")

# Lo que conviene que veas antes de decir que sí (se busca en las líneas nuevas)
PELIGROS = [
    (r"\b(?:shutil\.rmtree|os\.remove|os\.unlink|os\.rmdir)\b|\.unlink\(|\.rmdir\(|Remove-Item|\bdel /|rd /s",
     "borra archivos"),
    (r"\bkeyring\.|API_KEY|\bclave\(|password", "usa tus claves o contraseñas"),
    (r"\b(?:eval|exec|__import__)\(|\bos\.system\(", "ejecuta código armado en el momento"),
    (r"\brequests\.(?:post|put)\b|\burlopen\(|\bsmtplib\b|\bsocket\.", "manda o pide datos a internet"),
    (r"\bsubprocess\.|\bos\.startfile\(|\bPopen\(", "abre o ejecuta programas"),
]

propuesta = None  # el último cambio armado, esperando tu "sí"


# ======================= El índice: qué funciones hay y dónde =======================

def archivos_editables():
    return sorted(a for a in os.listdir(BASE) if a.endswith(".py") and a not in PROTEGIDOS)


def _desde(nodo):
    """La primera línea de una función (contando los decoradores @...)."""
    return min([nodo.lineno] + [d.lineno for d in getattr(nodo, "decorator_list", [])])


def nombre_de(nodo):
    if isinstance(nodo, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return nodo.name
    if isinstance(nodo, ast.Assign) and len(nodo.targets) == 1 and isinstance(nodo.targets[0], ast.Name):
        return nodo.targets[0].id
    if isinstance(nodo, ast.AnnAssign) and isinstance(nodo.target, ast.Name):
        return nodo.target.id
    return None


def partes_de(fuente):
    """{nombre: (desde, hasta, nodo)} de las funciones, clases y constantes (en MAYÚSCULAS) de primer nivel."""
    partes = {}
    for nodo in ast.parse(fuente).body:
        nombre = nombre_de(nodo)
        if nombre and (not isinstance(nodo, (ast.Assign, ast.AnnAssign)) or nombre.isupper()):
            partes[nombre] = (_desde(nodo), nodo.end_lineno, nodo)
    return partes


def indice():
    """Una lista de todas las partes del código: archivo, nombre, líneas, qué hace y el código."""
    lista = []
    for archivo in archivos_editables():
        try:
            with open(os.path.join(BASE, archivo), encoding="utf-8") as f:
                fuente = f.read()
            partes = partes_de(fuente)
        except (OSError, SyntaxError, ValueError):
            continue
        lineas = fuente.splitlines()
        for nombre, (desde, hasta, nodo) in partes.items():
            doc = ""
            if not isinstance(nodo, (ast.Assign, ast.AnnAssign)):
                doc = (ast.get_docstring(nodo) or "").strip().split("\n")[0]
            if not doc:  # sin docstring: el comentario de arriba o de la primera línea
                arriba = lineas[desde - 2].strip() if desde >= 2 else ""
                doc = arriba[1:].strip() if arriba.startswith("#") else ""
            lista.append({"archivo": archivo, "nombre": nombre, "desde": desde, "hasta": hasta, "doc": doc[:120],
                          "codigo": "\n".join(lineas[desde - 1:hasta])})
    return lista


VACIAS = {"para", "que", "cuando", "como", "este", "esta", "esto", "algo", "tambien", "pero", "porque", "sobre", "desde",
          "hasta", "entre", "todo", "todos", "cada", "mejor", "quiero", "puedas", "pueda", "podes", "hace", "haga", "diga",
          "decime", "dame", "pido", "pida", "pidas", "tenga", "tengas", "funcion", "codigo", "jarvis", "vos", "mismo"}


def palabras_clave(pedido):
    t = jarvis.normalizar(pedido) if jarvis else pedido.lower()
    return [p[:6] for p in re.findall(r"[a-zñ0-9_]{4,}", t) if p not in VACIAS]


def candidatas(pedido, indice_):
    """Las partes que más tienen que ver con el pedido (por palabras en el nombre, la explicación y el código).
    La primera es siempre mejoras.py :: manejar, donde van las órdenes nuevas. Las partes muy largas no entran: la IA
    las tendría que reescribir enteras y ahí se equivoca."""
    claves = palabras_clave(pedido)
    puntajes = []
    nuevas = [p for p in indice_ if p["archivo"] == "mejoras.py" and p["nombre"] == "manejar"]
    for parte in indice_:
        if parte in nuevas or len(parte["codigo"]) > LETRAS_POR_PARTE or "```" in parte["codigo"]:
            continue
        cabeza = (parte["archivo"] + " " + parte["nombre"] + " " + parte["doc"]).lower().replace("_", " ")
        cuerpo = parte["codigo"].lower()
        if jarvis:
            cabeza, cuerpo = jarvis.normalizar(cabeza), jarvis.normalizar(cuerpo)
        puntos = sum(3 for c in claves if c in cabeza) + sum(min(cuerpo.count(c), 3) for c in claves)
        if puntos:
            puntajes.append((puntos, parte))
    puntajes.sort(key=lambda x: -x[0])
    return nuevas + [p for _, p in puntajes[:30]]


# ======================= La IA =======================

def cerebro():
    """'nube' o 'local' (Gemma)."""
    if USAR_NUBE and jarvis and jarvis.cerebro_nvidia.configurado():
        return "nube"
    return "local"


def preguntar(mensajes, donde, json_=False):
    if donde != "nube":
        r = jarvis.chat_modelo(mensajes, esquema="json" if json_ else None, temperature=0.2, num_predict=4096)
        return r["message"]["content"]
    for intento in range(3):
        try:
            return "".join(jarvis.cerebro_nvidia.chat_stream(mensajes, temperatura=0.2, largo=8192, espera=150))
        except Exception as e:
            if "429" not in str(e) or intento == 2:
                raise
            time.sleep(45)  # el tope por minuto de la nube (el gratis de Groq): se espera y se vuelve a pedir


PROMPT_ELEGIR = """Mantenés el código de JARVIS, un asistente de escritorio hecho en Python. Te paso un pedido de mejora y \
una lista de partes del código (archivo :: nombre: qué hace). Elegí las partes que hay que cambiar para cumplir el \
pedido: las menos posibles, como mucho 4.
- Si el pedido es una orden o una respuesta NUEVA ("que cuando te diga X hagas Y"), elegí mejoras.py :: manejar: ahí \
van las órdenes nuevas. Sumá otra parte solo si hay que usarla o cambiarla.
- Si el pedido cambia algo que JARVIS ya hace, elegí la función que lo hace.
Respondé solo con JSON: {"partes": ["archivo.py :: nombre"], "archivo_para_lo_nuevo": "mejoras.py"}"""

PROMPT_CAMBIAR = """Sos un programador experto en Python que mejora a JARVIS, un asistente de escritorio en español \
rioplatense. Te paso el pedido del usuario y el código actual de algunas partes. Escribí las partes cambiadas \
COMPLETAS (la función entera, no solo lo nuevo), cambiando solo lo necesario y con el mismo estilo (comentarios \
cortos en español). Podés agregar funciones, constantes o imports nuevos.
Las órdenes nuevas van en mejoras.py, en manejar(texto, t): t es el mensaje en minúsculas, sin tildes y sin signos \
al principio ni al final (por ejemplo "que hora es en japon"); texto es como lo escribió. Si el mensaje es la orden, \
devolvé el texto que JARVIS dice; si no, seguí y al final devolvé None. Reconocé la orden con re.search y varias \
formas de decirla. Para usar el resto de JARVIS está jarvis (jarvis.herramientas, jarvis.musica, jarvis.emitir...). \
En esta PC (Windows) zoneinfo no tiene zonas horarias: para la hora de otro país usá datetime.timezone con la \
diferencia en horas.
Reglas: no borres archivos ni datos del usuario, no leas ni mandes claves, no cambies cómo pide confirmación antes de \
mandar mensajes, y no uses nombres que no existan en ese archivo (si necesitás algo de otro módulo, importalo). Si el \
pedido es peligroso o no se puede hacer así, respondé solo: NO SE PUEDE: el motivo.
Formato: un bloque por archivo, así:
=== archivo.py ===
```python
(las funciones, constantes o imports nuevos o cambiados de ese archivo)
```
Y al final una línea: RESUMEN: qué cambia para el usuario, en una oración."""


def elegir_partes(pedido, opciones, donde):
    lista = "\n".join(f"{p['archivo']} :: {p['nombre']}: {p['doc'] or '(sin explicación)'}" for p in opciones)
    texto = preguntar([{"role": "system", "content": PROMPT_ELEGIR},
                       {"role": "user", "content": f"Pedido: {pedido}\n\nPartes:\n{lista}"}], donde, json_=True)
    m = re.search(r"\{.*\}", texto, re.S)
    datos = json.loads(m.group(0)) if m else {}
    elegidas = []
    for item in datos.get("partes") or []:
        archivo, _, nombre = str(item).partition("::")
        for p in opciones:
            if p["archivo"] == archivo.strip() and p["nombre"] == nombre.strip() and p not in elegidas:
                elegidas.append(p)
    nuevo = str(datos.get("archivo_para_lo_nuevo") or "").strip()
    if nuevo not in archivos_editables():
        nuevo = "mejoras.py"
    if not elegidas:  # no eligió nada: va como orden nueva
        elegidas = [p for p in opciones if p["archivo"] == "mejoras.py" and p["nombre"] == "manejar"]
    return elegidas[:MAX_PARTES], nuevo


def contexto_de(archivo):
    """Los imports y los nombres de primer nivel de un archivo (para que la IA use lo que existe)."""
    with open(os.path.join(BASE, archivo), encoding="utf-8") as f:
        arbol = ast.parse(f.read())
    imports = [ast.unparse(n) for n in arbol.body if isinstance(n, (ast.Import, ast.ImportFrom))]
    nombres = [nombre_de(n) for n in arbol.body if nombre_de(n)]
    return f"# {archivo}\n# imports: {'; '.join(imports)}\n# nombres que existen: {', '.join(nombres)}"


def pedido_de_codigo(pedido, elegidas, nuevo, donde):
    archivos = list(dict.fromkeys([p["archivo"] for p in elegidas] + ([nuevo] if nuevo else [])))
    partes = [contexto_de(a) for a in archivos]
    letras = LETRAS_CODIGO[donde]
    if donde == "nube":  # una nube con tope chico (el gratis de Groq): menos código, así el pedido entra
        tope = jarvis.cerebro_nvidia.PROVEEDORES[jarvis.cerebro_nvidia.activo()].get("max_letras")
        if tope:
            letras = min(letras, tope // 2)
    for p in sorted(elegidas, key=lambda p: len(p["codigo"])):
        if len(p["codigo"]) > letras:
            continue  # demasiado larga para la memoria de la IA
        letras -= len(p["codigo"])
        partes.append(f"=== {p['archivo']} :: {p['nombre']} (código actual) ===\n```python\n{p['codigo']}\n```")
    if nuevo:
        partes.append(f"Si agregás funciones nuevas que no van en esos archivos, ponelas en {nuevo}.")
    return f"Pedido del usuario: {pedido}\n\n" + "\n\n".join(partes)


CABEZA = re.compile(r"^\s*===\s*([\w\-]+\.py)\s*(?:::[^=\n]*)?===\s*$", re.M)


def sin_cercas(trozo):
    """El código de adentro de ```python ... ```: desde la primera cerca hasta la ÚLTIMA (el código puede tener ```
    adentro de un texto). Sin cercas, el trozo tal cual."""
    lineas = trozo.strip("\n").splitlines()
    abre = next((i for i, l in enumerate(lineas) if l.strip().startswith("```")), None)
    if abre is None:
        return "\n".join(lineas).strip("\n")
    cierra = next((i for i in range(len(lineas) - 1, abre, -1) if lineas[i].strip() == "```"), len(lineas))
    return "\n".join(lineas[abre + 1:cierra]).strip("\n")


def leer_respuesta(texto, archivos_posibles):
    """{archivo: código} y el resumen. Si la IA no puso los === archivo ===, y era un solo archivo, va a ese."""
    cuerpo = re.split(r"^\s*RESUMEN:", texto, flags=re.M)[0]
    bloques = {}
    cabezas = list(CABEZA.finditer(cuerpo))
    for i, m in enumerate(cabezas):
        fin = cabezas[i + 1].start() if i + 1 < len(cabezas) else len(cuerpo)
        codigo = sin_cercas(cuerpo[m.end():fin])
        if codigo.strip():
            bloques[m.group(1)] = (bloques.get(m.group(1), "") + "\n\n\n" + codigo).strip("\n")
    if not bloques and len(archivos_posibles) == 1 and "```" in cuerpo:
        bloques[archivos_posibles[0]] = sin_cercas(cuerpo)
    m = re.search(r"^\s*RESUMEN:\s*(.+)", texto, re.M)
    return bloques, (m.group(1).strip() if m else "")


# ======================= Armar el archivo nuevo =======================

def aplicar_bloque(fuente, codigo, archivo):
    """El archivo con las partes del bloque cambiadas (las que ya existen) o agregadas (las nuevas)."""
    nodos = ast.parse(codigo).body
    existentes = partes_de(fuente)
    lineas_codigo = codigo.splitlines()
    lineas = fuente.splitlines()
    arbol = ast.parse(fuente)
    reemplazos, nuevos, imports = [], [], []
    ya_importado = {ast.unparse(n) for n in arbol.body if isinstance(n, (ast.Import, ast.ImportFrom))}
    for nodo in nodos:
        texto = "\n".join(lineas_codigo[_desde(nodo) - 1:nodo.end_lineno])
        if isinstance(nodo, (ast.Import, ast.ImportFrom)):
            if ast.unparse(nodo) not in ya_importado:
                imports.append(ast.unparse(nodo))
            continue
        nombre = nombre_de(nodo)
        if nombre is None:
            raise ValueError(f"en {archivo} la IA puso código suelto (solo se aceptan funciones, clases, constantes e "
                             "imports)")
        if (archivo, nombre) in FUNCIONES_PROTEGIDAS:
            raise ValueError(f"{nombre} es una de las confirmaciones de envío: no la puedo cambiar")
        if nombre in existentes:
            desde, hasta, _ = existentes[nombre]
            reemplazos.append((desde, hasta, texto))
        else:
            nuevos.append(texto)
    for desde, hasta, texto in sorted(reemplazos, reverse=True):  # de abajo para arriba: no se corren las líneas
        lineas[desde - 1:hasta] = texto.splitlines()
    if nuevos:
        agregado = []
        for texto in nuevos:
            agregado += texto.splitlines() + ["", ""]
        principal = next((i for i, l in enumerate(lineas) if l.startswith("if __name__")), None)
        if principal is None:  # no hay "if __name__": al final del archivo
            while lineas and not lineas[-1].strip():
                lineas.pop()
            lineas += ["", ""] + agregado[:-2]
        else:  # justo antes del "if __name__" (que ya tiene sus dos líneas en blanco arriba)
            lineas[principal:principal] = agregado
    if imports:
        ultimos = [n.end_lineno for n in arbol.body if isinstance(n, (ast.Import, ast.ImportFrom))]
        lugar = max(ultimos) if ultimos else 0  # los imports están arriba de todo: los reemplazos no los movieron
        lineas[lugar:lugar] = imports
    return "\n".join(lineas) + "\n"


def avisos_pyflakes(fuente, archivo):
    """Los problemas que encuentra pyflakes (nombres que no existen, etc.), sin el número de línea."""
    try:
        from pyflakes import api, reporter
    except ImportError:
        return set()
    import io
    salida = io.StringIO()
    api.check(fuente, archivo, reporter.Reporter(salida, salida))
    return {re.sub(r"^[^:]*:\d+:\d+:?\s*", "", linea).strip() for linea in salida.getvalue().splitlines() if linea.strip()}


def probar_importar(nuevos):
    """Copia JARVIS a una carpeta aparte con los archivos cambiados e importa cada módulo cambiado en otro proceso.
    Devuelve el error ('' si anduvo)."""
    carpeta = tempfile.mkdtemp(prefix="jarvis_automejora_")
    try:
        for a in os.listdir(BASE):
            if a.endswith(".py"):
                shutil.copy2(os.path.join(BASE, a), os.path.join(carpeta, a))
        for archivo, fuente in nuevos.items():
            with open(os.path.join(carpeta, archivo), "w", encoding="utf-8") as f:
                f.write(fuente)
        for archivo in nuevos:
            modulo = archivo[:-3]
            r = subprocess.run([sys.executable, "-B", "-c", f"import {modulo}"], cwd=carpeta, capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=120,
                               env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"),
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if r.returncode != 0:
                ultimas = [l for l in (r.stderr or "").strip().splitlines() if l.strip()][-4:]
                return f"{archivo} no se puede importar: " + " | ".join(ultimas)
        return ""
    except subprocess.TimeoutExpired:
        return "importarlo tardó más de 2 minutos"
    finally:
        shutil.rmtree(carpeta, ignore_errors=True)


def revisar(bloques):
    """Arma los archivos nuevos y los revisa. Devuelve ({archivo: (viejo, nuevo)}, [problemas])."""
    cambios, problemas = {}, []
    for archivo, codigo in bloques.items():
        if archivo in PROTEGIDOS or archivo not in archivos_editables():
            problemas.append(f"{archivo}: no es un archivo que pueda cambiar")
            continue
        with open(os.path.join(BASE, archivo), encoding="utf-8") as f:
            viejo = f.read()
        try:
            nuevo = aplicar_bloque(viejo, codigo, archivo)
            compile(nuevo, archivo, "exec")
        except SyntaxError as e:
            problemas.append(f"{archivo}: error de sintaxis en la línea {e.lineno}: {e.msg}")
            continue
        except ValueError as e:
            problemas.append(str(e))
            continue
        if nuevo == viejo:
            continue
        nuevos_avisos = avisos_pyflakes(nuevo, archivo) - avisos_pyflakes(viejo, archivo)
        graves = [a for a in nuevos_avisos if "undefined name" in a or "referenced before assignment" in a]
        if graves:
            problemas.append(f"{archivo}: " + "; ".join(sorted(graves)))
            continue
        cambios[archivo] = (viejo, nuevo)
    if cambios and not problemas:
        error = probar_importar({a: n for a, (_, n) in cambios.items()})
        if error:
            problemas.append(error)
    return cambios, problemas


def diff_de(cambios):
    lineas = []
    for archivo, (viejo, nuevo) in cambios.items():
        lineas += difflib.unified_diff(viejo.splitlines(), nuevo.splitlines(), f"{archivo} (antes)",
                                       f"{archivo} (después)", lineterm="", n=2)
    return lineas


def peligros_de(lineas_diff):
    nuevas = "\n".join(l[1:] for l in lineas_diff if l.startswith("+") and not l.startswith("+++"))
    return [motivo for patron, motivo in PELIGROS if re.search(patron, nuevas)]


# ======================= El pedido completo =======================

def armar_cambio(pedido, donde, avisar=True, problemas_previos=None):
    """Busca qué cambiar, le pide el código a la IA y lo revisa (con una oportunidad de corregir).
    Devuelve (cambios, resumen, error): cambios = {archivo: (viejo, nuevo)}; error = '' si salió bien.
    problemas_previos: lo que falló en una prueba anterior (para que la IA lo tenga en cuenta)."""
    def detalle(texto):
        if avisar:
            jarvis.emitir("detalle", texto)
    nombre_ia = jarvis.cerebro_nvidia.nombre_completo() if donde == "nube" else jarvis.MODELO
    detalle("Buscando qué partes de mi código tienen que ver...")
    opciones = candidatas(pedido, indice())
    if not opciones:
        return {}, "", "no encontré qué parte de mi código tiene que ver con eso"
    try:
        elegidas, nuevo = elegir_partes(pedido, opciones, donde)
    except Exception as e:
        return {}, "", f"no pude pensar el cambio ({e})"
    if not elegidas and not nuevo:
        return {}, "", "no supe qué parte de mi código cambiar"
    nombres = ", ".join(f"{p['archivo']}::{p['nombre']}" for p in elegidas) or nuevo
    detalle(f"Escribiendo el cambio con {nombre_ia} ({nombres})...")
    archivos = list(dict.fromkeys([p["archivo"] for p in elegidas] + ([nuevo] if nuevo else [])))
    pedido_completo = pedido_de_codigo(pedido, elegidas, nuevo, donde)
    if problemas_previos:
        pedido_completo += "\n\nUn intento anterior falló así (no lo repitas):\n" + problemas_previos
    mensajes = [{"role": "system", "content": PROMPT_CAMBIAR}, {"role": "user", "content": pedido_completo}]
    cambios, problemas, resumen = {}, ["la IA no mandó código"], ""
    for intento in range(2):  # si la revisión encuentra errores, la IA tiene una oportunidad de corregirlos
        try:
            texto = preguntar(mensajes, donde)
        except Exception as e:
            return {}, "", f"no pude escribir el cambio ({e})"
        m = re.search(r"NO SE PUEDE:\s*(.+)", texto)
        if m and "```" not in texto:
            return {}, "", f"la IA dijo que no se puede: {m.group(1).strip()}"
        bloques, resumen = leer_respuesta(texto, archivos)
        if not bloques:
            problemas = ["no mandó los bloques de código en el formato pedido"]
        else:
            detalle("Revisando el cambio en una copia aparte...")
            cambios, problemas = revisar(bloques)
            if not problemas and not cambios:
                return {}, "", "la IA devolvió el mismo código"
        if not problemas:
            break
        mensajes += [{"role": "assistant", "content": texto},
                     {"role": "user", "content": "La revisión encontró estos problemas:\n- " + "\n- ".join(problemas)
                      + "\nCorregilos y mandá de nuevo los bloques completos, en el mismo formato."}]
        detalle("La revisión encontró errores: le pido que los corrija...")
    if problemas:
        return {}, "", "no pasó la revisión: " + "; ".join(problemas)[:400]
    return cambios, resumen or pedido, ""


def proponer(pedido):
    """Arma el cambio, lo revisa y lo deja esperando tu 'sí'. Devuelve lo que JARVIS te dice."""
    global propuesta
    donde = cerebro()
    nombre_ia = jarvis.cerebro_nvidia.nombre_completo() if donde == "nube" else jarvis.MODELO
    cambios, resumen, error = armar_cambio(pedido, donde)
    if error:
        return f"No toqué nada: {error}. Si querés, pedímelo de otra forma o más concreto."
    propuesta = {"pedido": pedido, "resumen": resumen, "cambios": cambios, "cerebro": nombre_ia,
                 "hasta": time.time() + SEGUNDOS_PROPUESTA}
    mostrar_cambio(cambios, f"Este es el cambio que armé (lo escribió {nombre_ia} y pasó la revisión):")
    return pedir_permiso()


def mostrar_cambio(cambios, titulo):
    lineas = diff_de(cambios)
    mostrar = lineas if len(lineas) <= 200 else lineas[:200] + [f"... ({len(lineas) - 200} líneas más)"]
    jarvis.emitir("jarvis", f"{titulo}\n\n```diff\n" + "\n".join(mostrar) + "\n```")


def pedir_permiso(peligros=None):
    p = propuesta
    if peligros is None:
        peligros = peligros_de(diff_de(p["cambios"]))
    archivos = ", ".join(p["cambios"])
    tarjeta = f"{p['resumen']}\n\nArchivos: {archivos}\nRevisado: compila, sin nombres inexistentes, se importa bien."
    aviso = ""
    if peligros:
        tarjeta += "\n⚠ Ojo, este cambio " + " y ".join(peligros) + "."
        aviso = " Ojo: este cambio " + " y ".join(peligros) + "."
    return jarvis.conexiones.pedir_confirmacion(
        "sistema", "Automejora", tarjeta, accion=aplicar,
        pregunta=f"{p['resumen']}{aviso} Te dejé el cambio en el chat. Guardo una copia antes. ¿Lo aplico?")


def aplicar():
    """Corre cuando decís que sí: aplica el cambio que estaba esperando."""
    global propuesta
    p, propuesta = propuesta, None
    if not p:
        return "No tengo ningún cambio esperando."
    return aplicar_cambios(p)


def aplicar_cambios(p, sola=False):
    """Guarda una copia de los archivos y escribe los nuevos. sola=True: la hizo la revisión automática."""
    fecha = datetime.datetime.now()
    carpeta = os.path.join(CARPETA, fecha.strftime("%Y-%m-%d_%H%M%S"))
    os.makedirs(carpeta, exist_ok=True)
    for archivo, (viejo, nuevo) in p["cambios"].items():
        with open(os.path.join(BASE, archivo), encoding="utf-8") as f:
            if f.read() != viejo:
                return f"No lo apliqué: {archivo} cambió mientras tanto. Pedímelo de nuevo."
    for archivo, (viejo, nuevo) in p["cambios"].items():
        shutil.copy2(os.path.join(BASE, archivo), os.path.join(carpeta, archivo))  # la copia, por si hay que volver
        tmp = os.path.join(BASE, archivo + ".tmp")
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            f.write(nuevo)
        os.replace(tmp, os.path.join(BASE, archivo))
    registro = leer_registro()
    registro.append({"fecha": fecha.strftime("%d/%m/%Y %H:%M"), "pedido": p["pedido"], "resumen": p["resumen"],
                     "archivos": list(p["cambios"]), "copia": os.path.basename(carpeta), "cerebro": p["cerebro"],
                     "estado": "aplicada", "sola": sola, "cuando": time.time(), "prueba": p.get("prueba")})
    guardar_registro(registro)
    return ("Listo, me lo apliqué y guardé una copia de antes. Se activa cuando me reinicio: decime «reiniciate». "
            "Si algo no anda, decime «deshacé la última mejora».")


def leer_registro():
    try:
        with open(REGISTRO, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def guardar_registro(lista):
    os.makedirs(CARPETA, exist_ok=True)
    tmp = REGISTRO + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(lista, f, ensure_ascii=False, indent=1)
    os.replace(tmp, REGISTRO)


def deshacer():
    registro = leer_registro()
    ultima = next((r for r in reversed(registro) if r["estado"] == "aplicada"), None)
    if not ultima:
        return "No tengo ninguna mejora para deshacer."

    def volver():
        carpeta = os.path.join(CARPETA, ultima["copia"])
        actual = os.path.join(carpeta, "deshecho")  # lo que había antes de deshacer, por las dudas
        os.makedirs(actual, exist_ok=True)
        for archivo in ultima["archivos"]:
            shutil.copy2(os.path.join(BASE, archivo), os.path.join(actual, archivo))
            shutil.copy2(os.path.join(carpeta, archivo), os.path.join(BASE, archivo))
        ultima["estado"] = "deshecha"
        guardar_registro(registro)
        return "Listo, volví a como estaba antes de esa mejora. Se nota cuando me reinicio («reiniciate»)."
    return jarvis.conexiones.pedir_confirmacion(
        "sistema", "Deshacer automejora", f"{ultima['resumen']}\n({ultima['fecha']}, archivos: "
        f"{', '.join(ultima['archivos'])})", accion=volver,
        pregunta=f"La última mejora fue: {ultima['resumen']} ¿La deshago?")


def ver():
    registro = leer_registro()
    if registro:
        lineas = [f"{i}. {r['fecha']}: {r['resumen']}" + (" (deshecha)" if r["estado"] == "deshecha" else "")
                  for i, r in enumerate(registro[-8:], start=max(1, len(registro) - 7))]
        texto = "Las mejoras que me hice:\n" + "\n".join(lineas)
    else:
        texto = "Todavía no me hice ninguna mejora. Pedímela así: «mejorate: que cuando...»."
    try:   # y las últimas revisiones solas, aunque no hayan cambiado nada (así se ve que sí se revisa, y por qué no)
        with open(DIARIO, encoding="utf-8") as f:
            diario = json.load(f)
        texto += "\n\nMis últimas revisiones:\n" + "\n".join(f"- {d['fecha']}: {d['que_paso'][:220]}" for d in diario[-4:])
    except (OSError, ValueError):
        pass
    try:
        with open(PEDIDOS, encoding="utf-8") as f:
            esperando = [p for p in json.load(f) if not p.get("hecho")]
        if esperando:
            texto += (f"\n\nPedidos de mi pantalla esperando que me programen ({len(esperando)}): "
                      + "; ".join(f"«{p['pedido'][:80]}»" for p in esperando[-3:]))
    except (OSError, ValueError):
        pass
    return texto


# ======================= Que se mejore solo =======================
# Cuando no lo usás (15 minutos, sin juego ni llamada) y como mucho cada 6 horas: revisa las charlas, encuentra lo que
# salió mal (te quejaste, repetiste el pedido, o no pudo), la IA elige UN problema y lo convierte en un pedido de
# mejora, se arma el cambio como siempre, y se PRUEBA de verdad en copias de JARVIS: la frase que falló tiene que andar
# y unas órdenes comunes no se pueden romper. Si todo anda y lo escribió la nube, se lo aplica solo (con copia de
# antes) y te avisa; si no lo pudo probar, o lo escribió Gemma, lo deja preparado y te pregunta. «automejorate» a
# secas hace la revisión en el momento.

SOLA = True                  # Configuraciones > "Que se mejore solo"
CADA_HORAS = 6               # cada cuánto se revisa solo (como mucho)
MAX_SOLAS_POR_DIA = 2        # cuántas mejoras se aplica solo por día (las demás te las pregunta)
INACTIVO = 15 * 60           # cuánto tiempo sin usarlo antes de revisarse
SEGUNDOS_PROPUESTA_SOLA = 24 * 3600  # lo que preparó solo te espera un día para que digas «aplicala»
ESTADO = os.path.join(CARPETA, "estado.json")  # cuándo se revisó y qué momentos ya miró

REVISATE = re.compile(r"^(?:(?:che|jarvis|dale|bueno|entonces)[\s,]+)*(?:auto ?mejorate|mejorate|automejora(?:te)?|"
                      r"arreglate|corregite|revisate|revisa tu codigo|aprende de tus errores)(?:\s+solo)?$")
QUEJA = re.compile(r"\b(?:no (?:funciona|anda|sirve|entendiste|es eso|era eso|te pedi eso|hiciste nada|hiciste eso)|"
                   r"sigue (?:igual|sin)|otra vez (?:lo mismo|mal)|te dije|ya te dije|cualquier cosa|no me sirve|"
                   r"inventaste|mentira|mentiste|no hiciste|esta mal|equivocad\w*)\b")
FALLO = re.compile(r"^(?:no pude|no entendi|no encontre|no se (?:hacer|abrir|como)|ojo: (?:no|desde)|uy,|"
                   r"no me pude conectar)")
# frases que en la prueba podrían hacer algo de verdad (música, mails, apagar...): esas no se prueban solas
PELIGROSAS = re.compile(r"\b(?:musica|cancion|pausa|volumen|apaga|reinicia|cerra|mail|correo|whatsapp|mensaje|"
                        r"llama|borra|elimina|manda|envia|compra|instala|ventilador|modo juego|pantalla|camara|"
                        r"reproduci|pone|subi|baja)\w*\b")
ORDENES_DE_PRUEBA = ["que hora es", "que dia es", "mis pendientes", "agrega comprar pan a mis pendientes",
                     "que recordatorios tengo", "recordame en 10 minutos tomar agua", "haceme un recordatorio",
                     "mis rutinas", "que mejoras te hiciste", "nueva charla"]
_revisando = threading.Lock()

PROMPT_DIAGNOSTICO = """Sos el programador de JARVIS, un asistente de escritorio hecho en Python que habla en español \
rioplatense. Te paso momentos recientes en que JARVIS respondió mal (el usuario se quejó, repitió el pedido o JARVIS \
no pudo) y errores del programa. Elegí UN problema que valga la pena y que se arregle cambiando el código de JARVIS: \
por ejemplo una orden que no reconoce, una respuesta inventada, algo que entiende mal. NO elijas problemas de \
internet, de cupo de la nube, de claves, de programas de afuera ni de personalidad. Si ninguno sirve, decí que no hay.
Respondé solo con JSON:
{"hay_algo": true, "ejemplo": número del momento elegido, "problema": "qué anda mal, en una oración",
 "pedido": "la mejora pedida como la diría el usuario: «que cuando le digan X, haga Y»",
 "debe_contener": "una palabra corta que la respuesta correcta a ese momento tendría que tener, o vacío"}"""

SCRIPT_PRUEBA = r'''import json, os, subprocess, sys, webbrowser
carpeta, entrada = sys.argv[1], sys.argv[2]
sys.path.insert(0, carpeta)
os.chdir(carpeta)
datos = json.load(open(entrada, encoding="utf-8"))
webbrowser.open = lambda *a, **k: True          # en la prueba no se abre nada de verdad
os.startfile = lambda *a, **k: None
class _NoAbre:
    returncode, pid, stdout, stderr = 0, 0, b"", b""
    def __init__(self, *a, **k): pass
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def poll(self): return 0
    def wait(self, *a, **k): return 0
    def communicate(self, *a, **k): return (b"", b"")
    def kill(self): pass
    terminate = kill
subprocess.Popen = _NoAbre
import main
avisos = []
main.emitir = lambda evento, dato=None, *a, **k: avisos.append(str(dato)) if evento == "detalle" else None
main.hablar = lambda *a, **k: None
main.entender_pedido = lambda *a, **k: None    # la IA que elige protocolos: lenta y no es lo que se prueba
salidas = {}
for frase in datos["frases"]:
    main.historial[:] = datos["contexto"] if frase == datos["frase"] else []
    avisos.clear()
    try:
        r = main.ejecutar_accion(frase)
    except Exception as e:
        r = "ERROR: %s: %s" % (type(e).__name__, str(e)[:200])
    fallo = [a for a in avisos if "mejoras fall" in a]   # main.py se traga el error de una mejora: acá se ve
    if fallo and r is None:
        r = "ERROR en mejoras.py: " + fallo[0][:300]
    salidas[frase] = r
print("@@" + json.dumps(salidas, ensure_ascii=False))
'''


def _estado():
    try:
        with open(ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _guardar_estado(estado):
    os.makedirs(CARPETA, exist_ok=True)
    tmp = ESTADO + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(estado, f, ensure_ascii=False)
    os.replace(tmp, ESTADO)


def _huella(p):
    import hashlib

    return hashlib.md5((p["pedido"] + "|" + p["respuesta"]).encode("utf-8")).hexdigest()[:12]


def juntar_problemas(desde):
    """Los momentos de las charlas (la actual y las guardadas después de 'desde') en que algo salió mal."""
    charlas = [list(jarvis.historial)]
    try:
        for c in jarvis.chats.lista()[1:]:
            if c["actualizado"] >= desde:
                datos = jarvis.chats._leer(os.path.join(jarvis.chats.CARPETA, c["id"] + ".json"), None)
                if datos:
                    charlas.append(datos["mensajes"])
    except Exception:
        pass
    n = jarvis.normalizar
    problemas = []
    for mensajes in charlas:
        for i, m in enumerate(mensajes[:-1]):
            if m.get("role") != "user" or mensajes[i + 1].get("role") != "assistant":
                continue
            pedido, respuesta = m["content"], mensajes[i + 1]["content"]
            despues = mensajes[i + 2]["content"] if i + 2 < len(mensajes) and mensajes[i + 2].get("role") == "user" else ""
            motivo = None
            if FALLO.search(n(respuesta)[:60]):
                motivo = "JARVIS no pudo"
            elif despues and (QUEJA.search(n(despues)) or jarvis.ENOJADO.search(n(despues))):
                motivo = "el usuario se quejó después"
            elif despues and len(pedido) > 8 and difflib.SequenceMatcher(None, n(pedido), n(despues)).ratio() > 0.8:
                motivo = "el usuario repitió el pedido"
            if motivo:
                problemas.append({"motivo": motivo, "contexto": mensajes[max(0, i - 2):i], "pedido": pedido[:500],
                                  "respuesta": respuesta[:500], "despues": despues[:300]})
    return problemas[-10:]


def errores_recientes(desde):
    """Lo último del registro de errores de la ventana, si cambió desde la última revisión."""
    ruta = os.path.join(BASE, "errores_interfaz.log")
    try:
        if os.path.getmtime(ruta) < desde:
            return ""
        with open(ruta, encoding="utf-8", errors="replace") as f:
            f.seek(max(0, os.path.getsize(ruta) - 6000))
            lineas = [l for l in f.read().splitlines() if re.search(r"Error|Traceback|File \"", l)]
        return "\n".join(lineas[-25:])[:2500]
    except OSError:
        return ""


def diagnosticar(problemas, errores, donde):
    momentos = []
    for i, p in enumerate(problemas, start=1):
        previo = " | ".join(f"{m['role']}: {m['content'][:120]}" for m in p["contexto"])
        momentos.append(f"{i}. ({p['motivo']})" + (f" Antes: {previo}." if previo else "")
                        + f"\n   Usuario: {p['pedido']}\n   JARVIS: {p['respuesta']}"
                        + (f"\n   Después el usuario: {p['despues']}" if p["despues"] else ""))
    texto = "Momentos:\n" + "\n".join(momentos) if momentos else "No hay momentos."
    if errores:
        texto += "\n\nErrores del programa:\n" + errores
    respuesta = preguntar([{"role": "system", "content": PROMPT_DIAGNOSTICO}, {"role": "user", "content": texto}],
                          donde, json_=True)
    m = re.search(r"\{.*\}", respuesta, re.S)
    return json.loads(m.group(0)) if m else {}


def _correr_en_copia(nuevos, frases, frase, contexto):
    """Copia JARVIS (con los archivos cambiados) a una carpeta aparte y le corre las frases. {frase: respuesta} o None."""
    carpeta = tempfile.mkdtemp(prefix="jarvis_prueba_")
    try:
        for a in os.listdir(BASE):
            if a.endswith(".py"):
                shutil.copy2(os.path.join(BASE, a), os.path.join(carpeta, a))
        for archivo, fuente in nuevos.items():
            with open(os.path.join(carpeta, archivo), "w", encoding="utf-8") as f:
                f.write(fuente)
        with open(os.path.join(carpeta, "_prueba.py"), "w", encoding="utf-8") as f:
            f.write(SCRIPT_PRUEBA)
        entrada = os.path.join(carpeta, "_entrada.json")
        with open(entrada, "w", encoding="utf-8") as f:
            json.dump({"frases": frases, "frase": frase, "contexto": contexto}, f, ensure_ascii=False)
        # PYTHONIOENCODING: que la copia escriba en UTF-8 (si no, Windows usa otra codificación y las frases con
        # tildes o «¿» no se encontraban al leer la respuesta: la prueba daba None aunque el arreglo anduviera)
        r = subprocess.run([sys.executable, "-B", os.path.join(carpeta, "_prueba.py"), carpeta, entrada], cwd=carpeta,
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180,
                           env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"),
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        salida = (r.stdout or "").rsplit("@@", 1)
        return json.loads(salida[1]) if len(salida) == 2 else None
    except (subprocess.TimeoutExpired, ValueError, OSError):
        return None
    finally:
        shutil.rmtree(carpeta, ignore_errors=True)


def probar(cambios, frase, contexto, debe_contener):
    """Prueba el cambio de verdad: las ORDENES_DE_PRUEBA no se pueden romper, y la frase que falló tiene que andar.
    {"anda": True/False/None (no se pudo probar), "antes", "despues", "rompio": [...]}"""
    n = jarvis.normalizar
    probar_frase = bool(frase) and not PELIGROSAS.search(n(frase))
    frases = ORDENES_DE_PRUEBA + ([frase] if probar_frase and frase not in ORDENES_DE_PRUEBA else [])
    antes = _correr_en_copia({}, frases, frase, contexto)
    despues = _correr_en_copia({a: nuevo for a, (_, nuevo) in cambios.items()}, frases, frase, contexto)
    if antes is None or despues is None:
        return {"anda": None, "antes": None, "despues": None, "rompio": ["no se pudo correr la prueba"]}
    rompio = [f for f in ORDENES_DE_PRUEBA if not str(antes.get(f) or "").startswith("ERROR")
              and str(despues.get(f) or "").startswith("ERROR")]
    anda, r_antes, r_despues = None, antes.get(frase), despues.get(frase)
    if probar_frase and r_despues is None and "mejoras.py" in cambios:
        anda = False  # era una orden nueva y no la reconoció (None: la siguió contestando la charla)
    elif probar_frase and r_despues is not None:  # (None: lo contesta la charla con la IA, no una orden)
        if str(r_despues).startswith("ERROR"):
            anda = False
            rompio.append(frase)
        elif debe_contener:
            anda = n(debe_contener) in n(str(r_despues))
        else:
            anda = r_despues != r_antes and not FALLO.search(n(str(r_despues))[:60])
    return {"anda": anda, "antes": r_antes, "despues": r_despues, "rompio": rompio}


def solas_hoy():
    hoy = datetime.date.today().strftime("%d/%m/%Y")
    return sum(1 for r in leer_registro() if r.get("sola") and r["fecha"].startswith(hoy))


def ciclo_solo(a_pedido=False):
    """La revisión: devuelve lo que le cuenta al usuario (o None si corrió sola y no hay nada que contar)."""
    global propuesta
    if not _revisando.acquire(blocking=False):
        return "Ya me estoy revisando: en un rato te cuento." if a_pedido else None
    try:
        estado = _estado()
        desde = time.time() - 3 * 86400 if a_pedido else estado.get("revisado_hasta", time.time() - 86400)
        vistos = set(estado.get("vistos", []))
        problemas = [p for p in juntar_problemas(desde) if _huella(p) not in vistos]
        errores = errores_recientes(desde)
        estado.update(revisado_hasta=time.time(), ultimo_ciclo=time.time())
        _guardar_estado(estado)
        if not problemas and not errores:
            return _fin("Revisé mis últimas charlas y no encontré nada que haya salido mal.", a_pedido)
        donde = cerebro()
        if a_pedido:
            jarvis.emitir("detalle", f"Revisando {len(problemas)} momentos en que algo salió mal...")
        try:
            d = diagnosticar(problemas, errores, donde)
        except Exception as e:
            return _fin(f"No pude revisarme ahora ({e}).", a_pedido)
        estado["vistos"] = list(vistos | {_huella(p) for p in problemas})[-300:]  # no volver a mirar los mismos
        _guardar_estado(estado)
        pedido = str(d.get("pedido") or "").strip()
        if not d.get("hay_algo") or not pedido:
            return _fin(f"Revisé {len(problemas)} momentos que salieron mal, pero no son de mi código (internet, cupo "
                        "de la nube...) o no supe cómo arreglarlos.", a_pedido)
        i = d.get("ejemplo")
        ejemplo = problemas[i - 1] if isinstance(i, int) and 1 <= i <= len(problemas) else (problemas or [None])[0]
        frase = ejemplo["pedido"] if ejemplo else ""
        contexto = ejemplo["contexto"] if ejemplo else []
        problema = str(d.get("problema") or "algo que salió mal").strip().rstrip(".")
        cambios, resumen, error = armar_cambio(pedido, donde, avisar=a_pedido)
        prueba = None
        for intento in range(2):  # si la prueba falla, una oportunidad más contándole a la IA qué pasó
            if error:
                break
            if a_pedido:
                jarvis.emitir("detalle", "Probando el arreglo en una copia de mí mismo...")
            prueba = probar(cambios, frase, contexto, str(d.get("debe_contener") or ""))
            if a_pedido and frase:
                jarvis.emitir("detalle", f"Prueba: «{frase}» -> {str(prueba['despues'])[:150]}"
                                         + (f" (rompió: {prueba['rompio']})" if prueba["rompio"] else ""))
            if prueba["anda"] is not False and not prueba["rompio"]:
                break
            fallo = (f"Al probar «{frase}» respondió: {prueba['despues']!r}"
                     + (" (None: la orden nueva no reconoció la frase; t llega en minúsculas y sin tildes, por "
                        f"ejemplo «{jarvis.normalizar(frase).strip(' ¿?¡!.,')}»)" if prueba["despues"] is None else "")
                     + "." if frase else "") + \
                    (f" Rompió estas órdenes: {prueba['rompio']}." if prueba["rompio"] else "")
            if intento == 1:
                error = "no pasó la prueba (" + fallo.strip() + ")"
                break
            cambios, resumen, error = armar_cambio(pedido, donde, avisar=a_pedido, problemas_previos=fallo)
        if error:
            return _fin(f"Me revisé y encontré esto: {problema}. Intenté arreglarlo, pero {error}, así que no toqué "
                        "nada.", a_pedido)
        nombre_ia = jarvis.cerebro_nvidia.nombre_completo() if donde == "nube" else jarvis.MODELO
        p = {"pedido": pedido, "resumen": resumen, "cambios": cambios, "cerebro": nombre_ia,
             "prueba": {"frase": frase, "antes": str(prueba["antes"])[:300], "despues": str(prueba["despues"])[:300]},
             "hasta": time.time() + SEGUNDOS_PROPUESTA_SOLA}
        probado = prueba["anda"] is True
        if donde == "nube" and probado and solas_hoy() < MAX_SOLAS_POR_DIA:
            aplicar_cambios(p, sola=True)
            return _fin(f"🛠️ Me mejoré solo. Encontré esto: {problema}. Lo arreglé ({resumen}) y lo probé con "
                        f"«{frase}»: ahora contesta «{str(prueba['despues'])[:160]}». Se activa cuando me reinicies "
                        "(«reiniciate»). Si no te gusta, decime «deshacé la última mejora».", a_pedido, siempre=True)
        propuesta = p
        mostrar_cambio(cambios, f"🛠️ Me revisé y preparé un arreglo para esto: {problema}.")
        motivo = ("no lo pude probar solo" if not probado else "lo escribió Gemma, que se equivoca más" if donde != "nube"
                  else "ya me hice dos mejoras solas hoy")
        return _fin(f"Preparé una mejora ({resumen}), pero {motivo}. ¿La aplico? Decime «aplicala».", a_pedido,
                    siempre=True)
    finally:
        _revisando.release()


DIARIO = os.path.join(CARPETA, "diario.json")   # cada revisión, aunque no haya cambiado nada (y por qué)


def _fin(texto, a_pedido, siempre=False):
    """Anota cómo terminó la revisión en el diario (antes, cuando corría sola y no podía arreglar algo, no quedaba
    rastro: parecía que no se mejoraba nunca) y devuelve qué contarte: siempre si la pediste, y si corrió sola, solo
    cuando cambió algo o te dejó una mejora para aprobar."""
    try:
        with open(DIARIO, encoding="utf-8") as f:
            diario = json.load(f)
    except (OSError, ValueError):
        diario = []
    diario.append({"fecha": datetime.datetime.now().strftime("%d/%m/%Y %H:%M"), "sola": not a_pedido, "que_paso": texto})
    try:
        os.makedirs(CARPETA, exist_ok=True)
        with open(DIARIO, "w", encoding="utf-8") as f:
            json.dump(diario[-60:], f, ensure_ascii=False, indent=1)
    except OSError:
        pass
    return texto if a_pedido or siempre else None


def avisar(texto):
    """Lo que hizo solo, en la charla (sin decirlo en voz alta: capaz no estás)."""
    with jarvis.lock:
        jarvis.historial.append({"role": "assistant", "content": texto})
        jarvis.guardar_historial()
    jarvis.emitir("jarvis", texto)


def _toca_revisarse():
    if not SOLA or jarvis is None or jarvis.herramientas.modo_juego.is_set():
        return False
    try:
        if jarvis.llamada.activa():
            return False
    except Exception:
        pass
    actividad = jarvis._actividad
    if actividad["pedidos"] or time.time() - actividad["ultima"] < INACTIVO:
        return False
    return time.time() - _estado().get("ultimo_ciclo", 0) > CADA_HORAS * 3600


def _bucle():
    time.sleep(10 * 60)  # que JARVIS termine de arrancar
    while True:
        try:
            if _toca_revisarse():
                texto = ciclo_solo()
                if texto:
                    avisar(texto)
        except Exception as e:
            print(f"[automejora] la revisión falló: {e}")
            _fin(f"La revisión falló: {e}", False)
        time.sleep(15 * 60)


def iniciar():
    threading.Thread(target=_bucle, daemon=True).start()


def reiniciar():
    """Abre un JARVIS nuevo apenas se cierra este (un programita que espera) y cierra este."""
    pythonw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if not os.path.exists(pythonw):
        pythonw = sys.executable
    espera = (f"import psutil, subprocess\ntry:\n    psutil.Process({os.getpid()}).wait(60)\nexcept Exception:\n    pass\n"
              f"subprocess.Popen([{pythonw!r}, {os.path.join(BASE, 'interfaz.py')!r}], cwd={BASE!r})")
    subprocess.Popen([sys.executable, "-c", espera], cwd=BASE,
                     creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
                     | subprocess.CREATE_NO_WINDOW)

    def cerrar():
        time.sleep(2)  # que llegue a decir que se reinicia
        if jarvis.oyentes:
            jarvis.emitir("cerrar")
        else:
            os._exit(0)
    threading.Thread(target=cerrar, daemon=True).start()
    return "Me reinicio. Vuelvo en unos segundos."


def manejar(texto, t):
    """Devuelve la respuesta si el mensaje es de automejora, o None."""
    t = t.strip(" ¿?¡!.,")
    if REINICIAR.match(t):
        return reiniciar()
    if VER.search(t):
        return ver()
    if DESHACER.search(t):
        return deshacer()
    if APLICAR.match(t):
        if propuesta and time.time() < propuesta["hasta"]:
            return pedir_permiso()
        return None
    if REVISATE.match(t):  # «automejorate» a secas: se revisa ahora (lo que salió mal en las últimas charlas)
        if jarvis.herramientas.modo_juego.is_set():
            return "Estoy en modo juego: después de jugar me reviso (para no quitarte rendimiento)."
        return ciclo_solo(a_pedido=True)
    m = PEDIR.match(t)
    suave = PEDIR_SUAVE.match(t) if not m else None
    if suave and not DE_JARVIS.search(t):
        suave = None   # «¿podés mejorar este texto?» no es un pedido para JARVIS
    if m or suave:
        pedido = (m or suave).group("pedido").strip(" .")
        if suave and DE_LA_PANTALLA.search(t):
            return anotar_pedido(texto.strip())
        if jarvis.herramientas.modo_juego.is_set():
            return "Estoy en modo juego: después de jugar me mejoro (para no quitarte rendimiento)."
        return proponer(pedido)
    return None


def anotar_pedido(texto):
    """Mi pantalla (HTML, CSS y JavaScript) no me la cambio solo: si me equivoco en una coma, la ventana no abre más y
    no me podrías ni pedir que lo deshaga. Esos pedidos quedan anotados en automejoras/pedidos.json para programarlos
    (con Claude Code o claude-gratis: «hacé los pedidos de automejoras/pedidos.json»)."""
    lista = []
    try:
        with open(PEDIDOS, encoding="utf-8") as f:
            lista = json.load(f)
    except (OSError, ValueError):
        pass
    if not any(p["pedido"] == texto for p in lista):
        lista.append({"fecha": datetime.datetime.now().strftime("%d/%m/%Y %H:%M"), "pedido": texto, "hecho": False})
        os.makedirs(CARPETA, exist_ok=True)
        with open(PEDIDOS, "w", encoding="utf-8") as f:
            json.dump(lista, f, ensure_ascii=False, indent=1)
    sin_hacer = sum(1 for p in lista if not p.get("hecho"))
    return ("Eso es de mi pantalla, y esa parte no me la cambio solo: si me equivoco, la ventana no abre más. Lo anoté "
            f"en mi lista de mejoras para programar (tenés {sin_hacer} esperando, en automejoras/pedidos.json). Lo que "
            "sí me cambio solo es cómo entiendo y respondo: pedímelo así, «mejorate: que cuando...».")
