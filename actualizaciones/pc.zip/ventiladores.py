"""Ventiladores, como en OMEN Gaming Hub (notebooks HP OMEN y Victus).

- "¿cómo están los ventiladores?": a cuántas vueltas giran, la temperatura y si están al máximo.
- "ventiladores al máximo" / "ventiladores en automático".
- "modo rendimiento", "modo equilibrado", "modo silencioso": el modo térmico del BIOS (el mismo de OMEN Gaming Hub).
- "configurá los ventiladores": la primera vez (pide permiso de administrador UNA vez).

Cómo funciona: el BIOS de HP tiene una puerta (WMI "hpqBIntM") que solo pueden usar los administradores, y JARVIS
corre como usuario común. Por eso, al configurarlo, Windows pide permiso una vez y se crea la tarea programada
"JARVIS Ventiladores", que corre como administrador un script fijo guardado en C:\\ProgramData\\JARVIS (una carpeta que
solo los administradores pueden cambiar). JARVIS le deja la orden en un archivo y lanza la tarea; el script solo acepta
estas órdenes: leer, máximo sí/no y modo (equilibrado, rendimiento o silencioso). Nunca apaga los ventiladores ni
pone velocidades a mano: el BIOS sigue cuidando la temperatura.
"""
import ctypes
import json
import os
import re
import subprocess
import tempfile
import threading
import time
import uuid
import winreg

jarvis = None  # main.py se anota acá al arrancar

CARPETA_ADMIN = os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), "JARVIS")
ORDEN = os.path.join(CARPETA_ADMIN, "pedidos", "orden.json")
RESULTADO = os.path.join(CARPETA_ADMIN, "resultado.json")
TAREA = "JARVIS Ventiladores"
POWERSHELL = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "WindowsPowerShell", "v1.0",
                          "powershell.exe")
SIN_VENTANA = 0x08000000
MODOS = {"equilibrado": 0, "rendimiento": 1, "silencioso": 3}  # los valores del BIOS de las Victus (0x1A)
REPETIR_MAXIMO = 100  # segundos: el máximo se vuelve a mandar cada tanto, por si el BIOS lo saca solo

estado = {"maximo": False, "modo": None}
_lock = threading.Lock()

# El script que corre como administrador. Solo hace estas órdenes fijas, con números validados.
SCRIPT = r"""# JARVIS - ventiladores. Lo corre la tarea "JARVIS Ventiladores" como administrador.
# Solo hace estas órdenes: leer, maximo (0 o 1) y modo (0, 1 o 3). Lee la orden de pedidos\orden.json y deja el
# resultado en resultado.json. Esta carpeta solo la pueden cambiar los administradores.
$env:PSModulePath = "$PSHOME\Modules"   # solo los módulos de Windows
$ErrorActionPreference = "Stop"
$salida = [ordered]@{ id = ""; ok = $false; error = ""; datos = [ordered]@{} }

function Llamar([uint32]$tipo, [byte[]]$datos) {
    # hpqBData tiene que medir exactamente Size (la clase de HP dice WmiSizeIs=Size)
    $entrada = ([wmiclass]"root\wmi:hpqBDataIn").CreateInstance()
    $entrada.Sign = [byte[]](0x53, 0x45, 0x43, 0x55)
    $entrada.Command = [uint32]0x20008
    $entrada.CommandType = $tipo
    $entrada.Size = [uint32]$datos.Length
    $entrada.hpqBData = $datos
    $bios = Get-WmiObject -Namespace root\wmi -Class hpqBIntM
    $r = $bios.hpqBIOSInt128($entrada)
    $bytes = @()
    if ($r.OutData.Data) { $bytes = @($r.OutData.Data[0..15] | ForEach-Object { [int]$_ }) }
    return [ordered]@{ codigo = [int]$r.OutData.rwReturnCode; bytes = $bytes }
}

try {
    $orden = Get-Content -Raw -LiteralPath "$PSScriptRoot\pedidos\orden.json" | ConvertFrom-Json
    if ([string]$orden.id -notmatch '^[0-9a-f]{8,32}$') { throw "orden sin id" }
    $salida.id = [string]$orden.id
    $valor = [int]$orden.valor
    switch ([string]$orden.accion) {
        "leer" {
            $salida.datos.cantidad = Llamar 0x10 ([byte[]](0, 0, 0, 0))
            $salida.datos.victus_s = Llamar 0x2D ([byte[]](0, 0, 0, 0))
            $salida.datos.fan0 = Llamar 0x11 ([byte[]](0, 0, 0, 0))
            $salida.datos.fan1 = Llamar 0x11 ([byte[]](1, 0, 0, 0))
            $salida.datos.maximo = Llamar 0x26 ([byte[]](0, 0, 0, 0))
            $salida.datos.temperatura = Llamar 0x23 ([byte[]](1, 0, 0, 0))
        }
        "maximo" {
            if ($valor -notin 0, 1) { throw "valor no permitido" }
            $salida.datos.respuesta = Llamar 0x27 ([byte[]]($valor, 0, 0, 0))
        }
        "modo" {
            if ($valor -notin 0, 1, 3) { throw "valor no permitido" }
            $salida.datos.respuesta = Llamar 0x1A ([byte[]](0xFF, $valor))
        }
        default { throw "orden desconocida" }
    }
    $salida.ok = $true
} catch {
    $salida.error = $_.Exception.Message
}
$salida | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$PSScriptRoot\resultado.json" -Encoding UTF8
"""

# El que instala (corre una sola vez, con el permiso de administrador que pide Windows)
INSTALADOR = r"""param([string]$Origen)
$ErrorActionPreference = "Stop"
$destino = "$env:ProgramData\JARVIS"
try {
    New-Item -ItemType Directory -Force -Path "$destino\pedidos" | Out-Null
    Copy-Item -LiteralPath "$Origen\ventiladores.ps1" -Destination "$destino\ventiladores.ps1" -Force
    # Solo administradores y SYSTEM cambian la carpeta (y el script); los usuarios leen. En "pedidos" JARVIS deja la orden.
    & icacls $destino /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "*S-1-5-32-545:(OI)(CI)RX" | Out-Null
    & icacls "$destino\pedidos" /grant "*S-1-5-32-545:(OI)(CI)M" | Out-Null
    $exe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $accion = New-ScheduledTaskAction -Execute $exe -Argument "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$destino\ventiladores.ps1`""
    $quien = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType S4U -RunLevel Highest
    $opciones = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances Queue -ExecutionTimeLimit (New-TimeSpan -Minutes 2)
    Register-ScheduledTask -TaskName "JARVIS Ventiladores" -Action $accion -Principal $quien -Settings $opciones -Force | Out-Null
    "ok" | Set-Content -LiteralPath "$Origen\instalado.txt"
} catch {
    $_.Exception.Message | Set-Content -LiteralPath "$Origen\instalado.txt"
}
"""


# ======================= ¿Se puede? =======================

def marca_y_modelo():
    """('HP', 'Victus by HP Gaming Laptop 15-fa2xxx'), leído del registro (no hace falta ser administrador)."""
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS") as k:
            return winreg.QueryValueEx(k, "SystemManufacturer")[0], winreg.QueryValueEx(k, "SystemProductName")[0]
    except OSError:
        return "", ""


def es_hp():
    marca, modelo = marca_y_modelo()
    return marca.upper().startswith("HP") or "HEWLETT" in marca.upper()


def instalado():
    return os.path.exists(os.path.join(CARPETA_ADMIN, "ventiladores.ps1")) and subprocess.run(
        ["schtasks", "/query", "/tn", TAREA], capture_output=True, creationflags=SIN_VENTANA).returncode == 0


def al_dia():
    """¿El script instalado es el de esta versión de JARVIS? (si cambió, hay que instalarlo de nuevo)."""
    try:
        with open(os.path.join(CARPETA_ADMIN, "ventiladores.ps1"), encoding="utf-8-sig") as f:
            return f.read().replace("\r\n", "\n").strip() == SCRIPT.strip()
    except OSError:
        return False


def instalar():
    """Pide permiso de administrador (el cartel de Windows) y crea la tarea. Devuelve el error ('' si anduvo)."""
    # una carpeta común de tu usuario (no tempfile.mkdtemp: esa tiene permisos tan cerrados que el archivo que deja el
    # instalador, que corre como administrador, después no se podía leer: "Permission denied")
    carpeta = os.path.join(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir(), "JARVIS", "instalar_ventiladores")
    os.makedirs(carpeta, exist_ok=True)
    marca = os.path.join(carpeta, "instalado.txt")
    if os.path.exists(marca):
        os.remove(marca)
    for nombre, texto in (("ventiladores.ps1", SCRIPT), ("instalar.ps1", INSTALADOR)):
        with open(os.path.join(carpeta, nombre), "w", encoding="utf-8-sig") as f:  # con BOM: PowerShell 5 lee bien las tildes
            f.write(texto)
    argumentos = f'-NoProfile -ExecutionPolicy Bypass -File "{os.path.join(carpeta, "instalar.ps1")}" -Origen "{carpeta}"'
    r = ctypes.windll.shell32.ShellExecuteW(None, "runas", POWERSHELL, argumentos, None, 0)
    if r <= 32:
        return "no me diste el permiso de administrador" if r == 5 else f"Windows no lo dejó abrir (error {r})"
    for _ in range(120):  # hasta 2 minutos para tocar "Sí"
        if os.path.exists(marca):
            time.sleep(0.5)
            try:
                with open(marca, encoding="utf-8-sig", errors="replace") as f:
                    texto = f.read().strip()
            except PermissionError:  # todavía lo está escribiendo
                continue
            return "" if texto == "ok" else texto
        time.sleep(1)
    if instalado() and al_dia():  # por si no se pudo leer la marca, pero quedó instalado
        return ""
    return "no me diste el permiso de administrador a tiempo"


# ======================= Las órdenes =======================

def ordenar(accion, valor=0, espera=20):
    """Deja la orden, lanza la tarea y espera el resultado. Devuelve el diccionario del resultado."""
    with _lock:
        identificador = uuid.uuid4().hex
        with open(ORDEN, "w", encoding="utf-8") as f:
            json.dump({"id": identificador, "accion": accion, "valor": int(valor)}, f)
        r = subprocess.run(["schtasks", "/run", "/tn", TAREA], capture_output=True, text=True,
                           creationflags=SIN_VENTANA)
        if r.returncode != 0:
            raise RuntimeError("no pude lanzar la tarea «JARVIS Ventiladores»: " + (r.stderr or r.stdout).strip()[:150])
        limite = time.time() + espera
        while time.time() < limite:
            time.sleep(0.4)
            try:
                with open(RESULTADO, encoding="utf-8-sig") as f:
                    datos = json.load(f)
            except (OSError, ValueError):
                continue
            if datos.get("id") == identificador:
                if not datos.get("ok"):
                    raise RuntimeError(datos.get("error") or "el BIOS no respondió")
                return datos.get("datos") or {}
        raise RuntimeError("la tarea no contestó a tiempo")


def _bien(respuesta):
    return isinstance(respuesta, dict) and respuesta.get("codigo") == 0


def leer():
    """{'rpm': [2400, 2600], 'maximo': False, 'cpu': 61 o None}, con lo que el BIOS sabe contestar."""
    d = ordenar("leer")
    cantidad = 2
    if _bien(d.get("cantidad")) and d["cantidad"]["bytes"] and 0 < d["cantidad"]["bytes"][0] <= 4:
        cantidad = d["cantidad"]["bytes"][0]
    rpm = []
    vs = d.get("victus_s")
    if _bien(vs) and any(vs["bytes"][:cantidad]):  # Victus nuevas: un byte por ventilador, en cientos de rpm
        rpm = [b * 100 for b in vs["bytes"][:cantidad]]
    else:  # OMEN: cada ventilador por separado, en los bytes 2 y 3
        for clave in ("fan0", "fan1")[:cantidad]:
            f = d.get(clave)
            if _bien(f) and len(f["bytes"]) >= 4:
                rpm.append(f["bytes"][2] * 256 + f["bytes"][3])
    maximo = None
    if _bien(d.get("maximo")) and d["maximo"]["bytes"]:
        maximo = d["maximo"]["bytes"][0] == 1
    cpu = None
    t = d.get("temperatura")
    if _bien(t) and t["bytes"] and 15 < t["bytes"][0] < 110:
        cpu = t["bytes"][0]
    return {"rpm": rpm, "maximo": maximo, "cpu": cpu}


def poner_maximo(activar):
    r = ordenar("maximo", 1 if activar else 0).get("respuesta")
    if not _bien(r):
        raise RuntimeError(f"el BIOS no lo aceptó (código {r.get('codigo') if isinstance(r, dict) else '?'})")
    estado["maximo"] = activar
    if activar:
        threading.Thread(target=_mantener_maximo, daemon=True).start()


def _mantener_maximo():
    """Mientras pediste el máximo, lo vuelve a mandar cada tanto (algunos BIOS lo sacan solos a los 2 minutos).
    Si cerrás JARVIS, deja de mandarlo y el BIOS vuelve solo a lo normal."""
    while True:
        time.sleep(REPETIR_MAXIMO)
        if not estado["maximo"]:
            return
        try:
            ordenar("maximo", 1)
        except Exception:
            pass


def poner_modo(modo):
    r = ordenar("modo", MODOS[modo]).get("respuesta")
    if not _bien(r):
        raise RuntimeError(f"el BIOS no aceptó el modo {modo} (código {r.get('codigo') if isinstance(r, dict) else '?'})")
    estado["modo"] = modo


def describir(datos):
    partes = []
    rpm = datos["rpm"]
    if rpm and any(rpm):
        if len(rpm) == 1:
            partes.append(f"El ventilador gira a {rpm[0]} rpm.")
        else:
            partes.append(f"Tus {len(rpm)} ventiladores giran a " + " y ".join(f"{r}" for r in rpm) + " rpm.")
    elif rpm:
        partes.append("Los ventiladores están quietos (la compu está fresca).")
    temperaturas = []
    if datos["cpu"]:
        temperaturas.append(f"el procesador a {datos['cpu']} grados")
    g = jarvis.herramientas.gpu() if jarvis else None
    if g:
        temperaturas.append(f"la placa de video a {g['temp']} grados")
    if temperaturas:
        partes.append("Está " + " y ".join(temperaturas) + ".")
    if datos["maximo"] is not None:
        partes.append("Están al máximo." if datos["maximo"] else "Están en automático.")
    if estado["modo"]:
        partes.append(f"El modo que puse es {estado['modo']}.")
    return " ".join(partes) or "El BIOS no me dio datos de los ventiladores."


# ======================= Lo que decís =======================

VENT = r"(?:ventiladores|ventilador|coolers|cooler|fans|ventilacion)"
VER = re.compile(rf"\b(?:como (?:estan|andan|van) (?:los |el )?{VENT}|(?:velocidad|rpm|estado|vueltas) de (?:los |el )?{VENT}|"
                 rf"a cuanto (?:giran|van|andan) (?:los )?{VENT})\b")
MAXIMO = re.compile(rf"\b(?:{VENT}\s+(?:al|a|en)\s+(?:maximo|full|tope|fondo|100(?: por ciento)?)|"
                    rf"(?:pone|poneme|subi|subime|manda|mete|activa|prende)\w*\s+(?:los |el )?{VENT}\s+(?:al|a)\s+"
                    rf"(?:maximo|full|tope|fondo)|(?:maximo|full) de (?:los )?{VENT}|max fan)\b")
NORMAL = re.compile(rf"\b(?:{VENT}\s+(?:en |al? )?(?:normal|automatico|auto|como estaban|como antes)|"
                    rf"(?:saca|sacale|desactiva|apaga|baja|bajame|frena|para)\w*\s+(?:el maximo de |el maximo a )?"
                    rf"(?:los |el )?{VENT}|(?:saca|desactiva|apaga)\w* el maximo de (?:los )?{VENT})\b")
MODO = re.compile(r"^(?:(?:che|jarvis)[\s,]+)?(?:pone(?:me|le)?|pon|activa|cambia|pasa|usa|quiero)?\w*\s*(?:a |al |en )?"
                  r"(?:el )?modo (?P<modo>rendimiento|performance|turbo|equilibrado|balanceado|balanced|silencioso|"
                  r"silencio|eco|quiet)\b")
INSTALAR = re.compile(rf"\b(?:configura|instala|habilita|conecta)\w*\s+(?:el control de |el manejo de )?(?:los |el )?{VENT}\b")
NOMBRE_MODO = {"rendimiento": "rendimiento", "performance": "rendimiento", "turbo": "rendimiento",
               "equilibrado": "equilibrado", "balanceado": "equilibrado", "balanced": "equilibrado",
               "silencioso": "silencioso", "silencio": "silencioso", "eco": "silencioso", "quiet": "silencioso"}


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    ver, maximo, normal = VER.search(t), MAXIMO.search(t), NORMAL.search(t)
    modo, instalar_ = MODO.match(t), INSTALAR.search(t)
    if not (ver or maximo or normal or modo or instalar_):
        return None
    if not es_hp():
        marca, modelo = marca_y_modelo()
        return (f"Manejar los ventiladores lo sé hacer en notebooks HP OMEN y Victus, y esta es {marca} {modelo}."
                .replace("  ", " "))
    if instalar_:
        if instalado() and al_dia():
            return "Ya está configurado. Decime «¿cómo están los ventiladores?», «ventiladores al máximo» o «modo rendimiento»."
        jarvis.emitir("detalle", "Windows te va a pedir permiso de administrador: tocá «Sí».")
        error = instalar()
        if error:
            return f"No pude configurarlo: {error}."
        try:
            return "Listo, ya manejo los ventiladores como OMEN Gaming Hub. " + describir(leer())
        except Exception as e:
            return f"Quedó configurado, pero el BIOS no me contestó la primera lectura ({e})."
    if not instalado():
        return ("Para manejar los ventiladores necesito permiso de administrador una sola vez: decime «configurá los "
                "ventiladores» y tocá «Sí» en el cartel de Windows.")
    if not al_dia():
        return ("Tengo que actualizar el control de los ventiladores (una sola vez): decime «configurá los ventiladores» "
                "y tocá «Sí» en el cartel de Windows.")
    try:
        if maximo and not normal:
            poner_maximo(True)
            return "Listo, ventiladores al máximo. Cuando quieras, decime «ventiladores en automático»."
        if normal:
            poner_maximo(False)
            aviso = " (Apagarlos del todo no, que se recalentaría.)" if re.search(r"\bapaga", t) else ""
            return "Listo, los ventiladores vuelven a automático: los maneja el BIOS según la temperatura." + aviso
        if modo:
            nombre = NOMBRE_MODO[modo.group("modo")]
            poner_modo(nombre)
            explicacion = {"rendimiento": "más potencia; los ventiladores suben antes",
                           "equilibrado": "el normal", "silencioso": "menos ruido y menos potencia"}[nombre]
            return f"Listo, modo {nombre} ({explicacion})."
        return describir(leer())
    except Exception as e:
        return f"No pude manejar los ventiladores: {e}."
