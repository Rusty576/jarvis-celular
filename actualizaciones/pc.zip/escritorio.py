"""JARVIS en la ventana que tenés adelante (dictado, escribir, reescribir y clics por voz). Todo sin internet.

  Dictado:      "dictá hola cómo andás coma ya llegué", "modo dictado" (todo lo que digas se escribe) y
                "terminá el dictado". Correcciones habladas: "borrá eso", "no, quise decir ...", "mejor dicho ...".
                Puntuación hablada: coma, punto, dos puntos, nueva línea, nuevo párrafo, abrir/cerrar paréntesis...
                "dictado exacto / limpio / pulido" cambia cómo queda (pulido lo prolija la IA).
  Diccionario:  "agregá al diccionario: jarbis se escribe JARVIS". Frases guardadas: "guardá la frase firma: Saludos,
                Héctor" y después "insertá firma".
  Escribir:     "escribí acá un mail pidiendo un turno" (la IA lo redacta y lo pega en la ventana).
  Reescribir:   con un texto seleccionado: "hacé más corto lo seleccionado", "pasá esto a formal", "traducí lo
                seleccionado al inglés", "corregí la selección".
  Clics:        "hacé clic en iniciar sesión", "tocá el botón siguiente", "marcá la casilla envío gratis",
                "elegí la opción envío express", "completá mi nombre con Sam". Nunca toca botones de comprar,
                pagar, enviar ni borrar.
  Mostrar:      "¿dónde está el botón exportar?" (lo marca con un anillo en la pantalla).
  Teleprompter: "empezá el teleprompter" (con el texto que copiaste; avanza mientras hablás, clic para pausar).
"""
import ctypes
import difflib
import json
import os
import re
import subprocess
import sys
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "dictado.json")
_u32 = ctypes.windll.user32
_lock = threading.Lock()

# la última ventana que usaste que no es JARVIS (JARVIS la mira cada 0,3 s)
objetivo = {"hwnd": 0, "titulo": "", "exe": ""}
dictando = {"activo": False, "ultimo": 0.0}


def _n(texto):
    return jarvis.normalizar(texto)


# ---------- La ventana de adelante ----------

def _datos_ventana(hwnd):
    import psutil
    import win32gui
    import win32process
    _, pid = win32process.GetWindowThreadProcessId(hwnd)
    try:
        exe = psutil.Process(pid).name().lower()
    except Exception:
        exe = ""
    return pid, exe, win32gui.GetWindowText(hwnd).strip(), win32gui.GetClassName(hwnd)


def _vigilar():
    import win32gui
    while True:
        time.sleep(0.3)
        try:
            hwnd = win32gui.GetForegroundWindow()
            if not hwnd or hwnd == objetivo["hwnd"]:
                continue
            pid, exe, titulo, clase = _datos_ventana(hwnd)
            if pid == os.getpid() or clase in ("Shell_TrayWnd", "Progman", "WorkerW") or not titulo \
                    or titulo.startswith("JARVIS ·"):  # JARVIS, la barra de tareas, el escritorio y sus ventanitas
                continue
            objetivo.update(hwnd=hwnd, titulo=titulo, exe=exe)
        except Exception:
            pass


_iniciado = [False]


def iniciar():
    if not _iniciado[0]:
        _iniciado[0] = True
        threading.Thread(target=_vigilar, daemon=True).start()
        threading.Thread(target=_vigilar_teclas, daemon=True).start()


def nombre_ventana():
    titulo = objetivo["titulo"]
    return f"«{titulo[:60]}»" if titulo else "la ventana de adelante"


def traer_al_frente():
    """Pone adelante la última ventana que usaste (no JARVIS). True si quedó adelante."""
    hwnd = objetivo["hwnd"]
    if not hwnd or not _u32.IsWindow(hwnd):
        return False
    if _u32.GetForegroundWindow() == hwnd:
        return True  # ya está adelante: sin el Alt de abajo (en muchas ventanas abre el menú y se come el Ctrl+V)
    if _u32.IsIconic(hwnd):
        _u32.ShowWindow(hwnd, 9)  # SW_RESTORE
    for _ in range(3):
        _u32.keybd_event(0x12, 0, 0, 0)  # un Alt "suelto" deja que Windows nos pase el foco
        _u32.keybd_event(0x12, 0, 2, 0)
        _u32.SetForegroundWindow(hwnd)
        limite = time.time() + 0.8
        while time.time() < limite:
            if _u32.GetForegroundWindow() == hwnd:
                time.sleep(0.15)
                return True
            time.sleep(0.05)
    return False


def _teclas(*vks):
    for vk in vks:
        _u32.keybd_event(vk, 0, 0, 0)
    for vk in reversed(vks):
        _u32.keybd_event(vk, 0, 2, 0)


def pegar(texto):
    """Escribe el texto en la ventana de adelante (pegándolo) y deja el portapapeles como estaba."""
    hab = jarvis.habilidades
    if not traer_al_frente():
        raise RuntimeError(f"no pude volver a {nombre_ventana()}")
    antes = hab.leer_portapapeles()
    hab.escribir_portapapeles(texto)
    _teclas(0x11, 0x56)  # Ctrl+V
    time.sleep(0.35)
    if antes is not None:
        threading.Timer(0.6, lambda: hab.escribir_portapapeles(antes)).start()


def copiar_seleccion():
    """El texto que tenés seleccionado en la ventana de adelante ("" si no hay nada)."""
    hab = jarvis.habilidades
    if not traer_al_frente():
        return ""
    antes = hab.leer_portapapeles()
    marca = f"⁣jarvis{time.time()}"
    hab.escribir_portapapeles(marca)
    _teclas(0x11, 0x43)  # Ctrl+C
    texto = ""
    limite = time.time() + 1.2
    while time.time() < limite:
        time.sleep(0.08)
        actual = hab.leer_portapapeles()
        if actual and actual != marca:
            texto = actual
            break
    if antes is not None:
        hab.escribir_portapapeles(antes)
    return texto


# ---------- Dictado ----------

def _config():
    try:
        with open(ARCHIVO, encoding="utf-8") as f:
            datos = json.load(f)
    except (OSError, ValueError):
        datos = {}
    datos.setdefault("estilo", "limpio")
    datos.setdefault("diccionario", {})
    datos.setdefault("frases", {})
    return datos


def _guardar(datos):
    with _lock:
        tmp = ARCHIVO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=1)
        os.replace(tmp, ARCHIVO)


PUNTUACION = [  # (lo que decís, lo que se escribe); primero las frases largas
    (r"punto y aparte|nuevo parrafo", "\n\n"), (r"punto y coma", ";"), (r"punto final", "."),
    (r"nueva linea|salto de linea|otra linea|renglon nuevo", "\n"), (r"dos puntos", ":"),
    (r"signo de (?:pregunta|interrogacion)|cerrar pregunta", "?"), (r"abrir pregunta|abrir signo de pregunta", "¿"),
    (r"signo de exclamacion|cerrar exclamacion", "!"), (r"abrir exclamacion", "¡"),
    (r"abrir parentesis", "("), (r"cerrar parentesis", ")"), (r"abrir comillas|cerrar comillas|comillas", "\""),
    (r"puntos suspensivos", "..."), (r"guion", "-"), (r"coma", ","),
    (r"punto(?=\s*$)", "."),  # "punto" suelto solo al final ("punto de vista" queda como está)
]
BORRAR_ESO = re.compile(r"[\s,]*\b(?:borra|tacha|saca) eso\b[\s,.]*", re.IGNORECASE)
QUISE_DECIR = re.compile(r"[\s,]*\b(?:no,? quise decir|no,? quiero decir|mejor dicho|perdon,? quise decir)\b[\s,]*",
                         re.IGNORECASE)


def _sin_tildes(texto):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", texto) if unicodedata.category(c) != "Mn")


def _reemplazar_hablado(texto, patron, por):
    """Reemplaza una palabra dicha (sin importar tildes ni mayúsculas) conservando el resto tal cual."""
    plano = _sin_tildes(texto).lower()
    salida, desde = [], 0
    for m in re.finditer(rf"(?<!\w)(?:{patron})(?!\w)", plano):
        salida.append(texto[desde:m.start()])
        salida.append(por)
        desde = m.end()
    salida.append(texto[desde:])
    return "".join(salida)


def aplicar_correcciones(texto):
    """'mañana voy, borrá eso, el lunes voy' -> 'el lunes voy'; 'a las cinco no quise decir a las seis' ->
    'a las seis'."""
    while True:
        m = BORRAR_ESO.search(_sin_tildes(texto))
        if not m:
            break
        antes = texto[:m.start()]
        corte = max(antes.rfind(c) for c in ".,;:!?\n")  # se va la última frase (hasta la coma o el punto anterior)
        texto = (antes[:corte + 1] + " " if corte >= 0 else "") + texto[m.end():]
    while True:
        m = QUISE_DECIR.search(_sin_tildes(texto))
        if not m:
            break
        antes, despues = texto[:m.start()], texto[m.end():]
        nuevas = despues.split()
        if not nuevas:
            texto = antes
            break
        palabras = antes.split()
        cuantas = min(len(nuevas), len(palabras))
        texto = " ".join(palabras[:len(palabras) - cuantas] + nuevas)
    return texto


def puntuar(texto):
    for patron, signo in PUNTUACION:
        texto = _reemplazar_hablado(texto, patron, f"⁠{signo}⁠")
    # los signos se pegan a la palabra de antes ("hola ,") y los de abrir a la de después
    texto = re.sub(r"\s*⁠([,.;:?!)\"]|\.\.\.)⁠\s*", r"\1 ", texto)
    texto = re.sub(r"\s*⁠([¿¡(])⁠\s*", r" \1", texto)
    texto = re.sub(r"\s*⁠(\n+)⁠\s*", r"\1", texto)
    return re.sub(r"[ \t]{2,}", " ", texto).strip(" ")


MULETILLAS = re.compile(r"(?<!\w)(?:e+h+|e+m+|m{2,}|a+h+|u+m+|u+h+)(?!\w)[\s,]*", re.IGNORECASE)
REPETIDA = re.compile(r"\b(\w+)(\s+\1\b)+", re.IGNORECASE)


def sin_muletillas(texto):
    """'eh mañana em voy voy al centro' -> 'mañana voy al centro'."""
    texto = MULETILLAS.sub("", texto)
    texto = REPETIDA.sub(r"\1", texto)
    return re.sub(r"\s{2,}", " ", texto).strip()


def limpiar_dictado(texto, estilo="limpio", diccionario=None):
    texto = aplicar_correcciones(texto.strip())
    for mal, bien in (diccionario or {}).items():
        texto = _reemplazar_hablado(texto, re.escape(_sin_tildes(mal).lower()), bien)
    if estilo == "exacto":
        return texto
    texto = sin_muletillas(texto)
    texto = puntuar(texto)
    # mayúscula al principio y después de cada punto
    texto = re.sub(r"(^|[.?!]\s+|[¿¡]|\n)([a-záéíóúñü])", lambda m: m.group(1) + m.group(2).upper(), texto)
    return texto


def pulir(texto):
    """Dictado pulido: la IA arregla gramática y puntuación sin cambiar lo que dijiste (si falla, queda limpio)."""
    try:
        r = jarvis.chat_modelo([
            {"role": "system", "content": "Corregí la puntuación, las mayúsculas y los errores de dictado del texto. "
             "No agregues ni saques ideas, no cambies el sentido, no respondas nada: devolvé solo el texto corregido."},
            {"role": "user", "content": texto}], temperature=0.1, num_predict=len(texto) // 2 + 60)
        nuevo = r["message"]["content"].strip().strip('"«»')
    except Exception:
        return texto
    # si la IA se fue de mambo (lo alargó mucho o se comió números, mails o links), queda el limpio
    protegidos = re.findall(r"\S+@\S+|https?://\S+|\d+", texto)
    if not nuevo or len(nuevo) > len(texto) * 1.4 + 20 or any(p not in nuevo for p in protegidos):
        return texto
    return nuevo


# Estilo según la app donde dictás (como heynixi): casual en los chats, formal en el mail y los documentos, código
# en el editor y la terminal. Se cambia con "en WhatsApp dictá formal" (queda en dictado.json).
ESTILOS_APP = {  # parte del exe o del título de la ventana -> estilo
    "whatsapp": "casual", "telegram": "casual", "discord": "casual", "instagram": "casual", "messenger": "casual",
    "gmail": "formal", "outlook": "formal", "winword": "formal", "word": "formal", "onlyoffice": "formal",
    "docs.google": "formal", "documentos de google": "formal",
    "code.exe": "codigo", "visual studio code": "codigo", "windowsterminal": "codigo", "powershell": "codigo",
    "cmd.exe": "codigo", "pycharm": "codigo", "notepad++": "codigo",
}


def estilo_de_la_app(datos=None):
    """El estilo para la ventana donde vas a dictar (lo que elegiste vos para esa app manda)."""
    datos = datos or _config()
    donde = (objetivo["exe"] + " " + objetivo["titulo"]).lower()
    for clave, estilo in list(datos.get("estilos_app", {}).items()) + list(ESTILOS_APP.items()):
        if clave.lower() in donde:
            return estilo
    return None


def con_estilo(texto, estilo):
    """casual: sin mayúscula al principio ni punto final (como en un chat). formal: mayúscula, punto final y sin
    abreviaturas de chat. codigo: tal cual, sin mayúsculas ni puntuación agregadas."""
    if estilo == "casual":
        texto = texto.rstrip()
        if texto.endswith(".") and not texto.endswith(".."):
            texto = texto[:-1]
        if len(texto) > 1 and texto[0].isupper() and not texto[1].isupper():
            texto = texto[0].lower() + texto[1:]
    elif estilo == "formal":
        for chat, bien in (("q ", "que "), ("xq", "porque"), ("tmb", "también"), ("pq", "porque"), ("x favor", "por favor")):
            texto = re.sub(rf"\b{re.escape(chat.strip())}\b", bien.strip(), texto)
        texto = texto[:1].upper() + texto[1:]
        if texto and texto.rstrip()[-1:] not in ".?!:":
            texto = texto.rstrip() + "."
    return texto


def dictar(texto):
    datos = _config()
    t = _n(texto).strip(" .,")
    m = re.match(r"^(?:inserta|escribi|pone|tipea)?\s*(?:la frase\s+)?(.+)$", t)
    clave = m.group(1) if m else t
    frases = {_n(k): v for k, v in datos["frases"].items()}
    if clave in frases:
        final = frases[clave]
    else:
        estilo_app = estilo_de_la_app(datos)
        if estilo_app == "codigo":
            final = limpiar_dictado(texto, "exacto", datos["diccionario"])
        else:
            final = limpiar_dictado(texto, datos["estilo"], datos["diccionario"])
            if datos["estilo"] == "pulido" and len(final.split()) > 3:
                final = pulir(final)
            if estilo_app:
                final = con_estilo(final, estilo_app)
    if not final:
        return "No me quedó nada para escribir."
    pegar(final if final.endswith(("\n", " ")) else final + " ")
    dictando["ultimo"] = time.time()
    return None


DICTAR = re.compile(r"^(?:dicta|tipea|escribi lo siguiente|escribi textual)\s*:?\s+(?P<texto>.+)$")
EMPEZAR_DICTADO = re.compile(r"^(?:modo dictado|activa(?:r)? (?:el )?(?:modo )?dictado|empeza(?:r)? a dictar|"
                             r"vamos a dictar|quiero dictar)$")
TERMINAR_DICTADO = re.compile(r"^(?:termina\w*|para|frena|corta|sali\w*|desactiva\w*|fin(?: del)?|basta(?: de)?|"
                              r"deja de)\s*(?:el |del |de )?(?:modo )?dict\w*$")
ESTILO = re.compile(r"^(?:pone(?:me)?\s+(?:el\s+)?)?(?:dictado|modo de dictado)\s+(exacto|limpio|pulido)$")
DICCIONARIO = re.compile(r"^(?:agrega|suma|anota)\w*\s+(?:al|en el|a mi)\s+diccionario\s*:?\s*(?P<mal>.+?)\s+"
                         r"(?:se escribe|es|va como|escribilo como)\s+(?P<bien>.+)$")
FRASE = re.compile(r"^(?:guarda|agrega|crea)\w*\s+(?:la |una )?frase\s+(?P<clave>[\w ]+?)\s*:\s*(?P<texto>.+)$")


def _original(texto, t, m, g):
    """El grupo g del match (hecho sobre el texto normalizado) pero con las tildes y mayúsculas que dijiste."""
    base = texto.strip(" ,.;:¡!¿?")
    if len(base) == len(m.string):
        return base[m.start(g):m.end(g)]
    return m.group(g)


def dictado_en_curso(texto, t):
    """En modo dictado, todo lo que digas se escribe en la ventana ("" = escrito, sin nada que mostrar).
    None si no hay dictado en curso."""
    t = t.strip(" ¿?¡!.,")
    if not dictando["activo"]:
        return None
    if time.time() - dictando["ultimo"] > 600:  # 10 minutos sin dictar: se apaga solo
        dictando["activo"] = False
        return None
    if TERMINAR_DICTADO.match(t):
        dictando["activo"] = False
        return "Listo, terminé el dictado."
    try:
        return dictar(texto) or ""
    except Exception as e:
        return f"No pude escribirlo: {e}."


ESTILO_APP = re.compile(r"^(?:en|para)\s+(?:el\s+|la\s+)?(?P<app>[\w .+-]+?)\s*,?\s+(?:dicta(?:me)?|escribi(?:me)?|"
                        r"usa(?:\s+estilo)?|estilo)\s+(?P<estilo>casual|formal|codigo|normal)$|"
                        r"^(?:estilo|dictado)\s+(?P<estilo2>casual|formal|codigo|normal)\s+(?:en|para)\s+(?:el\s+|la\s+)?"
                        r"(?P<app2>[\w .+-]+)$")


def manejar_dictado(texto, t):
    m = ESTILO_APP.match(t)
    if m:
        app = (m.group("app") or m.group("app2")).strip()
        estilo = m.group("estilo") or m.group("estilo2")
        datos = _config()
        estilos = datos.setdefault("estilos_app", {})
        if estilo == "normal":
            estilos.pop(app, None)
            estilos[app] = "ninguno"  # "normal" le saca también el estilo que traía por defecto
        else:
            estilos[app] = estilo
        _guardar(datos)
        explica = {"casual": "como en un chat (sin mayúscula al principio ni punto final)",
                   "formal": "con mayúscula, punto final y sin abreviaturas", "codigo": "tal cual, sin agregar nada",
                   "normal": "con el estilo de siempre"}[estilo]
        return f"Listo: cuando dictes en {app}, lo escribo {explica}."
    if EMPEZAR_DICTADO.match(t):
        if not objetivo["hwnd"]:
            return "Primero hacé clic en la ventana donde querés que escriba, y después decime «modo dictado»."
        dictando.update(activo=True, ultimo=time.time())
        return (f"Modo dictado: todo lo que digas lo escribo en {nombre_ventana()}. Decí «terminá el dictado» "
                "para volver.")
    m = ESTILO.match(t)
    if m:
        datos = _config()
        datos["estilo"] = m.group(1)
        _guardar(datos)
        explica = {"exacto": "tal cual lo decís", "limpio": "con puntuación y mayúsculas",
                   "pulido": "y además la IA le arregla la gramática"}[m.group(1)]
        return f"Listo, el dictado ahora queda {m.group(1)}: {explica}."
    m = DICCIONARIO.match(t)
    if m:
        datos = _config()
        datos["diccionario"][m.group("mal").strip()] = _original(texto, t, m, "bien").strip(" .")
        _guardar(datos)
        return f"Anotado: cuando digas «{m.group('mal').strip()}» voy a escribir «{datos['diccionario'][m.group('mal').strip()]}»."
    m = FRASE.match(t)
    if m:
        datos = _config()
        datos["frases"][m.group("clave").strip()] = _original(texto, t, m, "texto").strip()
        _guardar(datos)
        return f"Guardé la frase «{m.group('clave').strip()}». Para usarla decí «insertá {m.group('clave').strip()}»."
    m = re.match(r"^inserta(?:me)?\s+(?:la frase\s+)?(.+)$", t)
    if m and _n(m.group(1)) in {_n(k) for k in _config()["frases"]}:
        try:
            return dictar(m.group(1)) or "Listo, la escribí."
        except Exception as e:
            return f"No pude escribirla: {e}."
    m = DICTAR.match(t)
    if m:
        try:
            dictar(_original(texto, t, m, "texto"))
            return f"Listo, lo escribí en {nombre_ventana()}."
        except Exception as e:
            return f"No pude escribirlo: {e}."
    return None


# ---------- Escribir y reescribir con la IA ----------

ESCRIBIR_AHI = re.compile(r"^(?:escribi|escribime|redacta|redactame|arma|armame)\s+(?:aca|ahi|en (?:la|esta|esa) "
                          r"ventana|en (?:el|la) (?:word|documento|mail|correo|chat|bloc de notas|notepad))\s*:?\s+"
                          r"(?P<pedido>.+)$")
SELECCION = r"(?:lo (?:que (?:seleccione|marque|tengo seleccionado|tengo marcado))|lo seleccionado|lo marcado|" \
            r"la seleccion|el texto (?:seleccionado|marcado)|esto)"
REESCRIBIR = re.compile(
    rf"^(?:(?:hace(?:me|lo|la)?|pone(?:lo|la)?|pasa(?:lo|la)?|reescribi(?:lo|la)?|deja(?:lo|la)?)\s+(?:mas\s+)?(?P<como1>.+?)\s+{SELECCION}"
    rf"|(?:hace(?:me)?|pone|pasa|reescribi|deja)\s+{SELECCION}\s+(?:a |en |mas |como )?(?P<como2>.+)"
    rf"|(?P<verbo>corregi|traduci|resumi|mejora|acorta|alarga|simplifica|ordena)\w*\s+{SELECCION}(?P<resto>.*))$")


def escribir_con_ia(pedido):
    if not objetivo["hwnd"]:
        return "Primero hacé clic en la ventana donde querés que escriba."
    try:
        r = jarvis.chat_modelo([
            {"role": "system", "content": "Escribí el texto que te piden, listo para pegar: sin títulos ni "
             "explicaciones antes o después, sin comillas y sin markdown. En español rioplatense salvo que pidan otro "
             "idioma."},
            {"role": "user", "content": pedido}], temperature=0.6, num_predict=700)
        texto = r["message"]["content"].strip()
    except jarvis.IAPausada:
        return "Estoy en modo juego: la IA está pausada."
    except Exception as e:
        return f"No pude escribirlo: {e}."
    if not texto:
        return "No me salió nada para escribir."
    try:
        pegar(texto)
    except Exception as e:
        return f"Lo escribí pero no lo pude pegar ({e}). Te lo dejo acá:\n{texto}"
    return f"Listo, lo escribí en {nombre_ventana()}."


def reescribir(como):
    original = copiar_seleccion()
    if not original.strip():
        return "No encontré texto seleccionado. Marcá el texto en la ventana y pedímelo de nuevo."
    try:
        r = jarvis.chat_modelo([
            {"role": "system", "content": "Reescribí el texto como te piden. Devolvé solo el texto nuevo, sin "
             "explicaciones, sin comillas y sin markdown. Conservá nombres, números, links y mails tal cual."},
            {"role": "user", "content": f"Cómo: {como}\n\nTexto:\n{original}"}],
            temperature=0.3, num_predict=len(original) + 300)
        nuevo = r["message"]["content"].strip()
    except jarvis.IAPausada:
        return "Estoy en modo juego: la IA está pausada."
    except Exception as e:
        return f"No pude reescribirlo: {e}."
    if not nuevo:
        return "No me salió nada; dejé tu texto como estaba."
    try:
        pegar(nuevo)  # el texto sigue seleccionado: pegar lo reemplaza
    except Exception as e:
        return f"No lo pude pegar ({e}). Te lo dejo acá:\n{nuevo}"
    return "Listo, lo reemplacé."


def manejar_texto(texto, t):
    m = ESCRIBIR_AHI.match(t)
    if m:
        return escribir_con_ia(_original(texto, t, m, "pedido"))
    m = REESCRIBIR.match(t)
    if m:
        if m.group("verbo"):
            como = {"corregi": "corregido (ortografía y gramática)", "traduci": "traducido", "resumi": "resumido",
                    "mejora": "mejor escrito", "acorta": "más corto", "alarga": "más largo",
                    "simplifica": "más simple", "ordena": "ordenado"}[m.group("verbo")]
            como += " " + m.group("resto").strip()
        else:
            como = "más " + (m.group("como1") or m.group("como2") or "")
            como = re.sub(r"^mas (?:a |en |como )", "", como)
        return reescribir(como.strip())
    return None


# ---------- Clics por voz (UI Automation de Windows) ----------

PELIGROSO = re.compile(r"\b(?:compr\w*|pag\w*|checkout|finaliz\w*|confirm\w* (?:compra|pedido|pago)|realizar pedido|"
                       r"envi\w*|mand\w*|borr\w*|elimin\w*|suprim\w*|transfer\w*|suscrib\w*|buy|pay|purchase|"
                       r"place order|send|delete|remove|subscribe|transfer)\b", re.IGNORECASE)
TIPOS = {  # nombre del tipo de control -> id de UI Automation
    "boton": 50000, "casilla": 50002, "combo": 50003, "campo": 50004, "link": 50005, "item": 50007,
    "menu": 50011, "opcion": 50013, "pestana": 50019, "texto": 50020,
}
CLIC = re.compile(r"^(?:hace(?:me)?\s+)?(?:un\s+)?(?:clic|click|clik)\s+(?:en|sobre)\s+(?:el |la |los |las )?"
                  r"(?:boton |link |enlace |opcion |pestana |menu )?(?P<que>.+)$"
                  r"|^(?:toca|apreta|presiona|pulsa)(?:me|le)?\s+(?:en\s+)?(?:el |la )?(?:boton|link|enlace|pestana)"
                  r"\s+(?:de\s+)?(?P<que2>.+)$")
MARCAR = re.compile(r"^(?P<accion>marca|tilda|activa|desmarca|destilda|desactiva)(?:me|le)?\s+(?:la |el )?"
                    r"(?:casilla|opcion|filtro|checkbox|tilde)\s+(?:de\s+)?(?P<que>.+)$")
ELEGIR = re.compile(r"^(?:elegi|elegime|selecciona|seleccioname|escoge)\s+(?:la |el )?(?:opcion|item)\s+(?:de\s+)?"
                    r"(?P<que>.+)$")
LLENAR = re.compile(r"^(?:(?:completa|llena|rellena)(?:me)?\s+(?:el |la )?(?:campo |casilla )?(?:de |del )?|"
                    r"(?:pone|escribi)(?:me)?\s+en\s+el\s+campo\s+(?:de |del )?)(?P<campo>.+?)\s+(?:con|como)\s+"
                    r"(?P<valor>.+)$")
DONDE = re.compile(r"^(?:(?:mostra|marca|indica)(?:me)?\s+|decime\s+)?donde\s+(?:esta|queda|se encuentra)\s+(?:el |la )"
                   r"(?:boton|link|enlace|opcion|casilla|campo|pestana|menu)\s+(?:de\s+)?(?P<que>.+)$")


def _uia():
    import comtypes.client
    comtypes.client.GetModule("UIAutomationCore.dll")
    from comtypes.gen import UIAutomationClient as U
    return U, comtypes.client.CreateObject(U.CUIAutomation, interface=U.IUIAutomation)


def _parecido(nombre, buscado):
    a, b = _n(nombre).strip(" :*."), _n(buscado).strip(" .")
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    puntaje = difflib.SequenceMatcher(None, a, b).ratio()
    if b in a.split() or (len(b) > 3 and b in a):
        puntaje = max(puntaje, 0.75 + 0.2 * len(b) / len(a))
    return puntaje


def buscar_control(buscado, tipos, espera=4.0):
    """El control de la ventana de adelante que más se parece a lo que nombraste: (elemento, nombre, puntaje)."""
    U, uia = _uia()
    hwnd = objetivo["hwnd"]
    if not hwnd or not _u32.IsWindow(hwnd):
        raise RuntimeError("no sé en qué ventana: hacé clic en ella primero")
    ventana = uia.ElementFromHandle(hwnd)
    conds = [uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, TIPOS[t]) for t in tipos]
    cond = conds[0]
    for c in conds[1:]:
        cond = uia.CreateOrCondition(cond, c)
    mejor = (None, "", 0.0)
    limite = time.time() + espera
    while True:  # los navegadores arman la accesibilidad de la página recién cuando alguien la pide: se reintenta
        elementos = ventana.FindAll(U.TreeScope_Descendants, cond)
        for i in range(min(elementos.Length, 3000)):
            el = elementos.GetElement(i)
            try:
                nombre = (el.CurrentName or "").strip()
                if not nombre or el.CurrentIsOffscreen:
                    continue
            except Exception:
                continue
            p = _parecido(nombre, buscado)
            if p > mejor[2]:
                mejor = (el, nombre, p)
        if mejor[2] >= 0.6 or time.time() > limite:
            break
        time.sleep(0.6)
    return mejor if mejor[2] >= 0.6 else (None, "", 0.0)


def _clic_en(el):
    r = el.CurrentBoundingRectangle
    traer_al_frente()
    _u32.SetCursorPos((r.left + r.right) // 2, (r.top + r.bottom) // 2)
    _u32.mouse_event(0x0002, 0, 0, 0, 0)
    _u32.mouse_event(0x0004, 0, 0, 0, 0)


def _patron(el, U, pid, interfaz):
    try:
        p = el.GetCurrentPattern(pid)
        return p.QueryInterface(interfaz) if p else None
    except Exception:
        return None


def tocar(buscado):
    if PELIGROSO.search(buscado):
        return f"Eso no lo toco yo: los botones de comprar, pagar, enviar o borrar los tocás vos."
    U, _ = _uia()
    el, nombre, _p = buscar_control(buscado, ["boton", "link", "menu", "pestana", "item", "opcion", "casilla"])
    if el is None:
        return f"No encontré «{buscado}» en {nombre_ventana()}."
    if PELIGROSO.search(nombre):
        return f"Encontré «{nombre}», pero ese no lo toco yo: es de comprar, pagar, enviar o borrar. Tocalo vos."
    inv = _patron(el, U, U.UIA_InvokePatternId, U.IUIAutomationInvokePattern)
    sel = _patron(el, U, U.UIA_SelectionItemPatternId, U.IUIAutomationSelectionItemPattern)
    if inv:
        inv.Invoke()
    elif sel:
        sel.Select()
    else:
        _clic_en(el)
    return f"Listo, toqué «{nombre}»."


def marcar(buscado, prender=True):
    U, _ = _uia()
    el, nombre, _p = buscar_control(buscado, ["casilla", "opcion", "item", "boton"])
    if el is None:
        return f"No encontré la casilla «{buscado}» en {nombre_ventana()}."
    tog = _patron(el, U, U.UIA_TogglePatternId, U.IUIAutomationTogglePattern)
    if tog:
        estado = tog.CurrentToggleState == 1
        if estado == prender:
            return f"«{nombre}» ya estaba {'marcada' if prender else 'desmarcada'}."
        tog.Toggle()
        return f"Listo, {'marqué' if prender else 'desmarqué'} «{nombre}»."
    sel = _patron(el, U, U.UIA_SelectionItemPatternId, U.IUIAutomationSelectionItemPattern)
    if sel and prender:
        sel.Select()
        return f"Listo, elegí «{nombre}»."
    _clic_en(el)
    return f"Listo, toqué «{nombre}»."


def elegir(buscado):
    if PELIGROSO.search(buscado):
        return "Esa opción no la toco yo: las de comprar, pagar, enviar o borrar las tocás vos."
    U, _ = _uia()
    el, nombre, _p = buscar_control(buscado, ["opcion", "item", "pestana", "menu", "casilla", "boton"])
    if el is None:
        return f"No encontré la opción «{buscado}» en {nombre_ventana()}."
    if PELIGROSO.search(nombre):
        return f"Encontré «{nombre}», pero esa no la toco yo. Elegila vos."
    sel = _patron(el, U, U.UIA_SelectionItemPatternId, U.IUIAutomationSelectionItemPattern)
    inv = _patron(el, U, U.UIA_InvokePatternId, U.IUIAutomationInvokePattern)
    if sel:
        sel.Select()
    elif inv:
        inv.Invoke()
    else:
        _clic_en(el)
    return f"Listo, elegí «{nombre}»."


def llenar(campo, valor):
    U, _ = _uia()
    campo = re.sub(r"^(?:mi|el|la|tu)\s+", "", campo)
    el, nombre, _p = buscar_control(campo, ["campo", "combo"])
    if el is None:
        return f"No encontré el campo «{campo}» en {nombre_ventana()}."
    val = _patron(el, U, U.UIA_ValuePatternId, U.IUIAutomationValuePattern)
    if val:
        try:
            val.SetValue(valor)
            return f"Listo, en «{nombre}» puse «{valor}»."
        except Exception:
            pass
    _clic_en(el)  # sin ValuePattern: clic en el campo, selecciono todo y pego
    _teclas(0x11, 0x41)
    pegar(valor)
    return f"Listo, en «{nombre}» puse «{valor}»."


def mostrar_donde(buscado):
    el, nombre, _p = buscar_control(buscado, list(TIPOS))
    if el is None:
        return f"No encontré «{buscado}» en {nombre_ventana()}."
    r = el.CurrentBoundingRectangle
    _abrir_script("anillo.py", str(r.left), str(r.top), str(r.right), str(r.bottom))
    return f"Ahí te lo marco: «{nombre}»."


def _abrir_script(nombre, *args):
    pythonw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    subprocess.Popen([pythonw if os.path.exists(pythonw) else sys.executable, os.path.join(BASE, nombre), *args],
                     creationflags=0x08000000)  # CREATE_NO_WINDOW


def manejar_clics(texto, t):
    try:
        m = DONDE.match(t)
        if m:
            return mostrar_donde(m.group("que"))
        m = CLIC.match(t)
        if m:
            return tocar(m.group("que") or m.group("que2"))
        m = MARCAR.match(t)
        if m:
            return marcar(m.group("que"), not m.group("accion").startswith("des"))
        m = ELEGIR.match(t)
        if m:
            return elegir(m.group("que"))
        m = LLENAR.match(t)
        if m:
            return llenar(m.group("campo").strip(), _original(texto, t, m, "valor").strip(" ."))
    except Exception as e:
        return f"No pude hacerlo en {nombre_ventana()}: {e}."
    return None


# ---------- Mantener una tecla y hablar (en cualquier app) ----------

TECLAS_ACTIVAS = True  # Configuraciones > "Alt derecho: dictar / Ctrl derecho: orden"
TECLA_DICTAR, TECLA_ORDEN = 0xA5, 0xA3  # Alt derecho (AltGr) y Ctrl derecho
_ocupado = threading.Event()


def _apretada(vk):
    return bool(_u32.GetAsyncKeyState(vk) & 0x8000)


def _otra_tecla(vk_propia):
    """¿Apretaste otra tecla junto con la nuestra? (AltGr+Q es la @: eso no es para dictar)."""
    for vk in list(range(0x08, 0x5B)) + list(range(0x60, 0x70)) + list(range(0xBA, 0xE0)):
        if vk not in (0x10, 0x11, 0x12, vk_propia) and _apretada(vk):
            return True
    return False


def grabar_mientras(vk):
    """Graba mientras tengas la tecla apretada y devuelve el texto ("" si no se entendió o era un atajo)."""
    import audioop

    import sounddevice as sd
    import speech_recognition as sr

    j = jarvis
    if not j.mic_lock.acquire(blocking=False):
        return ""
    try:
        info = sd.query_devices(j.MICROFONO, "input")
        tasa = int(info["default_samplerate"])
        bloque = int(tasa * 0.05)
        frames, maximo, inicio, avisado = [], 0, time.time(), False
        with sd.RawInputStream(samplerate=tasa, channels=1, dtype="int16", blocksize=bloque,
                               device=j.MICROFONO) as stream:
            while _apretada(vk) and time.time() - inicio < 120:
                if _otra_tecla(vk):
                    return ""  # era un atajo (AltGr+algo, Ctrl+algo): no se dicta nada
                datos, _ = stream.read(bloque)
                datos = bytes(datos)
                frames.append(datos)
                maximo = max(maximo, audioop.rms(datos, 2))
                if not avisado and time.time() - inicio > 0.3:  # recién ahí se nota que la tenés apretada
                    avisado = True
                    _u32.keybd_event(0xE8, 0, 0, 0)  # una tecla "vacía": así soltar el Alt no abre el menú de la app
                    _u32.keybd_event(0xE8, 0, 2, 0)
                    j.sonar("activar")
                    j.emitir("estado", "escuchando")
                if avisado:
                    j.emitir("nivel", min(audioop.rms(datos, 2) / 4000, 1.0))
        if time.time() - inicio < 0.5 or maximo < 300:
            if avisado:
                j.emitir("estado", "libre")
            return ""
        j.emitir("estado", "pensando")
        opciones = j.reconocer(sr.AudioData(b"".join(frames), tasa, 2))
        if not opciones:
            j.sonar("error")
            j.emitir("estado", "libre")
            return ""
        j.sonar("listo")
        return opciones[0]
    except Exception:
        j.emitir("estado", "libre")
        return ""
    finally:
        j.mic_lock.release()


def _al_apretar(vk):
    try:
        texto = grabar_mientras(vk)
        if not texto:
            return
        if vk == TECLA_DICTAR:
            try:
                dictar(texto)
                jarvis.emitir("detalle", f"Escribí: {texto[:80]}")
            except Exception as e:
                jarvis.aviso(f"No pude escribirlo: {e}")
            jarvis.emitir("estado", "libre")
        else:
            jarvis.emitir("voz", texto)
            jarvis.despachar(texto, jarvis.nueva_orden())
    finally:
        _ocupado.clear()


def _vigilar_teclas():
    antes = {TECLA_DICTAR: False, TECLA_ORDEN: False}
    while True:
        time.sleep(0.03)
        if not TECLAS_ACTIVAS or jarvis.herramientas.modo_juego.is_set():
            continue
        for vk in antes:
            ahora = _apretada(vk)
            if ahora and not antes[vk] and not _ocupado.is_set():
                _ocupado.set()
                threading.Thread(target=_al_apretar, args=(vk,), daemon=True).start()
            antes[vk] = ahora


# ---------- Teleprompter ----------

TELEPROMPTER = re.compile(r"^(?:empeza|arranca|abri|inicia|activa|pone)\w*\s+(?:el\s+)?(?:modo\s+)?teleprompter"
                          r"(?:\s+con (?:lo que copie|el texto copiado))?$|^teleprompter$")


def teleprompter():
    texto = jarvis.habilidades.leer_portapapeles() or ""
    if len(texto.strip()) < 10:
        return "Copiá primero el texto que vas a leer (Ctrl+C) y después decime «empezá el teleprompter»."
    ruta = os.path.join(BASE, "adjuntos", "teleprompter.txt")
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(texto.strip())
    _abrir_script("teleprompter.py", ruta)
    return ("Ahí tenés el teleprompter arriba de la pantalla: avanza mientras hablás. Clic para pausar, Esc o "
            "clic derecho para cerrarlo. No sale en las capturas ni en las grabaciones de pantalla.")


# ---------- Entrada ----------

def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    respuesta = manejar_dictado(texto, t)
    if respuesta is not None:
        return respuesta
    if TELEPROMPTER.match(t):
        return teleprompter()
    respuesta = manejar_texto(texto, t)
    if respuesta is not None:
        return respuesta
    return manejar_clics(texto, t)
