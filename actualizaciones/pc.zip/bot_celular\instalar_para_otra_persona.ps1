﻿# ============================================================
#  JARVIS para otra persona (por ejemplo tu mamá): la PC hace sola los pasos de bot_celular\LEEME.md
# ------------------------------------------------------------
#  En SU cuenta de Google: crea el proyecto de Apps Script con Codigo.gs, lo publica, le pone la clave de Gemini y te
#  muestra el QR para conectar la app de su celular. Esa persona solo entra con su cuenta, acepta y copia la clave de
#  Gemini.
#  Con los que ya hiciste: los actualiza al Codigo.gs de ahora (la dirección sigue siendo la misma).
#  Nada de su cuenta queda en esta PC: el permiso que le da a esta PC se borra al terminar. Queda solo cuál es su
#  proyecto (en %LOCALAPPDATA%\JARVIS\otras_personas), para poder actualizarlo.
#  Usa clasp (la herramienta de Google para Apps Script) y Node.js: se bajan solos la primera vez, en
#  %LOCALAPPDATA%\JARVIS (no se instala nada en Windows).
# ============================================================
$ErrorActionPreference = "Stop"

$AQUI = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $AQUI "clasp_comun.ps1")   # Node, clasp, Paso/Dice/Ojo, Navegador, Estado-Bot, Soltar-Permiso...
$script:deQuien = "su cuenta (entrá con SU cuenta)"   # (la «API de Google Apps Script» se prende en la cuenta de esa persona)
$script:paginaPrivada = $true
$CODIGO = Join-Path $AQUI "Codigo.gs"
$PERSONAS = Join-Path $RAIZ "otras_personas"
$APK = "https://rusty576.github.io/jarvis-celular/android/JARVIS.apk"
$OBRA = Join-Path $env:TEMP ("jarvis_instalacion_" + [guid]::NewGuid().ToString("N").Substring(0, 8))
$AUTH = Join-Path $OBRA ".clasprc.json"   # el permiso de su cuenta: solo mientras dura esto

function Clave-AlAzar {
    $b = New-Object byte[] 24
    [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
    return -join ($b | ForEach-Object { $_.ToString("x2") })
}

# ---------- El bot de ella ----------

function Esperar-Permisos($url, $scriptId, $version, $nombre) {
    $estado = Estado-Bot $url
    if ($estado -and $estado.version -eq $version) { return $estado }   # (ya los tenía: no hace falta nada)
    Paso "3. Que $nombre acepte los permisos de JARVIS"
    Dice "Se abre una ventana privada. Entrá con SU cuenta y tocá «Revisar permisos» > su cuenta."
    Dice "Si dice «Google no verificó esta app»: «Configuración avanzada» > «Ir a JARVIS (no seguro)» > «Permitir»."
    Dice "Es normal: la app es suya y nadie más la usa. Cuando diga «JARVIS está andando», volvé acá."
    Navegador $url -Privado
    $desde = Get-Date
    $plan_b = $false
    while ($true) {
        Start-Sleep -Seconds 4
        $estado = Estado-Bot $url
        if ($estado -and $estado.version -eq $version) { return $estado }
        if (-not $plan_b -and ((Get-Date) - $desde).TotalMinutes -gt 4) {
            $plan_b = $true
            Ojo "¿No apareció «Revisar permisos»? Te abro el proyecto: arriba, al lado de «Ejecutar», elegí «autorizar»,"
            Ojo "tocá «Ejecutar» y aceptá igual que arriba. Yo sigo esperando."
            Navegador "https://script.google.com/d/$scriptId/edit" -Privado
        }
    }
}

function Esperar-Gemini {
    # Apenas copia la clave, sigue sola. La que ya estaba copiada antes (¿la tuya?) no cuenta. Las claves de Gemini
    # empezaban con AIza; desde 2026 AI Studio da las nuevas, que empiezan con «AQ.»: valen las dos
    $formato = '^(AIza[\w-]{30,}|AQ\.[\w.-]{30,})$'
    $antes = ""
    try { $antes = "" + (Get-Clipboard -Raw) } catch { }
    while ($true) {
        $tecla = $false
        try { $tecla = [Console]::KeyAvailable } catch { }   # (sin consola de verdad, solo el portapapeles)
        if ($tecla) {
            $t = ("" + (Read-Host "   Pegala")).Trim()
            if ($t -match $formato) { return $t }
            Ojo "Esa no parece una clave de Gemini (empiezan con AQ. o con AIza)."
        }
        $c = ""
        try { $c = "" + (Get-Clipboard -Raw) } catch { }
        if ($c -ne $antes -and $c.Trim() -match $formato) { return $c.Trim() }
        Start-Sleep -Milliseconds 700
    }
}

function Pagina-Conectar($link, $nombre) {
    # Dos QR: la app de Android y el link que la conecta (la llave va en el link: este archivo se borra al terminar)
    $nombre = [Net.WebUtility]::HtmlEncode($nombre)
    $html = @"
<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Conectar JARVIS</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<style>body{margin:0;background:#02070d;color:#d4f3ff;font-family:Segoe UI,sans-serif;text-align:center;padding:32px 16px}
h1{letter-spacing:.3em;color:#7ae9ff;font-weight:600}.fila{display:flex;gap:48px;justify-content:center;flex-wrap:wrap}
.caja{max-width:340px}.qr{background:#fff;padding:14px;border-radius:12px;display:inline-block}
p{line-height:1.5}b{color:#7ae9ff}</style></head><body>
<h1>J.A.R.V.I.S.</h1><p>El JARVIS de $nombre ya está listo. Con su celular:</p>
<div class="fila">
<div class="caja"><h2>1. La app</h2><div class="qr" id="apk"></div>
<p>Escaneá con la cámara e instalá <b>JARVIS.apk</b> (si pregunta, permití instalar apps de Chrome).</p></div>
<div class="caja"><h2>2. Conectarla</h2><div class="qr" id="link"></div>
<p>Escaneá este, tocá <b>«Copiar»</b> (no lo abras) y abrí la app JARVIS: se conecta sola.<br>
Sin la app: abrilo en Chrome y después ⋮ &gt; «Instalar app».</p></div>
</div>
<p style="color:#8fb9cf">El link de la derecha es la llave de su JARVIS: no lo mandes a nadie. También quedó copiado en esta PC.</p>
<script>
new QRCode(document.getElementById("apk"), {text: "$APK", width: 240, height: 240});
new QRCode(document.getElementById("link"), {text: "$link", width: 240, height: 240, correctLevel: QRCode.CorrectLevel.M});
</script></body></html>
"@
    $ruta = Join-Path $OBRA "conectar.html"
    Escribir $ruta $html
    Start-Process $ruta
}

# ============================================================

Write-Host ""
Write-Host "  J.A.R.V.I.S. para otra persona" -ForegroundColor Cyan
Write-Host "  Le armo su propio JARVIS en SU cuenta de Google: sus mails, su calendario, sus recuerdos." -ForegroundColor DarkGray
Write-Host "  Sentate con esa persona (o tené su cuenta a mano): hay que entrar y aceptar un par de veces." -ForegroundColor DarkGray

$fuente = [IO.File]::ReadAllText($CODIGO)   # (ojo: en PowerShell $codigo y $CODIGO son la misma variable)
if ($fuente -notmatch 'const VERSION = "([\d.]+)"') { throw "No encontré VERSION en $CODIGO" }
$version = $Matches[1]

New-Item -ItemType Directory -Force $PERSONAS | Out-Null
$ya = @(Get-ChildItem $PERSONAS -Filter *.json | ForEach-Object {
    Get-Content $_.FullName -Raw -Encoding UTF8 | ConvertFrom-Json | Add-Member -NotePropertyName archivo -NotePropertyValue $_.FullName -PassThru })
$elegido = $null
if ($ya.Count) {
    Write-Host ""
    Dice "Ya hiciste el JARVIS de:"
    for ($i = 0; $i -lt $ya.Count; $i++) { Dice ("  {0}) {1}: actualizarlo a la versión {2} (o volver a conectar su celular)" -f ($i + 1), $ya[$i].nombre, $version) }
    Dice "  N) alguien nuevo"
    $r = ("" + (Read-Host "   Elegí")).Trim()
    if ($r -match '^\d+$' -and [int]$r -ge 1 -and [int]$r -le $ya.Count) { $elegido = $ya[[int]$r - 1] }
}
if ($elegido) {
    $nombre = $elegido.nombre
} else {
    $nombre = ("" + (Read-Host "   ¿Para quién es? (por ejemplo: mamá)")).Trim()
    if (-not $nombre) { $nombre = "otra persona" }
}

Limpiar-Restos "jarvis_instalacion_"
$node = Carpeta-Node
$env:Path = "$node;$env:Path"
$script:CLASP = Instalar-Clasp $node
New-Item -ItemType Directory -Force $OBRA | Out-Null
$antes = Get-Location

try {
    Set-Location $OBRA
    Paso "1. Entrá con la cuenta de Google de $nombre"
    Ojo "En la página de Google elegí SU cuenta (o «Usar otra cuenta»), NO la tuya."
    Dice "(Es el permiso para que esta PC le arme el proyecto: se borra solo al terminar.)"
    Entrar-Cuenta

    if ($elegido) {
        Paso "2. Actualizando su JARVIS a la versión $version"
        Escribir (Join-Path $OBRA ".clasp.json") (@{ scriptId = $elegido.script } | ConvertTo-Json)
        $scriptId = $elegido.script
    } else {
        Paso "2. Creando el proyecto «JARVIS» en su cuenta"
        $sinCasillas = 0
        while ($true) {
            # (Google trae apagada la «API de Google Apps Script»: abre la página para prenderla y espera)
            $s = Clasp-Con-API create-script --type standalone --title "JARVIS"
            if ($script:codigoClasp -eq 0 -and (Test-Path (Join-Path $OBRA ".clasp.json"))) { break }
            if ((Faltan-Permisos $s) -and $sinCasillas -lt 2) {
                $sinCasillas++
                Ojo "En la página de Google quedaron permisos sin marcar. Entrá de nuevo y tocá «Seleccionar todo»."
                Soltar-Permiso
                Remove-Item $AUTH -Force -ErrorAction SilentlyContinue
                Entrar-Cuenta
                continue
            }
            Sin-API $s
            throw "No pude crear el proyecto:`n$s"
        }
        $scriptId = (Get-Content (Join-Path $OBRA ".clasp.json") -Raw | ConvertFrom-Json).scriptId
    }

    # el código, la clave de un solo uso para terminar la instalación, y cómo se publica
    Copy-Item $CODIGO (Join-Path $OBRA "Codigo.gs")
    $clave = Clave-AlAzar
    Escribir (Join-Path $OBRA "Instalacion.gs") ("// Lo puso la PC («JARVIS para otra persona»): con esta clave, una sola vez, termina de instalarse.`n" +
                                                 "const CLAVE_INSTALACION = `"$clave`";`n")
    $zonas = @{ "Montevideo Standard Time" = "America/Montevideo"; "Argentina Standard Time" = "America/Argentina/Buenos_Aires";
                "E. South America Standard Time" = "America/Sao_Paulo"; "Paraguay Standard Time" = "America/Asuncion";
                "Pacific SA Standard Time" = "America/Santiago"; "Romance Standard Time" = "Europe/Madrid" }
    $zona = $zonas[[TimeZoneInfo]::Local.Id]
    if (-not $zona) { $zona = "America/Montevideo" }
    $manifiesto = [pscustomobject][ordered]@{ timeZone = $zona; exceptionLogging = "STACKDRIVER"; runtimeVersion = "V8";
        webapp = [ordered]@{ executeAs = "USER_DEPLOYING"; access = "ANYONE_ANONYMOUS" } }
    Agregar-Servicios $manifiesto   # (Drive y Slides: archivos grandes, presentaciones y pósters)
    Escribir (Join-Path $OBRA "appsscript.json") ($manifiesto | ConvertTo-Json -Depth 20)
    Escribir (Join-Path $OBRA ".claspignore") "**/**`n!Codigo.gs`n!Instalacion.gs`n!appsscript.json`n"
    # (si la API se prendió recién, Google tarda unos minutos: acá todavía puede decir que no)
    $s = Clasp-Con-API push --force
    if ($script:codigoClasp -ne 0) { Sin-API $s; throw "No pude subir el código:`n$s" }

    if ($elegido) { $s = Clasp-Con-API create-deployment --deploymentId $elegido.implementacion --description "JARVIS $version" }
    else { $s = Clasp-Con-API create-deployment --description "JARVIS $version" }
    Sin-API $s
    if ($script:codigoClasp -ne 0 -or $s -notmatch "(AKfyc[\w-]{20,})") { throw "No pude publicarlo:`n$s" }
    $implementacion = $Matches[1]
    $url = "https://script.google.com/macros/s/$implementacion/exec"
    # (solo cuál es su proyecto: nada de su cuenta ni claves)
    $registro = [ordered]@{ nombre = $nombre; script = $scriptId; implementacion = $implementacion; version = $version;
                            fecha = (Get-Date -Format "yyyy-MM-dd") }
    if ($elegido) {
        $archivo = $elegido.archivo
    } else {   # (otra persona con el mismo nombre: no pisa la anterior)
        $base = Join-Path $PERSONAS ($nombre -replace '[^\w-]', '_')
        $archivo = "$base.json"
        for ($i = 2; Test-Path $archivo; $i++) { $archivo = "$base`_$i.json" }
    }
    Escribir $archivo ($registro | ConvertTo-Json)

    $estado = Esperar-Permisos $url $scriptId $version $nombre
    # (contestar, contesta aunque le falte el permiso de Drive o Documentos: se le pregunta a Google y, si falta, se abre)
    Revisar-Permisos $url "SU cuenta (la de $nombre)" -Privado | Out-Null

    if ($estado.instalado) {
        Paso "Listo: el JARVIS de $nombre ya tiene la versión $version"
        Dice "La app de su celular sigue conectada: no hay que tocar nada más."
        # volver a conectar su celular: uno nuevo, la app reinstalada, o si nunca se usaron los QR
        Write-Host ""
        $otra = ("" + (Read-Host "   ¿Volver a conectar su celular (otro celular, o la app desconectada)? Escribí s y Enter; si no, solo Enter")).Trim()
        if ($otra -match '^(s|si|sí)$') {
            $nueva = ("" + (Read-Host "   ¿Desconecto los celulares que ya estaban conectados (por ejemplo, si se perdió uno)? s y Enter, o solo Enter")).Trim() -match '^(s|si|sí)$'
            $cuerpo = [ordered]@{ accion = "reconectar"; clave = $clave; nueva = $nueva } | ConvertTo-Json
            $r = Invoke-RestMethod $url -Method Post -ContentType "application/json" -TimeoutSec 90 -Body ([Text.Encoding]::UTF8.GetBytes($cuerpo))
            if (-not $r.ok) { throw "No pude sacar el link para conectar su celular: $($r.error)" }
            Set-Clipboard -Value $r.link
            Paso "Conectar su celular"
            Dice "Se abre una página con dos QR: la app de Android y el link que la conecta."
            Dice "En su celular: instalá la app con el primer QR; después abrí el segundo QR (o mantené apretado el link y «Copiar»)"
            Dice "y abrí la app: se conecta sola."
            Pagina-Conectar $r.link $nombre
            Write-Host ""
            Read-Host "   Cuando su celular esté conectado, tocá Enter (borro la página con la llave)"
            Set-Clipboard -Value " "
        }
    } else {
        Paso "4. La clave de Gemini (la inteligencia de JARVIS: gratis)"
        Dice "Se abre AI Studio en la ventana privada (con SU cuenta). Tocá «Create API key» («Crear clave de API»);"
        Dice "si pregunta por un proyecto, elegí el que aparezca o «Create project». Después tocá el botón de copiar."
        Dice "Apenas la copies, sigo solo. (También la podés pegar acá: tocá una tecla.)"
        Navegador "https://aistudio.google.com/apikey" -Privado
        while ($true) {
            $gemini = Esperar-Gemini
            Dice "Probando la clave..."
            $cuerpo = [ordered]@{ accion = "instalar"; clave = $clave; gemini = $gemini;
                                  zona_min = [int][TimeZoneInfo]::Local.GetUtcOffset((Get-Date)).TotalMinutes } | ConvertTo-Json
            $r = Invoke-RestMethod $url -Method Post -ContentType "application/json" -TimeoutSec 90 -Body ([Text.Encoding]::UTF8.GetBytes($cuerpo))
            if ($r.ok) { break }
            if ("$($r.error)" -notmatch "Gemini") { throw "No se pudo terminar: $($r.error)" }
            Ojo "$($r.error). Copiá la clave de nuevo."
        }
        Set-Clipboard -Value $r.link   # (así la clave de Gemini tampoco queda copiada)
        Paso "5. Conectar su celular"
        Dice "Se abre una página con dos QR: la app de Android y el link que la conecta."
        Pagina-Conectar $r.link $nombre
        Write-Host ""
        Read-Host "   Cuando su celular esté conectado, tocá Enter (borro la página con la llave)"
        Set-Clipboard -Value " "
        Paso "Listo: $nombre ya tiene su JARVIS"
        Dice "Ya puede decirle «Jarvis…» o tocar HABLAR. Para actualizarlo, más adelante: este mismo .bat."
    }
} finally {
    Set-Location $antes
    Soltar-Permiso
    Remove-Item $OBRA -Recurse -Force -ErrorAction SilentlyContinue
}
