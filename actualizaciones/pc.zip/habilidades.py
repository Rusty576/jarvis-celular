"""Habilidades extra de JARVIS (livianas: no cargan nada pesado en la laptop).

  Pantalla:       "¿qué hay en mi pantalla?", "ayudame con este error", "leeme la pantalla"
  Portapapeles:   "resumí lo que copié", "traducí lo que copié", "explicame la imagen que copié", "copiá la respuesta"
  Pendientes:     "agregá comprar pan a mis pendientes", "¿qué tengo pendiente?", "ya hice lo del pan"
  Modo estudio:   "modo estudio", "pomodoro de 45 minutos", "pausá el estudio", "¿cuánto me queda?"
  Conversor:      "¿cuántos pesos son 100 dólares?", "pasá 30 grados a fahrenheit", "¿a cuánto está el dólar?"
  Resumen del día: "¿qué tengo hoy?", "buen día" (a la mañana)
"""
import base64
import ctypes
import datetime
import difflib
import io
import os
import re
import threading
import time

import disco

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_PENDIENTES = os.path.join(BASE, "pendientes.json")
ocultar_ventana = None  # la interfaz pone acá una función(True/False) que esconde JARVIS para sacar la captura


def _n(texto):
    return jarvis.normalizar(texto)


def _grupo(texto, t, m, g=1):
    """El grupo g de un match hecho sobre el texto normalizado, pero con las tildes y mayúsculas originales."""
    if len(texto) == len(t) or len(texto.strip(" ¿?¡!.,")) == len(t):
        base = texto if len(texto) == len(t) else texto.strip(" ¿?¡!.,")
        return base[m.start(g):m.end(g)]
    return m.group(g)


# =========================================================================
#  PANTALLA: JARVIS mira lo que tenés abierto
# =========================================================================

PANTALLA = re.compile(
    r"\b(?:(?:que|lo que) (?:hay|tengo|ves|se ve|aparece|dice|sale) en (?:mi |la |esta )?pantalla|"
    r"mira(?:me)? (?:mi |la |esta )?pantalla|fijate (?:en )?(?:mi |la |esta )?pantalla|"
    r"lee(?:me)? (?:mi |la |esta )?pantalla|lee(?:me)? lo que (?:hay|dice) en (?:mi |la )?pantalla|"
    r"(?:ayudame|ayuda) con (?:lo que tengo en|esto de|esta) (?:la |mi )?pantalla|"
    r"(?:que|este) error (?:me sale|tengo|aparece|me aparece)|que significa este error|"
    r"explicame (?:lo que hay en |esto de )?(?:mi |la )?pantalla|captura y (?:decime|explicame)|"
    r"(?:que|como) (?:resuelvo|hago) (?:esto|este ejercicio) (?:de|en) (?:la|mi) pantalla)\b")
PROMPT_PANTALLA = """Ves una captura de la pantalla del usuario (su computadora). Respondé en español rioplatense, con "vos",
a lo que te pregunta sobre lo que se ve. Si hay un mensaje de error, decí qué significa y cómo arreglarlo paso a paso.
Si hay un ejercicio, ayudalo a resolverlo. Si algo no se lee bien, decilo: NO inventes texto que no se ve."""


def captura_b64(lado=1600):
    """Captura de la pantalla principal achicada, en JPEG base64 (para la IA)."""
    imagen = captura()
    imagen.thumbnail((lado, lado))
    buf = io.BytesIO()
    imagen.save(buf, "JPEG", quality=85)
    return base64.b64encode(buf.getvalue()).decode()


def captura():
    """Captura de la pantalla principal, entera (escondiendo un instante a JARVIS, si está adelante)."""
    from PIL import ImageGrab

    if ocultar_ventana:
        try:
            ocultar_ventana(True)
            time.sleep(0.45)
        except Exception:
            pass
    try:
        imagen = ImageGrab.grab()
    finally:
        if ocultar_ventana:
            try:
                ocultar_ventana(False)
            except Exception:
                pass
    return imagen.convert("RGB")


# Grabación: "grabá mi pantalla", "mirá lo que hago", "grabame 15 segundos la pantalla" (la foto rápida sigue siendo
# "¿qué hay en mi pantalla?")
GRABAR_PANTALLA = re.compile(
    r"\b(?:(?:graba|grabame|filma|filmame)\b.*\bpantalla|grabacion de (?:mi |la )?pantalla|"
    r"mira(?:me)? (?:lo que hago|como (?:lo )?hago|esto que hago|lo que voy a hacer)|"
    r"fijate (?:lo que hago|como (?:lo )?hago|lo que voy a hacer)|mirame mientras)\b")
SEGUNDOS_GRABACION = 8

# =========================================================================
#  MODO "MENEA TU CHAPA": modo fiesta (pone el tema de Wilo D New y JARVIS se pone a bailar)
# =========================================================================

MENEA_ON = re.compile(r"\bmenea (?:tu|la|esa) chapa\b|^(?:(?:activa|activame|pone|poneme|arranca|entra en|dale)\w*\s+"
                      r"(?:el\s+)?)?modo (?:fiesta|perreo|boliche)$")
MENEA_OFF = re.compile(r"^(?:apaga|desactiva|para|basta|termina|saca|corta|frena)\w*\b.*\b(?:menea|chapa|fiesta|perreo|"
                       r"boliche)\b|^(?:se )?termino la fiesta$|^basta de (?:fiesta|perreo|menear)$|^chau fiesta$")
CANCION_MENEA = "Menea tu chapa Wilo D New"
DURA_FIESTA = 4 * 60  # se apaga sola cuando termina el tema (más o menos)
fiesta = {"activa": False, "desde": 0.0}


def modo_menea(activar=True):
    if not activar:
        if not fiesta["activa"]:
            return "No había fiesta."
        fiesta["activa"] = False
        jarvis.emitir("fiesta", False)
        if "menea" in (jarvis.musica.estado.get("titulo") or "").lower() and not jarvis.musica.estado.get("pausado"):
            try:
                jarvis.musica.control("pausa")  # el tema de la fiesta también para
            except Exception:
                pass
        return "Se terminó la fiesta. Volvemos a la normalidad."
    if jarvis.herramientas.modo_juego.is_set():
        return "Estás en modo juego: primero terminá la partida y después meneamos la chapa."
    try:
        jarvis.musica.reproducir(CANCION_MENEA, desde_lo_mejor=True)  # directo al estribillo
    except Exception as e:
        return f"No pude poner el tema: {e}"
    fiesta.update(activa=True, desde=time.time())
    jarvis.emitir("fiesta", True)
    threading.Thread(target=_vigilar_fiesta, args=(fiesta["desde"],), daemon=True).start()
    return "¡Modo menea tu chapa activado! A mover el esqueleto."


def _vigilar_fiesta(desde):
    """Se apaga sola si pausás o cerrás la música, o cuando termina el tema."""
    time.sleep(10)  # que cargue el video
    while fiesta["activa"] and fiesta["desde"] == desde:
        estado = jarvis.musica.estado
        if not estado.get("modo") or estado.get("pausado") or time.time() - desde > DURA_FIESTA:
            fiesta["activa"] = False
            jarvis.emitir("fiesta", False)
            return
        time.sleep(2)


# Compartir la pantalla en vivo (pantalla.py): "compartí mi pantalla", "mirá mi pantalla en vivo"
COMPARTIR_PANTALLA = re.compile(
    r"\b(?:comparti\w*|compartir|transmiti\w*)\s+(?:mi |la |tu )?pantalla\b|\bpantalla compartida\b|"
    r"\bmira(?:me)?\s+(?:mi |la )?pantalla\s+(?:en vivo|todo el tiempo|mientras)\b|"
    r"\b(?:ves|mira|segui)\s+lo que hago en (?:la |mi )?pantalla\b")
DEJAR_PANTALLA = re.compile(
    r"\b(?:deja|dejá|para|pará|corta|cortá|apaga|terminá|termina|frena|basta)\w*\s+(?:de\s+)?(?:compartir|ver|mirar|"
    r"transmitir)\s+(?:mi |la )?pantalla\b|\b(?:apaga|corta|termina|frena|para|cerra)\w*\s+(?:la )?pantalla "
    r"compartida\b|^no (?:mires|veas) (?:mas )?(?:mi )?pantalla\b|\bdeja(?:la)? de compartir\b")


def grabar_pantalla(texto, t):
    m = re.search(r"\b(\d+)\s*(segundos?|seg|minutos?|min)\b", t)
    segundos = SEGUNDOS_GRABACION
    if m:
        segundos = int(m.group(1)) * (60 if m.group(2).startswith("min") else 1)
    segundos = max(3, min(segundos, 60))  # más de un minuto son demasiados cuadros para mirar bien
    jarvis.emitir("detalle", f"Grabo {segundos} segundos tu pantalla: hacé lo que quieras que mire")
    time.sleep(1.2)  # para que alcances a leer el aviso
    try:
        ruta, cuadros = jarvis.video.grabar_pantalla(segundos, ocultar=ocultar_ventana)
    except Exception as e:
        return f"No pude grabar la pantalla: {e}"
    jarvis.emitir("detalle", "Mirando la grabación...")
    pedido = texto if not GRABAR_PANTALLA.fullmatch(t) else "Contame qué hice y ayudame con lo que se ve."
    try:
        respuesta, datos = jarvis.video.analizar_grabacion(ruta, cuadros, pedido)
    except jarvis.IAPausada as e:
        return f"Grabé la pantalla (quedó en la carpeta grabaciones), pero ahora no puedo mirarla: {e}."
    except Exception as e:
        return f"Grabé la pantalla (quedó en la carpeta grabaciones), pero mi IA no respondió ({e}). ¿Está abierto Ollama?"
    jarvis.emitir("camara_foto", {"imagen": "data:image/jpeg;base64," + datos["imagenes"][0], "pregunta": texto,
                                  "origen": "PANTALLA"})
    jarvis.adjuntos.recordar_video(datos)  # para seguir preguntando: "¿y qué hice al final?"
    return respuesta


def mirar_pantalla(texto):
    jarvis.emitir("detalle", "Mirando tu pantalla...")
    try:
        # si la estás compartiendo, ya tengo cómo está ahora (sin esconder la ventana ni sacar otra captura)
        imagen = jarvis.pantalla._estado["completa"] or captura()
    except Exception as e:
        return f"No pude sacar la captura de pantalla: {e}"
    chica = imagen.copy()
    chica.thumbnail((1600, 1600))
    buf = io.BytesIO()
    chica.save(buf, "JPEG", quality=85)
    b64 = base64.b64encode(buf.getvalue()).decode()
    miniatura = "data:image/jpeg;base64," + b64
    jarvis.emitir("camara_foto", {"imagen": miniatura, "pregunta": texto, "origen": "PANTALLA"})
    pedido = texto
    try:   # el texto exacto de la pantalla (la IA no lee bien la letra chica de la imagen y lo inventa)
        leido = jarvis.ocr.texto(jarvis.ocr.leer(imagen))[:6000]
        if leido:
            pedido += ("\n\nEl texto que se ve en la pantalla, leído letra por letra con el lector de Windows (usalo para "
                       f"leer y citar; no menciones palabras que no estén acá):\n<<<\n{leido}\n>>>")
    except Exception:
        pass
    try:
        r = jarvis.chat_modelo([{"role": "system", "content": PROMPT_PANTALLA},
                                {"role": "user", "content": pedido, "images": [b64]}],
                               temperature=0.2, num_predict=700)
    except jarvis.IAPausada as e:
        return f"Ahora no puedo mirar: {e}."
    except Exception as e:
        return f"Saqué la captura, pero mi IA no respondió ({e}). ¿Está abierto Ollama?"
    return r["message"]["content"].strip()


# =========================================================================
#  PORTAPAPELES: lo que copiaste (Ctrl+C)
# =========================================================================

COPIADO = re.compile(r"\b(?:lo que (?:copie|tengo copiado|acabo de copiar|copiaste)|(?:el|del|en el) portapapeles|"
                     r"lo copiado|esto que copie|el texto que copie|la imagen que copie|lo que pegue)\b")
COPIAR_RESPUESTA = re.compile(r"^(?:copia(?:me|lo|la)?|copiame|pasalo al portapapeles)"
                              r"(?:\s+(?:eso|esto|la respuesta|lo que dijiste|tu respuesta|el codigo|el texto|"
                              r"al portapapeles))?$")

_u32, _k32 = ctypes.windll.user32, ctypes.windll.kernel32
_u32.GetClipboardData.restype = ctypes.c_void_p
_u32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
_u32.SetClipboardData.restype = ctypes.c_void_p
_k32.GlobalLock.argtypes = [ctypes.c_void_p]
_k32.GlobalLock.restype = ctypes.c_void_p
_k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
_k32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
_k32.GlobalAlloc.restype = ctypes.c_void_p
CF_UNICODETEXT = 13


def leer_portapapeles():
    """El texto que copiaste (o None)."""
    for _ in range(5):  # si otro programa lo tiene abierto, reintenta
        if _u32.OpenClipboard(None):
            break
        time.sleep(0.05)
    else:
        return None
    try:
        h = _u32.GetClipboardData(CF_UNICODETEXT)
        if not h:
            return None
        p = _k32.GlobalLock(h)
        try:
            return ctypes.wstring_at(p)
        finally:
            _k32.GlobalUnlock(h)
    finally:
        _u32.CloseClipboard()


def escribir_portapapeles(texto):
    datos = (texto + "\0").encode("utf-16-le")
    h = _k32.GlobalAlloc(0x0042, len(datos))  # GMEM_MOVEABLE | GMEM_ZEROINIT
    p = _k32.GlobalLock(h)
    ctypes.memmove(p, datos, len(datos))
    _k32.GlobalUnlock(h)
    if not _u32.OpenClipboard(None):
        raise RuntimeError("el portapapeles está ocupado")
    try:
        _u32.EmptyClipboard()
        _u32.SetClipboardData(CF_UNICODETEXT, h)
    finally:
        _u32.CloseClipboard()


def cargar_copiado(t):
    """'Resumí lo que copié': pasa lo copiado (texto o imagen) como si lo hubieras adjuntado. True si cargó algo."""
    if not COPIADO.search(t):
        return False
    try:
        from PIL import ImageGrab

        img = ImageGrab.grabclipboard()
    except Exception:
        img = None
    if img is not None and not isinstance(img, list):
        buf = io.BytesIO()
        img.convert("RGB").save(buf, "PNG")
        info = jarvis.adjuntos.agregar("imagen copiada.png", buf.getvalue())
    else:
        texto = leer_portapapeles()
        if isinstance(img, list) and img and os.path.isfile(img[0]):  # copiaste un archivo en el Explorador
            with open(img[0], "rb") as f:
                info = jarvis.adjuntos.agregar(os.path.basename(img[0]), f.read())
        elif texto and texto.strip():
            info = jarvis.adjuntos.agregar("lo que copiaste.txt", texto.encode("utf-8"))
        else:
            jarvis.aviso("No tenés nada copiado (texto o imagen). Copiá algo con Ctrl+C y pedímelo de nuevo.")
            return False
    if not info.get("ok"):
        jarvis.aviso(info.get("error", "No pude leer lo que copiaste."))
        return False
    jarvis.emitir("detalle", "Leyendo lo que copiaste...")
    return True


def copiar_respuesta(t):
    with jarvis.lock:
        ultima = next((m["content"] for m in reversed(jarvis.historial) if m["role"] == "assistant"), "")
    if not ultima:
        return "Todavía no te dije nada para copiar."
    if "codigo" in t and "```" in ultima:
        texto = "\n\n".join(c for _, c in re.findall(r"```([\w#+.-]*)[^\n]*\n(.*?)```", ultima, re.S))
    else:
        texto = re.sub(r"\n+Verificado en:.*$", "", ultima).strip()
    try:
        escribir_portapapeles(texto)
    except Exception as e:
        return f"No pude copiarlo: {e}"
    return "Listo, lo copié: pegalo donde quieras con Ctrl+V."


# =========================================================================
#  PENDIENTES (lista de cosas por hacer)
# =========================================================================
# "poneme en pendientes investigar la pila, programar a RUSTY y estudiar para filosofía" -> 3 pendientes
# "separalos" / "ponelos en diferentes pendientes" -> parte el último que anotó
# "¿qué tengo pendiente?" -> numerados, lo que vence antes primero
# "tachá el 2", "ya estudié para filosofía", "desmarcá el 2", "borrá el pendiente 3", "cambiá el 1 a ..."
# "estudiar para filosofía para el jueves" / "el 2 es para el viernes" -> con fecha (los consejos avisan el día antes)

_lock = threading.Lock()
LISTA = (r"(?:mis |la |mi |los |las |tus )?(?:lista de (?:pendientes|tareas|cosas(?: por hacer)?)|pendientes|tareas|to ?do|"
         r"lista)(?!\s+de (?:reproduccion|canciones|musica|youtube|spotify|compras de))")
_PREFIJO = (r"^(?:(?:ok|okey|dale|bueno|che|jarvis|bro|porfa|y)[\s,]+)*(?:(?:preciso|necesito|quiero|podes|podrias|puedes)"
            r"\s+(?:que\s+)?)?(?:me\s+)?")
_VERBO = (r"(?:agrega|anota|pone|pon|suma|mete|carga|agregues|anotes|pongas|sumes|metas|cargues|agregar|anotar|poner|"
          r"sumar)(?:me|le|los|las|lo|la)?")
AGREGAR = [
    re.compile(rf"{_PREFIJO}{_VERBO}\s+(?:a |en |como )?(?:un |una |nuevos? )?{LISTA}\s*[:,]?\s+(?:que\s+)?(.+)$"),
    re.compile(rf"{_PREFIJO}{_VERBO}\s+(.+?)\s+(?:a|en|al?|como) (?:un |una )?{LISTA}$"),
    re.compile(r"^(?:tengo que|no me dejes olvidar(?: de)?|no te olvides de que tengo que)\s+(.+?)[,.]?\s+"
               r"(?:anotalo|agregalo|ponelo)(?: en (?:mis )?pendientes)?$"),
    re.compile(r"^(?:nuevos? pendientes?|pendientes? nuevos?|nuevas? tareas?)\s*[:,]?\s+(.+)$"),
]
VER_PENDIENTES = re.compile(r"\b(?:mis pendientes|que (?:tengo|me queda|me falta) (?:pendiente|por hacer|hacer)|"
                            r"que me falta hacer|mi lista(?: de (?:pendientes|tareas|cosas))?|que tareas tengo|mis tareas|"
                            r"lista de pendientes|mostra(?:me)? (?:los |mis )?pendientes|cuantos pendientes|"
                            r"(?:que|cuales) (?:son )?(?:los |mis )?pendientes)\b")
NUMERO = r"(\d+|uno|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|primero|primer|segundo|tercero|tercer|cuarto|quinto|ultimo)"
HECHO = re.compile(r"^(?:(?:ya|bueno|dale)[\s,]+)*(?:hice|termine|complete|resolvi|cumpli|tacha(?:me|lo|la)?|tache|"
                   r"marca(?:me|lo|la)?(?: como hech[oa])?|listo con|ya esta|ya fue)\s+(?:lo del? |el |la |los |las |eso del? )?"
                   r"(?:pendiente\s+|tarea\s+)?(?:numero |nro |n )?(?:de |del )?(.+?)(?: como hech[oa])?$|"
                   rf"^(?:listo|hecho)\s+(?:el |la )?(?:pendiente\s+|tarea\s+)?(?:numero\s+)?{NUMERO}$")
YA_HICE = re.compile(r"^(?:(?:bueno|listo|dale)[\s,]+)*ya\s+(?!esta\b|fue\b|es\b|son\b|no\b|se\b|me\b|te\b|lo\b|la\b|"
                     r"estoy\b|tengo\b|voy\b|vamos\b)(\w+[ei])\b\s*(.*)$")
DESMARCAR = re.compile(rf"^(?:desmarca\w*|destacha\w*|todavia no (?:hice|termine)|no (?:hice|termine))\s+(?:el |la |lo del? )?"
                       r"(?:pendiente\s+|tarea\s+)?(?:numero\s+)?(.+)$")
BORRAR_UNO = re.compile(r"^(?:borra|saca|elimina|quita)(?:me|le)?\s+(?:el |la )?(?:pendiente|tarea)\s+(?:numero |nro |n )?"
                        r"(?:de |del |que dice |sobre )?(.+)$|"
                        r"^(?:borra|saca|elimina|quita)(?:me|le)?\s+(.+?)\s+de (?:mis |la |los )?(?:pendientes|lista|tareas)$")
CAMBIAR = re.compile(r"^(?:cambia|modifica|corregi|edita)(?:me|le)?\s+(?:el |la )?(?:pendiente|tarea)\s+(?:numero |nro )?"
                     r"(.+?)\s+(?:a|por|para que diga)\s+(.+)$")
PONER_FECHA = re.compile(rf"^(?:el|la|lo de|lo del)\s+(?:pendiente\s+|tarea\s+)?(?:numero\s+)?(.+?)\s+(?:es|vence|lo tengo que "
                         r"(?:hacer|entregar)|hay que (?:hacerlo|entregarlo)|se entrega)\s+(para .+|el .+|antes del? .+|"
                         r"manana|hoy|pasado manana)$")
SEPARAR = re.compile(r"\b(?:separa\w*|ponelos?\s+(?:en|como)\s+(?:diferentes|distintos|varios|separados)|"
                     r"(?:en|como)\s+(?:diferentes|distintos|varios|pendientes separados)\s*(?:pendientes)?|uno por uno|"
                     r"por separado|cada uno (?:aparte|por separado)|dividi\w*|partilos?)\b")
LIMPIAR = re.compile(r"^(?:borra|limpia|saca)(?:me)?\s+(?:los |las |mis )?(?:pendientes |tareas )?(?:hech[oa]s|terminad[oa]s|"
                     r"completad[oa]s)$|^limpia(?:me)? (?:la lista|mis pendientes)$")
DIAS_N = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"]
MESES_N = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre",
           "diciembre"]
PARA_FECHA = re.compile(r"\s*,?\s*\b(?:para|antes del?|hasta)\s+(?:el\s+|este\s+|el proximo\s+|la\s+)?(hoy|manana|pasado manana|"
                        r"lunes|martes|miercoles|jueves|viernes|sabado|domingo|fin de semana|finde|semana que viene|"
                        r"(\d{1,2})(?: de (" + "|".join(MESES_N) + r"|setiembre)|/(\d{1,2})))\s*$")
ORDINALES_N = {"uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7, "ocho": 8,
               "nueve": 9, "diez": 10, "primero": 1, "primer": 1, "segundo": 2, "tercero": 3, "tercer": 3, "cuarto": 4,
               "quinto": 5}
_vista = {"ids": [], "cuando": 0.0}  # el orden de la última lista que te mostré (para "tachá el 2")


def es_pendiente(t):
    """¿Es "anotá X en mis pendientes"? (para que no se guarde como recuerdo)"""
    t = t.strip(" ¿?¡!.,")
    return any(p.match(t) for p in AGREGAR)


def pendientes():
    return disco.leer(ARCHIVO_PENDIENTES, [])


def _guardar_pendientes(lista):
    disco.guardar(ARCHIVO_PENDIENTES, lista)
    jarvis.emitir("pendientes", lista)


def fecha_de(t, hoy=None):
    """('2026-10-22', donde empieza) de 'estudiar para filosofía para el jueves'; (None, None) si no dice cuándo."""
    hoy = hoy or datetime.date.today()
    m = PARA_FECHA.search(t)
    if not m:
        return None, None
    palabra = m.group(1)
    if palabra == "hoy":
        fecha = hoy
    elif palabra == "manana":
        fecha = hoy + datetime.timedelta(days=1)
    elif palabra == "pasado manana":
        fecha = hoy + datetime.timedelta(days=2)
    elif palabra in DIAS_N:
        fecha = hoy + datetime.timedelta(days=(DIAS_N.index(palabra) - hoy.weekday()) % 7 or 7)
    elif palabra in ("fin de semana", "finde"):
        fecha = hoy + datetime.timedelta(days=(5 - hoy.weekday()) % 7)
    elif palabra == "semana que viene":
        fecha = hoy + datetime.timedelta(days=7 - hoy.weekday())
    else:
        dia = int(m.group(2))
        mes = 9 if m.group(3) == "setiembre" else MESES_N.index(m.group(3)) + 1 if m.group(3) else int(m.group(4))
        try:
            fecha = datetime.date(hoy.year, mes, dia)
        except ValueError:
            return None, None
        if fecha < hoy:
            fecha = fecha.replace(year=hoy.year + 1)
    return fecha.isoformat(), m.start()


def describir_fecha(iso, hoy=None):
    hoy = hoy or datetime.date.today()
    fecha = datetime.date.fromisoformat(iso)
    dias = (fecha - hoy).days
    if dias < 0:
        return f"venció el {DIAS_N[fecha.weekday()].replace('miercoles', 'miércoles').replace('sabado', 'sábado')} {fecha.day}"
    if dias == 0:
        return "para hoy"
    if dias == 1:
        return "para mañana"
    if dias < 7:
        return f"para el {DIAS_N[fecha.weekday()].replace('miercoles', 'miércoles').replace('sabado', 'sábado')} {fecha.day}"
    return f"para el {fecha.day}/{fecha.month}"


def separar(texto):
    """'investigar la pila, programar a RUSTY un jarvis y estudiar para filosofía' -> ['investigar la pila', ...].
    Se parte por renglones, ';' o números, y por comas e "y" solo si cada pedazo empieza con un verbo
    ('comprar pan y leche' queda como uno solo)."""
    texto = texto.strip(" .")
    partes = [p.strip(" ,.-") for p in re.split(r"\s*(?:\n+|;|(?:^|\s)\d+[.)-]\s+)\s*", texto) if p.strip(" ,.-")]
    if len(partes) > 1:
        return partes
    verbo = r"[a-zñ]+(?:ar|er|ir)(?:me|te|le|lo|la|se|nos)?\b"
    t = jarvis.normalizar(texto)
    if len(t) != len(texto):
        return [texto]
    cortes = [0]
    for m in re.finditer(rf"\s*,\s*(?:y\s+|e\s+)?(?={verbo})|\s+(?:y|e)\s+(?={verbo})", t):
        cortes += [m.start(), m.end()]
    cortes.append(len(t))
    pedazos = [(texto[cortes[i]:cortes[i + 1]].strip(" ,."), t[cortes[i]:cortes[i + 1]].strip(" ,."))
               for i in range(0, len(cortes) - 1, 2)]
    if len(pedazos) > 1 and all(re.match(verbo, n) and len(n.split()) >= 2 for _o, n in pedazos):
        return [o for o, _n in pedazos]
    return [texto]


def _sin_fecha(texto):
    """('Estudiar para filosofía', '2026-10-22') de 'estudiar para filosofía para el jueves'."""
    t = jarvis.normalizar(texto)
    fecha, donde = fecha_de(t)
    if fecha and donde and len(t) == len(texto):
        texto = texto[:donde]
    return texto.strip(" ,."), fecha


def agregar_pendiente(texto, para=None):
    texto = texto.strip(" .,;:")
    texto = texto[:1].upper() + texto[1:]
    if not para:
        texto, para = _sin_fecha(texto)
        texto = texto[:1].upper() + texto[1:]
    with _lock:
        lista = pendientes()
        if any(_n(p["texto"]) == _n(texto) and not p["hecho"] for p in lista):
            return lista
        nuevo_id = max((p["id"] for p in lista), default=0) + 1
        nuevo = {"id": nuevo_id, "texto": texto, "hecho": False, "creado": datetime.datetime.now().isoformat(timespec="minutes")}
        if para:
            nuevo["para"] = para
        lista.append(nuevo)
        _guardar_pendientes(lista)
    # verificación cruzada: se relee el archivo y se anota en la lista de control
    jarvis.control.registrar("pendiente", texto, lambda: any(p["id"] == nuevo_id for p in pendientes()))
    return pendientes()


def marcar_pendiente(id_, hecho=None):
    with _lock:
        lista = pendientes()
        for p in lista:
            if p["id"] == id_:
                p["hecho"] = (not p["hecho"]) if hecho is None else hecho
                p["hecho_en"] = datetime.datetime.now().isoformat(timespec="minutes") if p["hecho"] else None
        _guardar_pendientes(lista)
    return lista


def borrar_pendiente(id_=None, solo_hechos=False):
    with _lock:
        lista = [p for p in pendientes() if not ((id_ is not None and p["id"] == id_) or (solo_hechos and p["hecho"]))]
        _guardar_pendientes(lista)
    return lista


def _cambiar(id_, **cambios):
    with _lock:
        lista = pendientes()
        for p in lista:
            if p["id"] == id_:
                p.update({k: v for k, v in cambios.items() if v is not None})
        _guardar_pendientes(lista)


def ordenados(hechos=False):
    """Los pendientes sin hacer: primero los que vencen antes, después en el orden en que los anotaste."""
    return sorted([p for p in pendientes() if bool(p["hecho"]) == hechos], key=lambda p: (p.get("para") or "9999", p["id"]))


def _buscar_pendiente(frase, hechos=False, minimo=0.5):
    """El pendiente que más se parece a lo que dijiste ('ya estudié para filosofía' -> 'Estudiar para filosofía')."""
    vacias = {"del", "los", "las", "que", "con", "para", "eso", "esto", "una", "uno", "por"}
    frase_n = set(re.findall(r"\w{3,}", _n(frase))) - vacias
    raices = {w[:5] for w in frase_n}
    mejor, puntos = None, 0.0
    for p in pendientes():
        if bool(p["hecho"]) != hechos:
            continue
        palabras = set(re.findall(r"\w{3,}", _n(p["texto"]))) - vacias
        comunes = len(raices & {w[:5] for w in palabras})  # "estudie" y "estudiar" cuentan como la misma
        parecido = max(comunes / max(1, len(palabras)), comunes / max(1, len(frase_n)) if comunes else 0,
                       difflib.SequenceMatcher(None, _n(frase), _n(p["texto"])).ratio())
        if parecido > puntos:
            mejor, puntos = p, parecido
    return mejor if puntos >= minimo else None


def _elegir(ref, hechos=False):
    """El pendiente del que hablás: por número ('el 2', 'el último', 'el primero') o por lo que dice."""
    ref = re.sub(r"^(?:el|la|lo del?|de|del)\s+", "", ref.strip(" .,"))
    lista = ordenados(hechos)
    if not hechos and _vista["ids"] and time.time() - _vista["cuando"] < 3600:
        por_id = {p["id"]: p for p in lista}
        lista = [por_id[i] for i in _vista["ids"] if i in por_id] + [p for p in lista if p["id"] not in _vista["ids"]]
    numero = int(ref) if ref.isdigit() else len(lista) if ref == "ultimo" else ORDINALES_N.get(ref)
    if numero:
        return lista[numero - 1] if 1 <= numero <= len(lista) else None
    return _buscar_pendiente(ref, hechos)


def texto_pendientes():
    lista = ordenados()
    _vista.update(ids=[p["id"] for p in lista], cuando=time.time())
    if not lista:
        return "No tenés pendientes. Para agregar: «poneme en pendientes estudiar para filosofía para el jueves»."
    lineas = [f"{i}. {p['texto']}" + (f" ({describir_fecha(p['para'])})" if p.get("para") else "")
              for i, p in enumerate(lista, 1)]
    return (f"Tenés {len(lista)} pendiente{'s' if len(lista) > 1 else ''}:\n" + "\n".join(lineas)
            + "\nCuando hagas uno, decime «tachá el 1» o «ya hice ...».")


def _cuantos():
    n = sum(1 for p in pendientes() if not p["hecho"])
    return "Es tu único pendiente." if n == 1 else f"Ya tenés {n} pendientes."


def anotar(cosa):
    """Anota uno o varios pendientes y dice cuáles."""
    agregados = []
    for parte in separar(cosa):
        texto, para = _sin_fecha(parte)
        if len(texto) < 2:
            continue
        antes = len(pendientes())
        agregar_pendiente(texto, para)
        if len(pendientes()) > antes:
            agregados.append(texto[:1].upper() + texto[1:] + (f" ({describir_fecha(para)})" if para else ""))
    if not agregados:
        return "Eso ya estaba en tus pendientes."
    if len(agregados) == 1:
        return f"Anotado: «{agregados[0]}». {_cuantos()}"
    lista = ", ".join(f"«{a}»" for a in agregados[:-1]) + f" y «{agregados[-1]}»"
    return f"Anoté {len(agregados)} pendientes: {lista}. {_cuantos()}"


def separar_ultimo():
    """'separalos': parte en varios el último pendiente que anotaste (si tiene varias cosas juntas)."""
    sin_hacer = [p for p in pendientes() if not p["hecho"]]
    if not sin_hacer:
        return "No tenés pendientes para separar."
    ultimo = max(sin_hacer, key=lambda p: p["id"])
    partes = separar(ultimo["texto"])
    if len(partes) == 1:  # lo pediste vos: se parte por comas e "y" aunque no empiecen con un verbo
        partes = [p.strip(" ,.") for p in re.split(r"\s*,\s*|\s+y\s+", ultimo["texto"]) if p.strip(" ,.")]
    if len(partes) < 2:
        juntos = [p["texto"] for p in sin_hacer if p.get("creado") == ultimo.get("creado")]
        if len(juntos) > 1:  # los anotó recién, ya separados
            lista = ", ".join(f"«{x}»" for x in juntos[:-1]) + f" y «{juntos[-1]}»"
            return f"Ya están separados: son {len(juntos)} pendientes, {lista}."
        return f"«{ultimo['texto']}» es una sola cosa: no sé cómo separarlo. Decime cómo querés que quede."
    borrar_pendiente(ultimo["id"])
    for parte in partes:
        agregar_pendiente(parte, ultimo.get("para"))
    lista = ", ".join(f"«{p[:1].upper() + p[1:]}»" for p in partes[:-1]) + f" y «{partes[-1][:1].upper() + partes[-1][1:]}»"
    return f"Listo, lo separé en {len(partes)} pendientes: {lista}."


def _ultimo_de_jarvis_fue_de_pendientes():
    with jarvis.lock:
        ultimo = next((m["content"] for m in reversed(jarvis.historial[-3:]) if m["role"] == "assistant"), "")
    return "pendiente" in _n(ultimo)


def manejar_pendientes(texto, t):
    t = t.strip(" ¿?¡!.,")
    if SEPARAR.search(t) and ("pendiente" in t or _ultimo_de_jarvis_fue_de_pendientes()):
        return separar_ultimo()
    for patron in AGREGAR:
        m = patron.match(t)
        if m:
            return anotar(_grupo(texto, t, m))
    if VER_PENDIENTES.search(t):
        if t.startswith("cuantos"):
            n = sum(1 for p in pendientes() if not p["hecho"])
            return f"Tenés {n} pendiente{'s' if n != 1 else ''}." if n else "No tenés pendientes."
        return texto_pendientes()
    if LIMPIAR.match(t):
        borrar_pendiente(solo_hechos=True)
        return "Listo, saqué de la lista los pendientes que ya hiciste."
    m = CAMBIAR.match(t)
    if m:
        p = _elegir(m.group(1))
        if not p:
            return "¿Cuál cambio? Decime el número (mirá «mis pendientes»)."
        nuevo, para = _sin_fecha(_grupo(texto, t, m, 2))
        _cambiar(p["id"], texto=nuevo[:1].upper() + nuevo[1:], para=para)
        return f"Listo, el pendiente ahora dice «{nuevo[:1].upper() + nuevo[1:]}»."
    m = PONER_FECHA.match(t)
    if m:
        p = _elegir(m.group(1))
        fecha, _ = fecha_de(m.group(2) if m.group(2).startswith(("para", "antes")) else "para " + m.group(2))
        if p and fecha:
            _cambiar(p["id"], para=fecha)
            return f"Listo: «{p['texto']}» {describir_fecha(fecha)}. Te aviso el día antes."
    m = BORRAR_UNO.match(t)
    if m:
        p = _elegir(m.group(1) or m.group(2))
        if not p:
            return "¿Cuál borro? Decime el número (mirá «mis pendientes») o lo que dice."
        borrar_pendiente(p["id"])
        return f"Listo, borré «{p['texto']}». " + (_cuantos() if any(not x["hecho"] for x in pendientes()) else
                                                   "No te queda nada pendiente.")
    m = DESMARCAR.match(t)
    if m:
        p = _elegir(m.group(1), hechos=True)
        if p:
            marcar_pendiente(p["id"], False)
            return f"Listo, «{p['texto']}» vuelve a estar pendiente."
    m = HECHO.match(t)
    if m:
        p = _elegir(m.group(1) or m.group(2) or "")
        if p:
            return _tachar(p)
    m = YA_HICE.match(t)
    if m:  # "ya estudié para filosofía", "ya investigué lo de la pila"
        p = _buscar_pendiente(f"{m.group(1)} {m.group(2)}", minimo=0.6)
        if p:
            return _tachar(p)
    return None


def _tachar(p):
    marcar_pendiente(p["id"], True)
    quedan = sum(1 for x in pendientes() if not x["hecho"])
    return f"¡Bien! Taché «{p['texto']}». " + (f"Te {'queda 1' if quedan == 1 else f'quedan {quedan}'}." if quedan
                                              else "¡No te queda nada pendiente!")


def que_vence(hoy=None, dias=1):
    """Los pendientes sin hacer que vencen de acá a 'dias' días (o ya vencieron)."""
    hoy = hoy or datetime.date.today()
    salida = []
    for p in ordenados():
        if p.get("para"):
            d = (datetime.date.fromisoformat(p["para"]) - hoy).days
            if d <= dias:
                salida.append((p, d))
    return salida


# =========================================================================
#  MODO ESTUDIO (pomodoro): bloques de concentración con descansos
# =========================================================================

estudio = {"activo": False, "fase": None, "fin": 0.0, "restante": None, "bloque": 0, "foco": 25, "descanso": 5,
           "tema": ""}
_estudio_lock = threading.Lock()
EMPEZAR_ESTUDIO = re.compile(r"\b(?:modo (?:estudio|concentracion|foco)|pomodoro|sesion de estudio|bloque de estudio|"
                             r"temporizador de estudio|vamos a estudiar|a estudiar|ponete en modo estudio)\b")
CONTROL_ESTUDIO = [
    (re.compile(r"\b(?:pausa|pone pausa|frena)\w*\s+(?:el |la )?(?:estudio|pomodoro|modo estudio|temporizador)\b"), "pausa"),
    (re.compile(r"\b(?:segui|reanuda|continua|retoma)\w*\s+(?:con )?(?:el |la )?(?:estudio|pomodoro|modo estudio)\b"), "seguir"),
    (re.compile(r"\b(?:termina|para|corta|frena|deten|cancela|apaga|sali)\w*\s+(?:del? |el |la )?(?:estudio|pomodoro|"
                r"modo estudio)\b|\bterminamos de estudiar\b|\bbasta de estudiar\b"), "terminar"),
    (re.compile(r"\b(?:cuanto (?:me )?(?:queda|falta)|cuanto tiempo (?:me )?(?:queda|falta))\b"), "cuanto"),
    (re.compile(r"\b(?:saltea|salta|pasa)\w*\s+(?:el )?descanso\b"), "saltear"),
]


def _emitir_estudio():
    jarvis.emitir("estudio", {k: estudio[k] for k in ("activo", "fase", "fin", "restante", "bloque", "foco",
                                                       "descanso", "tema")})


def _minutos(t, por_defecto):
    m = re.search(r"\b(\d{1,3})\s*(?:minutos|min|m)\b", t)
    h = re.search(r"\b(?:una|1) hora\b", t)
    return int(m.group(1)) if m else 60 if h else por_defecto


def empezar_estudio(t, texto=""):
    foco = max(5, min(120, _minutos(t, 25)))
    descanso = 15 if foco >= 50 else 10 if foco >= 40 else 5
    tema = ""
    m = re.search(r"\b(?:de|sobre|para)\s+(?!\d)(.+?)(?:\s+(?:por|durante|de)\s+\d.*)?$", t)
    if m and not re.match(r"(?:estudio|concentracion|\d)", m.group(1)):
        tema = _grupo(texto, t, m).strip(" .")
    with _estudio_lock:
        estudio.update(activo=True, fase="foco", fin=time.time() + foco * 60, restante=None, bloque=1,
                       foco=foco, descanso=descanso, tema=tema)
    _emitir_estudio()
    threading.Thread(target=_bucle_estudio, daemon=True).start()
    return (f"¡Modo estudio activado! {foco} minutos de concentración" + (f" en {tema}" if tema else "")
            + f" y después {descanso} de descanso. Te aviso cuando termine cada bloque. Para cortar: «terminá el modo estudio».")


def _bucle_estudio():
    while estudio["activo"]:
        time.sleep(1)
        with _estudio_lock:
            if not estudio["activo"] or estudio["restante"] is not None or time.time() < estudio["fin"]:
                continue
            if estudio["fase"] == "foco":
                estudio.update(fase="descanso", fin=time.time() + estudio["descanso"] * 60)
                frase = (f"¡Terminó el bloque {estudio['bloque']} de estudio! Tomate {estudio['descanso']} minutos: "
                         "levantate, tomá agua y estirá un poco.")
            else:
                estudio.update(fase="foco", fin=time.time() + estudio["foco"] * 60, bloque=estudio["bloque"] + 1)
                frase = f"Se terminó el descanso. Arrancamos el bloque {estudio['bloque']}: {estudio['foco']} minutos de foco."
        _emitir_estudio()
        jarvis.sonar("activar")
        jarvis.herramientas.notificar("J.A.R.V.I.S. · Modo estudio", frase)
        jarvis.mostrar(frase, jarvis.nueva_orden())


def manejar_estudio(texto, t):
    if estudio["activo"]:
        for patron, accion in CONTROL_ESTUDIO:
            if patron.search(t):
                with _estudio_lock:
                    if accion == "pausa" and estudio["restante"] is None:
                        estudio["restante"] = max(0, estudio["fin"] - time.time())
                        r = "Pausé el modo estudio. Decime «seguí con el estudio» cuando vuelvas."
                    elif accion == "seguir" and estudio["restante"] is not None:
                        estudio.update(fin=time.time() + estudio["restante"], restante=None)
                        r = "¡Seguimos! Dale con todo."
                    elif accion == "saltear" and estudio["fase"] == "descanso":
                        estudio.update(fase="foco", fin=time.time() + estudio["foco"] * 60, bloque=estudio["bloque"] + 1)
                        r = f"Salteamos el descanso: bloque {estudio['bloque']}, {estudio['foco']} minutos."
                    elif accion == "terminar":
                        bloques = estudio["bloque"] - (1 if estudio["fase"] == "foco" else 0)
                        estudio.update(activo=False, fase=None)
                        r = "Terminamos el modo estudio" + (f": completaste {bloques} bloque{'s' if bloques != 1 else ''}. "
                                                             "¡Buen trabajo!" if bloques else ".")
                    else:
                        resto = estudio["restante"] if estudio["restante"] is not None else estudio["fin"] - time.time()
                        r = (f"Te quedan {int(resto // 60)} minutos y {int(resto % 60)} segundos de "
                             f"{'concentración' if estudio['fase'] == 'foco' else 'descanso'} (bloque {estudio['bloque']}).")
                _emitir_estudio()
                return r
    if EMPEZAR_ESTUDIO.search(t) and not re.search(r"\b(?:que es|como funciona|explicame)\b", t):
        return empezar_estudio(t, texto)
    return None


# =========================================================================
#  CONVERSOR: monedas (cotización de referencia) y unidades
# =========================================================================

MONEDAS = [
    (r"dolar(?:es)?(?: americanos?| estadounidenses?)?|usd|u\$s|us\$|verdes", "USD", "dólares"),
    (r"pesos? argentinos?|ars", "ARS", "pesos argentinos"),
    (r"pesos? chilenos?|clp", "CLP", "pesos chilenos"),
    (r"pesos? mexicanos?|mxn", "MXN", "pesos mexicanos"),
    (r"pesos? colombianos?|cop", "COP", "pesos colombianos"),
    (r"pesos?(?: uruguayos?)?|uyu|\$u", "UYU", "pesos uruguayos"),
    (r"euros?|eur", "EUR", "euros"),
    (r"real(?:es)?|brl", "BRL", "reales"),
    (r"libras?(?: esterlinas?)?|gbp", "GBP", "libras"),
    (r"yenes|yen|jpy", "JPY", "yenes"),
    (r"guaranies|pyg", "PYG", "guaraníes"),
]
_MONEDA = "|".join(f"(?:{p})" for p, _, _ in MONEDAS)
NUM = r"(\d+(?:[.,]\d+)?)"
CONVERTIR = [
    re.compile(rf"\bcuant[oa]s? ({_MONEDA}) (?:son|es|serian|me dan por|equivalen a) {NUM} ({_MONEDA})\b"),
    re.compile(rf"\b{NUM}\s*({_MONEDA})\s+(?:a|en|son cuant[oa]s?|cuant[oa]s? son en|en cuant[oa]s?)\s+({_MONEDA})\b"),
    re.compile(rf"\b(?:pasa(?:me)?|converti(?:me)?|cambia(?:me)?)\s+{NUM}\s*({_MONEDA})\s+(?:a|en)\s+({_MONEDA})\b"),
]
COTIZACION = re.compile(rf"\b(?:a cuanto (?:esta|cotiza|sale)|cotizacion del?|cuanto (?:esta|sale|vale)) (?:el |la )?({_MONEDA})\b")
_cache_cambio = {"cuando": 0.0, "tasas": None}


def tasas():
    if _cache_cambio["tasas"] and time.time() - _cache_cambio["cuando"] < 3600:
        return _cache_cambio["tasas"]
    d = jarvis.herramientas.json_de("https://open.er-api.com/v6/latest/USD", 8)
    _cache_cambio.update(cuando=time.time(), tasas=d["rates"])
    return d["rates"]


def _moneda(texto):
    for patron, codigo, nombre in MONEDAS:
        if re.fullmatch(patron, texto):
            return codigo, nombre
    return None, None


def _num(s):
    return float(s.replace(".", "").replace(",", ".")) if re.fullmatch(r"\d{1,3}(?:\.\d{3})+", s) else \
        float(s.replace(",", "."))


def _plata(v):
    return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".").rstrip("0").rstrip(",")


UNIDADES = {  # unidad: (magnitud, factor a la unidad base)
    "km": ("largo", 1000), "kilometros": ("largo", 1000), "metros": ("largo", 1), "m": ("largo", 1),
    "cm": ("largo", 0.01), "centimetros": ("largo", 0.01), "millas": ("largo", 1609.344), "pies": ("largo", 0.3048),
    "pulgadas": ("largo", 0.0254), "yardas": ("largo", 0.9144),
    "kg": ("peso", 1), "kilos": ("peso", 1), "kilogramos": ("peso", 1), "gramos": ("peso", 0.001), "g": ("peso", 0.001),
    "libras": ("peso", 0.45359237), "onzas": ("peso", 0.0283495),
    "litros": ("volumen", 1), "l": ("volumen", 1), "ml": ("volumen", 0.001), "mililitros": ("volumen", 0.001),
    "galones": ("volumen", 3.78541),
    "km/h": ("velocidad", 1), "mph": ("velocidad", 1.609344),
    "gb": ("datos", 1024), "mb": ("datos", 1), "tb": ("datos", 1024 * 1024),
}
_UNIDAD = "|".join(sorted((re.escape(u) for u in UNIDADES), key=len, reverse=True))
TEMPERATURA = re.compile(rf"\b{NUM}\s*(?:grados\s*)?(celsius|centigrados|c|fahrenheit|f)?\s+(?:a|en)\s+(?:grados\s+)?"
                         r"(celsius|centigrados|fahrenheit|c|f)\b")
UNIDAD = re.compile(rf"\b{NUM}\s*({_UNIDAD})\s+(?:a|en|son cuant[oa]s)\s+({_UNIDAD})\b|"
                    rf"\bcuant[oa]s ({_UNIDAD}) (?:son|hay en|tiene) {NUM}\s*({_UNIDAD})\b")


def manejar_conversor(texto, t):
    t = t.replace("°", " grados ")
    for i, patron in enumerate(CONVERTIR):
        m = patron.search(t)
        if m:
            if i == 0:
                destino, cantidad, origen = m.group(1), m.group(2), m.group(3)
            else:
                cantidad, origen, destino = m.group(1), m.group(2), m.group(3)
            (c_o, n_o), (c_d, n_d) = _moneda(origen), _moneda(destino)
            if not c_o or not c_d or c_o == c_d:
                break
            try:
                r = tasas()
            except Exception as e:
                return f"No pude consultar la cotización: {e}"
            valor = _num(cantidad) / r[c_o] * r[c_d]
            return (f"{_plata(_num(cantidad))} {n_o} son unos {_plata(valor)} {n_d} "
                    f"(cotización de referencia de hoy; en el banco o el cambio puede variar un poco).")
    m = COTIZACION.search(t)
    if m:
        codigo, nombre = _moneda(m.group(1))
        if codigo and codigo != "UYU":
            try:
                r = tasas()
            except Exception as e:
                return f"No pude consultar la cotización: {e}"
            valor = r["UYU"] / r[codigo]
            singular = {"dólares": "dólar", "reales": "real", "libras": "libra", "yenes": "yen", "guaraníes": "guaraní"}.get(
                nombre, re.sub(r"s\b", "", nombre))
            return (f"1 {singular} está a unos {_plata(valor)} pesos uruguayos "
                    "(cotización de referencia; la compra y la venta en el banco difieren un poco).")
    m = TEMPERATURA.search(t)
    if m:
        valor, de, a = _num(m.group(1)), (m.group(2) or ""), m.group(3)
        a_f = a.startswith("f")
        if a_f and not de.startswith("f"):
            return f"{_plata(valor)} °C son {_plata(valor * 9 / 5 + 32)} °F."
        if not a_f and de.startswith("f") or (not a_f and not de):
            return f"{_plata(valor)} °F son {_plata((valor - 32) * 5 / 9)} °C."
    m = UNIDAD.search(t)
    if m:
        if m.group(1):
            valor, u_o, u_d = _num(m.group(1)), m.group(2), m.group(3)
        else:
            u_d, valor, u_o = m.group(4), _num(m.group(5)), m.group(6)
        (mag_o, f_o), (mag_d, f_d) = UNIDADES[u_o], UNIDADES[u_d]
        if mag_o == mag_d and u_o != u_d:
            return f"{_plata(valor)} {u_o} son {_plata(valor * f_o / f_d)} {u_d}."
    return None


# =========================================================================
#  RESUMEN DEL DÍA: "¿qué tengo hoy?", "buen día"
# =========================================================================

PIDE_RESUMEN = re.compile(r"\b(?:que tengo (?:para )?hoy|resumen del dia|como (?:viene|pinta) (?:mi |el )?dia|"
                          r"que hay para hoy|mi dia|agenda de hoy|ponete al dia)\b")
BUEN_DIA = re.compile(r"^(?:(?:hola|che)[\s,]+)?buen(?:os)? dias?(?:[\s,]+jarvis)?$")


def clima_corto():
    """'14° nublado' (para el resumen y la barra de Hoy)."""
    h = jarvis.herramientas
    nombre, lat, lon = h.ubicacion_actual()
    d = h.json_de(f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
                  "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,"
                  "precipitation_probability_max&timezone=auto&forecast_days=1", 6)
    c, dia = d["current"], d["daily"]
    return {"ciudad": nombre, "temp": round(c["temperature_2m"]), "estado": h.CLIMA_CODIGOS.get(c["weather_code"], ""),
            "max": round(dia["temperature_2m_max"][0]), "min": round(dia["temperature_2m_min"][0]),
            "lluvia": dia["precipitation_probability_max"][0] or 0}


def recordatorios_de_hoy():
    hoy = datetime.date.today()
    salida = []
    for r in jarvis.herramientas.cargar_recordatorios():
        try:
            cuando = datetime.datetime.fromisoformat(r["cuando"])
        except (KeyError, ValueError):
            continue
        if cuando.date() == hoy and cuando >= datetime.datetime.now():
            salida.append((cuando, r))
    return sorted(salida, key=lambda x: x[0])


def mails_sin_leer():
    if not jarvis.conexiones.gmail_configurado():
        return None
    try:
        total, _ = jarvis.conexiones.leer_correos(1, True)
        return total
    except Exception:
        return None


def resumen_del_dia():
    ahora = datetime.datetime.now()
    saludo = "Buen día" if ahora.hour < 13 else "Buenas tardes" if ahora.hour < 20 else "Buenas noches"
    partes = [f"{saludo}. Hoy es {jarvis.DIAS[ahora.weekday()]} {ahora.day} de {jarvis.MESES[ahora.month - 1]}."]
    try:
        c = clima_corto()
        partes.append(f"En {c['ciudad']} hay {c['temp']} grados, {c['estado']}; máxima de {c['max']} y mínima de "
                      f"{c['min']}" + (f", con {c['lluvia']}% de probabilidad de lluvia (llevá paraguas)" if c["lluvia"] >= 50
                                       else "") + ".")
    except Exception:
        pass
    hoy = recordatorios_de_hoy()
    if hoy:
        partes.append("Para hoy tenés: " + "; ".join(
            f"{'alarma' if r.get('tipo') == 'alarma' else r.get('texto') or 'recordatorio'} a las {c:%H:%M}" for c, r in hoy[:4]) + ".")
    lista = ordenados()
    if lista:
        urgentes = [f"{p['texto']} ({describir_fecha(p['para'])})" for p, d in que_vence(dias=1)]
        if urgentes:
            partes.append("Ojo con esto: " + "; ".join(urgentes[:3]) + ".")
        partes.append(f"Pendientes: {len(lista)} (" + ", ".join(p["texto"] for p in lista[:3])
                      + (", ..." if len(lista) > 3 else "") + ").")
    n = mails_sin_leer()
    if n:
        partes.append(f"Tenés {n} mail{'s' if n > 1 else ''} sin leer.")
    if not hoy and not lista:
        partes.append("No tenés nada agendado: buen día para avanzar con algo. ¿Arrancamos un modo estudio?")
    return " ".join(partes)


def datos_de_hoy():
    """Para la barra 'Hoy' de la interfaz."""
    datos = {"pendientes": sum(1 for p in pendientes() if not p["hecho"]), "clima": None, "proximo": None,
             "mails": None, "estudio": {k: estudio[k] for k in ("activo", "fase", "fin", "restante", "bloque", "tema")}}
    try:
        datos["clima"] = clima_corto()
    except Exception:
        pass
    hoy = recordatorios_de_hoy()
    if hoy:
        c, r = hoy[0]
        datos["proximo"] = {"hora": f"{c:%H:%M}", "texto": r.get("texto") or ("Alarma" if r.get("tipo") == "alarma" else "Recordatorio")}
    datos["mails"] = mails_sin_leer()
    return datos


# =========================================================================
#  ENTRADA
# =========================================================================

def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    # modo "menea tu chapa" (primero el de apagar: "apagá el modo menea tu chapa" también dice "menea tu chapa")
    if MENEA_OFF.search(t) and fiesta["activa"]:
        return modo_menea(False)
    if MENEA_ON.search(t) and not MENEA_OFF.search(t):
        return modo_menea(True)
    # pantalla compartida en vivo (primero "dejá de compartir", que también dice "compartir la pantalla")
    if DEJAR_PANTALLA.search(t):
        return jarvis.pantalla.terminar()
    if COMPARTIR_PANTALLA.search(t):
        return jarvis.pantalla.empezar()
    respuesta = jarvis.pantalla.revisar_ortografia(texto, t)   # «¿qué errores de ortografía tiene ...?»
    if respuesta is not None:
        return respuesta
    if GRABAR_PANTALLA.search(t):
        return grabar_pantalla(texto, t)
    if PANTALLA.search(t):
        return mirar_pantalla(texto)
    if COPIAR_RESPUESTA.match(t):
        return copiar_respuesta(t)
    for manejador in (manejar_estudio, manejar_pendientes, manejar_conversor):
        r = manejador(texto, t)
        if r is not None:
            return r
    if PIDE_RESUMEN.search(t) or (BUEN_DIA.match(t) and datetime.datetime.now().hour < 13):
        return resumen_del_dia()
    return None
