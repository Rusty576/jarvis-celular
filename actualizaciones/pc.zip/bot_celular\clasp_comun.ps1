﻿# ============================================================
#  Lo que comparten «JARVIS para otra persona» y «actualizar mi bot» (se carga con un punto: . clasp_comun.ps1)
# ------------------------------------------------------------
#  Node.js y clasp (la herramienta de Google para Apps Script) se bajan solos la primera vez en %LOCALAPPDATA%\JARVIS
#  (no se instala nada en Windows). El permiso sobre la cuenta de Google vive en $AUTH (lo define cada script) y se
#  borra al terminar con Soltar-Permiso.
# ============================================================
$ProgressPreference = "SilentlyContinue"   # (la barra de progreso hace lentísimas las descargas)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$RAIZ = Join-Path $env:LOCALAPPDATA "JARVIS"
$HERRAMIENTAS = Join-Path $RAIZ "clasp"
$CLASP_VERSION = "3.4.1"

function Paso($texto) { Write-Host ""; Write-Host "== $texto" -ForegroundColor Cyan }
function Dice($texto) { Write-Host "   $texto" }
function Ojo($texto) { Write-Host "   $texto" -ForegroundColor Yellow }

function Navegador($url, [switch]$Privado) {
    # En una ventana privada: así entra con SU cuenta aunque el navegador tenga la tuya abierta (las páginas de Apps
    # Script se confunden con dos cuentas abiertas a la vez)
    if ($Privado) {
        $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
                    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
                    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
        if ($chrome) { Start-Process $chrome -ArgumentList "--incognito", $url; return }
        $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
                  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
        if ($edge) { Start-Process $edge -ArgumentList "-inprivate", $url; return }
    }
    Start-Process $url
}

function Escribir($ruta, $texto) {
    [IO.File]::WriteAllText($ruta, $texto, (New-Object Text.UTF8Encoding($false)))
}

# ---------- Las herramientas (una sola vez) ----------

function Carpeta-Node {
    $n = Get-Command node -ErrorAction SilentlyContinue
    if ($n) {
        $v = (& $n.Source --version) -replace "^v", ""
        if ([int]($v.Split(".")[0]) -ge 20) { return (Split-Path -Parent $n.Source) }
    }
    $carpeta = Join-Path $RAIZ "node"
    $listo = Get-ChildItem $carpeta -Directory -Filter "node-v*-win-x64" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listo) { return $listo.FullName }
    Paso "Bajando Node.js (una sola vez, unos 30 MB)"
    $base = "https://nodejs.org/dist/latest-v22.x/"
    $sumas = (Invoke-WebRequest ($base + "SHASUMS256.txt") -UseBasicParsing).Content
    if ($sumas -notmatch "([0-9a-f]{64})\s+(node-v[\d.]+-win-x64\.zip)") { throw "No encontré Node.js para Windows en $base" }
    $suma, $nombre = $Matches[1], $Matches[2]
    New-Item -ItemType Directory -Force $carpeta | Out-Null
    $zip = Join-Path $carpeta $nombre
    Invoke-WebRequest ($base + $nombre) -OutFile $zip -UseBasicParsing
    if ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -ne $suma) {
        Remove-Item $zip
        throw "Node.js se bajó mal (no coincide la suma de control): probá de nuevo"
    }
    Expand-Archive $zip $carpeta -Force
    Remove-Item $zip
    return (Join-Path $carpeta ($nombre -replace "\.zip$", ""))
}

function Instalar-Clasp($node) {
    $cmd = Join-Path $HERRAMIENTAS "node_modules\.bin\clasp.cmd"
    $paquete = Join-Path $HERRAMIENTAS "node_modules\@google\clasp\package.json"
    if ((Test-Path $cmd) -and (Test-Path $paquete) -and
        ((Get-Content $paquete -Raw | ConvertFrom-Json).version -eq $CLASP_VERSION)) { return (Clasp-Rapido $node $cmd) }
    Paso "Bajando clasp, la herramienta de Google para Apps Script (una sola vez)"
    New-Item -ItemType Directory -Force $HERRAMIENTAS | Out-Null
    $ErrorActionPreference = "Continue"   # npm cuenta lo que hace por stderr
    & (Join-Path $node "npm.cmd") install --prefix $HERRAMIENTAS --no-fund --no-audit --loglevel=error "@google/clasp@$CLASP_VERSION" | Out-Host
    $ErrorActionPreference = "Stop"
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $cmd)) { throw "No pude instalar clasp" }
    return (Clasp-Rapido $node $cmd)
}

function Clasp-Rapido($node, $cmd) {
    # clasp carga más de 4000 archivos cada vez que arranca (la librería entera de las APIs de Google) y Windows los
    # revisa uno por uno: 3 a 10 segundos por comando, y la página de Google tardaba en aparecer. Juntado en UN archivo
    # (con esbuild, una sola vez) y con lo ya compilado guardado, arranca en menos de un segundo. Si algo falla, el de
    # siempre.
    $unido = Join-Path $HERRAMIENTAS "rapido\clasp_unido.mjs"
    $rapido = Join-Path $HERRAMIENTAS "rapido\clasp_rapido.cmd"
    $marca = Join-Path $HERRAMIENTAS "rapido\package.json"
    $exe = Join-Path $node "node.exe"
    # (sin el clasp de verdad al lado, o sin Node, no hay nada que juntar: el de siempre, sin bajar esbuild por nada)
    if (-not (Test-Path (Join-Path $HERRAMIENTAS "node_modules\@google\clasp\build\src\index.js")) -or -not (Test-Path $exe)) { return $cmd }
    try {
        $listo = (Test-Path $unido) -and (Test-Path $marca) -and
                 ((Get-Content $marca -Raw | ConvertFrom-Json).version -eq $CLASP_VERSION)
        if (-not $listo) {
            Dice "Preparando clasp para que arranque rápido (una sola vez)..."
            $carpeta = Join-Path $HERRAMIENTAS "rapido"
            New-Item -ItemType Directory -Force $carpeta | Out-Null
            $esbuild = Join-Path $HERRAMIENTAS "empaquetar\node_modules\.bin\esbuild.cmd"
            $ErrorActionPreference = "Continue"
            if (-not (Test-Path $esbuild)) {
                & (Join-Path $node "npm.cmd") install --prefix (Join-Path $HERRAMIENTAS "empaquetar") --no-fund --no-audit `
                    --loglevel=error "esbuild@0.25.12" 2>&1 | Out-Null
            }
            $entrada = Join-Path $HERRAMIENTAS "node_modules\@google\clasp\build\src\index.js"
            # (clasp es un módulo moderno: los pedazos viejos que usan require() lo necesitan definido)
            $arriba = "import { createRequire as __jarvisCr } from 'module'; const require = __jarvisCr(import.meta.url);"
            & $esbuild $entrada --bundle --platform=node --format=esm --target=node20 "--outfile=$unido" `
                "--banner:js=$arriba" --log-level=error 2>&1 | Out-Null
            $ErrorActionPreference = "Stop"
            # (clasp lee su versión del package.json que tiene al lado: si no, «--version» sale vacío)
            Escribir $marca (@{ name = "@google/clasp"; version = $CLASP_VERSION; type = "module" } | ConvertTo-Json)
        }
        # (se escribe siempre: si Node cambió de carpeta, apunta al de ahora)
        Escribir $rapido ("@set `"NODE_COMPILE_CACHE=%~dp0cache`"`r`n@`"$exe`" `"%~dp0clasp_unido.mjs`" %*`r`n")
        $ErrorActionPreference = "Continue"
        $v = (& $rapido --version 2>&1 | Out-String).Trim()
        $ErrorActionPreference = "Stop"
        if ($v -eq $CLASP_VERSION) { return $rapido }
        Remove-Item $marca -ErrorAction SilentlyContinue   # (la próxima vez se arma de nuevo)
    } catch {
        $ErrorActionPreference = "Stop"
    }
    return $cmd
}

$script:codigoClasp = 0
function Clasp {
    # (clasp también escribe por stderr lo que va haciendo: no es un error)
    $ErrorActionPreference = "Continue"
    $salida = & $script:CLASP --auth $AUTH @args 2>&1 | ForEach-Object { "$_" }
    $script:codigoClasp = $LASTEXITCODE
    $ErrorActionPreference = "Stop"
    return ($salida -join "`n")
}

function Navegador-Predeterminado {
    # el nombre del navegador que abre los links (para decir dónde buscar la página de Google)
    try {
        $id = (Get-ItemProperty "HKCU:\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice").ProgId
    } catch { return "tu navegador" }
    switch -Regex ("$id") {
        "^MSEdge" { return "Edge" }
        "^Chrome" { return "Chrome" }
        "Opera ?GX" { return "Opera GX" }
        "^Opera" { return "Opera" }
        "^Firefox" { return "Firefox" }
        "^Brave" { return "Brave" }
        default { return "tu navegador" }
    }
}

function Leer-Compartido($ruta) {
    # un archivo que otro programa todavía está escribiendo
    if (-not (Test-Path $ruta)) { return "" }
    try {
        $f = [IO.File]::Open($ruta, "Open", "Read", "ReadWrite")
        try { return (New-Object IO.StreamReader($f)).ReadToEnd() } finally { $f.Dispose() }
    } catch { return "" }
}

function Linea-Escrita {
    # lo que se escribió en esta ventana (con Enter), sin quedarse esperando; nada si no es una ventana de verdad
    try {
        if (-not [Console]::KeyAvailable) { return $null }
        return [Console]::ReadLine()
    } catch { return $null }
}

function Limpiar-Restos($prefijo) {
    # si una vez anterior se cerró la ventana a mitad de camino, quedó su carpeta de trabajo (y quizás el permiso)
    Get-ChildItem $env:TEMP -Directory -Filter "$prefijo*" -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt [DateTime]::Now.AddHours(-1) } | ForEach-Object {
            $permiso = Join-Path $_.FullName ".clasprc.json"
            if (Test-Path $permiso) {
                foreach ($m in [regex]::Matches((Get-Content $permiso -Raw), '"refresh_token"\s*:\s*"([^"]+)"')) {
                    try { Invoke-RestMethod "https://oauth2.googleapis.com/revoke" -Method Post -Body @{ token = $m.Groups[1].Value } | Out-Null } catch { }
                }
            }
            Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
}

function Entrar-Cuenta {
    # clasp abre el navegador en la página de Google (elegir la cuenta y aceptar) y espera a que vuelva; el permiso
    # queda en $AUTH. Lo que escribe clasp (en inglés) se lee acá: el link queda copiado por si el navegador no
    # aparece, Enter lo vuelve a abrir, y si la última página no carga se puede pegar acá su dirección.
    $carpeta = Split-Path -Parent $AUTH
    $salida = Join-Path $carpeta "entrar_salida.txt"
    $errores = Join-Path $carpeta "entrar_errores.txt"
    Remove-Item $salida, $errores -ErrorAction SilentlyContinue
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $env:ComSpec
    $info.Arguments = "/d /s /c `"`"$($script:CLASP)`" --auth `"$AUTH`" login > `"$salida`" 2> `"$errores`"`""
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.WorkingDirectory = (Get-Location).Path   # (la carpeta de trabajo de PowerShell, no la del programa)
    $p = [Diagnostics.Process]::Start($info)
    $reloj = [Diagnostics.Stopwatch]::StartNew()   # (un reloj aparte: las pruebas cambian Get-Date y Start-Sleep)
    $link = $null
    $recordado = $false
    while (-not $p.HasExited) {
        if (-not $link -and (Leer-Compartido $salida) -match "(https://accounts\.google\.com/\S+)") {
            $link = $Matches[1]
            try { Set-Clipboard $link } catch { }
            $donde = Navegador-Predeterminado
            Dice "Se abrió $donde en la página de Google (si no la ves, buscala en la barra de tareas)."
            Dice "Si tu cuenta de Google está en otro navegador, abrilo y pegá el link arriba (Ctrl+V): ya lo copié."
            Dice "En esa página:"
            Dice " 1. Elegí la cuenta (si no aparece, «Usar otra cuenta» y entrá con el mail y la contraseña)."
            Dice " 2. Si aparece una lista de permisos con casillas, tocá «Seleccionar todo»."
            Dice " 3. Tocá «Continuar» (o «Permitir»). Al final dice «Logged in! You may close this page.»: ya está."
            Dice "(Si no se abrió nada, apretá Enter acá y lo abro de nuevo.)"
        }
        if ($link) {
            $linea = Linea-Escrita
            if ($null -ne $linea) {
                if ($linea -match "(http://(localhost|127\.0\.0\.1):\d+/\S*code=\S+)") {
                    # la última página no cargó: lo que traía su dirección se lo paso a clasp
                    try { Invoke-WebRequest $Matches[1] -UseBasicParsing -TimeoutSec 15 | Out-Null } catch { }
                } else {
                    Navegador $link
                }
            }
            if (-not $recordado -and $reloj.Elapsed.TotalMinutes -ge 3) {
                $recordado = $true
                Ojo "¿Se trabó? Si la página quedó en «No se puede acceder a este sitio», copiá su dirección (empieza"
                Ojo "con http://localhost), pegala acá y apretá Enter."
            }
        }
        if ($reloj.Elapsed.TotalMinutes -ge 15) {
            & taskkill.exe /PID $p.Id /T /F 2>&1 | Out-Null
            throw "No terminaste de entrar a la cuenta (pasaron 15 minutos)"
        }
        [Threading.Thread]::Sleep(300)
    }
    $p.WaitForExit()
    $todo = (Leer-Compartido $salida) + "`n" + (Leer-Compartido $errores)
    Remove-Item $salida, $errores -ErrorAction SilentlyContinue
    if ($p.ExitCode -ne 0 -or -not (Test-Path $AUTH)) {
        if ($todo -match "access_denied") { throw "Google no dio el permiso (se tocó «Cancelar», o la cuenta no lo deja)" }
        $ultimo = @($todo -split "`r?`n" | Where-Object { $_.Trim() }) | Select-Object -Last 1
        throw "No se pudo entrar a la cuenta ($ultimo)"
    }
    if ($todo -match "logged in as ([^\s]+@[^\s]+?)\.?(\s|$)") { Dice "Listo: entraste como $($Matches[1])." }
}

function Falta-API($salida) {
    # Google trae apagada la «API de Google Apps Script» de cada cuenta: hay que prenderla a mano, una sola vez
    return ($salida -match "Apps Script API|usersettings")
}

# de quién es la cuenta (para los avisos) y si la página va en una ventana privada (la cuenta de otra persona)
$script:deQuien = "tu cuenta"
$script:paginaPrivada = $false
$script:avisadoAPI = $false

function Clasp-Con-API {
    # clasp, pero si Google dice que la «API de Google Apps Script» está apagada (o que se prendió hace poco y todavía
    # no llegó a todos lados: tarda unos minutos, y puede pasar en cualquier paso), abre esa página una sola vez y
    # reintenta solo, hasta 10 minutos
    $desde = Get-Date
    while ($true) {
        $s = Clasp @args
        if ($script:codigoClasp -eq 0 -or -not (Falta-API $s)) { return $s }
        if (-not $script:avisadoAPI) {
            $script:avisadoAPI = $true
            Ojo "Falta prender un permiso de $($script:deQuien). Se abre una página: prendé «API de Google Apps Script»"
            Ojo "(Google Apps Script API). Si ya está prendida, Google tarda unos minutos en darse cuenta: yo sigo solo."
            if ($script:paginaPrivada) { Navegador "https://script.google.com/home/usersettings" -Privado }
            else { Navegador "https://script.google.com/home/usersettings" }
        }
        if (((Get-Date) - $desde).TotalMinutes -gt 10) { return $s }
        Start-Sleep -Seconds 15
    }
}

function Agregar-Servicios($m) {
    # las APIs de Google que usa el bot (Drive y Slides), en el manifiesto: sin repetir las que ya estén
    $servicios = @(
        [pscustomobject][ordered]@{ userSymbol = "Drive"; serviceId = "drive"; version = "v3" },
        [pscustomobject][ordered]@{ userSymbol = "Slides"; serviceId = "slides"; version = "v1" })
    if (-not $m.dependencies) { $m | Add-Member -NotePropertyName dependencies -NotePropertyValue ([pscustomobject]@{}) }
    $lista = @()
    if ($m.dependencies.enabledAdvancedServices) { $lista = @($m.dependencies.enabledAdvancedServices) }
    foreach ($sv in $servicios) {
        if (-not ($lista | Where-Object { $_.serviceId -eq $sv.serviceId })) { $lista += $sv }
    }
    if ($m.dependencies.PSObject.Properties["enabledAdvancedServices"]) { $m.dependencies.enabledAdvancedServices = $lista }
    else { $m.dependencies | Add-Member -NotePropertyName enabledAdvancedServices -NotePropertyValue $lista }
    # los permisos, escritos: para actualizarse solo el bot usa la API de Apps Script (script.projects y
    # script.deployments), que Google no detecta sola; escritos, hay que poner TODOS los que usa (Gmail, Drive, Docs,
    # Slides, Calendar, internet y los avisos). Cada uno acepta el permiso nuevo una vez (Revisar-Permisos)
    $permisos = @("https://mail.google.com/", "https://www.googleapis.com/auth/drive",
        "https://www.googleapis.com/auth/documents", "https://www.googleapis.com/auth/presentations",
        "https://www.googleapis.com/auth/calendar", "https://www.googleapis.com/auth/script.external_request",
        "https://www.googleapis.com/auth/script.scriptapp", "https://www.googleapis.com/auth/script.projects",
        "https://www.googleapis.com/auth/script.deployments")
    if ($m.oauthScopes) { $permisos = @(@($m.oauthScopes) + $permisos | Select-Object -Unique) }
    if ($m.PSObject.Properties["oauthScopes"]) { $m.oauthScopes = $permisos }
    else { $m | Add-Member -NotePropertyName oauthScopes -NotePropertyValue $permisos }
}

function Sin-API($salida) {
    # pasaron 10 minutos y Google sigue diciendo que está apagada
    if (Falta-API $salida) {
        throw ("Google sigue diciendo que la «API de Google Apps Script» está apagada en $($script:deQuien). Prendela en la " +
               "página que se abrió (con la misma cuenta del bot) y probá de nuevo en unos minutos.")
    }
}

function Faltan-Permisos($salida) {
    # en la página de Google quedaron casillas sin marcar: clasp entra, pero no puede tocar el proyecto
    return ($salida -match "insufficient authentication scopes|ACCESS_TOKEN_SCOPE_INSUFFICIENT|insufficientPermissions")
}

# ---------- El bot ----------

function Estado-Bot($url) {
    # {ok, instalado, version} si contesta; un texto si devuelve una página de Google (falta aceptar los permisos);
    # nada si no se pudo hablar con él
    try {
        $r = Invoke-RestMethod $url -Method Post -ContentType "application/json" -TimeoutSec 60 `
            -Body ([Text.Encoding]::UTF8.GetBytes('{"accion":"instalar_estado"}'))
        if ($r -is [string]) { return $r }
        if ($r.ok) { return $r }
    } catch { }
    return $null
}

function Revisar-Permisos($url, $cuenta, [switch]$Privado) {
    # Contestar, el bot contesta aunque le falte un permiso de Google (responder no usa Drive): por eso antes quedaba
    # sin dar y fallaban los documentos, los reportes y los archivos para la PC. Se le pregunta (Google mismo sabe si
    # falta algo y da el link para aceptarlo) y, si falta, se abre esa página y se espera
    $desde = Get-Date
    $abierto = $false
    while ($true) {
        $p = $null
        try {
            $p = Invoke-RestMethod $url -Method Post -ContentType "application/json" -TimeoutSec 60 `
                -Body ([Text.Encoding]::UTF8.GetBytes('{"accion":"permisos"}'))
        } catch { }
        if ($p -and $p.ok -and $p.falta -eq $false) { Dice "Tiene todos los permisos."; return $true }
        if ($p -and $p.ok -and $null -eq $p.falta) { Ojo "No pude saber si le falta un permiso: si algo falla, el bot lo dice."; return $true }
        if ($p -and $p.falta -and $p.url -and -not $abierto) {
            $abierto = $true
            Ojo "El bot necesita un permiso de Google (Drive y Documentos: reportes, documentos y archivos para la PC)."
            Ojo "Se abre la página de Google:"
            Ojo " 1. Elegí $cuenta."
            Ojo " 2. Si dice que Google no verificó la app: «Configuración avanzada» > «Ir a JARVIS (no seguro)»."
            Ojo " 3. Marcá todo y tocá «Permitir» (o «Continuar»)."
            Dice "Yo sigo esperando solo."
            if ($Privado) { Navegador $p.url -Privado } else { Navegador $p.url }
        }
        if (((Get-Date) - $desde).TotalMinutes -gt 10) {
            Ojo "Todavía no está el permiso. Cuando quieras, abrí la página de nuevo:"
            if ($p -and $p.url) { Ojo $p.url }
            return $false
        }
        Start-Sleep -Seconds 4
    }
}

function Soltar-Permiso {
    # Le saca a esta PC el permiso sobre la cuenta (como «Quitar acceso» en la cuenta de Google)
    if (-not (Test-Path $AUTH)) { return }
    $t = Get-Content $AUTH -Raw
    foreach ($m in [regex]::Matches($t, '"refresh_token"\s*:\s*"([^"]+)"')) {
        try { Invoke-RestMethod "https://oauth2.googleapis.com/revoke" -Method Post -Body @{ token = $m.Groups[1].Value } | Out-Null } catch { }
    }
}
