"""Lo que hacés en la compu: qué app tenés adelante y cuánto tiempo (para "¿qué estuve haciendo hoy?", "¿cuánto
jugué?", "¿en qué me quedé?", las rutinas y los consejos).

Todo queda en ESTA compu (carpeta actividad\\, un archivo por día, se borra solo a los 30 días). Se anota solo el
nombre de la app y el título de la ventana, cada 5 segundos; nada de capturas ni de lo que escribís. Las ventanas
privadas (InPrivate, incógnito) no se anotan. Se apaga en Configuraciones o diciendo "dejá de registrar lo que hago".
"""
import ctypes
import ctypes.wintypes as wt
import datetime
import json
import os
import re
import threading
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(BASE, "actividad")
ACTIVO = True        # Configuraciones > "Registrar qué apps uso"
CADA = 5             # segundos entre una mirada y otra
AUSENTE = 300        # 5 minutos sin tocar nada: no cuenta (salvo jugando o mirando videos)
DIAS_GUARDADOS = 30
PRIVADO = re.compile(r"inprivate|incognito|incógnito|navegación privada|private browsing", re.I)

NOMBRES = {"opera.exe": "Opera GX", "chrome.exe": "Chrome", "msedge.exe": "Edge", "firefox.exe": "Firefox",
           "brave.exe": "Brave", "code.exe": "VS Code", "whatsapp.exe": "WhatsApp", "whatsapp.root.exe": "WhatsApp",
           "discord.exe": "Discord", "telegram.exe": "Telegram", "spotify.exe": "Spotify", "capcut.exe": "CapCut",
           "winword.exe": "Word", "excel.exe": "Excel", "powerpnt.exe": "PowerPoint", "desktopeditors.exe": "ONLYOFFICE",
           "editors.exe": "ONLYOFFICE", "notepad.exe": "Bloc de notas", "explorer.exe": "Explorador de archivos",
           "steam.exe": "Steam", "steamwebhelper.exe": "Steam", "epicgameslauncher.exe": "Epic Games",
           "obs64.exe": "OBS", "vlc.exe": "VLC", "wizTree64.exe": "WizTree", "windowsterminal.exe": "Terminal",
           "systemsettings.exe": "Configuración de Windows", "taskmgr.exe": "Administrador de tareas",
           "acrord32.exe": "Acrobat Reader", "acrobat.exe": "Acrobat", "sumatrapdf.exe": "SumatraPDF",
           "rdr2.exe": "Red Dead Redemption 2", "launcher.exe": "Rockstar Games Launcher"}
NAVEGADORES = {"opera.exe", "chrome.exe", "msedge.exe", "firefox.exe", "brave.exe"}
POR_PROGRAMA = {
    "estudio": {"code.exe", "winword.exe", "excel.exe", "powerpnt.exe", "desktopeditors.exe", "editors.exe",
                "notepad.exe", "acrord32.exe", "acrobat.exe", "sumatrapdf.exe", "onenote.exe", "pycharm64.exe",
                "idea64.exe", "windowsterminal.exe", "python.exe"},
    "charla": {"whatsapp.exe", "whatsapp.root.exe", "discord.exe", "telegram.exe", "teams.exe", "zoom.exe"},
    "crear": {"capcut.exe", "obs64.exe", "photoshop.exe", "blender.exe", "audacity.exe", "kdenlive.exe"},
    "videos": {"vlc.exe", "spotify.exe"},
    "otros": {"explorer.exe", "systemsettings.exe", "taskmgr.exe", "applicationframehost.exe", "steam.exe",
              "steamwebhelper.exe", "epicgameslauncher.exe", "launcher.exe"},
}
EN_EL_TITULO = [(re.compile(r"youtube|twitch|netflix|prime video|disney|tiktok|max\b|crunchyroll", re.I), "videos"),
                (re.compile(r"whatsapp|gmail|outlook|discord|messenger|instagram|telegram", re.I), "charla"),
                (re.compile(r"docs\.google|documentos de google|google docs|classroom|wikipedia|crea2|ceibal|moodle|"
                            r"campus|\.pdf|chatgpt|claude|gemini|stack ?overflow|github|w3schools|khan", re.I), "estudio")]
JUEGO_EN_LA_RUTA = re.compile(r"steamapps\\common|epic games\\|rockstar games\\|riot games\\|\\games\\", re.I)
CATEGORIAS = {"juego": "jugando", "estudio": "estudiando o trabajando", "videos": "viendo videos o música",
              "charla": "chateando", "crear": "creando (videos, fotos)", "navegar": "navegando", "otros": "en otras cosas"}

_lock = threading.Lock()
_estado = {"dia": None, "entradas": [], "actual": None, "guardado": 0.0, "activo_desde": None,
           "juego": None, "visto": {}}
_oyentes = []  # funciones que se llaman cuando abrís una app (las rutinas)
_juegos_cache = {"cuando": 0.0, "nombres": []}


# ---------- Mirar la ventana de adelante ----------

class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", wt.UINT), ("dwTime", wt.DWORD)]


def segundos_sin_tocar():
    info = LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(info)
    if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
        return 0.0
    return (ctypes.windll.kernel32.GetTickCount() - info.dwTime) / 1000.0


def ventana_de_adelante():
    """(exe, ruta del exe, título) de la ventana que estás usando, o None."""
    import psutil
    import win32gui
    import win32process

    hwnd = win32gui.GetForegroundWindow()
    if not hwnd:
        return None
    titulo = win32gui.GetWindowText(hwnd).strip()
    _, pid = win32process.GetWindowThreadProcessId(hwnd)
    try:
        p = psutil.Process(pid)
        exe, ruta = p.name().lower(), p.exe()
    except Exception:
        return None
    return exe, ruta, titulo


def _juegos():
    """Los nombres de tus juegos (de Steam, Epic...), para reconocerlos por el título de la ventana."""
    if time.time() - _juegos_cache["cuando"] > 3600:
        try:
            _juegos_cache["nombres"] = [jarvis.normalizar(j) for j in jarvis.programas.lista_de_juegos()]
        except Exception:
            pass
        _juegos_cache["cuando"] = time.time()
    return _juegos_cache["nombres"]


def clasificar(exe, ruta, titulo):
    """(nombre lindo de la app, categoría, título limpio)."""
    t = re.sub(r"^\(\d+\)\s*", "", titulo)  # "(1327) Bee Gees - YouTube" -> sin el contador de notificaciones
    if exe in NAVEGADORES:
        t = re.sub(r"\s+[-—]\s+(?:Opera|Google Chrome|Microsoft​? Edge|Mozilla Firefox|Brave)\s*$", "", t)
    if exe in ("pythonw.exe", "python.exe") and re.search(r"J\.?A\.?R\.?V\.?I\.?S", titulo):
        return "JARVIS", "otros", t
    if exe in ("pythonw.exe", "python.exe") and re.search(r"R\.?U\.?S\.?T\.?Y", titulo):
        return "RUSTY", "estudio", t
    nombre = NOMBRES.get(exe) or (t.split(" - ")[-1].strip() if exe == "applicationframehost.exe" and t else
                                   os.path.splitext(exe)[0].capitalize())
    n = jarvis.normalizar(t)
    if JUEGO_EN_LA_RUTA.search(ruta or "") or any(j and len(j) > 3 and j in n for j in _juegos()):
        return (t or nombre), "juego", t
    for categoria, exes in POR_PROGRAMA.items():
        if exe in exes:
            return nombre, categoria, t
    if exe in NAVEGADORES:
        for patron, categoria in EN_EL_TITULO:
            if patron.search(t):
                return nombre, categoria, t
        return nombre, "navegar", t
    return nombre, "otros", t


# ---------- Anotar ----------

def _archivo(dia):
    return os.path.join(CARPETA, f"{dia}.json")


def entradas_del_dia(dia):
    """[[desde, hasta, app, título, categoría], ...] de ese día (fecha 'AAAA-MM-DD')."""
    with _lock:
        if dia == _estado["dia"]:
            return [list(e) for e in _estado["entradas"]]
    try:
        with open(_archivo(dia), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _guardar():
    if not _estado["dia"]:
        return
    os.makedirs(CARPETA, exist_ok=True)
    tmp = _archivo(_estado["dia"]) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_estado["entradas"], f, ensure_ascii=False)
    os.replace(tmp, _archivo(_estado["dia"]))
    _estado["guardado"] = time.time()


def _limpiar_viejos():
    limite = (datetime.date.today() - datetime.timedelta(days=DIAS_GUARDADOS)).isoformat()
    try:
        for a in os.listdir(CARPETA):
            if a.endswith(".json") and a[:10] < limite:
                os.remove(os.path.join(CARPETA, a))
    except OSError:
        pass


def anotar(ahora=None, ventana=None, sin_tocar=None):
    """Una mirada: suma tiempo a lo que estás usando (o empieza una entrada nueva). Devuelve la entrada actual."""
    ahora = ahora or time.time()
    dia = datetime.date.fromtimestamp(ahora).isoformat()
    ventana = ventana if ventana is not None else ventana_de_adelante()
    sin_tocar = segundos_sin_tocar() if sin_tocar is None else sin_tocar
    nueva_app = None
    with _lock:
        if dia != _estado["dia"]:  # cambió el día (o recién arranca): se guarda el anterior y se carga el nuevo
            if _estado["dia"]:
                _guardar()
            _estado["dia"] = dia
            try:
                with open(_archivo(dia), encoding="utf-8") as f:
                    _estado["entradas"] = json.load(f)
            except (OSError, ValueError):
                _estado["entradas"] = []
            _estado["actual"] = None
        if not ventana:
            return None
        exe, ruta, titulo = ventana
        if PRIVADO.search(titulo):
            _estado["actual"] = None
            return None
        app, categoria, titulo = clasificar(exe, ruta, titulo)
        if sin_tocar > AUSENTE and categoria not in ("juego", "videos"):
            _estado["actual"] = None  # no estás: no se cuenta (y lo que sigue empieza de nuevo)
            _estado["activo_desde"] = None
            return None
        _estado["activo_desde"] = _estado["activo_desde"] or ahora
        actual = _estado["actual"]
        if actual is not None and actual[2] == app and actual[3] == titulo and ahora - actual[1] <= CADA * 3:
            actual[1] = ahora
        else:
            actual = [ahora, ahora, app, titulo[:160], categoria]
            _estado["entradas"].append(actual)
            _estado["actual"] = actual
            if app != "JARVIS" and ahora - _estado["visto"].get(app, 0) > 600:
                nueva_app = (app, exe, titulo, categoria)  # la abriste (o volviste después de un rato)
            _estado["visto"][app] = ahora
        # cuánto llevás jugando seguido (para los consejos)
        juego = _estado["juego"]
        if categoria == "juego":
            if juego is None or juego["app"] != app or ahora - juego["hasta"] > 120:
                _estado["juego"] = juego = {"app": app, "desde": ahora, "hasta": ahora, "avisado": False}
            juego["hasta"] = ahora
        if time.time() - _estado["guardado"] > 60:
            _guardar()
    if nueva_app:
        for oyente in list(_oyentes):
            try:
                oyente(*nueva_app)
            except Exception:
                pass
    return actual


def al_abrir(funcion):
    """funcion(app, exe, título, categoría) se llama cada vez que abrís una app (las rutinas la usan)."""
    _oyentes.append(funcion)


def _bucle():
    _limpiar_viejos()
    while True:
        time.sleep(CADA)
        if not ACTIVO:
            continue
        try:
            anotar()
        except Exception:
            pass


_iniciado = [False]


def iniciar():
    if _iniciado[0]:
        return
    _iniciado[0] = True
    threading.Thread(target=_bucle, daemon=True).start()


def guardar_ya():
    with _lock:
        _guardar()


# ---------- Contar ----------

def _hms(segundos):
    m = int(segundos // 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h} h {m} min" if m else f"{h} h"
    return f"{m} min" if m else "menos de un minuto"


def totales(entradas):
    por_categoria, por_app = {}, {}
    for desde, hasta, app, titulo, categoria in entradas:
        dur = max(0.0, hasta - desde) + CADA
        por_categoria[categoria] = por_categoria.get(categoria, 0) + dur
        if app != "JARVIS":
            por_app[(app, categoria)] = por_app.get((app, categoria), 0) + dur
    return por_categoria, por_app


def dias_del_periodo(t):
    hoy = datetime.date.today()
    if re.search(r"\bayer\b", t):
        return [hoy - datetime.timedelta(days=1)], "Ayer"
    if re.search(r"\b(?:esta semana|la semana|ultimos (?:7|siete) dias)\b", t):
        return [hoy - datetime.timedelta(days=i) for i in range(7)], "Esta semana"
    return [hoy], "Hoy"


def resumen(t):
    dias, nombre = dias_del_periodo(t)
    entradas = [e for d in dias for e in entradas_del_dia(d.isoformat())]
    por_categoria, por_app = totales(entradas)
    total = sum(v for k, v in por_categoria.items())
    if total < 60:
        return f"{nombre} casi no registré actividad en la compu." + ("" if ACTIVO else
                                                                     " (El registro está apagado: decí «registrá lo que hago».)")
    partes = []
    for categoria, segundos in sorted(por_categoria.items(), key=lambda x: -x[1]):
        if segundos < 120 or categoria == "otros":
            continue
        apps = sorted([(a, s) for (a, c), s in por_app.items() if c == categoria], key=lambda x: -x[1])[:3]
        detalle = ", ".join(f"{a} {_hms(s)}" for a, s in apps if s >= 60)
        partes.append(f"- {_hms(segundos)} {CATEGORIAS[categoria]}" + (f" ({detalle})" if detalle else ""))
    return f"{nombre} usaste la compu {_hms(total)}:\n" + "\n".join(partes)


def tiempo_en(t):
    dias, nombre = dias_del_periodo(t)
    entradas = [e for d in dias for e in entradas_del_dia(d.isoformat())]
    por_categoria, por_app = totales(entradas)
    if re.search(r"\bjug(?:ue|ando|aste|amos|ar)\b", t) and not re.search(r"\bal |\ba la |\bel \w", t):
        categoria = "juego"
    elif re.search(r"\b(?:estudie|estudiando|trabaje|trabajando)\b", t):
        categoria = "estudio"
    elif re.search(r"\b(?:videos?|youtube|series?|peliculas?)\b", t):
        categoria = "videos"
    elif re.search(r"\b(?:chatee|chateando)\b", t):
        categoria = "charla"
    else:
        categoria = None
    if categoria:
        segundos = por_categoria.get(categoria, 0)
        apps = sorted([(a, s) for (a, c), s in por_app.items() if c == categoria], key=lambda x: -x[1])[:3]
        detalle = ", ".join(f"{a} {_hms(s)}" for a, s in apps if s >= 60)
        return f"{nombre}: {_hms(segundos)} {CATEGORIAS[categoria]}" + (f" ({detalle})." if detalle else ".")
    # "¿cuánto estuve en Opera?", "¿cuánto jugué al Red Dead?"
    m = re.search(r"\b(?:en|con|al|a la|a|el|la|usando)\s+(.+?)(?:\s+(?:hoy|ayer|esta semana))?$", t)
    pedido = (m.group(1) if m else "").strip()
    if not pedido:
        return None
    palabras = [w for w in re.findall(r"[a-z0-9]+", pedido) if len(w) > 1]
    segundos, nombres = 0, set()
    for (app, _c), s in por_app.items():
        n = jarvis.normalizar(app)
        sigla = "".join(w if w.isdigit() else w[0] for w in re.findall(r"[a-z0-9]+", n))  # "red dead redemption 2" -> "rdr2"
        if all(w in n for w in palabras) or pedido.replace(" ", "") == sigla:
            segundos += s
            nombres.add(app)
    if not nombres:
        return f"{nombre} no te vi usando «{pedido}»."
    return f"{nombre} estuviste {_hms(segundos)} en {', '.join(sorted(nombres))}."


def en_que_me_quede():
    """Lo último en lo que estabas trabajando (sin contar JARVIS ni el explorador): [(app, título, hasta)]."""
    entradas = entradas_del_dia(datetime.date.today().isoformat()) + []
    if len([e for e in entradas if e[4] in ("estudio", "crear")]) < 1:
        entradas = entradas_del_dia((datetime.date.today() - datetime.timedelta(days=1)).isoformat()) + entradas
    vistos, salida = set(), []
    for desde, hasta, app, titulo, categoria in reversed(entradas):
        if categoria not in ("estudio", "crear", "navegar") or app in ("JARVIS",) or hasta - desde < 20:
            continue
        clave = (app, titulo)
        if clave in vistos:
            continue
        vistos.add(clave)
        salida.append((app, titulo, hasta))
        if len(salida) >= 3:
            break
    return salida


def para_consejos():
    """Lo que necesitan los consejos: totales de hoy, cuánto llevás seguido y si estás jugando."""
    hoy = entradas_del_dia(datetime.date.today().isoformat())
    por_categoria, por_app = totales(hoy)
    with _lock:
        juego = dict(_estado["juego"]) if _estado["juego"] else None
        activo_desde = _estado["activo_desde"]
        actual = list(_estado["actual"]) if _estado["actual"] else None
    ahora = time.time()
    return {"hoy": por_categoria, "apps": por_app, "juego": juego,
            "jugando_ahora": bool(actual and actual[4] == "juego" and ahora - actual[1] < 30),
            "seguido": (ahora - activo_desde) if activo_desde else 0,
            "actual": actual}


def texto_para_consejos():
    d = para_consejos()
    if not d["hoy"]:
        return "Hoy todavía no registré actividad en la compu."
    partes = [f"{_hms(s)} {CATEGORIAS[c]}" for c, s in sorted(d["hoy"].items(), key=lambda x: -x[1])
              if s >= 300 and c != "otros"]
    texto = "Hoy en la compu: " + (", ".join(partes) if partes else "poco tiempo") + "."
    if d["seguido"] > 1800:
        texto += f" Lleva {_hms(d['seguido'])} seguidos frente a la compu."
    if d["actual"]:
        texto += f" Ahora está en {d['actual'][2]}" + (f" («{d['actual'][3][:60]}»)" if d["actual"][3] else "") + "."
    return texto


# ---------- Frases ----------

RESUMEN = re.compile(r"\b(?:que (?:estuve|estoy|he estado|anduve) haciendo|que hice (?:hoy|ayer|esta (?:manana|tarde|semana))|"
                     r"resumen de (?:mi|hoy|ayer)\w*(?: (?:dia|actividad))?|en que (?:gaste|use|se me fue|perdi|pase) el tiempo|"
                     r"como use la compu|mi actividad|como (?:fue|vino) mi dia en la compu)\b")
TIEMPO = re.compile(r"^(?:y\s+)?cuanto(?: tiempo)? (?:estuve|llevo|pase|use|jugue|estuve jugando|estudie|estuve estudiando|"
                    r"estuve en|vi|mire|chatee|tuve abierto)\b")
QUEDE = re.compile(r"\b(?:en que me quede|que estaba haciendo|donde (?:me )?quede|que tenia abierto|en que estaba)\b")
SEGUIR = re.compile(r"\b(?:segui|sigamos|retoma|retomemos|volve a abrir|abrime|abri)\s+(?:con\s+)?(?:lo que (?:estaba "
                    r"haciendo|tenia abierto|hice ayer)|donde (?:me )?quede|en lo que estaba)\b")
APAGAR = re.compile(r"\b(?:deja|para|pausa|no)\s+(?:de\s+)?(?:registrar|anotar|guardar|mirar|vigilar)\s+(?:lo que hago|"
                    r"mi actividad|que apps uso|las apps)\b")
PRENDER = re.compile(r"\b(?:volve a |segui |empeza a )?(?:registra|registrar|anota|anotar)\s+(?:de nuevo\s+)?(?:lo que hago|"
                     r"mi actividad|que apps uso)\b")
BORRAR = re.compile(r"\b(?:borra|borrame|elimina)\s+(?:toda\s+)?(?:mi actividad|el registro|lo que registraste)(?:\s+de (hoy|ayer))?\b")


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    if APAGAR.search(t):
        cambiar(False)
        return "Listo, dejé de registrar qué apps usás. Decime «registrá lo que hago» para volver."
    if PRENDER.search(t) and not re.search(r"\bno\b", t):
        cambiar(True)
        return "Listo, vuelvo a anotar qué apps usás (queda solo en tu compu)."
    m = BORRAR.search(t)
    if m:
        cual = m.group(1)

        def borrar():
            with _lock:
                if cual in (None, "hoy"):
                    _estado["entradas"], _estado["actual"] = [], None
                for a in os.listdir(CARPETA) if os.path.isdir(CARPETA) else []:
                    dia = datetime.date.today() - datetime.timedelta(days=1 if cual == "ayer" else 0)
                    if a.endswith(".json") and (cual is None or a.startswith(dia.isoformat())):
                        os.remove(os.path.join(CARPETA, a))
            return "Listo, borré " + (f"la actividad de {cual}." if cual else "todo el registro de actividad.")
        return jarvis.conexiones.pedir_confirmacion(
            "sistema", "Borrar actividad", "Registro de apps usadas", accion=borrar,
            pregunta=f"¿Borro {'la actividad de ' + cual if cual else 'todo lo que registré de tu actividad'}?")
    if SEGUIR.search(t):
        return seguir_donde_quede()
    if QUEDE.search(t):
        ultimos = en_que_me_quede()
        if not ultimos:
            return "No tengo registrado en qué estabas trabajando."
        lineas = [f"- {app}: «{titulo[:80]}» (hasta las {datetime.datetime.fromtimestamp(h):%H:%M})" if titulo else
                  f"- {app} (hasta las {datetime.datetime.fromtimestamp(h):%H:%M})" for app, titulo, h in ultimos]
        return "Lo último que estabas haciendo:\n" + "\n".join(lineas) + "\nDecime «seguí con lo que estaba haciendo» y lo abro."
    if TIEMPO.search(t):
        return tiempo_en(t)
    if RESUMEN.search(t):
        return resumen(t)
    return None


def seguir_donde_quede():
    ultimos = en_que_me_quede()
    if not ultimos:
        return "No tengo registrado en qué estabas trabajando."
    abiertos = []
    for app, titulo, _ in ultimos[:2]:
        archivo = re.match(r"^●?\s*([^\\/:*?\"<>|]+\.(?:docx?|xlsx?|pptx?|pdf|txt|py|odt))\b", titulo or "", re.I)
        try:
            if archivo and app != "VS Code":
                ruta = jarvis.buscar_archivo(os.path.splitext(archivo.group(1))[0])
                if ruta:
                    jarvis.abrir_archivo(ruta)
                    abiertos.append(f"«{os.path.basename(ruta)}»")
                    continue
            nombre = {"VS Code": "Visual Studio Code"}.get(app, app)
            r = jarvis.programas.abrir_por_nombre(nombre)
            if r and r.startswith("Abriendo"):
                abiertos.append(app)
        except Exception:
            pass
    if not abiertos:
        app, titulo, _ = ultimos[0]
        return f"Estabas en {app}" + (f" («{titulo[:80]}»)" if titulo else "") + ", pero no lo pude abrir solo."
    return "Listo, abrí " + " y ".join(dict.fromkeys(abiertos)) + " para que sigas donde quedaste."


def cambiar(activo):
    global ACTIVO
    ACTIVO = bool(activo)
    try:
        jarvis.ajustes.guardar({"registro_actividad": ACTIVO})
    except Exception:
        pass
