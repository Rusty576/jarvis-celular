"""Compartir la pantalla con JARVIS, como en una videollamada.

Mientras está activa, JARVIS saca una captura por segundo (solo en memoria: no se guarda nada en el disco) y, cuando
le preguntás algo de lo que estás haciendo ("¿qué es este error?", "¿dónde toco?", "¿qué hice recién?"), mira cómo
está la pantalla en ese momento. JARVIS no sale en las capturas (Windows lo excluye), así que podés tenerlo encima.
Se activa con el protocolo Pantalla o "compartí mi pantalla"; se apaga con "dejá de compartir la pantalla", la ✕
del panel, el modo juego o sola después de una hora.
"""
import base64
import collections
import io
import re
import threading
import time

jarvis = None  # main.py se anota acá al arrancar
excluir_de_capturas = None  # la interfaz pone acá una función(bool) que saca a JARVIS de las capturas de pantalla

INTERVALO = 1.0      # una captura por segundo
VIVO_CADA = 2.0      # cada cuánto se actualiza la miniatura en la ventana de JARVIS
MAX_MINUTOS = 60     # si te olvidás de apagarla, se apaga sola
CAMBIO_MINIMO = 3.0  # cuánto tiene que cambiar la pantalla para guardar ese momento (los "momentos clave")

_estado = {"activa": False, "desde": 0.0, "ultima": None, "ultima_t": 0.0, "completa": None}
_leido = {"imagen": None, "renglones": []}  # el último texto que leyó el OCR (no se vuelve a leer la misma captura)
_momentos = collections.deque(maxlen=12)  # (segundo, imagen) de los últimos cambios de la pantalla
_lock = threading.Lock()

# "¿qué hice recién?", "¿qué cambió?": además de cómo está ahora, los últimos momentos
PASADO = re.compile(r"\b(?:que hice|que hiciste|que paso|recien|hace un rato|antes|cambio|cambiaron|lo que (?:hago|hice|estoy haciendo)|"
                    r"me viste|viste (?:lo|como)|paso a paso)\b")
# palabras que señalan algo de la pantalla ("esto", "acá", "este error")
SENALA = re.compile(r"\b(?:esto|esta|este|estos|estas|eso|aca|ahi|aqui|pantalla|ves|veo|viste|aparece|aparecio|dice|error|"
                    r"ventana|pagina|boton|clic|toco|apreto|codigo|ejercicio|hago|hacer|ayuda|ayudame|donde|que es esto)\b")


def activa():
    return _estado["activa"]


def empezar():
    """Empieza a compartir. Devuelve el mensaje para el usuario."""
    if _estado["activa"]:
        return "Ya estoy viendo tu pantalla. Preguntame lo que necesites sobre lo que tenés abierto."
    if jarvis.herramientas.modo_juego.is_set():
        return "Ahora estás en modo juego: para no gastar recursos no comparto la pantalla."
    try:
        from PIL import ImageGrab

        ImageGrab.grab()  # que se pueda capturar (si no, se avisa ya)
    except Exception as e:
        return f"No pude ver tu pantalla: {e}"
    _momentos.clear()
    _estado.update(activa=True, desde=time.time(), ultima=None)
    if excluir_de_capturas:
        try:
            excluir_de_capturas(True)
        except Exception:
            pass
    threading.Thread(target=_bucle, daemon=True).start()
    jarvis.emitir("pantalla_estado", True)
    return ("Listo, estoy viendo tu pantalla en vivo (yo no salgo en lo que veo, así que podés tenerme abierto). "
            "Preguntame lo que quieras sobre lo que estás haciendo: «¿qué es este error?», «¿dónde toco?», "
            "«¿qué hice recién?». No guardo nada. Decime «dejá de compartir la pantalla» para terminar.")


def terminar(motivo=""):
    if not _estado["activa"]:
        return "No estaba viendo tu pantalla."
    _estado.update(activa=False, ultima=None, completa=None)
    _momentos.clear()
    if excluir_de_capturas:
        try:
            excluir_de_capturas(False)
        except Exception:
            pass
    jarvis.emitir("pantalla_estado", False)
    return "Listo, dejé de ver tu pantalla." + (f" ({motivo})" if motivo else "")


def _bucle():
    import numpy as np
    from PIL import ImageGrab

    ultimo_vivo, firma_anterior = 0.0, None
    while _estado["activa"]:
        inicio = time.time()
        if jarvis.herramientas.modo_juego.is_set():
            terminar("entraste en modo juego")
            jarvis.aviso("Dejé de ver tu pantalla porque entraste en modo juego.")
            return
        if inicio - _estado["desde"] > MAX_MINUTOS * 60:
            terminar("pasó una hora")
            jarvis.aviso("Dejé de ver tu pantalla: pasó una hora. Si querés, pedímelo de nuevo.")
            return
        try:
            img = ImageGrab.grab().convert("RGB")
        except Exception:
            time.sleep(INTERVALO)
            continue
        completa = img.copy()   # entera, para leer la letra chica (OCR); la IA ve la achicada
        img.thumbnail((1600, 1600))
        segundo = inicio - _estado["desde"]
        with _lock:
            _estado.update(ultima=img, ultima_t=segundo, completa=completa)
        # ¿cambió algo? (comparando una versión chiquita en gris): así quedan los momentos clave
        firma = np.asarray(img.resize((64, 36)).convert("L"), dtype=np.int16)
        if firma_anterior is None or float(np.abs(firma - firma_anterior).mean()) > CAMBIO_MINIMO:
            with _lock:
                _momentos.append((segundo, img))
            firma_anterior = firma
        if inicio - ultimo_vivo >= VIVO_CADA:
            ultimo_vivo = inicio
            jarvis.emitir("pantalla_vivo", {"imagen": _jpg(img, 480, 70, con_prefijo=True)})
        time.sleep(max(0.05, INTERVALO - (time.time() - inicio)))


def _jpg(img, lado, calidad=85, con_prefijo=False):
    copia = img.copy()
    copia.thumbnail((lado, lado))
    buf = io.BytesIO()
    copia.save(buf, "JPEG", quality=calidad)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return "data:image/jpeg;base64," + b64 if con_prefijo else b64


def ahora_b64(lado=1600):
    """Cómo está la pantalla en este momento (JPEG base64), o None si no está compartida."""
    with _lock:
        img = _estado["ultima"]
    return _jpg(img, lado) if img is not None else None


def corresponde(pregunta):
    """¿La pregunta es sobre la pantalla? Si señala algo ("esto", "este error", "acá") sí; si es de cultura general
    ("¿quién fue Artigas?") no: esas se responden como siempre (y se verifican en internet)."""
    if not _estado["activa"]:
        return False
    n = jarvis.normalizar(pregunta)
    if SENALA.search(n) or PASADO.search(n):
        return True
    return not jarvis.herramientas.conviene_verificar(pregunta)


def para_el_mensaje(pregunta_n):
    """(texto para el sistema, imágenes) para responder mirando la pantalla."""
    with _lock:
        img, momentos = _estado["ultima"], list(_momentos)
    if img is None:
        return "", []
    try:  # la captura salió negra (pasa con videos protegidos o juegos en pantalla completa): decirlo, no inventar
        negra = img.convert("L").resize((64, 36)).getextrema()[1] < 14
    except Exception:
        negra = False
    if negra:  # (antes una captura negra terminó en "veo un laboratorio virtual con gráficos de enzimas")
        return ("El usuario está compartiendo la pantalla, pero la captura de AHORA salió toda negra (suele pasar con "
                "videos protegidos o juegos en pantalla completa). Decile eso en una frase y que pruebe con la ventana "
                "sin pantalla completa. No describas nada ni inventes lo que hay."), []
    imagenes = [_jpg(img, 1600)]
    texto = ("El usuario está COMPARTIENDO SU PANTALLA en vivo. La primera imagen adjunta es cómo se ve AHORA (vos no "
             "aparecés en ella). Si la pregunta es sobre lo que está haciendo, respondé mirándola: leé los textos, "
             "errores y botones que se ven de verdad y decí dónde tocar. Si pregunta otra cosa, respondé normal sin "
             "describir la pantalla. Si algo no se lee bien, decilo: no inventes.")
    texto += texto_para_la_ia(pregunta_n)
    if PASADO.search(pregunta_n) and len(momentos) > 1:
        imagenes += jarvis.video.hojas(momentos[-8:])
        texto += (" Después vienen los últimos cambios de la pantalla, en orden (cada imagen junta 4 momentos, con "
                  "el segundo marcado en amarillo desde que empezó a compartir).")
    return texto, imagenes


# ---------- Leer el texto de la pantalla (OCR de Windows) y revisar la ortografía ----------
# La IA ve la captura achicada: la letra chica (un póster, un documento) no la lee y la inventa. Antes, pidiéndole los
# errores de ortografía de «Metodología», contestó «differencial» y «difereñcia», que no estaban en ningún lado.

ORTOGRAFIA = re.compile(r"\b(?:ortografi\w*|faltas?(?: de ortografia)?|errores? (?:ortografic\w*|de ortografia|"
                        r"de escritura|de tipeo)|mal escrit\w*|(?:revisa|corregi|corrigi)\w* (?:la ortografia|el texto|"
                        r"lo que escribi|las tildes|los acentos))\b")
# palabras de la pregunta que no son el nombre de una sección
NO_SECCION = {"errores", "error", "ortografia", "ortograficos", "ortografico", "faltas", "texto", "pantalla", "quiero",
              "cuales", "decime", "digas", "favor", "mirar", "revisa", "revisame", "corregi", "corregime", "tiene",
              "parte", "seccion", "escrito", "escritos", "palabras", "estan", "donde", "porque", "puedes", "podes",
              "ahora", "compartiendo", "estoy", "fijate", "mires", "miras", "buscame", "encontra", "dice", "dicen",
              "tildes", "acentos", "redaccion", "solamente", "mejores", "mejor"}


def _renglones(img):
    """Los renglones de texto de esa captura (con el OCR de Windows). Si es la misma de recién, no la vuelve a leer."""
    if img is None:
        return []
    if _leido["imagen"] is not img:
        _leido.update(imagen=img, renglones=jarvis.ocr.leer(img))
    return _leido["renglones"]


def _seccion_pedida(pregunta_n, renglones):
    """«los errores del texto de metodología»: (título, texto) de esa sección de la pantalla, o None."""
    for palabra in re.findall(r"[a-zñ]{5,}", pregunta_n):
        if palabra not in NO_SECCION:
            encontrada = jarvis.ocr.seccion(renglones, palabra)
            if encontrada and encontrada[1]:
                return encontrada
    return None


def texto_para_la_ia(pregunta_n):
    """El texto exacto de la pantalla (y de la sección que nombra, si nombra una), para que la IA cite y no invente."""
    with _lock:
        img = _estado["completa"]
    try:
        renglones = _renglones(img)
    except Exception:
        return ""
    if not renglones:
        return ""
    todo = jarvis.ocr.texto(renglones)
    if len(todo) > 6000:
        todo = todo[:6000] + "\n[...]"
    texto = (" Además, este es el texto que se ve en la pantalla, leído letra por letra con el lector de texto de "
             "Windows (más confiable que la imagen para la letra chica): usalo para leer y citar, y no menciones "
             f"palabras que no estén acá.\n<<<\n{todo}\n>>>")
    seccion = _seccion_pedida(pregunta_n, renglones)
    if seccion:
        texto += f"\nLa parte que nombra («{seccion[0]}»), tal cual:\n<<<\n{seccion[1]}\n>>>"
    return texto


def revisar_ortografia(texto, t):
    """«¿Qué errores de ortografía tiene el texto de metodología?»: lo lee con el OCR y lo revisa con el corrector de
    Windows. La respuesta la arma el programa (no la IA): solo errores de verdad, cada uno con la frase donde está.
    Si no comparte la pantalla, saca una captura. None si no es un pedido de ortografía de la pantalla."""
    if not ORTOGRAFIA.search(t) or not (_estado["activa"] or re.search(r"\bpantalla\b", t)):
        return None
    jarvis.emitir("detalle", "Leyendo el texto de tu pantalla...")
    with _lock:
        img = _estado["completa"]
    if img is None:
        try:
            img = jarvis.habilidades.captura()
        except Exception as e:
            return f"No pude ver tu pantalla: {e}"
    try:
        renglones = _renglones(img)
    except Exception as e:
        return f"No pude leer el texto de tu pantalla ({e})."
    if not renglones:
        return ("No pude leer texto en tu pantalla. Si es un póster o un documento chiquito, agrandalo (Ctrl y +) y "
                "preguntame de nuevo.")
    seccion = _seccion_pedida(t, renglones)
    if seccion:
        donde, a_revisar = f"«{seccion[0]}»", seccion[1]
    else:
        donde, a_revisar = "el texto que se ve en tu pantalla", jarvis.ocr.texto(renglones)
    errores = jarvis.ortografia.revisar(a_revisar)
    if errores is None:
        return "Windows no tiene el corrector en español instalado, así que no puedo revisarte la ortografía."
    if not errores:
        return f"Revisé {donde} con el corrector de Windows y no encontré errores de ortografía."
    lineas, solo_tildes = [], False
    for n, e in enumerate(errores[:15], start=1):
        if e["repetida"]:
            lineas.append(f"{n}. «{e['palabra']}» está repetida. Está en: «{e['frase']}»")
            continue
        sugerencia = e["sugerencias"][0] if e["sugerencias"] else None
        if sugerencia and jarvis.normalizar(sugerencia) == jarvis.normalizar(e["palabra"]):
            solo_tildes = True
        como = f" → «{sugerencia}»" if sugerencia else " (no sé cómo va)"
        lineas.append(f"{n}. «{e['palabra']}»{como}. Está en: «{e['frase']}»")
    respuesta = (f"En {donde} encontré {len(errores)} error{'es' if len(errores) != 1 else ''} de ortografía:\n"
                 + "\n".join(lineas))
    if len(errores) > 15:
        respuesta += f"\n(Y {len(errores) - 15} más.)"
    if solo_tildes:
        respuesta += ("\nLas tildes las leo de la pantalla: si alguna de esas ya la tiene, es que no la vi bien "
                      "(agrandá el texto y te lo reviso de nuevo).")
    return respuesta
