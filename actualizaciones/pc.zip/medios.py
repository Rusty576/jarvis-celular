"""La música o el video que suena en OTRAS apps (YouTube en Opera GX, Chrome o Edge, Spotify...), con el control de
medios de Windows: el mismo que aparece al tocar las teclas de volumen. Sin instalar nada en el navegador.

- Qué suena: título, artista, app, tapa, en qué segundo va y cuánto dura.
- Play / pausa, siguiente, anterior e ir a un momento (si la página lo permite: YouTube sí).
- El volumen de una app sola Windows no lo deja tocar desde afuera: se usa el volumen general.
La música de JARVIS (su propia ventana) no se toca acá: esa la maneja musica.py.
"""
import asyncio
import base64
import ctypes
import datetime
import threading

jarvis = None  # main.py se anota acá al arrancar

ESTADOS = {4: "reproduciendo", 5: "pausado", 3: "detenido", 2: "cambiando", 1: "abierto", 0: "cerrado"}
PROPIOS = ("msedgewebview2",)  # la ventana de música de JARVIS: esa la maneja musica.py
_loop = {"loop": None, "gestor": None}
_lock = threading.Lock()
_tapas = {}  # (app, título) -> data URL de la tapa (se lee una sola vez por tema)


def disponible():
    try:
        import winrt.windows.media.control  # noqa: F401

        return True
    except Exception:
        return False


def _hilo_loop(listo):
    ctypes.windll.combase.RoInitialize(1)  # MTA: las llamadas de Windows se hacen desde este hilo
    loop = asyncio.new_event_loop()
    _loop["loop"] = loop
    listo.set()
    loop.run_forever()


def _correr(coro, espera=6):
    """Corre una corrutina en el hilo de medios y devuelve el resultado (o tira la excepción)."""
    with _lock:
        if _loop["loop"] is None:
            listo = threading.Event()
            threading.Thread(target=_hilo_loop, args=(listo,), daemon=True).start()
            listo.wait(3)
    return asyncio.run_coroutine_threadsafe(coro, _loop["loop"]).result(espera)


async def _gestor():
    if _loop["gestor"] is None:
        from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as Gestor

        _loop["gestor"] = await Gestor.request_async()
    return _loop["gestor"]


def nombre_app(id_app):
    i = (id_app or "").lower()
    for clave, nombre in (("operagx", "Opera GX"), ("opera", "Opera"), ("chrome", "Chrome"), ("msedge", "Edge"),
                          ("microsoftedge", "Edge"), ("spotify", "Spotify"), ("firefox", "Firefox"), ("brave", "Brave"),
                          ("vlc", "VLC"), ("zunemusic", "Reproductor multimedia"), ("music", "Música")):
        if clave in i:
            return nombre
    return (id_app or "otra app").split("!")[0].split(".")[0]


async def _tapa(props, clave):
    if clave in _tapas:
        return _tapas[clave]
    url = ""
    try:
        if props.thumbnail is not None:
            from winrt.windows.storage.streams import DataReader

            flujo = await props.thumbnail.open_read_async()
            tam = min(int(flujo.size), 2_000_000)
            lector = DataReader(flujo.get_input_stream_at(0))
            await lector.load_async(tam)
            datos = bytearray(tam)
            lector.read_bytes(datos)
            tipo = "image/png" if datos[:4] == b"\x89PNG" else "image/jpeg"
            url = f"data:{tipo};base64," + base64.b64encode(bytes(datos)).decode()
    except Exception:
        url = ""
    if len(_tapas) > 30:
        _tapas.clear()
    _tapas[clave] = url
    return url


async def _sesiones(con_tapa=False):
    g = await _gestor()
    actual = g.get_current_session()
    id_actual = actual.source_app_user_model_id if actual else ""
    salida = []
    for s in g.get_sessions():
        id_app = s.source_app_user_model_id or ""
        if any(p in id_app.lower() for p in PROPIOS):
            continue
        try:
            props = await s.try_get_media_properties_async()
            info = s.get_playback_info()
            t = s.get_timeline_properties()
        except Exception:
            continue
        estado = ESTADOS.get(int(info.playback_status), "?")
        posicion = t.position.total_seconds()
        if estado == "reproduciendo" and t.last_updated_time:  # Windows da la posición de la última vez que cambió
            try:
                posicion += (datetime.datetime.now(datetime.timezone.utc) - t.last_updated_time).total_seconds()
            except Exception:
                pass
        duracion = t.end_time.total_seconds()
        c = info.controls
        d = {"sesion": s, "app": nombre_app(id_app), "id_app": id_app, "titulo": props.title or "",
             "artista": props.artist or props.album_artist or "", "estado": estado,
             "actual": max(0.0, min(posicion, duracion or posicion)), "duracion": duracion, "es_actual": id_app == id_actual,
             "puede": {"siguiente": c.is_next_enabled, "anterior": c.is_previous_enabled,
                       "ir": c.is_playback_position_enabled}}
        if con_tapa:
            d["tapa"] = await _tapa(props, (id_app, d["titulo"]))
        salida.append(d)
    return salida


def sesiones(con_tapa=False):
    """Lo que está sonando (o en pausa) en otras apps. [] si no hay nada (o Windows no responde)."""
    if not disponible():
        return []
    try:
        return _correr(_sesiones(con_tapa))
    except Exception:
        return []


def elegir(lista, app=None):
    """De qué sesión habla: la de la app que nombraste; si no, la que está sonando; si no, la que Windows tiene
    como actual."""
    if app:
        n = jarvis.normalizar(app) if jarvis else app.lower()
        # si nombraste una app que no está sonando, NO se toca otra ("pausá Spotify" con Spotify cerrado pausaba Opera)
        lista = [s for s in lista if n in jarvis.normalizar(s["app"] + " " + s["id_app"])]
    if not lista:
        return None
    return sorted(lista, key=lambda s: (s["estado"] != "reproduciendo", not s["es_actual"]))[0]


def actual(app=None, con_tapa=False):
    return elegir(sesiones(con_tapa), app)


def para_la_barra():
    """Cómo lo muestra la barrita (mismo formato que la música de JARVIS)."""
    s = actual(con_tapa=True)
    if not s:
        return None
    return {"titulo": s["titulo"] or "(sin título)", "canal": " · ".join(x for x in (s["artista"], s["app"]) if x),
            "id": "", "tapa": s.get("tapa", ""), "pausado": s["estado"] != "reproduciendo", "actual": s["actual"],
            "duracion": s["duracion"], "anuncio": False, "video": False, "externo": True, "app": s["app"],
            "puede": s["puede"], "volumen": volumen_general()}


async def _hacer(s, accion, valor):
    if accion == "pausa":
        return await s.try_pause_async()
    if accion == "play":
        return await s.try_play_async()
    if accion == "alternar":
        return await s.try_toggle_play_pause_async()
    if accion == "siguiente":
        return await s.try_skip_next_async()
    if accion == "anterior":
        return await s.try_skip_previous_async()
    if accion == "ir":
        return await s.try_change_playback_position_async(int(max(0.0, float(valor)) * 10_000_000))
    return False


def control(accion, valor=None, app=None):
    """pausa / play / alternar / siguiente / anterior / ir (segundos) / subir / bajar / volumen / cerrar.
    Devuelve lo que JARVIS contesta, o None si no hay nada sonando en otras apps."""
    s = actual(app)
    if not s:
        return None
    donde = f" en {s['app']}"
    if accion in ("subir", "bajar", "volumen"):  # Windows no deja tocar el volumen de una app desde afuera: el general
        nuevo = (volumen_general(int(valor)) if accion == "volumen" and valor is not None
                 else volumen_general(cambio=10 if accion == "subir" else -10))
        if nuevo is None:
            return jarvis.accion_volumen("subi el volumen" if accion == "subir" else "baja el volumen")
        return f"Volumen general al {nuevo}% (Windows no deja cambiar el de {s['app']} solo)."
    if accion == "cerrar":
        accion = "pausa"  # la pestaña de Opera no la puede cerrar JARVIS: la pausa
    if accion == "siguiente" and not s["puede"]["siguiente"]:
        return f"En {s['app']} no se puede pasar al siguiente desde afuera (esa página no lo permite)."
    try:
        ok = _correr(_hacer(s["sesion"], accion, valor))
    except Exception as e:
        return f"No pude manejar{donde}: {e}"
    if not ok:
        return f"{s['app']} no me dejó hacer eso."
    titulo = f"«{s['titulo']}»" if s["titulo"] else "lo que suena"
    return {"pausa": f"Listo, pausé {titulo}{donde}.", "play": f"Listo, sigue {titulo}{donde}.",
            "alternar": f"Listo{donde}.", "siguiente": f"Listo, siguiente{donde}.", "anterior": f"Listo, anterior{donde}.",
            "ir": "Listo."}.get(accion, "Listo.")


def que_suena(app=None):
    s = actual(app)
    if not s or not s["titulo"]:
        return None
    quien = f" de {s['artista']}" if s["artista"] else ""
    pausa = " (en pausa)" if s["estado"] != "reproduciendo" else ""
    return f"En {s['app']} suena «{s['titulo']}»{quien}{pausa}."


# ---------- Volumen general de Windows, directo (sin "apretar" las teclas: eso hacía aparecer el cartel de volumen
# de Windows encima del juego) ----------

def _volumen_windows():
    import comtypes
    from ctypes import HRESULT, POINTER, c_float, c_int, c_uint, c_void_p
    from ctypes.wintypes import BOOL, DWORD

    from comtypes import CLSCTX_ALL, COMMETHOD, GUID, IUnknown

    class IAudioEndpointVolume(IUnknown):
        _iid_ = GUID("{5CDF2C82-841E-4546-9722-0CF74078229A}")
        _methods_ = [
            COMMETHOD([], HRESULT, "RegisterControlChangeNotify", (["in"], c_void_p)),
            COMMETHOD([], HRESULT, "UnregisterControlChangeNotify", (["in"], c_void_p)),
            COMMETHOD([], HRESULT, "GetChannelCount", (["out"], POINTER(c_uint))),
            COMMETHOD([], HRESULT, "SetMasterVolumeLevel", (["in"], c_float), (["in"], POINTER(GUID))),
            COMMETHOD([], HRESULT, "SetMasterVolumeLevelScalar", (["in"], c_float), (["in"], POINTER(GUID))),
            COMMETHOD([], HRESULT, "GetMasterVolumeLevel", (["out"], POINTER(c_float))),
            COMMETHOD([], HRESULT, "GetMasterVolumeLevelScalar", (["out"], POINTER(c_float))),
        ]

    class IMMDevice(IUnknown):
        _iid_ = GUID("{D666063F-1587-4E43-81F1-B948E807363F}")
        _methods_ = [COMMETHOD([], HRESULT, "Activate", (["in"], POINTER(GUID)), (["in"], DWORD), (["in"], c_void_p),
                               (["out"], POINTER(POINTER(IUnknown))))]

    class IMMDeviceEnumerator(IUnknown):
        _iid_ = GUID("{A95664D2-9614-4F35-A746-DE8DB63617E6}")
        _methods_ = [
            COMMETHOD([], HRESULT, "EnumAudioEndpoints", (["in"], c_int), (["in"], DWORD), (["out"], POINTER(c_void_p))),
            COMMETHOD([], HRESULT, "GetDefaultAudioEndpoint", (["in"], c_int), (["in"], c_int),
                      (["out"], POINTER(POINTER(IMMDevice)))),
        ]

    comtypes.CoInitialize()
    enum = comtypes.CoCreateInstance(GUID("{BCDE0395-E52F-467C-8E3D-C4579291692E}"), IMMDeviceEnumerator, CLSCTX_ALL)
    disp = enum.GetDefaultAudioEndpoint(0, 1)  # la salida multimedia predeterminada
    return disp.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None).QueryInterface(IAudioEndpointVolume)


def volumen_general(porcentaje=None, cambio=0):
    """Lee o cambia el volumen general de Windows (0-100). Devuelve el valor que quedó, o None si no se pudo."""
    try:
        vol = _volumen_windows()
        actual_ = round(vol.GetMasterVolumeLevelScalar() * 100)
        nuevo = actual_ + cambio if porcentaje is None else porcentaje
        nuevo = max(0, min(100, int(nuevo)))
        if nuevo != actual_:
            vol.SetMasterVolumeLevelScalar(nuevo / 100, None)
        return nuevo
    except Exception:
        return None
