"""Música y videos de YouTube: "poné Monaco de Bad Bunny", "quiero escuchar algo de Queen", "pausá", "siguiente".

Se reproduce en una ventana de navegador de JARVIS (así se puede pausar, pasar de tema, cambiar el volumen y
saber qué está sonando) o, si lo elegís en Configuraciones, en tu navegador (ahí se controla con las teclas
multimedia de Windows). Para música abre un "mix" de YouTube: cuando termina un tema sigue con otros parecidos.

La música se maneja con la barrita flotante (barra_musica.py): la ventana del video queda minimizada (sigue sonando
igual) y en modo juego nunca aparece encima del juego.
"""
import json
import re
import threading
import time
import urllib.parse
import webbrowser

jarvis = None  # main.py se anota acá al arrancar

REPRODUCIR_EN = "jarvis"  # "jarvis" (ventana propia, con controles) o "navegador" (tu navegador)
estado = {"titulo": None, "canal": None, "url": None, "pausado": False, "volumen": 100, "modo": None}
_ventana = [None]
_lock = threading.Lock()

NO_ES_MUSICA = re.compile(r"\b(?:tutorial|como (?:hacer|se hace|armar|instalar)|receta|trailer|gameplay|noticias|"
                          r"documental|clase|explicacion|curso|review|unboxing|entrevista|podcast|partido|resumen|"
                          r"goles|capitulo|episodio|pelicula)\b")


def buscar_videos(consulta, cantidad=5):
    """Los primeros resultados de YouTube: [{id, titulo, duracion, canal}]."""
    pagina = jarvis.herramientas.descargar(
        "https://www.youtube.com/results?" + urllib.parse.urlencode({"search_query": consulta, "hl": "es"}), 10)
    m = re.search(r"var ytInitialData = (\{.*?\});</script>", pagina, re.S)
    if not m:
        return []
    videos = []

    def recorrer(x):
        if len(videos) >= cantidad:
            return
        if isinstance(x, dict):
            v = x.get("videoRenderer")
            if v and v.get("videoId") and v.get("lengthText"):  # con duración: no es un "en vivo" ni un anuncio
                videos.append({"id": v["videoId"], "titulo": "".join(r["text"] for r in v["title"]["runs"]),
                               "duracion": v["lengthText"].get("simpleText", ""),
                               "canal": (v.get("ownerText", {}).get("runs") or [{}])[0].get("text", "")})
            for y in x.values():
                recorrer(y)
        elif isinstance(x, list):
            for y in x:
                recorrer(y)
    recorrer(json.loads(m.group(1)))
    return videos


def _emitir():
    jarvis.emitir("musica", dict(estado))
    jarvis.barra_musica.actualizar()


# ---------- La ventana de JARVIS ----------

def _ventana_abierta():
    v = _ventana[0]
    try:
        import webview

        return v if v is not None and v in webview.windows else None
    except Exception:
        return None


def _js(codigo):
    v = _ventana_abierta()
    if not v:
        return None
    try:
        return v.evaluate_js(codigo)
    except Exception:
        return None


def _abrir_en_ventana(url, mostrar=True):
    """mostrar=False (música con la barrita, o en modo juego): la ventana del video queda minimizada y sin robar el
    foco, y suena igual. Probado: escondida del todo YouTube no arranca nunca; minimizada sí."""
    import webview

    v = _ventana_abierta()
    if v:
        v.load_url(url)
        if mostrar:
            try:
                v.restore()
            except Exception:
                pass
        return
    v = webview.create_window("JARVIS · Música", url=url, width=820, height=500, background_color="#000000",
                              text_select=True, minimized=not mostrar, focus=mostrar)
    v.events.closed += lambda: _al_cerrar()
    v.events.loaded += lambda: _js(SIN_ANUNCIOS_JS)  # apenas carga cada página: sin publicidades desde el primer segundo
    v.events.minimized += lambda: estado.update(video_visible=False)
    v.events.restored += lambda: estado.update(video_visible=True)
    estado["video_visible"] = mostrar
    _ventana[0] = v
    threading.Thread(target=_vigilar, daemon=True).start()


def _al_cerrar():
    _ventana[0] = None
    estado.update(titulo=None, url=None, modo=None, pausado=False)
    _emitir()
    jarvis.barra_musica.cerrar()


ESTADO_JS = """(() => { const v = document.querySelector('video');
  let t = (document.querySelector('#title h1') || {}).innerText || document.title.replace(/ - YouTube$/, '');
  if (t === 'YouTube') t = '';  // mientras cambia de tema la página se llama así un momento: se deja el anterior
  const c = (document.querySelector('#owner #channel-name a') || {}).innerText || '';
  return JSON.stringify({titulo: t, canal: c, id: new URLSearchParams(location.search).get('v') || '',
                         pausado: v ? v.paused : true, volumen: v ? Math.round(v.volume * 100) : 100,
                         actual: v ? v.currentTime : 0, duracion: v ? v.duration : 0, anuncio: !!document.querySelector('.ad-showing')}); })()"""


# "siguiente" / "anterior" con la función del propio reproductor de YouTube (el botón ".ytp-next-button" a veces ni
# existe, por ejemplo con la ventana minimizada). Durante una publicidad: si tiene "Omitir", lo toca; si no, avisa.
SALTO_JS = """(() => { const p = document.getElementById('movie_player'), metodo = '%s';
  if (document.querySelector('.ad-showing')) {
    const omitir = document.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern');
    if (omitir) { omitir.click(); return 'salteada'; }
    return 'anuncio';
  }
  const lista = p && p.getPlaylist ? (p.getPlaylist() || []) : [];
  if (location.search.includes('list=') && !lista.length) return 'cargando';  // el mix todavía no cargó: después
  // "anterior" en el primer tema de un mix (no hay anterior adentro): vuelve a lo que sonaba antes
  if (metodo === 'previousVideo' && p && p.getPlaylistIndex && p.getPlaylistIndex() <= 0) { history.back(); return 'ok'; }
  if (p && p[metodo]) { p[metodo](); return 'ok'; }
  return 'sin reproductor'; })()"""


# Sin publicidades: un vigilante adentro de la página (4 veces por segundo). Si empieza una publicidad, la silencia al
# instante y la saltea: toca "Omitir" si está; si no, la adelanta hasta el final. Al terminar vuelve el sonido.
SIN_ANUNCIOS_JS = """(() => {
  if (window.__jarvisSinAnuncios) return 'ya';
  window.__jarvisSinAnuncios = setInterval(() => {
    const p = document.getElementById('movie_player'), v = document.querySelector('video');
    if (!p || !v) return;
    if (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting')) {
      if (!v.muted) { v.muted = true; window.__jarvisSilencie = true; }
      window.__jarvisAnuncios = (window.__jarvisAnuncios || 0) + 0.25;
      const omitir = document.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, '
                                            + '.ytp-ad-skip-button-slot button');
      if (omitir) { omitir.click(); return; }
      if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.3) v.currentTime = v.duration - 0.1;
      v.playbackRate = 16;
    } else if (window.__jarvisSilencie) {
      v.muted = false; v.playbackRate = 1; window.__jarvisSilencie = false;
    }
    document.querySelectorAll('.ytp-ad-overlay-close-button, .ytp-ad-overlay-close-container button').forEach((b) => b.click());
  }, 250);
  return 'instalado';
})()"""


def _vigilar():
    """Mientras la ventana está abierta, cada 2 segundos le cuenta a la interfaz qué está sonando."""
    arranque = time.time()
    while _ventana_abierta():
        time.sleep(2)
        _js(SIN_ANUNCIOS_JS)  # (si YouTube recargó la página, se vuelve a poner)
        try:
            datos = json.loads(_js(ESTADO_JS) or "{}")
        except ValueError:
            continue
        if not datos:
            continue
        # al cargar un tema nuevo, si el navegador no lo arrancó solo, le da play
        if datos.get("pausado") and not estado.get("pausado_a_mano") and time.time() - estado.get("desde", 0) < 12:
            _js("document.querySelector('video') && document.querySelector('video').play()")
        if time.time() - estado.get("desde", 0) < 15:
            # la ventana es para escuchar: video en calidad media (decodificar HD en la placa integrada le competía
            # al audio y la música se entrecortaba)
            _js("(() => { const p = document.getElementById('movie_player'); "
                "if (p && p.setPlaybackQualityRange) p.setPlaybackQualityRange('medium', 'medium'); })()")
        cambio = (datos.get("titulo"), datos.get("pausado"), datos.get("volumen")) != \
                 (estado.get("titulo"), estado.get("pausado"), estado.get("volumen"))
        estado.update({k: datos[k] for k in ("titulo", "canal", "pausado", "volumen", "id") if datos.get(k) not in (None, "")})
        estado.update(actual=datos.get("actual", 0), duracion=datos.get("duracion") or 0, anuncio=datos.get("anuncio"))
        if estado.get("pendiente"):  # un "siguiente" que llegó en una publicidad (o con el mix cargando): cada 2 s
            # prueba de nuevo ("Omitir" se habilita a los pocos segundos de la publicidad)
            metodo = "nextVideo" if estado["pendiente"] == "siguiente" else "previousVideo"
            if _js(SALTO_JS % metodo) == "ok" or time.time() - estado.get("pendiente_desde", 0) > 60:
                estado.pop("pendiente", None)
                estado["desde"] = time.time()
        if cambio or time.time() - arranque < 10:
            _emitir()
        else:
            jarvis.barra_musica.actualizar()  # la línea de tiempo de la barrita avanza


# ---------- Lo que se puede pedir ----------

def momento_mas_repetido(video_id):
    """El segundo donde arranca la parte más repetida del video (la curva "lo más repetido" de YouTube: en una
    canción, casi siempre el estribillo). None si YouTube no tiene esos datos para ese video."""
    try:
        import yt_dlp

        with yt_dlp.YoutubeDL({"quiet": True, "skip_download": True, "no_warnings": True, "socket_timeout": 8}) as y:
            info = y.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=False, process=False)
    except Exception:
        return None
    puntos = sorted(info.get("heatmap") or [], key=lambda p: p["start_time"])
    if len(puntos) < 10:
        return None
    # el arranque del video siempre sale "muy repetido" (todos empiezan ahí): el pico se busca después del 8% inicial
    duracion = puntos[-1].get("end_time") or puntos[-1]["start_time"]
    candidatos = [i for i in range(len(puntos)) if puntos[i]["start_time"] > max(10, duracion * 0.08)]
    if not candidatos:
        return None
    pico = max(candidatos, key=lambda i: puntos[i]["value"])
    # desde dónde empieza esa parte (hacia atrás mientras siga siendo de lo más repetido), para no caer a la mitad
    inicio = pico
    while inicio > 0 and puntos[inicio - 1]["value"] >= 0.85 * puntos[pico]["value"]:
        inicio -= 1
    segundo = puntos[inicio]["start_time"]
    return int(segundo) if segundo > 5 else None


def reproducir(consulta, buscar_solo=False, desde_lo_mejor=False):
    consulta = consulta.strip(" .¿?¡!")
    if not consulta:
        return "¿Qué querés que ponga? Por ejemplo: «poné Monaco de Bad Bunny»."
    if buscar_solo:  # "buscá en YouTube X": la lista de resultados para que elijas
        url = "https://www.youtube.com/results?" + urllib.parse.urlencode({"search_query": consulta})
        _abrir(url, f"Resultados de «{consulta}»")
        return f"Te abrí los resultados de «{consulta}» en YouTube."
    jarvis.emitir("detalle", f"Buscando «{consulta}» en YouTube...")
    try:
        videos = buscar_videos(consulta)
    except Exception as e:
        return f"No pude buscar en YouTube: {e}"
    if not videos:
        return f"No encontré «{consulta}» en YouTube."
    v = videos[0]
    es_musica = not NO_ES_MUSICA.search(jarvis.normalizar(consulta))
    estado["id"] = v["id"]
    # un "mix": cuando termina el tema sigue con otros parecidos (y "siguiente" funciona)
    url = f"https://www.youtube.com/watch?v={v['id']}" + (f"&list=RD{v['id']}" if es_musica else "")
    desde = momento_mas_repetido(v["id"]) if desde_lo_mejor else None
    if desde:
        url += f"&t={desde}s"  # arranca en la parte más reconocida (el estribillo)
    # música: se escucha con la barrita (el video queda minimizado); un tutorial o una película, se muestran
    _abrir(url, v["titulo"], v["canal"], mostrar=not es_musica or not jarvis.barra_musica.ACTIVA)
    return (f"Poniendo {v['titulo']}" + (f" desde la mejor parte ({desde // 60}:{desde % 60:02d})" if desde else "")
            + (f" ({v['duracion']})" if v["duracion"] and not desde else "") + ".")


def _abrir(url, titulo, canal="", mostrar=True):
    if jarvis.herramientas.modo_juego.is_set():
        mostrar = False  # jugando: nada aparece encima del juego (se maneja con la barrita o los atajos)
    with _lock:
        estado.update(titulo=titulo, canal=canal, url=url, pausado=False, pausado_a_mano=False, desde=time.time(),
                      actual=0, duracion=0)
        estado.pop("pendiente", None)
        en_ventana = REPRODUCIR_EN == "jarvis" and bool(jarvis.oyentes)
        if en_ventana:
            try:
                _abrir_en_ventana(url, mostrar)
                estado["modo"] = "jarvis"
            except Exception:
                en_ventana = False
        if not en_ventana:
            webbrowser.open(url)
            estado["modo"] = "navegador"
    if estado["modo"] == "jarvis":
        jarvis.barra_musica.mostrar()
    _emitir()


def control(accion, valor=None):
    """pausa / play / alternar / siguiente / anterior / volumen (0-100) / subir / bajar / cerrar."""
    if not estado.get("modo"):
        return "No hay nada sonando. Pedime algo: «poné...»."
    if estado["modo"] == "navegador":  # en tu navegador: el control de medios de Windows; si no, teclas multimedia
        r = jarvis.medios.control(accion, valor) if accion != "cerrar" else None
        if r is not None:
            return r
        h = jarvis.herramientas
        teclas = {"pausa": h.VK_PLAY, "play": h.VK_PLAY, "alternar": h.VK_PLAY, "siguiente": h.VK_SIGUIENTE,
                  "anterior": h.VK_ANTERIOR}
        if accion in teclas:
            jarvis.tecla(teclas[accion])
            estado["pausado"] = (not estado["pausado"]) if accion in ("pausa", "play", "alternar") else False
            _emitir()
            return "Listo."
        if accion in ("subir", "bajar", "volumen"):
            return jarvis.accion_volumen("subi el volumen" if accion == "subir" else "baja el volumen")
        if accion == "cerrar":
            jarvis.tecla(h.VK_PLAY)
            estado.update(titulo=None, modo=None)
            _emitir()
            return "Listo, pausé la música del navegador."
        return None
    if accion == "cerrar":
        v = _ventana_abierta()
        if v:
            v.destroy()
        _al_cerrar()
        return "Listo, cerré la música."
    if accion in ("pausa", "play", "alternar"):
        if accion == "alternar":
            accion = "play" if estado.get("pausado") else "pausa"
        _js(f"document.querySelector('video') && document.querySelector('video').{'pause' if accion == 'pausa' else 'play'}()")
        estado.update(pausado=accion == "pausa", pausado_a_mano=accion == "pausa")
        _emitir()
        return "Listo, en pausa." if accion == "pausa" else "Listo, sigue sonando."
    if accion in ("siguiente", "anterior"):
        metodo = "nextVideo" if accion == "siguiente" else "previousVideo"
        r = _js(SALTO_JS % metodo)
        estado["desde"] = time.time()
        if r in ("anuncio", "salteada", "cargando"):  # en una publicidad (o con el mix cargando) YouTube lo ignora:
            estado.update(pendiente=accion, pendiente_desde=time.time())  # se hace apenas se pueda
            if r == "cargando":
                return "Listo, siguiente." if accion == "siguiente" else "Listo, anterior."
            return ("Salteé la publicidad y " if r == "salteada" else "Hay una publicidad de YouTube: ") + \
                f"{'paso al siguiente' if accion == 'siguiente' else 'vuelvo al anterior'} apenas termine."
        return "Listo, siguiente." if accion == "siguiente" else "Listo, anterior."
    if accion == "ir" and valor is not None:  # la barrita: tocar la línea de tiempo
        _js(f"document.querySelector('video') && (document.querySelector('video').currentTime = {max(0.0, float(valor))})")
        estado["actual"] = max(0.0, float(valor))
        jarvis.barra_musica.actualizar()
        return "Listo."
    if accion == "video":  # mostrar / minimizar la ventana del video
        v = _ventana_abierta()
        if not v:
            return None
        if estado.get("video_visible") and not jarvis.herramientas.modo_juego.is_set():
            v.minimize()
            estado["video_visible"] = False
            return "Listo, minimicé el video (la música sigue)."
        v.restore()
        estado["video_visible"] = True
        return "Ahí está el video."
    if accion in ("subir", "bajar", "volumen"):
        actual = estado.get("volumen") or 100
        nuevo = valor if accion == "volumen" and valor is not None else actual + (15 if accion == "subir" else -15)
        nuevo = max(0, min(100, int(nuevo)))
        _js(f"document.querySelector('video') && (document.querySelector('video').volume = {nuevo / 100})")
        estado["volumen"] = nuevo
        _emitir()
        return f"Volumen de la música al {nuevo}%."
    return None


def que_suena():
    if not estado.get("modo") or not estado.get("titulo"):
        return "No está sonando nada."
    return f"Está sonando {estado['titulo']}" + (f", de {estado['canal']}" if estado.get("canal") else "") + "."


def _manejar_otra_app(t, app, nombra_otra):
    """Órdenes de música para otra app. None si no era eso o no suena nada afuera (sigue la ruta de siempre)."""
    if not jarvis.medios.disponible():
        return None
    if QUE_SUENA.search(t) or (nombra_otra and re.search(r"\bque (?:suena|esta sonando)\b", t)):
        return jarvis.medios.que_suena(app)
    if re.search(r"\b(?:mostra|abri|pone)\w*\s+(?:la )?barrita\b", t):
        return ("Ahí está, en la píldora." if jarvis.barra_musica.mostrar_externo() is not False
                else "No suena nada para mostrar.")
    m = re.search(r"\bvolumen de la musica (?:al|a) (\d{1,3})\b", t)
    if m:
        return jarvis.medios.control("volumen", int(m.group(1)), app=app)
    for patron, accion in CONTROLES:
        if patron.search(t):
            return jarvis.medios.control(accion, app=app)
    m = CONTROL_CON_APP.match(t) if nombra_otra else None  # "pausá opera", "siguiente en spotify"
    if m:
        accion = ["pausa", "play", "siguiente", "anterior", "que"][next(i for i, g in enumerate(m.groups()) if g)]
        return jarvis.medios.que_suena(app) if accion == "que" else jarvis.medios.control(accion, app=app)
    return None


# ---------- Frases ----------
VERBO_PONER = (r"(?:pone(?:me)?|ponga|pon|poneme|reproduci(?:me)?|reproduce|toca(?:me)?|"
               r"quiero (?:escuchar|oir)|(?:tengo ganas de|me gustaria) escuchar|escuchemos|quiero ver (?:el |un |la )?"
               r"(?:video|trailer|clip)|me (?:pones|pondrias)|podes poner|podrias poner|dale play a|"
               r"pone(?:me)? en youtube|busca y pone)")
PONER = re.compile(rf"^(?:(?:che|jarvis|dale|bueno)[\s,]+)?{VERBO_PONER}\s+(?:en youtube\s+)?(.+?)(?:\s+en youtube)?$")
BUSCAR_YT = re.compile(r"^(?:busca(?:me)?|buscar|mostra(?:me)?)\s+(?:en youtube\s+(.+)|(.+?)\s+en youtube)$")
NO_ES_PONER = re.compile(r"^(?:una? |el |la |los |las |mas |menos )?(?:alarma|recordatorio|temporizador|modo|pausa|play|"
                         r"volumen|brillo|camara|gestos|musica$|mensaje|a prueba|en (?:pausa|silencio)|imagen|foto|dibujo|"
                         r"documento|excel|planilla|presentacion|quiz|examen|archivo|nota|contacto|whatsapp|mail|correo|"
                         r"fondo|captura|cita|tarea|evento|agenda|recordatorios|alarmas|atencion|ganas|pila|las pilas)\b")
CONTROLES = [
    (re.compile(r"^(?:pausa(?:la|lo)?|pone pausa|para(?:la)?|frena(?:la)?|deten(?:e|ela)?|stop)(?:\s+(?:la |el )?(?:musica|cancion|tema|video|youtube))?$|"
                r"^(?:pausa|para|frena|corta)\s+(?:la |el )?(?:musica|cancion|tema|video)$"), "pausa"),
    (re.compile(r"^(?:segui|seguila|reanuda(?:la)?|continua|dale play|play|despausa(?:la)?|volve a ponerla)"
                r"(?:\s+(?:la |el )?(?:musica|cancion|tema|video))?$"), "play"),
    (re.compile(r"^(?:siguiente|la siguiente|proxima|la proxima|pasa(?:la)?|salta(?:la)?|saltea(?:la)?|cambia(?:la)?|"
                r"next)(?:\s+(?:cancion|tema|video))?$|\b(?:siguiente|proxima|otra)\s+(?:cancion|tema)\b|"
                r"\b(?:pasa|salta|saltea|cambia)\s+(?:de |la |el )?(?:cancion|tema)\b"), "siguiente"),
    (re.compile(r"^(?:anterior|la anterior)$|\b(?:cancion|tema|video) anterior\b|\bvolve (?:a )?(?:la|el) (?:cancion|tema) anterior\b"), "anterior"),
    (re.compile(r"\b(?:subi|subile|subir|mas) (?:el )?(?:volumen )?(?:de |a )?(?:la )?(?:musica|cancion|tema|youtube)\b|"
                r"\b(?:musica|cancion) mas fuerte\b"), "subir"),
    (re.compile(r"\b(?:baja|bajale|bajar|menos) (?:el )?(?:volumen )?(?:de |a )?(?:la )?(?:musica|cancion|tema|youtube)\b|"
                r"\b(?:musica|cancion) mas (?:bajo|despacio)\b"), "bajar"),
    (re.compile(r"^(?:cerra|cerrame|quita|saca|apaga|termina|para del todo)\s+(?:la |el )?(?:musica|reproductor|youtube|video)$|"
                r"^(?:basta de musica|chau musica)$"), "cerrar"),
]
QUE_SUENA = re.compile(r"\b(?:que (?:esta sonando|suena|cancion es esta|tema es este|tema es|cancion es)|"
                       r"como se llama (?:esta|este|la) (?:cancion|tema))\b")


# "pausá Opera", "siguiente en Spotify", "qué suena en el navegador": la música de otra app (medios.py)
OTRA_APP = re.compile(r"\b(opera(?: gx)?|spotify|chrome|edge|firefox|brave|(?:el )?navegador)\b")
CONTROL_CON_APP = re.compile(r"^(?:(pausa\w*|para\w*|frena\w*|stop)|(segui\w*|reanuda\w*|play|dale play|continua\w*)|"
                             r"(siguiente|pasa(?:la)?|salta(?:la)?|proxima)|(anterior|volve)|(que (?:suena|esta sonando)))\b")


# "abrí el reproductor de música", "mostrame el panel de música", "activá la barrita", "tu reproductor de música",
# y como se escribe de verdad: "buenaaaa me podes activar el panel?", "ok abre el panel", "me habres el panel de
# muica?", "abrelo al panel de musica" (antes no se entendían y la IA preguntaba "¿el panel de control?").
# La barrita aparece siempre que la pidas (con o sin modo juego, suene algo o no)
_RELLENO = r"(?:che|jarvis|dale|bueno\w*|buena\w*|ok\w*|listo|porfa\w*|por favor|hola|ey|eh|y|ya|pero|me|te)"
_PANEL = r"(reprod\w*|panel\w*|barrita|barra|controles?)"
MOSTRAR_PANEL = re.compile(
    rf"^(?:{_RELLENO}[\s,]+)*(?:(?:me |te )?(?:podes|podrias|puedes|podras)\s+)?(?:me\s+)?(?:(\w+)\s+)?"
    rf"(?:el |la |los |tu |mi |al |a la )?{_PANEL}(?:\s+de\s+(?:la\s+)?(\w+(?:\s+de\s+(?:la\s+)?\w+)?))?"
    rf"(?:\s+(?:porfi|porfa|por favor|ya|ahora|pls|please))?$")
VERBO_MOSTRAR = re.compile(r"^(?:h?abr|mostr|muestr|activ|prend|encend|pon|trae|ver|dam|dame|necesit|quier|despleg)")
# "precisó que controles la música que estoy poniendo": lo que quiere es el panel para manejarla
CONTROLAR_MUSICA = re.compile(r"\b(?:controles|controla|controlame|manejes|maneja|manejame)\s+(?:la |mi |esta )?musica\b")
ESCONDER_PANEL = re.compile(rf"^(?:{_RELLENO}[\s,]+)*(?:esconde|escondeme|escondelo|oculta|ocultame|ocultalo|saca|sacame|"
                            r"cerra|cerralo|quita)\s+(?:el |la |los |tu )?"
                            r"(?:panel|barrita|barra|controles?)(?:\s+de\s+control)?(?:\s+de\s+(?:la\s+)?musica)?$")
# después de "¿qué panel?": "al de música", "el de musica", "muica"
SOLO_MUSICA = re.compile(r"^(?:al|el|la|a la|en el|ese|el de|al de)?\s*(?:de\s+)?(?:la\s+)?(\w+)$")
# "no lo veo" justo después de mostrarlo: se esconde solo a los segundos, o quedó en un lugar donde no mirabas
NO_LO_VEO = re.compile(rf"^(?:{_RELLENO}[\s,]+)*(?:no (?:lo |la |me )?(?:veo|encuentro|aparece|sale|se ve)|no veo nada|"
                       r"donde (?:esta|lo pusiste|la pusiste|aparece|lo veo)|no esta|no aparece nada)\b")
_panel = {"mostrado": 0.0}


def _es_musica(palabra):
    """"música" aunque esté mal escrita ("muica", "musiac", "msica")."""
    import difflib

    return any(difflib.SequenceMatcher(None, p, "musica").ratio() >= 0.8 for p in palabra.split())


def _jarvis_pregunto_por_el_panel():
    try:
        with jarvis.lock:
            ultima = next((m["content"] for m in reversed(jarvis.historial) if m["role"] == "assistant"), "")
    except Exception:
        return False
    return bool(re.search(r"\bpanel\b|\breproductor\b", jarvis.normalizar(ultima)))


def pide_el_panel(t):
    """¿Pide ver el panel de música? (la frase ya normalizada)."""
    m = MOSTRAR_PANEL.match(t)
    if m:
        verbo, que, de_que = m.group(1), m.group(2), m.group(3)
        if verbo and not VERBO_MOSTRAR.match(verbo):
            return False   # "odio el panel"
        if de_que:
            return _es_musica(de_que)   # "el panel de control" es el de Windows, no este
        return que.startswith(("reprod", "barrita")) or bool(verbo)   # "el panel" a secas: si pide que lo muestre
    m = SOLO_MUSICA.match(t)
    if m and _es_musica(m.group(1)) and _jarvis_pregunto_por_el_panel():
        return True
    return bool(CONTROLAR_MUSICA.search(t))


def manejar_panel(t):
    """None si no habla del panel de música."""
    if ESCONDER_PANEL.match(t):
        jarvis.barra_musica.esconder()
        return "Listo, escondí el panel de música. Pedímelo cuando quieras («abrí el reproductor de música»)."
    if NO_LO_VEO.match(t) and time.time() - _panel["mostrado"] < 180:
        _panel["mostrado"] = time.time()
        if jarvis.barra_musica.traer_a_la_vista() is None:
            return "Para mostrarte el panel de música tengo que tener mi ventana abierta."
        if jarvis.barra_musica.PILDORA:
            return ("Está en la píldora, arriba de la pantalla: te la dejo a la vista un rato. Jugando se esconde y se "
                    "asoma sola con cada tema nuevo; con Ctrl+Alt+M la ves cuando quieras.")
        return ("Te la traje arriba al centro de la pantalla: es la barrita azul. Se esconde sola a los segundos para "
                "no molestarte; vuelve al pasar el mouse por ahí o con Ctrl+Alt+M. Arrastrala a donde quieras.")
    if not pide_el_panel(t):
        return None
    que = jarvis.barra_musica.mostrar_a_pedido()
    if que is None:
        return "Para mostrarte el panel de música tengo que tener mi ventana abierta."
    _panel["mostrado"] = time.time()
    if jarvis.barra_musica.PILDORA:   # (la barrita vieja ya no: la música está en la píldora)
        donde = (" Está en la píldora, arriba de la pantalla. Jugando no estorba: se esconde y se asoma unos segundos "
                 "con cada tema nuevo o con los atajos (Ctrl+Alt+Espacio pausa, Ctrl+Alt+. siguiente, Ctrl+Alt+M la "
                 "muestra).")
    else:
        donde = jarvis.barra_musica.donde_esta()
        donde = f" Está {donde}, donde la dejaste; se esconde sola a los segundos y vuelve al pasar el mouse por ahí." \
            if donde else ""
    if que == "jarvis":
        return "Ahí tenés el panel de música con lo que estoy poniendo." + donde
    if que == "externo":
        return "Ahí tenés el panel de música: maneja lo que está sonando en tu compu." + donde
    return "Te abrí el panel de música. Ahora no suena nada: decime «poné...» y lo manejás desde ahí." + donde


def manejar(texto, t):
    t = t.strip(" ¿?¡!.,")
    respuesta = manejar_panel(t)
    if respuesta is not None:
        return respuesta
    app = OTRA_APP.search(t)
    app = app.group(1).replace("el ", "") if app else None
    if app in ("navegador",):
        app = None  # "el navegador": cualquiera (Opera, Chrome...)
    nombra_otra = bool(OTRA_APP.search(t))
    if QUE_SUENA.search(t) and estado.get("modo") and not nombra_otra:
        return que_suena()
    if estado.get("modo") and not nombra_otra:  # hay algo sonando: "pausá", "siguiente", "subí la música"...
        m = re.search(r"\bvolumen de la musica (?:al|a) (\d{1,3})\b", t)
        if m:
            return control("volumen", int(m.group(1)))
        for patron, accion in CONTROLES:
            if patron.search(t):
                return control(accion)
    # sin música de JARVIS (o nombraste la app): lo que suena en Opera, Spotify, Chrome... (control de medios de Windows)
    respuesta = _manejar_otra_app(t, app, nombra_otra)
    if respuesta is not None:
        return respuesta
    m = BUSCAR_YT.match(t)
    if m:
        consulta = m.group(1) or m.group(2)
        return reproducir(jarvis.parte_original(texto, t.find(consulta)) or consulta, buscar_solo=True)
    m = PONER.match(t)
    if m and not NO_ES_PONER.match(m.group(1)):
        consulta = jarvis.parte_original(texto, m.start(1)) or m.group(1)
        consulta = re.sub(r"(?i)\s+en youtube$", "", consulta)
        consulta = re.sub(r"(?i)^a\s+(?=[A-ZÁÉÍÓÚÑ]|los |las )", "", consulta)  # "escuchar a Soda Stereo"
        # "algo de Queen", "música de Queen", "un tema de Queen" -> "Queen"
        consulta = re.sub(r"(?i)^(?:algo|musica|música|un tema|una cancion|una canción|temas|canciones|unos temas)\s+(?:de|del)\s+", "", consulta)
        if re.fullmatch(r"(?:algo de )?(?:musica|un tema|una cancion|algo|temas|unos temas)(?: (?:linda|buena|para escuchar))?",
                        jarvis.normalizar(consulta)):
            if estado.get("modo"):
                return control("play")
            return None  # "poné música" a secas: lo resuelve el control de la PC (retoma lo último que sonaba)
        # "poné X desde el estribillo / desde la mejor parte": arranca en lo más repetido del video
        lo_mejor = re.search(r"(?i)\s+(?:desde|en)\s+(?:el estribillo|el coro|la mejor parte|lo mejor|el drop|"
                             r"la parte (?:mas )?(?:conocida|famosa|reconocida))$", jarvis.normalizar(consulta))
        if lo_mejor:
            consulta = consulta[:lo_mejor.start()] if len(consulta) == len(jarvis.normalizar(consulta)) else \
                jarvis.normalizar(consulta)[:lo_mejor.start()]
        return reproducir(consulta, desde_lo_mejor=bool(lo_mejor))
    return None
