"""Crear con IA, gratis: sacar el fondo de fotos y videos, modelos 3D y videos generados.

  Sacar el fondo   «sacale el fondo» (a la foto o el video que me pasaste): rembg, en la compu y SIN internet (la
                   primera vez baja su modelo, unos 170 MB). Fotos: PNG transparente. Videos: cuadro por cuadro (tarda),
                   con fondo verde liso para poder editarlo, y un PNG transparente del primer cuadro.
  Modelos 3D       «haceme un modelo 3D de un dragón» o «pasá esta foto a 3D»: Hunyuan3D-2 de Tencent, en un Space de
                   Hugging Face (gratis). De un texto, primero hago la imagen del objeto y después la paso a 3D. Queda un
                   .glb (se abre con el Visor 3D de Windows, Blender, o se sube a cualquier lado).
  Videos con IA    «haceme un video con IA de un zorro corriendo en la nieve» o «animá esta foto»: LTX-Video de Lightricks
                   (Space de Hugging Face, gratis). Clips cortos, de unos segundos.

Los Spaces de Hugging Face dan unos minutos de placa de video por día gratis. Con una cuenta gratis (sin tarjeta) dan
más: «configurar Hugging Face» guarda la clave (huggingface.co/settings/tokens, de solo lectura). Lo hecho queda en
documentos/Creado con IA."""
import os
import re
import shutil
import time

jarvis = None  # main.py se anota acá al arrancar

BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(BASE, "documentos", "Creado con IA")
ESPACIO_3D = "tencent/Hunyuan3D-2"
ESPACIO_VIDEO = "Lightricks/ltx-video-distilled"

FONDO = re.compile(r"\b(?:saca|quita|borra|elimina|remove|recorta)\w*\s+(?:el |los |todo el )?fondos?\b|\bsin fondo\b|"
                   r"\bfondo transparente\b|\bfondo (?:verde|blanco) (?:atras|detras)\b")
TRES_D = re.compile(r"\b3 ?d\b|\btridimensional\b")
HACER = re.compile(r"\b(?:hace|haceme|hacer|crea|creame|crear|genera|generame|generar|arma|armame|converti|convertir|"
                   r"pasa|pasala|pasalo|pasame|modela|modelame|quiero|dame|transforma)\w*\b")
VIDEO_IA = re.compile(r"\b(?:video|videito|clip|animacion)s?\s+(?:con|por|de|hecho con|generado con)\s+(?:la\s+)?"
                      r"(?:ia|inteligencia artificial)\b|\bvideo ia\b|\banima\w*\s+(?:esta|la|esa|mi|una)\s+(?:foto|imagen)\b|"
                      r"\bdale vida\b|\bque se mueva\b|\bhace(?:la|lo)? mover\b")
SOBRE = re.compile(r"\b(?:de|del|sobre|con)\s+(.+)$")
CONFIGURAR = re.compile(r"^(?:configura\w*|pone\w*|agrega\w*|guarda\w*)\s+(?:la\s+)?(?:clave\s+de\s+)?hugging ?face\b")


def clave_hf():
    try:
        import keyring

        return keyring.get_password("JARVIS-HuggingFace", "clave")
    except Exception:
        return None


def _destino(nombre, ext):
    os.makedirs(CARPETA, exist_ok=True)
    limpio = re.sub(r"[^\w\- ]", "", nombre).strip()[:40] or "creacion"
    return os.path.join(CARPETA, f"{time.strftime('%Y-%m-%d %H-%M')} {limpio}{ext}")


def _abrir(ruta):
    jarvis.recordar_archivo(ruta)
    jarvis.emitir("archivo", ruta)
    if not jarvis.herramientas.modo_juego.is_set() and not jarvis.oyentes:
        try:
            os.startfile(ruta)
        except OSError:
            pass


def _cliente(espacio):
    from gradio_client import Client

    return Client(espacio, token=clave_hf() or None, verbose=False)


def _explicar(e):
    texto = str(e)
    if "quota" in texto.lower():
        return ("se gastó el ratito gratis de placa de video que da Hugging Face por hoy" +
                ("" if clave_hf() else ": con una cuenta gratis de Hugging Face te dan más (decí «configurar Hugging "
                 "Face»)") + ". Probá de nuevo mañana")
    return "el servicio gratis no contestó (" + texto[:120] + ")"


# ---------- Sacar el fondo (en la compu, sin internet) ----------

_sesion = {"rembg": None}


def _rembg():
    if _sesion["rembg"] is None:
        from rembg import new_session

        _sesion["rembg"] = new_session("u2net")
    return _sesion["rembg"]


def quitar_fondo_foto(ruta):
    from PIL import Image
    from rembg import remove

    jarvis.emitir("progreso", "Le estoy sacando el fondo a la foto (en la compu, sin internet)...")
    with Image.open(ruta) as img:
        recortada = remove(img.convert("RGBA"), session=_rembg())
    destino = _destino(os.path.splitext(os.path.basename(ruta))[0] + " sin fondo", ".png")
    recortada.save(destino)
    _abrir(destino)
    return "Listo, le saqué el fondo: queda transparente (PNG). Lo guardé en documentos › Creado con IA."


def quitar_fondo_video(ruta, maximo=900):
    """Cuadro por cuadro (hasta 900 cuadros: unos 30 segundos). Queda con fondo verde liso, para editarlo."""
    import av
    import numpy as np
    from PIL import Image
    from rembg import remove

    jarvis.emitir("progreso", "Le estoy sacando el fondo al video, cuadro por cuadro (tarda un rato)...")
    destino = _destino(os.path.splitext(os.path.basename(ruta))[0] + " sin fondo", ".mp4")
    entrada = av.open(ruta)
    flujo = entrada.streams.video[0]
    salida = av.open(destino, "w")
    tasa = flujo.average_rate or 30
    nuevo = salida.add_stream("libx264", rate=tasa)
    nuevo.width, nuevo.height, nuevo.pix_fmt = flujo.width - flujo.width % 2, flujo.height - flujo.height % 2, "yuv420p"
    verde = None
    hechos = 0
    primero = None
    for cuadro in entrada.decode(flujo):
        if hechos >= maximo:
            break
        img = remove(cuadro.to_image().convert("RGBA"), session=_rembg())
        if primero is None:
            primero = img
        if verde is None or verde.size != img.size:
            verde = Image.new("RGBA", img.size, (0, 255, 0, 255))
        plano = Image.alpha_composite(verde, img).convert("RGB").crop((0, 0, nuevo.width, nuevo.height))
        for paquete in nuevo.encode(av.VideoFrame.from_ndarray(np.asarray(plano), format="rgb24")):
            salida.mux(paquete)
        hechos += 1
        if hechos % 30 == 0:
            jarvis.emitir("progreso", f"Sacando el fondo: {hechos} cuadros...")
    for paquete in nuevo.encode():
        salida.mux(paquete)
    salida.close()
    entrada.close()
    if primero is not None:
        primero.save(destino.replace(".mp4", " (primer cuadro).png"))
    _abrir(destino)
    corto = " (hice los primeros 30 segundos)" if hechos >= maximo else ""
    return (f"Listo, le saqué el fondo al video{corto}: quedó con fondo verde liso, así lo ponés sobre lo que quieras en "
            "cualquier editor (CapCut, Premiere: «clave de croma»). Está en documentos › Creado con IA.")


# ---------- Modelos 3D (Hunyuan3D-2, gratis en Hugging Face) ----------

def modelo_3d(descripcion=None, imagen=None):
    from gradio_client import handle_file

    if not imagen:   # de un texto: primero la imagen del objeto, sola y con fondo blanco
        jarvis.emitir("progreso", "Primero dibujo el objeto, después lo paso a 3D...")
        tarea = jarvis.Tarea("imagen", "para el 3D: " + descripcion)
        try:
            imagen, _origen = jarvis._generar_imagen(descripcion + ", a single object, full view, centered, plain white "
                                                     "background, soft studio light, 3D render", tarea)
            tarea.terminar(imagen)
        except Exception as e:
            tarea.fallar("Error")
            return f"No pude dibujar el objeto para el 3D: {e}"
    jarvis.emitir("progreso", "Pasándolo a 3D con Hunyuan3D (un minuto más o menos)...")
    try:
        r = _cliente(ESPACIO_3D).predict(caption=None, image=handle_file(imagen), steps=30, octree_resolution=256,
                                          randomize_seed=True, api_name="/generation_all")
        hecho = r[1] if isinstance(r, (list, tuple)) and len(r) > 1 else r[0]
    except Exception:
        try:   # (sin la textura: gasta menos placa)
            r = _cliente(ESPACIO_3D).predict(caption=None, image=handle_file(imagen), steps=30, octree_resolution=256,
                                              randomize_seed=True, api_name="/shape_generation")
            hecho = r[0]
        except Exception as e:
            return "No pude hacer el modelo 3D: " + _explicar(e) + "."
    ruta = hecho.get("value", hecho) if isinstance(hecho, dict) else hecho
    if not ruta or not os.path.exists(str(ruta)):
        return "No pude hacer el modelo 3D: el servicio no devolvió el archivo."
    destino = _destino((descripcion or os.path.splitext(os.path.basename(imagen))[0]) + " 3D", os.path.splitext(ruta)[1] or ".glb")
    shutil.copy(ruta, destino)
    _abrir(destino)
    return ("Listo, acá está el modelo 3D (.glb): se abre con el Visor 3D de Windows o con Blender, y lo podés subir a "
            "cualquier lado. Está en documentos › Creado con IA.")


# ---------- Videos con IA (LTX-Video, gratis en Hugging Face) ----------

def video_ia(descripcion, imagen=None, segundos=3):
    jarvis.emitir("progreso", "Generando el video con IA (unos segundos de clip)...")
    try:
        prompt = jarvis.prompt_en_ingles(descripcion) if descripcion else "make this image come alive, cinematic motion"
    except Exception:
        prompt = descripcion or "cinematic motion"
    try:
        r = _cliente(ESPACIO_VIDEO).predict(prompt=prompt, mode="image-to-video" if imagen else "text-to-video",
                                            input_image_filepath=imagen, duration_ui=segundos, height_ui=512, width_ui=704,
                                            randomize_seed=True, api_name="/text_to_video")
    except Exception as e:
        return "No pude hacer el video: " + _explicar(e) + "."
    hecho = r[0] if isinstance(r, (list, tuple)) else r
    ruta = hecho.get("video", hecho) if isinstance(hecho, dict) else hecho
    if not ruta or not os.path.exists(str(ruta)):
        return "No pude hacer el video: el servicio no devolvió el archivo."
    destino = _destino((descripcion or "foto animada") + " video IA", ".mp4")
    shutil.copy(ruta, destino)
    _abrir(destino)
    return (f"Listo, acá está el video ({segundos} segundos). Si querés otro, pedímelo con más detalle: qué se mueve, "
            "cómo es la luz, desde dónde se ve. Está en documentos › Creado con IA.")


# ---------- Qué te pidieron ----------

def _lo_que_me_pasaste(tipo):
    """La foto (o el video) que adjuntaste hace poco: su ruta, y la saca de los pendientes."""
    adj = jarvis.adjuntos
    if tipo == "imagen" and adj.imagen_reciente():
        ruta = adj.imagen_reciente()["ruta"]
        adj.quitar(adj.imagen_reciente()["nombre"])
        return ruta
    if tipo == "video" and adj.video_activo and adj.video_activo.get("ruta"):
        ruta = adj.video_activo["ruta"]
        adj.quitar(adj.video_activo["nombre"])
        return ruta
    ultimo = jarvis.ultimo_archivo
    if ultimo.get("ruta") and time.time() - ultimo.get("cuando", 0) < 1800 and os.path.exists(ultimo["ruta"]):
        ext = os.path.splitext(ultimo["ruta"])[1].lower()
        if (tipo == "imagen" and ext in (".png", ".jpg", ".jpeg", ".webp")) or (tipo == "video" and ext in (".mp4", ".mov", ".webm", ".mkv")):
            return ultimo["ruta"]
    return None


def manejar(texto, t):
    """None si no es para esto."""
    t = t.strip(" ¿?¡!.,")
    if CONFIGURAR.match(t):
        return ("Para tener más ratito gratis de Hugging Face: entrá a huggingface.co/settings/tokens (con tu cuenta "
                "gratis, sin tarjeta), creá un token de solo lectura y decime «mi clave de Hugging Face es ...».")
    m = re.match(r"^mi (?:clave|token) de hugging ?face es\s+(\S+)$", texto.strip(), re.I)
    if m:
        try:
            import keyring

            keyring.set_password("JARVIS-HuggingFace", "clave", m.group(1))
            return "Listo, guardé tu clave de Hugging Face: los modelos 3D y los videos van a tener más tiempo gratis."
        except Exception as e:
            return f"No pude guardar la clave: {e}"
    if FONDO.search(t):
        video = _lo_que_me_pasaste("video") if re.search(r"\b(?:video|clip|grabacion)\b", t) else None
        foto = None if video else _lo_que_me_pasaste("imagen")
        if not (video or foto):
            return "Pasame la foto o el video (soltalo en la ventana o con el clip) y decime «sacale el fondo»."
        try:
            return quitar_fondo_video(video) if video else quitar_fondo_foto(foto)
        except Exception as e:
            return f"No pude sacarle el fondo: {e}"
    if TRES_D.search(t) and HACER.search(t):
        foto = _lo_que_me_pasaste("imagen") if re.search(r"\b(?:foto|imagen|esta|esto|eso)\b", t) else None
        sobre = SOBRE.search(re.sub(r"\b(?:un|una)?\s*(?:modelo|objeto|figura|archivo)?\s*(?:en\s+)?3 ?d\b", "", t))
        descripcion = (sobre.group(1).strip() if sobre else "") or None
        if not foto and not descripcion:
            return "¿De qué hago el modelo 3D? Decime qué objeto («un dragón», «una taza») o pasame una foto."
        return modelo_3d(descripcion, foto)
    if VIDEO_IA.search(t):
        foto = _lo_que_me_pasaste("imagen") if re.search(r"\b(?:foto|imagen|esta|esa)\b", t) else None
        sobre = SOBRE.search(VIDEO_IA.sub("", t))
        descripcion = (sobre.group(1).strip() if sobre else "") or None
        if not foto and not descripcion:
            return "¿De qué hago el video? Contame qué pasa en la escena (o pasame una foto para animarla)."
        return video_ia(descripcion, foto)
    return None
