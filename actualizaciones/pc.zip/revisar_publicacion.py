"""Revisión antes de publicar JARVIS (en GitHub o donde sea).

Mira SOLO los archivos que se subirían (respeta .gitignore) y avisa si encuentra:
  - claves de APIs o contraseñas escritas,
  - mails, teléfonos o rutas de tu usuario de Windows,
  - nombres o números de TUS contactos y de tus recuerdos (los saca de tus propios datos, que no se publican),
  - archivos de datos personales que no estén ignorados.
Uso:  python revisar_publicacion.py      (sale con código 1 si hay algo para arreglar)
No cambia ni borra nada.
"""
import fnmatch
import json
import os
import re
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
EXT_TEXTO = {".py", ".js", ".html", ".css", ".json", ".md", ".txt", ".yml", ".yaml", ".ini", ".cfg", ".bat", ".ps1",
             ".toml", ".pyw"}
CLAVES = [
    (r"nvapi-[A-Za-z0-9_-]{20,}", "clave de NVIDIA"),
    (r"AIza[0-9A-Za-z_-]{30,}", "clave de Google (Gemini)"),
    (r"\bAQ\.[0-9A-Za-z_.-]{30,}", "clave nueva de Google (Gemini, «AQ.»)"),
    (r"gsk_[A-Za-z0-9]{20,}", "clave de Groq"),
    (r"\bsk-[A-Za-z0-9_-]{20,}", "clave tipo OpenAI"),
    (r"ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}", "token de GitHub"),
    (r"xox[abps]-[A-Za-z0-9-]{10,}", "token de Slack"),
    (r"-----BEGIN [A-Z ]*PRIVATE KEY-----", "clave privada"),
    # una variable que se llama clave/password/token con un valor largo y con números (no el NOMBRE con que se guarda)
    (r"(?i)(?<![A-Za-z_-])(?:password|contrase(?:ñ|n)a|clave|api_?key|token|secret)\s*[=:]\s*[\"'](?=[^\"']*\d)[A-Za-z0-9_\-+/=.]{12,}[\"']",
     "contraseña o clave escrita"),
]
EJEMPLOS_MAIL = re.compile(r"(?:juan|usuario|ejemplo|example|tu|nombre|mail)@|@(?:example|ejemplo|dominio)\.", re.I)


def ignorados():
    patrones = []
    try:
        with open(os.path.join(BASE, ".gitignore"), encoding="utf-8") as f:
            patrones = [l.strip() for l in f if l.strip() and not l.startswith("#")]
    except OSError:
        print("⚠ No hay .gitignore: se publicaría TODO (incluidos tus datos).")
    return patrones


def esta_ignorado(relativo, patrones):
    partes = relativo.replace("\\", "/").split("/")
    for p in patrones:
        if p.endswith("/"):
            if p.rstrip("/") in partes[:-1]:
                return True
        elif fnmatch.fnmatch(partes[-1], p) or fnmatch.fnmatch(relativo.replace("\\", "/"), p):
            return True
    return False


def archivos_a_publicar():
    try:  # si hay git, que decida git (es lo que de verdad se subiría)
        r = subprocess.run(["git", "-C", BASE, "ls-files", "--cached", "--others", "--exclude-standard"],
                           capture_output=True, text=True, timeout=20)
        if r.returncode == 0:
            return [l for l in r.stdout.splitlines() if l]
    except (OSError, subprocess.SubprocessError):
        pass
    patrones = ignorados()
    salida = []
    for raiz, carpetas, archivos in os.walk(BASE):
        carpetas[:] = [c for c in carpetas if c != ".git" and not esta_ignorado(os.path.relpath(os.path.join(raiz, c), BASE) + "/x", patrones)]
        for a in archivos:
            rel = os.path.relpath(os.path.join(raiz, a), BASE)
            if not esta_ignorado(rel, patrones):
                salida.append(rel)
    return salida


def sin_tildes(texto):
    import unicodedata

    return "".join(c for c in unicodedata.normalize("NFD", texto) if unicodedata.category(c) != "Mn")


def palabras_del_codigo():
    """Cuántas veces aparece cada palabra en minúscula (sin tildes) en el código de JARVIS: las palabras comunes."""
    import collections

    cuenta = collections.Counter()
    for raiz, carpetas, archivos in os.walk(BASE):
        carpetas[:] = [c for c in carpetas if not c.startswith(".") and c not in ("node_modules", "__pycache__")]
        for a in archivos:
            if a.endswith((".py", ".js", ".gs")) and a != os.path.basename(__file__):
                try:
                    with open(os.path.join(raiz, a), encoding="utf-8", errors="replace") as f:
                        cuenta.update(sin_tildes(w) for w in re.findall(r"\b[a-záéíóúñ]{3,}\b", f.read()))
                except OSError:
                    pass
    return cuenta


def datos_personales():
    """Nombres y números que NO tienen que aparecer en el código (salen de tus contactos y recuerdos)."""
    buscar = set()
    try:
        with open(os.path.join(BASE, "contactos.json"), encoding="utf-8") as f:
            for nombre, d in json.load(f).items():
                buscar.add(nombre)
                for v in (d or {}).values():
                    if isinstance(v, str) and len(v) >= 6:
                        buscar.add(v)
    except (OSError, ValueError):
        pass
    try:
        with open(os.path.join(BASE, "recuerdos.json"), encoding="utf-8") as f:
            de_recuerdos = set()
            for r in json.load(f).get("recuerdos", []):
                # nombres propios dentro de los recuerdos ("Ruth", "Aza", "Salto"...)
                de_recuerdos.update(w for w in re.findall(r"(?<!^)(?<![.!?] )\b[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}", r["texto"]))
        # pero con los recuerdos automáticos entran palabras comunes con mayúscula («Estudio», «Socrático»): si el
        # código ya la usa en minúscula como palabra común, no es un nombre tuyo (un nombre como «ruth» no aparece así)
        comunes_codigo = palabras_del_codigo()
        buscar.update(w for w in de_recuerdos if not comunes_codigo.get(sin_tildes(w.lower())))
    except (OSError, ValueError, KeyError):
        pass
    usuario = os.environ.get("USERNAME", "")
    if len(usuario) >= 3:
        buscar.add(f"Users\\{usuario}")
        buscar.add(f"Users/{usuario}")
    # (Montevideo: la zona horaria y los ejemplos; Rusty: el usuario de GitHub donde ya está publicada la app)
    # (Socrático y Solucionador: los modos de estudio de JARVIS, que los recuerdos automáticos anotan con mayúscula)
    comunes = {"Mi", "Me", "El", "La", "Que", "Gemma", "Windows", "Google", "JARVIS", "Salud", "Montevideo", "Rusty",
               "Socrático", "Solucionador"}
    return {b for b in buscar if b not in comunes and len(b) >= 3}


def main(carpeta=None):
    """carpeta: revisar otra carpeta entera (el pendrive de «Llevar JARVIS a otra PC»); los datos tuyos que no tienen
    que aparecer se siguen sacando de esta (tus contactos y recuerdos)."""
    sys.stdout.reconfigure(errors="replace")  # redirigido a un archivo, la consola de Windows no tiene el ✓
    raiz_revisar = os.path.abspath(carpeta) if carpeta else BASE
    if carpeta:
        archivos = [os.path.relpath(os.path.join(r, a), raiz_revisar) for r, _, fs in os.walk(raiz_revisar) for a in fs]
    else:
        archivos = archivos_a_publicar()
    personales = datos_personales()
    problemas = []
    sospechosos = {"historial.json", "recuerdos.json", "contactos.json", "control.json", "pendientes.json", "dictado.json", "organizador.json",
                   "recordatorios.json", "examenes.json", "ajustes.json", "programas.json", "rutinas.json",
                   "consejos.json"}
    for rel in archivos:
        nombre = os.path.basename(rel)
        if nombre in sospechosos or rel.endswith(".log"):
            problemas.append((rel, 0, "archivo de datos personales que se publicaría (falta en .gitignore)"))
            continue
        if os.path.splitext(rel)[1].lower() not in EXT_TEXTO or nombre == os.path.basename(__file__):
            continue
        try:
            with open(os.path.join(raiz_revisar, rel), encoding="utf-8", errors="replace") as f:
                lineas = f.read().splitlines()
        except OSError:
            continue
        for n, linea in enumerate(lineas, 1):
            for patron, que in CLAVES:
                if re.search(patron, linea):
                    problemas.append((rel, n, que))
            for mail in re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,}", linea):
                if not EJEMPLOS_MAIL.search(mail) and not mail.endswith(("@anthropic.com", "@users.noreply.github.com")):
                    problemas.append((rel, n, f"mail: {mail}"))
            if re.search(r"\b598\d{8}\b", linea):
                problemas.append((rel, n, "teléfono"))
            for dato in personales:
                if re.search(rf"(?<![A-Za-z]){re.escape(dato)}(?![A-Za-z])", linea):
                    problemas.append((rel, n, f"dato tuyo: «{dato}»"))
    print(f"Revisé {len(archivos)} archivos que se publicarían.")
    if not problemas:
        print("✓ No encontré claves ni datos personales. Listo para publicar.")
        return 0
    print(f"✗ Encontré {len(problemas)} cosas para revisar antes de publicar:")
    for rel, n, que in problemas:
        print(f"  - {rel}" + (f":{n}" if n else "") + f"  →  {que}")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else None))
