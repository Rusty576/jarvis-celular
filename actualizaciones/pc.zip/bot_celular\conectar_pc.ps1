﻿# ============================================================
#  Conectar ESTA PC con el JARVIS del celular de su dueño (el que le armaste con «JARVIS para otra persona»)
# ------------------------------------------------------------
#  Lo usa el instalador de JARVIS que llevás en un pendrive (instalar_jarvis_pc.ps1), en la PC de esa persona:
#   1. entra con SU cuenta de Google (clasp) y encuentra su proyecto «JARVIS» (o usa el que viene anotado);
#   2. le sube el código de esta carpeta con una clave nueva de un solo uso (Instalacion.gs) y lo publica en la MISMA
#      dirección (la app de su celular sigue conectada);
#   3. con esa clave, el bot anota la clave de esta PC (vincular_pc) y deja de estar «sin PC»;
#   4. la dirección y la clave de esta PC quedan en el Administrador de credenciales de Windows (como en tu PC).
#  El permiso sobre su cuenta se borra al terminar.
# ============================================================
param(
    [Parameter(Mandatory = $true)][string]$Python,   # el python.exe de JARVIS en esta PC (para guardar la clave con keyring)
    [string]$Script = "",                            # su proyecto, si vino anotado en el pendrive (si no, se busca)
    [string]$Implementacion = ""                     # lo que va en /macros/s/<esto>/exec
)
$ErrorActionPreference = "Stop"

$AQUI = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $AQUI "clasp_comun.ps1")
$CODIGO = Join-Path $AQUI "Codigo.gs"
$OBRA = Join-Path $env:TEMP ("jarvis_conectar_" + [guid]::NewGuid().ToString("N").Substring(0, 8))
$PROYECTO = Join-Path $OBRA "proyecto"
$AUTH = Join-Path $OBRA ".clasprc.json"   # (fuera de la carpeta del proyecto: el permiso nunca se sube)

$fuente = [IO.File]::ReadAllText($CODIGO)
if ($fuente -notmatch 'const VERSION = "([\d.]+)"') { throw "No encontré VERSION en $CODIGO" }
$version = $Matches[1]
$script:deQuien = "tu cuenta"

function Clave-Nueva {
    $b = New-Object byte[] 24
    [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
    return -join ($b | ForEach-Object { $_.ToString("x2") })
}

function Json-De($texto, $abre, $cierra) {
    # lo que imprime clasp con --json (a veces con algún renglón antes): el JSON de adentro
    $i = $texto.IndexOf($abre); $j = $texto.LastIndexOf($cierra)
    if ($i -lt 0 -or $j -le $i) { return $null }
    try { return ($texto.Substring($i, $j - $i + 1) | ConvertFrom-Json) } catch { return $null }
}

$ok = $false
$antes = Get-Location
try {
    Limpiar-Restos "jarvis_conectar_"
    $node = Carpeta-Node
    $env:Path = "$node;$env:Path"
    $script:CLASP = Instalar-Clasp $node
    New-Item -ItemType Directory -Force $PROYECTO | Out-Null
    Set-Location $PROYECTO

    Paso "1. Entrá con tu cuenta de Google (la misma del JARVIS de tu celular)"
    Dice "Es el permiso para que esta PC se conecte con tu JARVIS: se borra solo al terminar."
    Entrar-Cuenta

    if ($Script -notmatch '^[\w-]{20,}$') {
        Paso "2. Buscando tu JARVIS en tu cuenta"
        $s = Clasp-Con-API --json list-scripts
        Sin-API $s
        $proyectos = @(Json-De $s "[" "]" | Where-Object { $_.name -eq "JARVIS" })
        if (-not $proyectos.Count) { throw "No encontré un proyecto «JARVIS» en esta cuenta. ¿Es la cuenta de Google del JARVIS de tu celular?" }
        $Script = $proyectos[0].id
        if ($proyectos.Count -gt 1) { Ojo "Hay $($proyectos.Count) proyectos «JARVIS»: uso el primero." }
    }
    Escribir (Join-Path $PROYECTO ".clasp.json") (@{ scriptId = $Script } | ConvertTo-Json)

    if ($Implementacion -notmatch '^AKfyc[\w-]{20,}$') {
        # la publicación de JARVIS (la que usa la app de su celular): la de número más alto con «JARVIS» en la descripción
        $s = Clasp-Con-API --json list-deployments $Script
        Sin-API $s
        $publicadas = @(Json-De $s "[" "]" | Where-Object { $_.versionNumber -and "$($_.description)" -match '^JARVIS' } |
                        Sort-Object { [int]$_.versionNumber } -Descending)
        if (-not $publicadas.Count) { throw "Tu JARVIS no tiene una publicación: volvé a correr «JARVIS para otra persona» desde la otra PC." }
        $Implementacion = $publicadas[0].deploymentId
    }
    $URL = "https://script.google.com/macros/s/$Implementacion/exec"

    Paso "3. Poniéndole el código de esta PC (versión $version), en la misma dirección"
    $s = Clasp-Con-API pull
    if ($script:codigoClasp -ne 0) { Sin-API $s; throw "No pude bajar tu proyecto:`n$s" }
    $bot = @(Get-ChildItem $PROYECTO -File -Recurse -Include *.js, *.gs | Where-Object {
        $t = [IO.File]::ReadAllText($_.FullName)
        ($t -match 'const VERSION = "') -and ($t -match 'function doPost\(')
    })
    if ($bot.Count -ne 1) { throw "No encontré el código del bot en tu proyecto." }
    Escribir $bot[0].FullName $fuente
    $clave = Clave-Nueva   # (la de un solo uso: prueba que esta PC entró con tu cuenta)
    Get-ChildItem $PROYECTO -File -Recurse -Include Instalacion.js, Instalacion.gs | Remove-Item
    Escribir (Join-Path $PROYECTO "Instalacion.gs") ("// Lo puso la PC (instalador de JARVIS): con esta clave se conectó la PC.`n" +
                                                     "const CLAVE_INSTALACION = `"$clave`";`n")
    $manifiesto = Join-Path $PROYECTO "appsscript.json"
    $m = Get-Content $manifiesto -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $m.webapp) {
        $m | Add-Member -NotePropertyName webapp -NotePropertyValue ([ordered]@{ executeAs = "USER_DEPLOYING"; access = "ANYONE_ANONYMOUS" })
    }
    Agregar-Servicios $m
    Escribir $manifiesto ($m | ConvertTo-Json -Depth 20)
    $s = Clasp-Con-API push --force
    if ($script:codigoClasp -ne 0) { Sin-API $s; throw "No pude subir el código:`n$s" }
    $s = Clasp-Con-API create-deployment --deploymentId $Implementacion --description "JARVIS $version"
    if ($script:codigoClasp -ne 0) { Sin-API $s; throw "No pude publicarlo:`n$s" }

    Paso "4. Esperando que tu JARVIS conteste con la versión nueva"
    $desde = Get-Date
    while ($true) {
        $e = Estado-Bot $URL
        if ($e -and $e -isnot [string] -and $e.version -eq $version) { break }
        if (((Get-Date) - $desde).TotalMinutes -gt 10) { throw "Tu JARVIS todavía no contesta con la versión nueva. Probá de nuevo en un rato." }
        Start-Sleep -Seconds 4
    }
    Revisar-Permisos $URL "tu cuenta (la del JARVIS de tu celular)" | Out-Null

    Paso "5. Conectando esta PC con tu JARVIS"
    $clavePc = Clave-Nueva
    $cuerpo = [ordered]@{ accion = "vincular_pc"; clave = $clave; clave_pc = $clavePc;
                          zona_min = [int][TimeZoneInfo]::Local.GetUtcOffset((Get-Date)).TotalMinutes } | ConvertTo-Json
    $r = Invoke-RestMethod $URL -Method Post -ContentType "application/json" -TimeoutSec 90 -Body ([Text.Encoding]::UTF8.GetBytes($cuerpo))
    if (-not $r.ok) { throw "Tu JARVIS no aceptó la conexión: $($r.error)" }
    # (la dirección y la clave de esta PC, en el Administrador de credenciales de Windows: como en la PC de quien lo armó)
    $ErrorActionPreference = "Continue"
    & $Python -c "import keyring, sys; keyring.set_password('JARVIS-Celular', 'url', sys.argv[1]); keyring.set_password('JARVIS-Celular', 'clave_pc', sys.argv[2])" $URL $clavePc 2>&1 | Out-Host
    $codigo = $LASTEXITCODE
    $ErrorActionPreference = "Stop"
    if ($codigo -ne 0) { throw "No pude guardar la conexión en esta PC (keyring)." }
    $ok = $true
    Paso "Listo: esta PC quedó conectada con tu JARVIS del celular"
    Dice "Lo que le pasás a la PC desde el celular, tus pendientes, finanzas, memoria y estudio, ahora van y vienen solos."
} catch {
    Write-Host ""
    Ojo "No pude terminar de conectar: $($_.Exception.Message)"
} finally {
    Set-Location $antes
    Soltar-Permiso
    Remove-Item $OBRA -Recurse -Force -ErrorAction SilentlyContinue
}
if (-not $ok) { exit 1 }
